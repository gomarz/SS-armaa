package data.scripts.weapons;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.util.Misc;
;
import org.lwjgl.util.vector.Vector2f;
import java.util.*; 
import java.util.List;
import com.fs.starfarer.api.combat.CombatUIAPI;
import java.awt.Color;
import data.scripts.util.MagicIncompatibleHullmods;
import java.util.Collection;
import com.fs.starfarer.api.combat.BaseCombatLayeredRenderingPlugin;

public class armaa_bitWeaponAssignment2 implements EveryFrameWeaponEffectPlugin {
	
	private boolean isWeaponSwapped = false;
	
		public boolean isBattling()
		{
			boolean check = false;
			CombatEngineAPI engine = Global.getCombatEngine();
			CombatUIAPI ui = engine.getCombatUI();
			
			if(ui != null)
			{
				check = true;
			}
			
			return check;
		}
		
    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) 
		{
			ShipAPI parent = weapon.getShip().getParentStation();
			ShipAPI ship = weapon.getShip();
			//CombatEngineAPI engine = Global.getCombatEngine();
			List<WeaponAPI> weapons = ship.getAllWeapons();				

			//Refit screen check
			if(ship.getOriginalOwner() == -1 || engine.isCombatOver() || engine.isPaused())
			{
				// don't render the weapons
				for(WeaponAPI w: weapons)
				{
					w.getSprite().setColor(new Color(255,255,255,0));
					if(w.getBarrelSpriteAPI() != null)
					w.getBarrelSpriteAPI().setColor(new Color(255,255,255,0));
				}
			
				//set the module to frigate hull size
				ship.setHullSize(HullSize.FRIGATE);
				Collection<String>hmods = ship.getVariant().getHullMods();
						List<String> mhmod = new ArrayList<>();
						mhmod.addAll(hmods);

				if(!mhmod.isEmpty())
					for(int i = 0; i < mhmod.size();i++)
					{
						if(ship.getVariant().hasHullMod(mhmod.get(i)))
						{
							ship.getVariant().removeMod(mhmod.get(i));
						}
					}

			}

			else if(isBattling())
			{
				ship.getSpriteAPI().setColor(new Color(255,255,255,0));
				ship.setCollisionClass(CollisionClass.NONE);
				ship.setHullSize(HullSize.FIGHTER);
				
				for(WeaponAPI w: weapons)
				{
					w.getSprite().setColor(new Color(255,255,255,0));
					if(w.getBarrelSpriteAPI() != null)
					w.getBarrelSpriteAPI().setColor(new Color(255,255,255,0));
					w.disable(true);
				}
				
			}

			if(parent != null && ship.isAlive() && !isWeaponSwapped)
			{
				//CombatEngineAPI engine = Global.getCombatEngine();
				List<FighterWingAPI> wings = parent.getAllWings();
			
				for(FighterWingAPI wing : wings)
				{
					if(wing == null || wing.getWingMembers() == null || wing.getWingMembers().isEmpty())
						continue;
					
					ShipAPI fighter = wing.getLeader();
					if(fighter == null)
						continue;
					
					for(int i = 0; i < wing.getWingMembers().size();i++)
					{
						fighter = wing.getWingMembers().get(i);
						if(fighter == null)
							continue;
						if(fighter.getAllWeapons().isEmpty())
							continue;
						if(!wing.getWingId().equals("armaa_bit_wing"))
						{
							continue;
						}
						MutableShipStatsAPI stats = fighter.getMutableStats();
						ShipVariantAPI OGVariant = stats.getVariant().clone();
						ShipVariantAPI newVariant = stats.getVariant().clone();

						String str = (String) Global.getCombatEngine().getCustomData().get("armaa_modularDroneWeaponId"+ship.getId());
						if(str == null) 
							str = "No weapon";
						if(engine.getPlayerShip() == parent)
						Global.getCombatEngine().maintainStatusForPlayerShip("AceSystem444", "graphics/ui/icons/icon_repair_refit.png","Drone Weapon", str + " installed. ",true);
						if(!fighter.getAllWeapons().get(0).getId().equals(str))
						{
							if(ship.getVariant().getWeaponSpec("WS0001") != null)
							{
								Global.getCombatEngine().getCustomData().put("armaa_modularDroneWeaponId"+ship.getId(),ship.getVariant().getWeaponId("WS0001"));
								//stats.getVariant().setOriginalVariant(null);
								fighter.getFleetMember().setVariant(newVariant,true,true);
							
								stats.getVariant().clearSlot("WS0001");								
								stats.getVariant().addWeapon("WS0001",ship.getVariant().getWeaponId("WS0001"));
								stats.getVariant().getWeaponSpec("WS0001").addTag("FIRE_WHEN_INEFFICIENT");
							}
							
							//isWeaponSwapped = true;
							wing.orderReturn(fighter);
							ship.getMutableStats().getHullDamageTakenMult().modifyMult("invincible",0f);
							ship.getMutableStats().getArmorDamageTakenMult().modifyMult("invincible",0f);
							ship.setHullSize(HullSize.FIGHTER);
							ship.setCollisionClass(CollisionClass.NONE);
							//ship.setHitpoints(0);
							//Global.getCombatEngine().removeEntity(ship);
							//fighter.getFleetMember().setVariant(OGVariant,true,true);
						}
					}//
						
				}
			}
		}
}

