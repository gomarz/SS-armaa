package data.scripts.campaign;

import java.util.Iterator;
import java.util.List;
import data.hullmods.armaa_weaponSwap;
import data.hullmods.armaa_leynosWeaponSwap;
import com.fs.starfarer.api.campaign.listeners.ShowLootListener;
import com.fs.starfarer.api.campaign.*;
import com.fs.starfarer.api.Global;

public class armaa_lootCleaner implements ShowLootListener
{
	@Override
	public void reportAboutToShowLootToPlayer(CargoAPI loot, InteractionDialogAPI dialog) 
	{
		
		armaa_weaponSwap a = new armaa_weaponSwap();
		armaa_leynosWeaponSwap b = new armaa_leynosWeaponSwap();
		for (CargoStackAPI s : loot.getStacksCopy())
		{
			if(s.isWeaponStack() && (a.LEFT_SELECTOR.containsValue(s.getWeaponSpecIfWeapon().getWeaponId()) || a.RIGHT_SELECTOR.containsValue(s.getWeaponSpecIfWeapon().getWeaponId())))
			{
				loot.removeStack(s);
			}

			if(s.isWeaponStack() && (b.LEFT_SELECTOR.containsValue(s.getWeaponSpecIfWeapon().getWeaponId()) || b.RIGHT_SELECTOR.containsValue(s.getWeaponSpecIfWeapon().getWeaponId())))
			{
				loot.removeStack(s);
			}
		}
		CargoAPI inventory = Global.getSector().getPlayerFleet().getCargo();
		for (CargoStackAPI s : Global.getSector().getPlayerFleet().getCargo().getStacksCopy())
		{
			if(s.isWeaponStack() && (a.LEFT_SELECTOR.containsValue(s.getWeaponSpecIfWeapon().getWeaponId()) || a.RIGHT_SELECTOR.containsValue(s.getWeaponSpecIfWeapon().getWeaponId())))
			{
				inventory.removeStack(s);
			}

			if(s.isWeaponStack() && (b.LEFT_SELECTOR.containsValue(s.getWeaponSpecIfWeapon().getWeaponId()) || b.RIGHT_SELECTOR.containsValue(s.getWeaponSpecIfWeapon().getWeaponId())))
			{
				inventory.removeStack(s);
			}
		}
		
	}	
}
