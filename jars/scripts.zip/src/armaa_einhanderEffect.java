package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.graphics.SpriteAPI;
import data.scripts.util.MagicAnim;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.util.Misc;

/**
 * This is a heavily modified script using
 * @author Tartiflette
 * 's work as a basis
 */
public class armaa_einhanderEffect implements EveryFrameWeaponEffectPlugin {

    private boolean runOnce = false, lockNloaded = false;
    private ShipSystemAPI system;
    private ShipAPI ship;
    private SpriteAPI sprite;
    private AnimationAPI anim, aGlow, aGlow2;
    private WeaponAPI head, armL, armR, pauldronL, pauldronR, torso, cannon;

    //sliver cannon charging fx
    private boolean charging = false;
    private boolean cooling = false;
    private boolean firing = false;
    private final IntervalUtil interval = new IntervalUtil(0.015f, 0.015f);
    private final IntervalUtil interval2 = new IntervalUtil(0.075f, 0.075f);
    private float level = 0f;

    private float glowLevel = 1, PUMP_ACTION=3, RECOIL=3;
    private int glowEffect = 0;
    float eyeG = 0.0f; //eye glow
    private static final Vector2f ZERO = new Vector2f();

    private SpriteAPI HAND, SHOULDER;
    private float HAND_WIDTH, HAND_HEIGHT;
    private float CHARGEUP_PARTICLE_ANGLE_SPREAD = 360f;
    private float CHARGEUP_PARTICLE_BRIGHTNESS = 0.5f;
    private float CHARGEUP_PARTICLE_DISTANCE_MAX = 300f;
    private float CHARGEUP_PARTICLE_DISTANCE_MIN = 200f;
    private float CHARGEUP_PARTICLE_DURATION = 0.35f;
    private float CHARGEUP_PARTICLE_SIZE_MAX = 2f;
    private float CHARGEUP_PARTICLE_SIZE_MIN = 1f;
    public float TURRET_OFFSET = 30f;
    private int limbInit = 0; // used to make sure all limbs are accounted for

    private float overlap = 0;
    private final float TORSO_OFFSET = -45, LEFT_ARM_OFFSET = -75, RIGHT_ARM_OFFSET = -25, MAX_OVERLAP = 10;

    public void init()
    {
        runOnce = true;

        for (WeaponAPI w : ship.getAllWeapons()) {
            switch (w.getSlot().getId()) {
                case "B_TORSO":
                    if(torso==null) {
                        torso = w;
                        limbInit++;
                    }
                    break;
                case "C_ARML":
                    if(armL==null) {
                        armL = w;
			HAND = w.getSprite();
			HAND_WIDTH=HAND.getWidth()/2;
			HAND_HEIGHT = HAND.getHeight()/2;
                        limbInit++;
                    }
                    break;
                case "C_ARMR":
                    if(armR==null) {
                        armR = w;
                        limbInit++;
                    }
                    break;
                case "D_PAULDRONL":
                    if(pauldronL == null) {
                        pauldronL = w;
                        limbInit++;
                    }
                    break;
                case "D_PAULDRONR":
                    if(pauldronR == null) {
                        pauldronR = w;
			SHOULDER = w.getSprite();
                        limbInit++;
                    }
                    break;
                case "E_HEAD":
                    if(head == null) {
                        head = w;
                        limbInit++;
                    }
                    break;

                case "WS0001":
                    if(cannon == null) {
                        cannon = w;
                        limbInit++;
                    }
                    break;

            }
        }

    }
    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) {

        ship = weapon.getShip();
        sprite = ship.getSpriteAPI();
        system = ship.getSystem();
        anim = weapon.getAnimation();
        init();


        if(!runOnce || limbInit != 7)
        {
           return;
        }

            if (ship.getEngineController().isAccelerating()) {
                if (overlap > (MAX_OVERLAP - 0.1f)) {
                    overlap = MAX_OVERLAP;
                } else {
                    overlap = Math.min(MAX_OVERLAP, overlap + ((MAX_OVERLAP - overlap) * amount * 5));
                }
            } else if (ship.getEngineController().isDecelerating() || ship.getEngineController().isAcceleratingBackwards()) {
                if (overlap < -(MAX_OVERLAP - 0.1f)) {
                    overlap = -MAX_OVERLAP;
                } else {
                    overlap = Math.max(-MAX_OVERLAP, overlap + ((-MAX_OVERLAP + overlap) * amount * 5));
                }
            } else {
                if (Math.abs(overlap) < 0.1f) {
                    overlap = 0;
                } else {
                    overlap -= (overlap / 2) * amount * 3;
                }
            }

            float sineA = 0, sinceB = 0;
            SHOULDER.setCenterY(weapon.getBarrelSpriteAPI().getCenterY()-23f);
            if (system.isActive()) 
			{
				if(weapon.getChargeLevel() > 0 && system.getEffectLevel() == 1)
				{
					HAND.setCenterY(weapon.getBarrelSpriteAPI().getCenterY()-15f);
				}

                if (system.getEffectLevel() < 1) {
                    if (!lockNloaded) {
                        lockNloaded = true;
                       // aGlow.setFrame(1);
                    }
                    sineA = MagicAnim.SO(system.getEffectLevel(), 0, 0.7f);
                    sinceB = MagicAnim.SO(system.getEffectLevel(), 0.3f, 1f);
                } else {
                    sineA = 1;
                    sinceB = 1;
                }
            } else if (lockNloaded) {
                lockNloaded = false;

            }

            float global = ship.getFacing();
            float aim = MathUtils.getShortestRotation(global, weapon.getCurrAngle());

            if (torso != null)
	    {
                torso.setCurrAngle(global + sineA * TORSO_OFFSET + aim * 0.3f);
		
	    }

            if (armR != null)
	    {
                armR.setCurrAngle(weapon.getCurrAngle() + RIGHT_ARM_OFFSET);
	    }

            if (pauldronR != null)
            {
                pauldronR.setCurrAngle(global + sineA * TORSO_OFFSET * 0.5f + aim * 0.75f + RIGHT_ARM_OFFSET * 0.5f);
	    }
	    
	    if(ship.getHitpoints()/ship.getMaxHitpoints() <= .50)
            ship.syncWeaponDecalsWithArmorDamage();

            Vector2f origin = new Vector2f(weapon.getLocation());
            Vector2f offset = new Vector2f(TURRET_OFFSET, -15f);
            VectorUtils.rotate(offset, weapon.getCurrAngle(), offset);
            Vector2f.add(offset, origin, origin);
            float shipFacing = weapon.getCurrAngle();
            Vector2f shipVelocity = ship.getVelocity();
            if (armL != null) {
                armL.setCurrAngle(
                        global
                                +
                                ((aim + LEFT_ARM_OFFSET) * sinceB)
                                +
                                ((overlap + aim * 0.25f) * (1 - sinceB))
                );
            }

            if (pauldronL != null)
                pauldronL.setCurrAngle(torso.getCurrAngle() + MathUtils.getShortestRotation(torso.getCurrAngle(), armL.getCurrAngle()) * 0.6f);
			
			if(weapon.isFiring() && weapon.getChargeLevel() > 0f)
			{
			   float radius = 20f + (weapon.getChargeLevel() * weapon.getChargeLevel()* MathUtils.getRandomNumberInRange(25f, 75f));
			   Color color = new Color(200, 55, 200, 200);

				 engine.addHitParticle(origin, ZERO, (radius)-10, 0.1f + weapon.getChargeLevel() * 0.3f, 0.2f, color);
				 engine.addHitParticle(origin, ZERO, (radius/2)-10, 0.1f + weapon.getChargeLevel() * 0.3f, 0.2f, new Color(255,255,255,255));
			}

            if (charging) {
                if (firing && (weapon.getChargeLevel() < 1f)) {
                    charging = false;
                    cooling = true;
                    firing = false;
                } else if (weapon.getChargeLevel() < 1f) {
                    interval.advance(amount);
                    if (interval.intervalElapsed()) {
                        float radius = 20f + (weapon.getChargeLevel() * weapon.getChargeLevel()
                                * MathUtils.getRandomNumberInRange(25f, 75f));
                        Color color = new Color(200, 55, 200, 200);
                        engine.addHitParticle(origin, ZERO, radius, 0.1f + weapon.getChargeLevel() * 0.3f, 0.2f, color);
						engine.addHitParticle(origin, ZERO, radius/2, 0.1f + weapon.getChargeLevel() * 0.3f, 0.2f, new Color(255,255,255,255));

                        int count = 10 + (int) (weapon.getChargeLevel() * 25);
                        for (int i = 0; i < count; i++) {
                            float distance = MathUtils.getRandomNumberInRange(CHARGEUP_PARTICLE_DISTANCE_MIN,
                                    CHARGEUP_PARTICLE_DISTANCE_MAX)
                                    * weapon.getChargeLevel();
                            float size = MathUtils.getRandomNumberInRange(CHARGEUP_PARTICLE_SIZE_MIN, CHARGEUP_PARTICLE_SIZE_MAX);
                            float angle = MathUtils.getRandomNumberInRange(-0.5f * CHARGEUP_PARTICLE_ANGLE_SPREAD, 0.5f
                                    * CHARGEUP_PARTICLE_ANGLE_SPREAD);
                            float speed = 0.75f * distance / CHARGEUP_PARTICLE_DURATION;
                            Vector2f particleVelocity = MathUtils.getPointOnCircumference(shipVelocity, speed, angle + shipFacing
                                    + 180f);
                            engine.addHitParticle(origin, particleVelocity, size, CHARGEUP_PARTICLE_BRIGHTNESS * Math.min(
                                    weapon.getChargeLevel() + 0.5f, 1f)
                                            * MathUtils.getRandomNumberInRange(0.75f, 1.25f), CHARGEUP_PARTICLE_DURATION,
                                    color);
                        }
                    }
                } else {
                    firing = true;
                }
            } else {
                if (cooling) {
                    if (weapon.getChargeLevel() <= 0f) {
                        cooling = false;
                    }
                } else if (weapon.getChargeLevel() > level) {
                    charging = true;
                }
            }
            level = weapon.getChargeLevel();
        }
    }

