package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.input.InputEventAPI;
import java.util.ArrayList;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.util.List;
import java.util.Collections;
import com.fs.starfarer.api.combat.CombatFleetManagerAPI.*;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.CollisionUtils;
import org.lwjgl.util.vector.Vector2f;
import data.scripts.util.MagicRender;
import java.awt.Color;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.util.IntervalUtil;


//import org.lazywizard.console.commands.ToggleAI;

//this script manages things that otherwise wouldn't be possible via hullmod; primarily ensuring fake fighters being only ship left on field doesnt end combat 
//and ensuring its always selectable in UI
public class armaa_EinhanderHaxPlugin extends BaseEveryFrameCombatPlugin
{
    protected CombatEngineAPI engine;
	protected List<ShipAPI> cataphrachtii = new ArrayList<ShipAPI>();
	protected List<ShipAPI> toRemove = new ArrayList<ShipAPI>();
	protected CombatTaskManagerAPI ctm;
	protected CombatFleetManagerAPI cfm;
	protected CombatUIAPI ui;
	private String origPersonality = "steady";
	boolean canEnd = false;
	private IntervalUtil interval = new IntervalUtil(.025f, .05f);
	
    @Override
    public void advance(float amount, List<InputEventAPI> events)
    {
		if(engine == null)
			return;
			
		cfm = engine.getFleetManager(FleetSide.PLAYER);
		ctm = cfm.getTaskManager(false);
		ui = engine.getCombatUI();
		
		interval.advance(amount);
		if(interval.intervalElapsed())
		{
			for (MissileAPI missile : engine.getMissiles())
			{
				if(missile.getWeapon() != null)
				{
					if(!missile.getWeapon().getId().equals("armaa_sprigganTorso"))
						continue;
						if(missile.isFizzling() || missile.isFading())
						{
							if(MagicRender.screenCheck(0.25f, missile.getLocation())){
								engine.addSmoothParticle(missile.getLocation(), new Vector2f(), 50, 0.5f, 0.15f, Color.blue);
								engine.addHitParticle(missile.getLocation(), new Vector2f(), 50, 1f, 0.25f, new Color(250,192,250,255));
							}
							engine.removeEntity(missile);
							return;
						}
					}
				}

			for (ShipAPI ship : engine.getShips())
			{
				if(!ship.isFighter())
					continue;
				if(ship.getHullSpec().getBuiltInMods().contains("strikeCraft") || ship.getVariant().getHullMods().contains("strikeCraft"))
				{
					if(!cataphrachtii.contains(ship))
					{
						cataphrachtii.add(ship);
					}
				}
			}
		}
		
		if(cataphrachtii.isEmpty() || engine.isEnemyInFullRetreat() || engine.isCombatOver() || engine.getFleetManager(0).getTaskManager(false).isInFullRetreat())
		{
			engine.setDoNotEndCombat(false);
			canEnd = true;
			//Global.getCombatEngine().maintainStatusForPlayerShip("debug", "graphics/ui/icons/icon_repair_refit.png","Retreat OK" ,"" ,true);
		}
		
		if(cataphrachtii.isEmpty())
		{
			return;
		}

		if(!cataphrachtii.isEmpty())
		{
			if(!engine.isEnemyInFullRetreat() || !engine.getFleetManager(0).getTaskManager(false).isInFullRetreat())
			{
				if(!canEnd)
				engine.setDoNotEndCombat(true);
			}
			//engine.setDoNotEndCombat(true);
			for(ShipAPI mech : cataphrachtii)
			{
				if(mech.getShipAI() instanceof com.fs.starfarer.combat.ai.FighterAI || mech.getShipAI() == null && (mech != engine.getPlayerShip() || !Global.getCombatEngine().isUIAutopilotOn()))
				{
					mech.setHullSize(HullSize.FRIGATE);
					mech.resetDefaultAI();
				}
				
				if(ui != null)
				{
					if((ui.isShowingCommandUI()))
					{
						CombatFleetManagerAPI cfm = Global.getCombatEngine().getFleetManager(mech.getOwner()); 
						boolean isAlly = mech.isAlly() ? true : false;
						CombatTaskManagerAPI ctm = cfm.getTaskManager(isAlly);
						if(mech.getOwner() == 1 || mech.isAlly())
						{
							if(ctm.getAssignmentFor(mech) != null && ctm.getAssignmentFor(mech).getType() == CombatAssignmentType.SEARCH_AND_DESTROY) 
							{
								DeployedFleetMemberAPI dfm = cfm.getDeployedFleetMember(mech);
								ArrayList<ShipAPI> targets = new ArrayList<ShipAPI>(CombatUtils.getShipsWithinRange(mech.getLocation(), 4000.0F));
								Collections.shuffle(targets);
								if(!targets.isEmpty())
								{
									
									DeployedFleetMemberAPI defendee = cfm.getDeployedFleetMember(CombatUtils.getShipsWithinRange(mech.getLocation(), 4000.0F).get(0));
									CombatFleetManagerAPI.AssignmentInfo assign = ctm.createAssignment(CombatAssignmentType.DEFEND,defendee,false);	
								
									ctm.giveAssignment(dfm,assign,false);
								}
								
							}
						}
							
						else if(mech.getOwner() == 0 && !mech.getVariant().hasHullMod("armaa_strikeCraftFrig"))
						{
							if(ctm.getAssignmentFor(mech) != null)
								if(ctm.getAssignmentFor(mech).getType() == CombatAssignmentType.CAPTURE || 
									ctm.getAssignmentFor(mech).getType() == CombatAssignmentType.ASSAULT || 
									ctm.getAssignmentFor(mech).getType() == CombatAssignmentType.CONTROL)
								{
									if(mech.getHullSize() == HullSize.FRIGATE)
									{
										DeployedFleetMemberAPI dfm = cfm.getDeployedFleetMember(mech);
										Global.getCombatEngine().getCombatUI().addMessage(1,Global.getSettings().getColor("textFriendColor"),mech.getName(),Color.red, " is incapable of capturing objectives due to being a strikecraft.");
										Global.getSoundPlayer().playUISound("cr_allied_critical", 0.5f, 1f);
										ctm.orderSearchAndDestroy(dfm,false);
									}
								}
									
									
						}
						if(mech.getHullSize() != HullSize.FRIGATE && !mech.isFinishedLanding())						
							mech.setHullSize(HullSize.FRIGATE);
					}
				}
				
				if(mech == null || mech.isRetreating())
				{
					toRemove.add(mech);
				}
				// should no longer be needed, but leaving it here just in case
				if(mech.getHitpoints() <= 0f || mech.isHulk() || mech.getOwner() == 100)
				{
					toRemove.add(mech);
				}
			}
		}
			if(!toRemove.isEmpty())
			cataphrachtii.removeAll(toRemove);
	}

    @Override
    public void init(CombatEngineAPI engine)
    {
        this.engine = engine;
    }
}
