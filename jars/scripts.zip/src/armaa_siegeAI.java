// 
// Decompiled by Procyon v0.5.36
// 

package data.scripts.shipsystems.ai;

import com.fs.starfarer.api.combat.FluxTrackerAPI;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAIScript;
import com.fs.starfarer.api.combat.ShipCommand;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.util.ArrayList;
import com.fs.starfarer.api.Global;
import java.util.List;

public class armaa_siegeAI implements ShipSystemAIScript
{
    private ShipAPI ship;
    private CombatEngineAPI engine;
    private ShipwideAIFlags flags;
    private ShipSystemAPI system;
    private IntervalUtil tracker;
    
    public armaa_siegeAI() {
        this.tracker = new IntervalUtil(0.5f, 1.0f);
    }
    
    public void init(final ShipAPI ship, final ShipSystemAPI system, final ShipwideAIFlags flags, final CombatEngineAPI engine) {
        this.ship = ship;
        this.flags = flags;
        this.engine = engine;
        this.system = ship.getSystem();
    }
    
    public void advance(final float amount, final Vector2f missileDangerDir, final Vector2f collisionDangerDir, final ShipAPI target) {
        this.tracker.advance(amount);
        if (engine == null) {
            return;
        }
        if (engine.isPaused()) {
            return;
        }
        if (tracker.intervalElapsed()) {
            float dicision = 0.0f;
            if (flags.hasFlag(ShipwideAIFlags.AIFlags.PURSUING)) {
                dicision -= 3f;
            }
			if (flags.hasFlag(ShipwideAIFlags.AIFlags.MANEUVER_TARGET)) {
                dicision -= 1f;
            }
            if (!ship.areAnyEnemiesInRange()) {
                dicision -= 9999f;
            }
            if (flags.hasFlag(ShipwideAIFlags.AIFlags.BACKING_OFF)) {
                dicision -= 5f;
            }
            if (flags.hasFlag(ShipwideAIFlags.AIFlags.RUN_QUICKLY)) {
                dicision -= 5f;
            }
		
            if (flags.hasFlag(ShipwideAIFlags.AIFlags.NEEDS_HELP)) {
                dicision -= 2f;
            }
            if (flags.hasFlag(ShipwideAIFlags.AIFlags.HAS_INCOMING_DAMAGE)) {
                dicision+= 2f;
            }
			float bonus = 1.55f;
			
			for(WeaponAPI weapon: ship.getAllWeapons())
			{
				if(weapon.isDecorative())
					continue;
				if(system.isActive())
					bonus = 0f;
				List<ShipAPI> targets = CombatUtils.getShipsWithinRange(ship.getLocation(), weapon.getRange()*1.5f);
				for(ShipAPI neartarget: targets)
				{
					if(neartarget.getOwner() == ship.getOwner())
						continue;
					
					if(neartarget.isHulk() || neartarget.isFighter() || !neartarget.isAlive() || neartarget.isAlly())
						continue;
					
					if(neartarget.isDestroyer())
						dicision+=2	;
					
					if(neartarget.isCruiser())
						dicision+=2;
					if(neartarget.isCapital())
						dicision+=2;
					
					if(MathUtils.getDistance(neartarget,ship.getLocation()) <= 1000f)
						dicision-=3;
				}
				if(targets.isEmpty())
					dicision-= 5f;
			}
			
            final FluxTrackerAPI fluxTracker = ship.getFluxTracker();
			if(fluxTracker.getFluxLevel() >= .60f)
				dicision-=9999f;
            if (dicision >= 2f && !system.isActive()) 
			{
				ship.useSystem();
            }
            else if (dicision <= 1f && system.isActive()) {
                ship.useSystem();
            }
        }
    }
}