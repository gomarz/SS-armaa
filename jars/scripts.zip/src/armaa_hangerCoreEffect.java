package data.scripts.weapons;
import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.graphics.SpriteAPI;
import data.scripts.util.MagicAnim;
import data.scripts.util.MagicRender;
import data.scripts.util.MagicUI;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.Global;
import data.scripts.ai.armaa_hangar_drone_AI;
import com.fs.starfarer.api.combat.listeners.AdvanceableListener;
import com.fs.starfarer.api.combat.listeners.DamageTakenModifier;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.combat.listeners.DamageListener;
import com.fs.starfarer.api.combat.*;
import java.util.ArrayList;
import java.util.List;
import data.scripts.util.armaa_utils;



public class armaa_hangerCoreEffect implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin
{
    private List<ShipAPI> alreadyRegisteredBits = new ArrayList<ShipAPI>();


    public void init(ShipAPI ship)
    {

    }

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) 
	{
		
		List<ShipAPI> cloneList = new ArrayList<>(alreadyRegisteredBits);
		for (ShipAPI drone : cloneList) {
			if (!engine.isEntityInPlay(drone) || !drone.isAlive()) 
			{
				alreadyRegisteredBits.remove(drone);
			}
			
			else
			{
			        float shipRadius = armaa_utils.effectiveRadius(drone);

				float randRange = (float) shipRadius * 0.2f * 1f;
				float randSpeed = (float) shipRadius * 0.5f * 1f;
				float randAngle = MathUtils.getRandomNumberInRange(0f, 360f);
			float randRadiusFrac = (float) (Math.random() + Math.random());
			randRadiusFrac = (randRadiusFrac > 1f ? 2f - randRadiusFrac : randRadiusFrac);
			Vector2f randLoc = MathUtils.getPointOnCircumference(new Vector2f(), randRange * randRadiusFrac, randAngle);
				float currflux = weapon.getShip().getFluxTracker().getCurrFlux();
				if(!drone.getWeaponGroupFor(drone.getAllWeapons().get(0)).isAutofiring())
				drone.getWeaponGroupFor(drone.getAllWeapons().get(0)).toggleOn();
				weapon.getShip().getFluxTracker().setCurrFlux(currflux+Math.min(100*amount,drone.getAllWeapons().get(0).getFluxCostToFire()*amount ));
				drone.addAfterimage(Color.red, randLoc.x, randLoc.y, -drone.getVelocity().x, -drone.getVelocity().y,
					randRange, 0f, 0.1f, 0.7f * 1f, true, false, false);
				//armaa_utils.setLocation(drone, new Vector2f(weapon.getShip().getLocation().x-100,weapon.getShip().getLocation().y));
				if(weapon.getShip().getMouseTarget() != null)
				{
					//drone.setFacing(VectorUtils.getAngle(drone.getLocation(),weapon.getShip().getMouseTarget()));	
						armaa_hangar_drone_AI DockingAI = new armaa_hangar_drone_AI(drone,weapon.getShip(),weapon);
						if(drone.getShipAI() != DockingAI);
						{
							drone.setShipAI(DockingAI);
							DockingAI.init();
						}
				}
			}
		}		
		
    }

	public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) 
	{
		engine.getFleetManager(weapon.getShip().getOwner()).setSuppressDeploymentMessages(true); 
		ShipAPI bit = engine.getFleetManager(weapon.getShip().getOwner()).spawnShipOrWing("armaa_bit_valk_wing",projectile.getLocation(),-projectile.getFacing(),0f,weapon.getShip().getCaptain());
			//bit.cloneVariant();
			bit.getVariant().clearSlot("WS0001");								
			bit.getVariant().addWeapon("WS0001",weapon.getShip().getVariant().getWeaponId("WS0001"));
			bit.setHitpoints(0f);
		ShipAPI bit2  = engine.getFleetManager(weapon.getShip().getOwner()).spawnShipOrWing("armaa_bit_valk_wing",projectile.getLocation(),-projectile.getFacing(),0f,weapon.getShip().getCaptain());
			//bit2.cloneVariant
		if (!alreadyRegisteredBits.contains(bit2) && engine.isEntityInPlay(bit) && bit2.isAlive()) 
		{
			alreadyRegisteredBits.add(bit2);
		}
		engine.getFleetManager(weapon.getShip().getOwner()).setSuppressDeploymentMessages(false); 

	}

}
