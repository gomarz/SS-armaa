package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;

import com.fs.starfarer.api.PluginPick;
import com.fs.starfarer.api.campaign.CampaignPlugin;
import com.fs.starfarer.api.combat.MissileAIPlugin;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAIPlugin;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;

import org.dark.shaders.light.LightData;
import org.dark.shaders.util.ShaderLib;
import org.dark.shaders.util.TextureData;
import data.scripts.campaign.armaa_raid;
import data.scripts.ai.armaa_repairdrone_AI;
import data.scripts.ai.armaa_reloaddrone_AI;
import data.scripts.util.MagicSettings;
import data.scripts.ai.armaa_spikeAI;
import data.scripts.ai.armaa_grenadeAI;
import data.scripts.plugins.CataphractCheck;
import data.scripts.world.ARMAAWorldGen;

import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;

import java.util.ArrayList;
import java.util.List;

//import exerelin.campaign.SectorManager;

public class armaa_ModPlugin extends BaseModPlugin {


	public static final String spike_ID = "armaa_spike_rod";
	public static final String grenade_ID = "armaa_grenade_shot";
	public static List<String> KARMA_IMMUNE = new ArrayList<>();

    @Override
    public void onNewGame() {
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
            new ARMAAWorldGen().generate(Global.getSector());
    }

 @Override
    public PluginPick<MissileAIPlugin> pickMissileAI(MissileAPI missile, ShipAPI launchingShip)    {
        switch (missile.getProjectileSpecId()) {
            case spike_ID:
                return new PluginPick<MissileAIPlugin>(new armaa_spikeAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
            case grenade_ID:
                return new PluginPick<MissileAIPlugin>(new armaa_grenadeAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
        }
        return null;
    }    


    @Override
	public void onApplicationLoad() throws ClassNotFoundException {  
            
        try {
            Global.getSettings().getScriptClassLoader().loadClass("org.lazywizard.lazylib.ModUtils");
        } catch (ClassNotFoundException ex) {
            String message = System.lineSeparator()
                    + System.lineSeparator() + "LazyLib is required to run at least one of the mods you have installed."
                    + System.lineSeparator() + System.lineSeparator()
                    + "You can download LazyLib at http://fractalsoftworks.com/forum/index.php?topic=5444"
                    + System.lineSeparator();
            throw new ClassNotFoundException(message);
        }
        
        try {
            Global.getSettings().getScriptClassLoader().loadClass("data.scripts.util.MagicAnim");
        } catch (ClassNotFoundException ex) {
            String message = System.lineSeparator()
                    + System.lineSeparator() + "MagicLib is required to run at least one of the mods you have installed."
                    + System.lineSeparator() + System.lineSeparator()
                    + "You can download MagicLib at http://fractalsoftworks.com/forum/index.php?topic=13718.0"
                    + System.lineSeparator();
            throw new ClassNotFoundException(message);
        }
        
        try {  
            Global.getSettings().getScriptClassLoader().loadClass("org.dark.shaders.util.ShaderLib");  
            ShaderLib.init();  
            LightData.readLightDataCSV("data/lights/armaa_bling.csv"); 
            TextureData.readTextureDataCSV("data/lights/armaa_texture.csv"); 
        } catch (ClassNotFoundException ex) {
        }
		
       //modSettings loader:
       KARMA_IMMUNE = MagicSettings.getList("armaarmatura", "missile_resist_karma");   		
    }

    @Override
    public void onGameLoad(boolean newGame) {

        Global.getSector().getListenerManager().addListener(new armaa_raid(), true);
	CataphractCheck newd = new CataphractCheck();
	Global.getSector().addTransientListener(newd.new CataphractCheckMarket());
    }

    @Override
    public PluginPick<ShipAIPlugin> pickShipAI(FleetMemberAPI member, ShipAPI ship) {
    	switch(ship.getHullSpec().getHullId()) {
    		case "armaa_repairdrone": 
    			return new PluginPick<ShipAIPlugin>(new armaa_repairdrone_AI(ship), CampaignPlugin.PickPriority.MOD_GENERAL);
    		case "armaa_reloaddrone": 
    			return new PluginPick<ShipAIPlugin>(new armaa_reloaddrone_AI(ship), CampaignPlugin.PickPriority.MOD_GENERAL);
    	}    	
    	return super.pickShipAI(member, ship);
    }   

    @Override
    public void onNewGameAfterEconomyLoad() {
        MarketAPI market = Global.getSector().getEconomy().getMarket("armaa_meshanii_market");
        if (market != null) {
           // log.info("Adding admin");
            PersonAPI admin = Global.getFactory().createPerson();
            admin.setFaction("independent");
            admin.setGender(FullName.Gender.FEMALE);
            admin.setPostId(Ranks.POST_FACTION_LEADER);
            admin.setRankId(Ranks.FACTION_LEADER);
            admin.getName().setFirst("Sera");
            admin.getName().setLast("");
            admin.setPortraitSprite("graphics/armaa/portraits/armaa_seraph.png");

            admin.getStats().setSkillLevel(Skills.COLONY_MANAGEMENT, 3);
            admin.getStats().setSkillLevel(Skills.INDUSTRIAL_PLANNING, 3);
            admin.getStats().setSkillLevel(Skills.PLANETARY_OPERATIONS, 3);
	    admin.setAICoreId(Commodities.ALPHA_CORE);

            market.setAdmin(admin);
            market.getCommDirectory().addPerson(admin, 0);
            market.addPerson(admin);
        }
    }
}