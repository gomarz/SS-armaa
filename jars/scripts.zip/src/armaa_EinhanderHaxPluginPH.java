package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.input.InputEventAPI;
import java.util.ArrayList;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.util.List;
import com.fs.starfarer.api.combat.CombatFleetManagerAPI.*;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.CollisionUtils;
import org.lwjgl.util.vector.Vector2f;
import data.scripts.util.MagicRender;
import java.awt.Color;
import com.fs.starfarer.api.combat.MissileAPI;
//import org.lazywizard.console.commands.ToggleAI;

//this script manages things that otherwise wouldn't be possible via hullmod; primarily killing the ship in certain conditions
//and ensuring its always selectable in UI
public class armaa_EinhanderHaxPluginPH extends BaseEveryFrameCombatPlugin
{
    public static boolean hasConsoleCommands = Global.getSettings().getModManager().isModEnabled("lw_console");

        protected CombatEngineAPI engine;
	
    @Override
    public void advance(float amount, List<InputEventAPI> events)
    {
		if(engine == null)
			return;
		
		cfm = engine.getFleetManager(FleetSide.PLAYER);
		ctm = cfm.getTaskManager(false);
		ui = engine.getCombatUI();
		
		for (MissileAPI missile : engine.getMissiles())
        {
			if(missile.getWeapon() != null)
			{
				if(missile.getWeapon().getId().equals("armaa_altagrave_rightArm"))
				{
					if(missile.isFizzling() || missile.isFading()){
						if(MagicRender.screenCheck(0.25f, missile.getLocation())){
							engine.addSmoothParticle(missile.getLocation(), new Vector2f(), 50, 0.5f, 0.25f, Color.red);
							engine.addHitParticle(missile.getLocation(), new Vector2f(), 50, 1f, 0.1f, new Color(250,192,92,255));
						}
						engine.removeEntity(missile);
						return;
					}
				}
			}
			
			else continue;
		}

		if(countdown == true)
			timer++;
		
        for (ShipAPI ship : engine.getShips())
        {
            if(ship.getHullSpec().getHullId().equals("armaa_einhander"))
			{
				if(ship.getHitpoints() > 0 && !cataphrachtii.contains(ship))
				cataphrachtii.add(ship);
			}
			
			else continue;
		}
		
		if(cataphrachtii.isEmpty())
		{
			return;
		}

		if(!cataphrachtii.isEmpty())
		{
			if(!engine.isEnemyInFullRetreat())
			{
				engine.setDoNotEndCombat(true);
			}
			//engine.setDoNotEndCombat(true);
			for(ShipAPI mech : cataphrachtii)
			{
				if(ui != null)
				{
					if(ui.isShowingCommandUI())
					{
						mech.setHullSize(HullSize.FRIGATE);
					}
				}
				
				if(mech == null || mech.isRetreating())
				{
					toRemove.add(mech);
					
				}

				if(mech.getHitpoints() <= 0f )
				{
					mech.setHullSize(HullSize.FRIGATE);
					//if(timer == 1)
					//killShip(mech,true);
					countdown = true;
					if(timer > 2)
					{
						//killShip(mech,true);
						toRemove.add(mech);
						engine.removeEntity(mech);
						timer = 0;
						countdown = false;
					}
				}
				

				//cataphrachtii.removeAll
				
				if((mech.getCurrentCR() >= .50f) && mech != engine.getPlayerShip())
				{
					if(ctm.getAssignmentFor(mech) == null)
						return;
					
					AssignmentInfo currentOrder = ctm.getAssignmentFor(mech);
					
						if(currentOrder.getType() == CombatAssignmentType.LIGHT_ESCORT)
						{
							mech.setHullSize(HullSize.FRIGATE);
							ctm.orderSearchAndDestroy(cfm.getDeployedFleetMember(mech),false);
							mech.setHullSize(HullSize.FIGHTER);
						}					
				}
				
				if(mech.getCurrentCR() < .30f && mech != engine.getPlayerShip() && !mech.isRetreating())
				{
						int side = mech.getOwner();
						float CR = mech.getCurrentCR();
						for (ShipAPI carrier : CombatUtils.getShipsWithinRange(mech.getLocation(), 10000f)) 
						{
							
							if (carrier.isFighter() || carrier.isHulk() || carrier.isFrigate()) {
								continue;
							}

							if (carrier.getOwner() != side) {
								continue;
							}

							if (carrier.hasLaunchBays()) 
							{
								if(carrier.getCurrentCR() > mech.getCurrentCR())
								{
									CR = carrier.getCurrentCR();
									//result.add(carrier);						
									//order= ctm.createAssignment(CombatAssignmentType.LIGHT_ESCORT,cfm.getDeployedFleetMember(carrier),false);
									
									if(ctm.getAssignmentFor(mech) == null )
									{
										order= ctm.createAssignment(CombatAssignmentType.LIGHT_ESCORT,cfm.getDeployedFleetMember(carrier),false);

										mech.setHullSize(HullSize.FRIGATE);
										ctm.giveAssignment(cfm.getDeployedFleetMember(mech),order,false);
										mech.setHullSize(HullSize.FIGHTER);
										
									}
									
									else return;
								}
							}
							
						}
				}
				
			}
		
		}
		
		if(cataphrachtii.isEmpty() || engine.isEnemyInFullRetreat())
		{
			engine.setDoNotEndCombat(false);
		}
			//if(!toRemove.isEmpty())
			cataphrachtii.removeAll(toRemove);
	}

    @Override
    public void init(CombatEngineAPI engine)
    {
        this.engine = engine;
    }
	
	public void killShip(ShipAPI target, boolean creditKillToPlayer)
    {
        if (target == null)
        {
            return;
        }

        // Ensure we hit (needed for certain oddly-shaped mod ships)
        Vector2f hitLoc = target.getLocation();
        if (!CollisionUtils.isPointWithinBounds(hitLoc, target))
        {
            if (!target.getAllWeapons().isEmpty())
            {
                //System.out.println("Using alternate hit location for "
                //        + ship.getHullSpec().getHullId());
                hitLoc = target.getAllWeapons().get(0).getLocation();
            }
            else if (!target.getEngineController().getShipEngines().isEmpty())
            {
                hitLoc = target.getEngineController().getShipEngines().get(0).getLocation();
            }
            else
            {
            //    Console.showMessage("Couldn't kill " + target.getHullSpec().getHullId());
            }
        }

        // Ensure a kill
        target.getMutableStats().getHullDamageTakenMult().unmodify();
        target.getMutableStats().getArmorDamageTakenMult().unmodify();
        target.setHitpoints(1f);
        int[] cell = target.getArmorGrid().getCellAtLocation(hitLoc);
        target.getArmorGrid().setArmorValue(cell[0], cell[1], 0f);
        Global.getCombatEngine().applyDamage(target, hitLoc, 500_000,
                DamageType.OTHER, 500_000, true, false, (creditKillToPlayer
                        ? Global.getCombatEngine().getPlayerShip() : null));
    }
	
	
}
