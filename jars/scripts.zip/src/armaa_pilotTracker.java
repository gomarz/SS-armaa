package data.scripts.util;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.util.MagicRender;
import data.scripts.util.MagicTargeting;
import data.scripts.util.MagicLensFlare;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.FaderUtil;
import com.fs.starfarer.api.graphics.SpriteAPI;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import org.lazywizard.lazylib.combat.CombatUtils;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.input.InputEventAPI;
import java.util.Random;

import com.fs.starfarer.api.characters.*;

import data.scripts.MechaModPlugin;


public class armaa_pilotTracker extends BaseEveryFrameCombatPlugin
{
	private ShipAPI fighter;
	private String name;
	private ShipAPI ship;
	private PersonAPI captain;
	private int pilotNo;
	private IntervalUtil interval = new IntervalUtil(10f, 10f);
	private IntervalUtil openingDialogue = new IntervalUtil(1f, 10f);
	private IntervalUtil combatDialogue = new IntervalUtil(20f, 50f);
	private boolean runOnce = false;
	private boolean hasChattered = false;
	private List<String> introChatter = new ArrayList<String>();
	private List<String> combatChatter = new ArrayList<String>();
	private List<String> squadChatter_s = new ArrayList<String>();
	private List<String> squadChatter_r = new ArrayList<String>();
    public armaa_pilotTracker(ShipAPI fighter, String name,int pilotNo) 
	{	
        this.fighter = fighter;
		this.name  = name;
		this.pilotNo = pilotNo;
		this.ship = fighter.getWing().getSourceShip();
		this.captain = fighter.getWing().getSourceShip().getCaptain();
		
		introChatter =MechaModPlugin.introChatter;
		combatChatter = MechaModPlugin.combatChatter;
		squadChatter_s =MechaModPlugin.intersquadChatter_statement;
		squadChatter_r =MechaModPlugin.intersquadChatter_response;		
    }

    @Override
	public void advance(float amount, List<InputEventAPI> events)
	{
		if(Global.getCombatEngine().isPaused())
			return;
		
		if(!introChatter.isEmpty())
		{
			if(Global.getCombatEngine().getCustomData().get("armaa_wingCommander_squadron_hasChattered_"+captain.getId()) instanceof Boolean)
				hasChattered = (Boolean)Global.getCombatEngine().getCustomData().get("armaa_wingCommander_squadron_hasChattered_"+captain.getId());

			//String squadName = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_"+ship.getCaptain().getId());
			if(!Global.getCombatEngine().isPaused())
			{
				interval.advance(amount);
				if(!runOnce && !hasChattered && fighter.getWing().getLeader() == fighter)
				{
					openingDialogue.advance(amount);
					if(openingDialogue.intervalElapsed())
					{
						if(Math.random() <= .50f)
						{
							String squadName = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_"+captain.getId());
							Random rand = new Random();
							int size = rand.nextInt(introChatter.size());
							String chatter = introChatter.get(size);
							Color color = fighter.isAlly() ? Misc.getHighlightColor() : Misc.getBasePlayerColor();
							Color textColor = Global.getSettings().getColor("textGrayColor");

							if(chatter.contains("$"))
							{
								String chatter2 = processSpecialStrings(fighter,ship,chatter);
								Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,squadName,Color.white,":",textColor,chatter2);
							}
							else
								Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,squadName,Color.white,":",textColor,chatter);
						}
						runOnce = true;
						Global.getCombatEngine().getCustomData().put("armaa_wingCommander_squadron_hasChattered_"+captain.getId(),true);
					}
				}
			}
		}
		
		combatDialogue.advance(amount);
		if(combatDialogue.intervalElapsed())
		{
			Color color = fighter.isAlly() ? Misc.getHighlightColor() : Misc.getBasePlayerColor();
			Color textColor = Global.getSettings().getColor("textGrayColor");
			if(fighter.getOwner() == 1)
				color = Misc.getNegativeHighlightColor();
			
			if(fighter.getShipTarget() != null)
			{
				if(Math.random() <= .40f)
				{
					Random rand = new Random();
					int size = rand.nextInt(combatChatter.size());
					String chatter = combatChatter.get(size);
					String squadName = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_"+captain.getId());
					
					if(chatter.contains("$"))
					{
						String chatter2 = processSpecialStrings(fighter,ship,chatter);
						chatter = chatter2;
					}
					if(!MagicRender.screenCheck(0.2f, fighter.getLocation()) )
					{						
						Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,name+", "+squadName,Color.white,":",textColor,chatter);
					}
					
					else
				Global.getCombatEngine().addFloatingTextAlways(fighter.getLocation(), chatter, 30f, Color.white, fighter, 0f, 0f, 1f, 3f, 2f, 0f); 	
				}
			}

			else if(Math.random() <= .05f)
			{
				int count = (Integer)Global.getSector().getPersistentData().get("armaa_wingCommander_squadSize_"+captain.getId());
				for(int j = 0; j < count; j++)
				{
					boolean wasAssigned = false;
					Object obj = Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_"+j+"_"+captain.getId());
					if(obj instanceof PersonAPI && fighter.getWing().getSpec().getVariant().getHullSpec().getMinCrew() > 0)
					{
						Object bool = Global.getCombatEngine().getCustomData().get("armaa_wingCommander_wingman_"+j+"_wasAssigned_"+captain.getId());
						if(bool instanceof Boolean)
						{
							wasAssigned = (Boolean)Global.getCombatEngine().getCustomData().get("armaa_wingCommander_wingman_"+j+"_wasAssigned_"+captain.getId());
						}
						PersonAPI pilot = (PersonAPI)Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_"+j+"_"+captain.getId());
						if(!wasAssigned)
							continue;
						if(pilot != fighter.getCaptain())
						{
							String otherguy = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_"+j+"_"+"callsign_"+captain.getId());
							String squadName = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_"+captain.getId());
							
							Random rand = new Random();
							int size = rand.nextInt(squadChatter_r.size());
							String chatter = squadChatter_r.get(size);
							
							if(chatter.contains("$"))
							{
								if(chatter.contains("$squadmember"))
								{
									String chatter2 = chatter.replace("$squadmember",name);
									chatter = chatter2;
								}
								
								String chatter2 = processSpecialStrings(fighter,ship,chatter);
								chatter = chatter2;
							}
					
							Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,otherguy+", "+squadName,Color.white,":",textColor,chatter);
													
							size = rand.nextInt(squadChatter_s.size());
							chatter = squadChatter_s.get(size);

							if(chatter.contains("$"))
							{
								if(chatter.contains("$squadmember"))
								{
									String chatter2 = chatter.replace("$squadmember",otherguy);
									chatter = chatter2;
								}
								
								String chatter2 = processSpecialStrings(fighter,ship,chatter);
								chatter = chatter2;
							}

							Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,name+", "+squadName,Color.white,":",textColor,chatter);
							break;				
						}			
					}
				}
			}
		}
		
		if(Global.getCombatEngine() == null || fighter== null || fighter.getHitpoints() <= 0 || !Global.getCombatEngine().isEntityInPlay(fighter) || Global.getCombatEngine().isCombatOver()) 
		{
			Global.getCombatEngine().getCustomData().put("armaa_wingCommander_wingman_"+pilotNo+"_wasAssigned_"+captain.getId(),false);
			Global.getCombatEngine().removePlugin(this);
		}	
		
		if(MagicRender.screenCheck(0.2f, fighter.getLocation()) && !fighter.isLiftingOff() && fighter.isAlive())
		{
			Color floatyColor = fighter.getOwner() == 1 ? Misc.getHighlightColor() : Misc.getBasePlayerColor();
			Vector2f loc = new Vector2f(fighter.getLocation());
			loc.setY(loc.getY()+35);
			if(!Global.getCombatEngine().hasAttachedFloaty(fighter))
				Global.getCombatEngine().addFloatingTextAlways(loc, name, 15f, floatyColor, fighter, 0f, 0f, 5f, amount, amount, 0f); 	
		}
	}
	
	private String processSpecialStrings(ShipAPI fighter, ShipAPI ship,String chatter)
	{
		int side = fighter.getOwner() == 0 ? 1 : 0;
		
		if(Global.getCombatEngine().getFleetManager(side) == null)
			return "*static*";			
		if(Global.getCombatEngine().getFleetManager(side).getFleetCommander() == null)
			return "*fzzt*";	
		if(Global.getCombatEngine().getFleetManager(side).getFleetCommander().getFaction() == null)
			return "*bzzt*";
		
		if(ship == null || fighter == null)
			return "*crackle*";

		String chatter2 = chatter;
		
		PersonAPI eneCommander = Global.getCombatEngine().getFleetManager(side).getFleetCommander();
		
		if(chatter2.contains("$factionnamearticle"))
		{
			String faction = "the enemy";
			//just nullcheck everything lel
			if(eneCommander.getFaction().isPlayerFaction())
			{
				if(Misc.getFactionMarkets(Global.getSector().getPlayerFaction()).isEmpty())
				{
					faction = "the Savior of Galatia";
				}
			}
			
			else
			faction = Global.getCombatEngine().getFleetManager(side).getFleetCommander().getFaction().getDisplayNameWithArticle();
			
			chatter2 = chatter.replace("$factionnamearticle",faction);
			chatter = chatter2;
		}
		
		if(chatter2.contains("$factionname"))
		{
			String faction = "hostiles";
			if(eneCommander.getFaction().isPlayerFaction())
			{
				if(Misc.getFactionMarkets(Global.getSector().getPlayerFaction()).isEmpty())
				{
					faction = "unaffiliated";
				}
			}
			
			else
			faction = Global.getCombatEngine().getFleetManager(side).getFleetCommander().getFaction().getDisplayName();
			chatter2 = chatter.replace("$factionname",faction);
			chatter = chatter2;
		}
		
		if(chatter2.contains("$squadronname"))
		{
			String squadName = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_"+captain.getId());
			chatter2 = chatter.replace("$squadronname",squadName);
			chatter = chatter2;
		}
				
		if(chatter2.contains("$squadleader"))
		{
			String squadLeader = "the Command Ship";
			if(ship != null && ship.getName() != null)
				squadLeader = ship.getName();
			
			chatter2 = chatter.replace("$squadleader",squadLeader);
			chatter = chatter2;
		}


		return chatter2;
	}
	

}