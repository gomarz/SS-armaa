package data.scripts;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;

import com.fs.starfarer.api.PluginPick;
import com.fs.starfarer.api.campaign.CampaignPlugin;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.combat.MissileAIPlugin;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAIPlugin;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.impl.campaign.ids.Commodities;
import com.fs.starfarer.api.campaign.PersonImportance;
import com.fs.starfarer.api.impl.campaign.ids.FleetTypes;

import org.dark.shaders.light.LightData;
import org.dark.shaders.util.ShaderLib;
import org.dark.shaders.util.TextureData;
import data.scripts.campaign.armaa_raid;
import data.scripts.util.MagicSettings;
import data.scripts.ai.armaa_spikeAI;
import data.scripts.ai.armaa_harpoonAI;
import data.scripts.ai.armaa_grenadeAI;
import data.scripts.ai.armaa_dispersalMortarAI;
import data.scripts.ai.armaa_curvyLaserAI;
import data.scripts.plugins.CataphractCheck;
import data.scripts.world.ARMAAWorldGen;
import data.scripts.ai.armaa_combat_docking_AI;
import data.hullmods.cataphract;

import com.fs.starfarer.api.fleet.FleetMemberType;

import com.fs.starfarer.api.impl.campaign.ids.Ranks;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import com.fs.starfarer.api.characters.FullName;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;

import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import data.scripts.campaign.armaa_wingmanPromotion;
import data.scripts.campaign.armaa_skyMindBattleResultListener;
import data.scripts.campaign.armaa_drugsAreBad;
import data.scripts.campaign.armaa_lootCleaner;
import data.scripts.campaign.intel.armaa_squadManagerIntel;
import com.fs.starfarer.api.campaign.SectorEntityToken;

import java.util.*;
import org.lwjgl.util.vector.Vector2f;
import org.apache.log4j.Logger;
import org.lazywizard.lazylib.campaign.CampaignUtils;
import org.lazywizard.lazylib.MathUtils;

import com.fs.starfarer.api.campaign.SectorAPI;

//import exerelin.campaign.SectorManager;

public class MechaModPlugin extends BaseModPlugin {


	public static final String spike_ID = "armaa_spike_rod";
	public static final String harpoon_ID = "armaa_harpoon_rod";
	public static final String grenade_ID = "armaa_grenade_shot";
	public static final String mortar_ID = "armaa_mortar_shot";
	public static final String laser_ID = "armaa_curvylaser_mirv";
	public static List<String> KARMA_IMMUNE = new ArrayList<>();
	
	//Wingcom schiz
	public static List<String> squadNames = new ArrayList<>();
	public static List<String> squadChatter = new ArrayList<>();
	public static List<String> squadChatter_soldier = new ArrayList<>();
	public static List<String> squadChatter_villain = new ArrayList<>();
	
	public static List<String> squadChatter_alpha = new ArrayList<>();
	public static List<String> squadChatter_beta = new ArrayList<>();
	public static List<String> squadChatter_gamma = new ArrayList<>();
	
	public static List<String> combatChatter = new ArrayList<>();
	public static List<String> introChatter = new ArrayList<>();
	public static Map<String,List<String>> introChatter_special = new HashMap<>();
	public static boolean chatterEnabled = true;
	public static List<String> intersquadChatter_statement = new ArrayList<>();
	public static List<String> intersquadChatter_response = new ArrayList<>();
	
	//
	
	public static List<String> varrifle_weapons = new ArrayList<>();	
	public static Map<String,String> SPECIAL_WING_DIALG = new HashMap<>();
	public static Map<String,Float> MISSILE_REFIT_MALUS = new HashMap<>();
	public static Map<String,Float> HULLMOD_REFIT_MALUS = new HashMap<>();		
	public static Map<String,Float> GROUND_SUPPORT_CUSTOM = new HashMap<>();	
	
	private armaa_wingmanPromotion script;
	private armaa_drugsAreBad copiumScript;
	
	private final armaa_skyMindBattleResultListener resultListener = new armaa_skyMindBattleResultListener(false);
   
    @Override
    public void onNewGame() {
        boolean haveNexerelin = Global.getSettings().getModManager().isModEnabled("nexerelin");
            new ARMAAWorldGen().generate(Global.getSector());
    }

 @Override
    public PluginPick<MissileAIPlugin> pickMissileAI(MissileAPI missile, ShipAPI launchingShip)    {
        switch (missile.getProjectileSpecId()) {
            case spike_ID:
                return new PluginPick<MissileAIPlugin>(new armaa_spikeAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
            case harpoon_ID:
                return new PluginPick<MissileAIPlugin>(new armaa_harpoonAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
            case grenade_ID:
                return new PluginPick<MissileAIPlugin>(new armaa_grenadeAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
            case mortar_ID:
                return new PluginPick<MissileAIPlugin>(new armaa_dispersalMortarAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
            case laser_ID:
                return new PluginPick<MissileAIPlugin>(new armaa_curvyLaserAI(missile, launchingShip), CampaignPlugin.PickPriority.MOD_SPECIFIC);
        }
        return null;
    }    


    @Override
	public void onApplicationLoad() throws ClassNotFoundException {  
            
        try {
            Global.getSettings().getScriptClassLoader().loadClass("org.lazywizard.lazylib.ModUtils");
        } catch (ClassNotFoundException ex) {
            String message = System.lineSeparator()
                    + System.lineSeparator() + "LazyLib is required to run at least one of the mods you have installed."
                    + System.lineSeparator() + System.lineSeparator()
                    + "You can download LazyLib at http://fractalsoftworks.com/forum/index.php?topic=5444"
                    + System.lineSeparator();
            throw new ClassNotFoundException(message);
        }
        
        try {
            Global.getSettings().getScriptClassLoader().loadClass("data.scripts.util.MagicAnim");
        } catch (ClassNotFoundException ex) {
            String message = System.lineSeparator()
                    + System.lineSeparator() + "MagicLib is required to run at least one of the mods you have installed."
                    + System.lineSeparator() + System.lineSeparator()
                    + "You can download MagicLib at http://fractalsoftworks.com/forum/index.php?topic=13718.0"
                    + System.lineSeparator();
            throw new ClassNotFoundException(message);
        }
        
        try {  
            Global.getSettings().getScriptClassLoader().loadClass("org.dark.shaders.util.ShaderLib");  
            ShaderLib.init();  
            LightData.readLightDataCSV("data/lights/armaa_bling.csv"); 
            TextureData.readTextureDataCSV("data/lights/armaa_texture.csv"); 
        } catch (ClassNotFoundException ex) {
        }
		
       //modSettings loader:
	   
		KARMA_IMMUNE = MagicSettings.getList("armaarmatura", "missile_resist_karma");
		
		squadNames = MagicSettings.getList("armaarmatura", "strikecraft_squad_names");
		squadChatter = MagicSettings.getList("armaarmatura", "strikecraft_squad_chatter");
		squadChatter_soldier = MagicSettings.getList("armaarmatura", "strikecraft_squad_chatter_soldier");
		squadChatter_villain = MagicSettings.getList("armaarmatura", "strikecraft_squad_chatter_villain");
		
		//ai
		squadChatter_alpha = MagicSettings.getList("armaarmatura", "strikecraft_squad_chatter_alpha");
		squadChatter_beta = MagicSettings.getList("armaarmatura", "strikecraft_squad_chatter_beta");
		squadChatter_gamma = MagicSettings.getList("armaarmatura", "strikecraft_squad_chatter_gamma");		
		//
		
		introChatter = MagicSettings.getList("armaarmatura","strikecraft_squad_chatter_intro");
		
		chatterEnabled = MagicSettings.getBoolean("armaarmatura","wingcom_chatter");		
		introChatter_special.put("$gaTJ_completed",MagicSettings.getList("armaarmatura","$gaTJ_completed"));
		introChatter_special.put("$atrocities",MagicSettings.getList("armaarmatura","$atrocities"));
		introChatter_special.put("$metBaird",MagicSettings.getList("armaarmatura","$metBaird"));
		
		combatChatter = MagicSettings.getList("armaarmatura","strikecraft_squad_chatter_combat");
		
		intersquadChatter_statement = MagicSettings.getList("armaarmatura","strikecraft_squad_chatter_intersquad_statement");
		intersquadChatter_response = MagicSettings.getList("armaarmatura","strikecraft_squad_chatter_intersquad_response");
		
		SPECIAL_WING_DIALG = MagicSettings.getStringMap("armaarmatura","special_wing_lines");
		MISSILE_REFIT_MALUS = MagicSettings.getFloatMap("armaarmatura","missile_refit_custom");
	    HULLMOD_REFIT_MALUS = MagicSettings.getFloatMap("armaarmatura","hullmod_refit_custom");
	    GROUND_SUPPORT_CUSTOM = MagicSettings.getFloatMap("armaarmatura","ground_support_custom");

		cataphract.GROUND_BONUS.putAll(GROUND_SUPPORT_CUSTOM);		

		varrifle_weapons = MagicSettings.getList("armaarmatura","variablerifle_whitelist");
    }

    @Override
    public void beforeGameSave() 
	{
		Global.getSector().removeTransientScript(script);
        Global.getSector().removeListener(script);
		Global.getSector().removeTransientScript(copiumScript);
        Global.getSector().removeListener(copiumScript);
    }
	
    @Override
    public void afterGameSave() 
	{
        Global.getSector().addTransientScript(script = new armaa_wingmanPromotion());
        Global.getSector().addTransientScript(copiumScript = new armaa_drugsAreBad());
    }

    @Override
    public void onGameLoad(boolean newGame) 
	{
		//idk if these are even necessary at this point, but...better safe than wrecking saves
		Global.getSector().getListenerManager().removeListenerOfClass(armaa_wingmanPromotion.class);
		Global.getSector().getListenerManager().removeListenerOfClass(armaa_drugsAreBad.class);
		
		Global.getSector().getListenerManager().addListener(new armaa_lootCleaner(), true);
		Global.getSector().getListenerManager().addListener(new armaa_raid(), true);
		Global.getSector().addTransientScript(script = new armaa_wingmanPromotion());
        Global.getSector().addTransientScript(copiumScript = new armaa_drugsAreBad());
		Global.getSector().getPlayerPerson().getStats().setSkillLevel("armaa_cataphract", 1);
		
        final SectorAPI sector = Global.getSector();	
		
        if (sector != null && sector.getListenerManager() != null) {
            sector.addListener(resultListener);
            if (!sector.getListenerManager().hasListener(resultListener)) {
                sector.getListenerManager().addListener(resultListener);
            }
        }
		
		if(!Global.getSector().getIntelManager().hasIntelOfClass(armaa_squadManagerIntel.class))
		{
			armaa_squadManagerIntel squadManager = new armaa_squadManagerIntel();
		}
		
		boolean hasValk = false;
		boolean check = false;
		if(Global.getSector().getPersistentData().get("armaa_superStart_valkazard?") instanceof Boolean)
		{
			check =  (Boolean)Global.getSector().getPersistentData().get("armaa_superStart_valkazard?");
		}
		if(!check)
		{			
			for(FleetMemberAPI f: Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy())
			{
				if(f.getHullId().equals("armaa_valkazard"))
				{
					hasValk= true;
					Global.getSector().getPersistentData().put("armaa_superStart_valkazard?",true);
					Global.getSector().getMemoryWithoutUpdate().set("$hasValk", true);
					break;
				}
			}
			
			if(hasValk && Global.getSector().getEntityById("valkazard") != null)
			{
				Global.getSector().getEntityById("valkazard").setExpired(true);
				Global.getSector().getEntityById("valkazard").setContainingLocation(null);
			}
		}
    }

    @Override
    public void onNewGameAfterEconomyLoad() 
	{
			FleetParamsV3 params = new FleetParamsV3(
					Global.getSector().getEntityById("armaa_research_station").getLocationInHyperspace(),
					"tritachyon",
					null,
					FleetTypes.PATROL_SMALL,
					10f, // combatPts
					0f, // freighterPts 
					0f, // tankerPts
					0f, // transportPts
					0f, // linerPts
					0f, // utilityPts
					.5f // qualityMod
					);
			CampaignFleetAPI fleet =FleetFactoryV3.createFleet(params);
SectorEntityToken loc = Global.getSector().getEntityById("armaa_research_station");

            // Spawn fleet around player
            loc.getContainingLocation().spawnFleet(
                    loc, 25, 25, fleet);
            Global.getSector().addPing(fleet, "danger");
			fleet.setLocation(loc.getLocation().x,loc.getLocation().y);
			fleet.setId("mecha");
			CampaignUtils.addShipToFleet("hyperion_Attack",FleetMemberType.SHIP,fleet);
            fleet.addAssignment(FleetAssignment.ORBIT_AGGRESSIVE, loc, 500f);

		//}
			
        MarketAPI market = Global.getSector().getEconomy().getMarket("armaa_meshanii_market");
        if (market != null) {
			Global.getSector().getEconomy().getMarket("armaa_meshanii_market").getMemoryWithoutUpdate().set("$musicSetId","music_armaa_market_neutral");
           // log.info("Adding admin");
            PersonAPI admin = Global.getFactory().createPerson();
            admin.setFaction("independent");
            admin.setGender(FullName.Gender.FEMALE);
            admin.setPostId(Ranks.POST_EXECUTIVE);
            admin.setRankId(Ranks.SPECIAL_AGENT);
            admin.getName().setFirst("Sera");
            admin.getName().setLast("Pha");
			admin.setImportanceAndVoice(PersonImportance.VERY_HIGH, new Random());
            admin.setPortraitSprite("graphics/armaa/portraits/armaa_seraph.png");
            admin.getStats().setSkillLevel(Skills.INDUSTRIAL_PLANNING, 3);
            admin.getStats().setSkillLevel(Skills.HYPERCOGNITION, 3);
			admin.setAICoreId(Commodities.ALPHA_CORE);

            market.setAdmin(admin);
            market.getCommDirectory().addPerson(admin, 0);
            market.addPerson(admin);
        }		
    }
}