package data.scripts.weapons;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.graphics.SpriteAPI;
import data.scripts.util.MagicAnim;
import data.scripts.util.MagicRender;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.Global;

public class armaa_shoulderColor implements EveryFrameWeaponEffectPlugin 
{
    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) 
	{
		if(!Global.getCombatEngine().isInCampaign())
				return;
		String id = weapon.getShip().getFleetMember().getFleetData().getFleet().getFaction().getId();
		Color color = weapon.getShip().getFleetMember().getFleetData().getFleet().getFaction().getColor();
		if(id.equalsIgnoreCase("pirates"));
		color = new Color(206,69,69);
		
		if(weapon.getShip().getOwner() == 0 && !weapon.getShip().isAlly())
		{
			if(Misc.getCommissionFaction() != null)
				color = Misc.getCommissionFaction().getBaseUIColor();
			else
				color = Global.getSector().getPlayerFaction().getColor();
		}
			
		weapon.getSprite().setColor(new Color(color.getRed(),color.getGreen(),color.getBlue(),255));
		
    }
}
