package data.hullmods;

import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.HullMods;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.characters.*;

import com.fs.starfarer.api.combat.WeaponAPI.WeaponSize;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import com.fs.starfarer.api.fleet.FleetGoal;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;

import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.entities.AnchoredEntity;

import com.fs.starfarer.api.combat.EmpArcEntityAPI;

import data.scripts.util.MagicUI;

import data.scripts.ai.armaa_combat_docking_AI;

import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.CollisionUtils;
import org.lwjgl.util.vector.Vector2f;

import java.util.List;
import java.util.ArrayList;
import java.awt.Color;
import java.util.Random;

import data.scripts.util.armaa_utils;
import com.fs.starfarer.api.SettingsAPI;

public class armaa_strikeCraft extends BaseHullMod {

	private Object KEY_JITTER = new Object();
	private Color COLOR = new Color(0, 106, 0, 50);
	private float DEGRADE_INCREASE_PERCENT = 100f;
	public MagicUI ui;
	private static final float RETREAT_AREA_SIZE = 2000f;
	private IntervalUtil interval = new IntervalUtil(25f,25f);
	private IntervalUtil textInterval = new IntervalUtil(5f,5f);
	private Color TEXT_COLOR = new Color(55,155,255,255);
	private final Color CORE_COLOR = new Color(200, 200, 200);
	private final Color FRINGE_COLOR = new Color(255, 10, 10);	
	private final float Repair = 100, CR = 20; //Hullmod in game description.
	private float HPPercent = 0.80f;
	private float BaseTimer = .30f;
    private float CRmarker = 0.4f;
	private float MISSILE_DAMAGE_THRESHOLD = 200f;
	private boolean hasLanded;
	public final ArrayList<String> landingLines_Good = new ArrayList<>();
	public final ArrayList<String> landingLines_Fair = new ArrayList<>();
	public final ArrayList<String> landingLines_Critical = new ArrayList<>();
	public final ArrayList<String> landingLines_notPossible = new ArrayList<>();

	
	{
		//If CR is low, but otherwise no major damage
        landingLines_Good.add("\"Welcome aboard, sir.\"");
		landingLines_Good.add("\"Looks like you got away pretty clean!\"");
		landingLines_Good.add("\"Hopefully, you bag a few more kills today.\"");
		landingLines_Good.add("\"All conditions good. Fuselage solid.\"");

		//If taken heavy damage, but CR isn't too bad
		landingLines_Critical.add("\"Glad you made it back alive, sir.\"");
		landingLines_Critical.add("\"Looks like this may be a tough battle, sir.\"");
		landingLines_Critical.add("\"Be careful flying while severely damaged. Even anti-air fire could bring you down.\"");
		
		
		//If heavy damage and low CR
	
		//Tried to find a carrier but could not
		landingLines_notPossible.add("\"Dammit, nowhere to land!\"");
		landingLines_notPossible.add("\"Could really use somewhere to land right now..\"");
		landingLines_notPossible.add("\"Zilch on available carriers. Aborting refit!\"");
		landingLines_notPossible.add("\"There's nowhere for me to resupply.\"");
	}
		

	public void applyEffectsBeforeShipCreation(HullSize hullSize, MutableShipStatsAPI stats, String id) {
		stats.getZeroFluxMinimumFluxLevel().modifyFlat(id, -1f); // -1 means boost never takes effect; 2 means always on
		stats.getCRLossPerSecondPercent().modifyPercent(id, DEGRADE_INCREASE_PERCENT);

	}
	
	public boolean canRetreat(ShipAPI ship)
	{
		float mapWidth = Global.getCombatEngine().getMapWidth() / 2f, mapHeight = Global.getCombatEngine().getMapHeight() / 2f;
		Vector2f rawLL = new Vector2f(-mapWidth, -mapHeight),rawUR = new Vector2f(mapWidth, mapHeight);
		CombatEngineAPI engine = Global.getCombatEngine();
		BattleCreationContext context = engine.getContext();
		FleetGoal objective = context.getPlayerGoal();
		boolean check = false;
		Vector2f location = ship.getLocation();
		if(objective == FleetGoal.ESCAPE || ship.getOwner() == 1)
		{
			if(location.getY() > rawUR.getY() - RETREAT_AREA_SIZE)
			{
				check = true;
			}
		}
		else if(location.getY() < RETREAT_AREA_SIZE+rawLL.getY())
		{
			check = true;
		}
		return check;
	}
	
	public void getPilotPersonality(ShipAPI ship)
	{
		String personality = "steady";
		if (ship.getCaptain() != null) 
		{
			PersonAPI pilot = ship.getCaptain();
			personality = pilot.getPersonalityAPI().getId().toString();
		}
		float dangerLevel = .50f;
		switch (personality) 
		{
			case "steady":
					// do nothing, we will use the default
				break;
			case "reckless":
					// we have a death wish
					dangerLevel = .30f;
				break;
			case "aggressive":
					dangerLevel = .40f;
				break;
			case "timid":
					dangerLevel = .70f;
				break;
			case "cautious":
					dangerLevel = .60f;
				break;
			default:
				break;
		}
		
		Global.getCombatEngine().getCustomData().put("armaa_strikecraftPilot"+ship.getId(),dangerLevel);
		
	}


	public void checkMalfChance(ShipAPI ship)
	{
		float cr = ship.getCurrentCR();

		if(cr < .20f && cr >= 0f )
		{
			if(cr == 0f)
			{
				ship.setDefenseDisabled(true);
				ship.setShipSystemDisabled(true);
			}

			else
			{
				ship.setDefenseDisabled(false);
				ship.setShipSystemDisabled(false);
			}

			ship.getMutableStats().getEngineMalfunctionChance().modifyFlat(ship.getId(), 0.03f*(1f + (1f-cr) ) );
			ship.getMutableStats().getWeaponMalfunctionChance().modifyFlat(ship.getId(), 0.03f*(1f + (1f-cr) ) );
		}

		else
		{
			ship.getMutableStats().getEngineMalfunctionChance().unmodify();
			ship.getMutableStats().getWeaponMalfunctionChance().unmodify();
		}
	}
	public void drawHud(ShipAPI ship)
	{
		MagicUI.drawHUDStatusBar(
			ship, 
			(ship.getHitpoints()/ship.getMaxHitpoints()),
			null,
			null,
			1,
			"HULL",
			">",
			true
		);

		MagicUI.drawHUDStatusBar(
		 ship, (ship.getCurrFlux()/ship.getMaxFlux()),
		 null,
		 null,
		(ship.getHardFluxLevel()),
		 "FLUX",
		 ">",
		 false
		);
		
		MagicUI.drawInterfaceStatusBar(
		 ship, ship.getCurrentCR(),
		 getColorCondition(ship),
		 getColorCondition(ship),
		 ship.getCurrentCR(),
		"CR",
		(int)(ship.getCurrentCR()*100)
		);
	}

	public void combatAlert(ShipAPI ship, ShipAPI servicee,String context)
	{
		switch(context) {
			case "overload":
				//if(
				ship.getFluxTracker().showOverloadFloatyIfNeeded("Overloaded!", TEXT_COLOR, 4f, true);
				
				break;
		}
		textInterval = new IntervalUtil(100f,100f);
	}

	public Color getColorCondition(ShipAPI ship)
	{
		return Global.getSettings().getColor("textFriendColor");
	}

	public String getDescriptionParam(int index, HullSize hullSize) 
	{

		if (index == 0) return "" + "maneuver over asteroids and other vessels"; 
		if (index == 1) return "" + "will crash if a flameout occurs";
		if (index == 2) return "" + "no zero-flux speed bonus";
		if (index == 3) return "" + "" + (int) DEGRADE_INCREASE_PERCENT + "%";
		if (index == 4) return "" + "" + (int) CR + "%";
		if (index == 5) return "" + (int)Repair+"%";
		if (index == 6) return "" + (int)(BaseTimer*100)+"%";
		if (index == 7) return "" + "Point Defense";
		return null;
	}
	
	private final Color HL=Global.getSettings().getColor("hColor");	
	@Override
    public void addPostDescriptionSection(TooltipMakerAPI tooltip, ShipAPI.HullSize hullSize, ShipAPI ship, float width, boolean isForModSpec) 
	{
        //title
        tooltip.addSectionHeading("Refit Time Modifiers", Alignment.MID, 15);        
        
        if(ship!=null && ship.getVariant()!=null)
		{
			float adjustedRate  = 0f;
			String weaponName = "";
			getRefitRate(ship);
			if(Global.getCombatEngine().getCustomData().get("armaa_strikecraftMissileMalus"+ship.getId()) instanceof Float)
			{
				adjustedRate = (float)Global.getCombatEngine().getCustomData().get("armaa_strikecraftMissileMalus"+ship.getId());
				weaponName = String.valueOf(Global.getCombatEngine().getCustomData().get("armaa_strikecraftWepName"+ship.getId()));

			}
		

            if( adjustedRate == 0f){
                tooltip.addPara(
                        "No refit penalty."
                        ,10
                        ,HL
                );

            } else {
                //effect applied
				float value = adjustedRate*100.0f;
                String depletion = String.valueOf((int)value)+" percent";
                String weapon = weaponName;
                tooltip.addPara(
                        "Refit time is increased by "
                        + depletion
                        + " due to the installation of: "
                        + weapon
                        ,10
                        ,HL
                        ,depletion
                        ,weapon
                );

            }
        }
        
    }
	
	private void getRefitRate(ShipAPI target)
	{
		float adjustedRate  = 0f;
		String wepName = "";
		List<WeaponAPI> weapons = target.getAllWeapons();
		for(WeaponAPI w : weapons)
		{
			if(w.getType() == WeaponType.MISSILE)
			{
				float damage =	w.getDerivedStats().getDamagePerShot();
				if(damage > MISSILE_DAMAGE_THRESHOLD)
				{
					float penalty = damage/MISSILE_DAMAGE_THRESHOLD;
					
					if(penalty < 1)
						continue;
					
					penalty = penalty/10f;
					float newRate = (float)Math.min(.35f,penalty);
					if(newRate > adjustedRate)
					{
						adjustedRate = newRate;
						wepName = w.getDisplayName();
					}
					Global.getCombatEngine().getCustomData().put("armaa_strikecraftMissileMalus"+target.getId(),adjustedRate);
					Global.getCombatEngine().getCustomData().put("armaa_strikecraftWepName"+target.getId(),wepName);
				}
				
			}	
		}
	}
	
    private boolean needsReload(ShipAPI target)
    {
		boolean check = false;
		getRefitRate(target);
		List<WeaponAPI> weapons = target.getAllWeapons();
		for(WeaponAPI w : weapons)		
		{
			//So long as we have at least one weapon with some ammo left, don't return yet
			if(w.getId().equals("armaa_landingBeacon"))
			{
				if(w.getAmmo() < 1 && target == Global.getCombatEngine().getPlayerShip())
				{
					check = true;
					return check;
				}
				
				else continue;
			}
			if(w.usesAmmo() && (w.getAmmo() >= 1 && w.getAmmoPerSecond() == 0) && !(w.getSlot().isDecorative()))
			{
					check = false;
					break;
			}

			else if(w.usesAmmo() && w.getAmmo() < 1 && !(w.getSlot().isDecorative()))
			{
				if(w.getAmmoPerSecond() == 0)
				{
					check = true;
				}
			}
			
		}
		return check;
    }
	
	private boolean canRefit(ShipAPI ship)
	{
		boolean canRefit = false;
		
		for (ShipAPI carrier : CombatUtils.getShipsWithinRange(ship.getLocation(), 10000.0F)) 
		{
			if(carrier.getOwner() != ship.getOwner() || carrier.isFighter() || carrier.isFrigate())
				continue;
			if(carrier.getNumFighterBays() > 0)
			{
				canRefit = true;
			}				
		}
		
		return canRefit;
	}
	
    @Override
    public void advanceInCombat(ShipAPI ship, float amount)
    {

		if(Global.getCombatEngine() != null)
		{
			if(!(Global.getCombatEngine().getCustomData().get("armaa_strikecraftLanded"+ship.getId()) instanceof Boolean))
				Global.getCombatEngine().getCustomData().put("armaa_strikecraftLanded"+ship.getId(),false);
		
			if(Global.getCombatEngine().getCustomData().get("armaa_strikecraftPilot"+ship.getId()) instanceof Float == false)
			{
				getPilotPersonality(ship);
			}
			
			else
				HPPercent = (float)Global.getCombatEngine().getCustomData().get("armaa_strikecraftPilot"+ship.getId());
		}

		if(ship.getCollisionClass() != CollisionClass.FIGHTER)
			ship.setCollisionClass(CollisionClass.FIGHTER);

		boolean player = ship == Global.getCombatEngine().getPlayerShip();

		CombatUIAPI ui = Global.getCombatEngine().getCombatUI();
		
		checkMalfChance(ship);
		
		if(ship.getCurrentCR() <= 0.4f && Global.getCombatEngine().getCombatUI() != null && ship.getOriginalOwner() != -1)
		{
			if(!(Global.getCombatEngine().getCustomData().get("armaa_strikecraftCRWarning"+ship.getId()) instanceof Boolean))
			{
				Global.getCombatEngine().getCombatUI().addMessage(1,Global.getSettings().getColor("textFriendColor"),ship.getName() + "'s ",Color.yellow, "performance is degrading due to combat stresses.");
				Global.getSoundPlayer().playUISound("cr_allied_critical", 1f, 1f);
				Global.getCombatEngine().getCustomData().put("armaa_strikecraftCRWarning"+ship.getId(),true);
			}
			
		}
		
		if(ship.getShipAI() instanceof com.fs.starfarer.combat.ai.FighterAI == false && ship.getShipAI() instanceof armaa_combat_docking_AI == false)
		{
			Global.getCombatEngine().getCustomData().put("armaa_strikecraftisLanding"+ship.getId(),null);
		}
		
		float CurrentHull = ship.getHitpoints();
		float MaxHull = ship.getMaxHitpoints();
		float CurrentCR = ship.getCurrentCR();
		
		if (((CurrentHull <= MaxHull * HPPercent) || (CurrentCR < CRmarker) || (needsReload(ship))) && canRefit(ship))
		{					
			if((player && !Global.getCombatEngine().isUIAutopilotOn() && ship.getShipAI() == null))
			{
				ship.setHullSize(HullSize.FRIGATE);
				ship.resetDefaultAI();
			}
			if (player) 
				Global.getCombatEngine().maintainStatusForPlayerShip("AceSystem1", "graphics/ui/icons/icon_repair_refit.png","/ - WARNING - /", "REFIT / REARM NEEDED( PRESS " + Global.getSettings().getControlStringForEnumName("C2_TOGGLE_AUTOPILOT") + " )" ,true);
			
			if((!player && canRefit(ship)) || (player && !Global.getCombatEngine().isUIAutopilotOn()))
			{
				armaa_combat_docking_AI DockingAI = new armaa_combat_docking_AI(ship);
				if(!ship.isFinishedLanding())
				{
					if(ship.getShipAI() != DockingAI);
					ship.setShipAI(DockingAI);
					
					//Do init -once-
					if(!(Global.getCombatEngine().getCustomData().get("armaa_strikecraftisLanding"+ship.getId()) instanceof Boolean))
					{
						DockingAI.init();
						Global.getCombatEngine().getCustomData().put("armaa_strikecraftisLanding"+ship.getId(),true);
					}
						//DockingAI.needsRefit();
						//DockingAI.beginlandingAI();
				}
				else
				{
					if(Global.getCombatEngine().getCustomData().get("armaa_strikecraftLanded"+ship.getId()) instanceof Boolean)
					{
						boolean hasLanded = (boolean)Global.getCombatEngine().getCustomData().get("armaa_strikecraftLanded"+ship.getId());
						if(player && !hasLanded)
						{
							Random rand = new Random();
							String txt =  landingLines_Critical.get(rand.nextInt(landingLines_Critical.size()));
							if(ship.getHullLevel() > 0.45f)
								txt =  landingLines_Good.get(rand.nextInt(landingLines_Good.size()));
							Vector2f texLoc;
							if(DockingAI.getCarrier() != null)
								texLoc = DockingAI.getCarrier().getLocation();
							else
								texLoc = ship.getLocation();
							if(Math.random() <= 35f)
							{
								ship.getFluxTracker().showOverloadFloatyIfNeeded(txt, Color.white, 2f, true);
								Global.getSoundPlayer().playSound("ui_noise_static", 1f, 1f, texLoc,new Vector2f());
							}
							Global.getCombatEngine().getCustomData().put("armaa_strikecraftLanded"+ship.getId(),true);
						}
					}
					
					Global.getCombatEngine().getCustomData().put("armaa_strikecraftRefitTime"+ship.getId(),DockingAI.getCarrierRefitRate());
					
				//	if(!(Global.getCombatEngine().getCustomData().get("armaa_strikecraftIntervalUtil"+ship.getId()) instanceof IntervalUtil))
				//	Global.getCombatEngine().getCustomData().put("armaa_strikecraftIntervalUtil"+ship.getId(),new IntervalUtil(20f,20f));

				//	float refitMod = (float)Global.getCombatEngine().getCustomData().get("armaa_strikecraftRefitTime"+ship.getId());
				//	IntervalUtil BASE_REFIT =(IntervalUtil)Global.getCombatEngine().getCustomData().get("armaa_strikecraftIntervalUtil"+ship.getId());
					
				//	float wepMalus = 0f;
				//	if(Global.getCombatEngine().getCustomData().get("armaa_strikecraftMissileMalus"+ship.getId()) instanceof Float)
				//		wepMalus = (float)Global.getCombatEngine().getCustomData().get("armaa_strikecraftMissileMalus"+ship.getId());
				//	float hullBonus = (float)Math.max(ship.getHullLevel()*1.5f,1f);
				//	float refitRate = (amount*hullBonus)*(1f-wepMalus)*refitMod;
				//	float adjustedRate = (float)Math.max(refitRate,amount*BaseTimer);
				//	Global.getCombatEngine().getCustomData().put("armaa_strikecraftAdjustedRefitTime"+ship.getId(),adjustedRate);
					
				//	BASE_REFIT.advance(adjustedRate);
					
				//	Global.getCombatEngine().getCustomData().put("armaa_strikecraftIntervalElapsed"+ship.getId(),BASE_REFIT.getElapsed());
				//	Global.getCombatEngine().getCustomData().put("armaa_strikecraftMaxInterval"+ship.getId(),BASE_REFIT.getMaxInterval());
					
				//	BASE_REFIT.setElapsed((float)Global.getCombatEngine().getCustomData().get("armaa_strikecraftIntervalElapsed"+ship.getId()));
					
				//	float refit_timer = Math.round(((float)Global.getCombatEngine().getCustomData().get("armaa_strikecraftIntervalElapsed"+ship.getId())/(float)Global.getCombatEngine().getCustomData().get("armaa_strikecraftMaxInterval"+ship.getId())) * 100f);
				//	String timer = String.valueOf(refit_timer);
				
					//if (player && BASE_REFIT.getElapsed() >= 0f) //Dislay count down timer
					//	Global.getCombatEngine().maintainStatusForPlayerShip("AceSystem", "graphics/ui/icons/icon_repair_refit.png","REFITTING ...", timer+"%" ,true);
					//if (BASE_REFIT.intervalElapsed()) 
					//{
						//DockingAI.advance(BaseTimer);
					//	BASE_REFIT = null;
					//	Global.getCombatEngine().getCustomData().put("armaa_strikecraftLanded"+ship.getId(),false);
					//	Global.getCombatEngine().getCustomData().put("armaa_strikecraftIntervalUtil"+ship.getId(),null);
					//	Global.getSoundPlayer().playSound("fighter_takeoff", 1f, 1f, ship.getLocation(),new Vector2f());
					//}
				}
			}
					
		}
				
		if(ship.getFluxTracker().isOverloaded())
		{
			if(textInterval.intervalElapsed())
			{
				Global.getSoundPlayer().playSound("emp_loop", 1f, 1f, ship.getLocation(), new Vector2f());
			float shipRadius = armaa_utils.effectiveRadius(ship);
			for (int i = 0; i < 2; i++) {
				Vector2f targetPoint = MathUtils.getRandomPointInCircle(ship.getLocation(), (shipRadius * 0.75f + 15f) * 1f);
				Vector2f anchorPoint = MathUtils.getRandomPointInCircle(ship.getLocation(), shipRadius);
				AnchoredEntity anchor = new AnchoredEntity(ship, anchorPoint);
				float thickness = (float) Math.sqrt(((shipRadius * 0.025f + 5f) * 1f) * MathUtils.getRandomNumberInRange(0.75f, 1.25f)) * 3f;
				Color coreColor = new Color(TEXT_COLOR.getRed(), TEXT_COLOR.getGreen(), TEXT_COLOR.getBlue(), 255);
				EmpArcEntityAPI arc = Global.getCombatEngine().spawnEmpArcPierceShields(ship, targetPoint, anchor, anchor, DamageType.ENERGY,
						0f, 0f, shipRadius, null, thickness, new Color(155,50,250,150), coreColor);
			}
				combatAlert(ship,null,"overload");
		}

			else textInterval.advance(1f);
		}

		if(ui != null)
		{
			if(canRetreat(ship) || ship.getHullLevel() < .05f || ship.getTravelDrive().isOn())
			{
				ship.setHullSize(HullSize.FRIGATE);
			}

			else
			{
				drawHud(ship);
				ship.setHullSize(HullSize.FIGHTER);
			}
		}
		
		if(ship.getOriginalOwner() == -1 || Global.getCombatEngine().isCombatOver() || Global.getCombatEngine().isPaused())
			ship.setHullSize(HullSize.FRIGATE);
    }

	@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, java.lang.String id)
	{
		ship.setHullSize(HullSize.FRIGATE);

	}

}

