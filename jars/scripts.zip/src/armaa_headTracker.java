package data.scripts.weapons;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.graphics.SpriteAPI;
import data.scripts.util.MagicAnim;
import data.scripts.util.MagicRender;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.Global;
import data.scripts.util.MagicRender;


public class armaa_headTracker implements EveryFrameWeaponEffectPlugin {

    private boolean runOnce = false, lockNloaded = false;
    private WeaponAPI lArm,rArm;
	public int frame = 7;
    private final IntervalUtil interval = new IntervalUtil(0.06f, 0.06f);

    public void init(WeaponAPI weapon)
    {
        runOnce = true;
		//need to grab another weapon so some effects are properly rendered, like lighting from glib
        for (WeaponAPI w : weapon.getShip().getAllWeapons()) 
		{
            switch (w.getSlot().getId()) {
                case "E_LARM":
                    if(lArm==null) {
                        lArm = w;
                    }
                    break;
                case "E_RARM":
                    if(rArm==null) {
                        rArm = w;
                    }
                    break;
            }
        }
    }
    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) 
	{
		if(!runOnce)
			init(weapon);
		ShipAPI ship = weapon.getShip();
		if(ship.getSelectedGroupAPI() == null)
			return;

		if(ship.getSelectedGroupAPI().getActiveWeapon() == lArm || ship.getSelectedGroupAPI().getActiveWeapon() == rArm)
			weapon.setCurrAngle(ship.getSelectedGroupAPI().getActiveWeapon().getCurrAngle());
    }
}
