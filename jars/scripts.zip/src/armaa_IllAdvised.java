package data.hullmods;

import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.campaign.ids.Stats;

public class armaa_IllAdvised extends BaseHullMod {

	private static final float RECOIL_MULT = 2f;
	private static final float WEAPON_MALFUNCTION_PROB = 0.05f;
	private static final float ENGINE_MALFUNCTION_PROB = 0.005f;
	
	public void advanceInCombat(ShipAPI ship, float amount)
    	{
		float effect = ship.getMutableStats().getDynamic().getValue(Stats.DMOD_EFFECT_MULT);
		
		ship.getMutableStats().getCriticalMalfunctionChance().modifyFlat(ship.getId(), 0.5f * effect);
		ship.getMutableStats().getWeaponMalfunctionChance().modifyFlat(ship.getId(), WEAPON_MALFUNCTION_PROB * effect);
		//stats.getEngineMalfunctionChance().modifyFlat(id, ENGINE_MALFUNCTION_PROB);
	}
	
	public String getDescriptionParam(int index, HullSize hullSize) {
		return null;
	}


}
