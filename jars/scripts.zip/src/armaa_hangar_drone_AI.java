package data.scripts.ai;

import data.scripts.util.armaa_utils;

import java.awt.Color;
import java.util.Iterator;
import java.util.List;
import java.util.ArrayList;
import java.util.Random;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;

import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.Point;
import org.lwjgl.util.vector.Vector2f;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.SoundAPI;
import com.fs.starfarer.api.combat.*;

import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipCommand;
import com.fs.starfarer.api.util.IntervalUtil;
//import com.fs.starfarer.combat.CombatEngine;
import com.fs.starfarer.combat.entities.Ship;
import com.fs.starfarer.api.combat.CombatTaskManagerAPI;

//based on code from Sundog's ICE repair drone and Dark.Revenant's Imperium Titan. Copied Maltese AI

public class armaa_hangar_drone_AI extends BaseShipAI {
	private final ShipwideAIFlags flags = new ShipwideAIFlags();
    private final ShipAIConfig config = new ShipAIConfig();
    
    public ShipAPI carrier;
	private float targetFacingOffset = Float.MIN_VALUE;
    private ShipAPI target;
    private Vector2f targetOffset;
    private boolean returning = false;
	private boolean rearm = false;
	private boolean hasbombingtarget = false;
	private ShipAPI parent;
	private WeaponAPI weapon;


    
    Vector2f getDestination() {
        return new Vector2f();
    }

    public armaa_hangar_drone_AI(ShipAPI ship, ShipAPI parent, WeaponAPI weapon) {
		super(ship);
		this.parent = parent;
		this.weapon = weapon;
		//super(ship);

	}

    @Override
    public void advance(float amount) {
		if(ship.getFluxLevel() >= .85f)
			rearm = true;
        goToDestination();
		 if(ship.isFinishedLanding())
			 Global.getCombatEngine().removeEntity(ship);

    }

    @Override
    public boolean needsRefit() 
	{						
        return true;
    }

    @Override
    public void cancelCurrentManeuver() {
    }

    @Override
    public void evaluateCircumstances() {

    }
    
    
    void goToDestination() 
	{
		Vector2f landingLoc = MathUtils.getRandomPointInCircle(parent.getLocation(),150f);
		if(!rearm && !parent.getFluxTracker().isOverloaded() && !parent.getFluxTracker().isVenting())
		{
			if(parent.getShipTarget()!= null)
			{
				if(MathUtils.getDistance(ship,parent.getShipTarget()) < ship.getAllWeapons().get(0).getRange())
				landingLoc = MathUtils.getRandomPointInCircle(parent.getShipTarget().getLocation(),ship.getAllWeapons().get(0).getRange());
			}
		}
			for( DamagingProjectileAPI proj : CombatUtils.getProjectilesWithinRange(ship.getLocation(), 100f))
			{
				if(proj.getOwner() == ship.getOwner())
					continue;
				
				if(proj.getOwner() != ship.getOwner())
				{
					landingLoc = MathUtils.getRandomPointInCircle(proj.getLocation(),200f);
					ship.useSystem();
				}
			}
		if(rearm)
		{
			if(parent.getShipTarget()!= null)
			{
				if(MathUtils.getDistance(ship,parent.getShipTarget()) < ship.getAllWeapons().get(0).getRange())
				landingLoc = MathUtils.getRandomPointInCircle(parent.getShipTarget().getLocation(),ship.getAllWeapons().get(0).getRange());
			}

			else
			{
				if(!hasbombingtarget)
					for(ShipAPI target :CombatUtils.getShipsWithinRange(ship.getLocation(), 1000f))
					{
						if(target.isFighter())
							continue;
						if(target.getOwner() == ship.getOwner())
							continue;
						ship.setShipTarget(target); 
						this.target = target;
						hasbombingtarget = true;
						landingLoc = MathUtils.getRandomPointInCircle(target.getLocation(),10f);

					}
			}
		}
        Vector2f to = landingLoc;
        float distance = MathUtils.getDistance(ship, to);
    	float distToCarrier = (float)(MathUtils.getDistanceSquared(parent.getLocation(),ship.getLocation()) / Math.pow(ship.getCollisionRadius(),2));

        if(target != null)
		{
			distToCarrier = (float)(MathUtils.getDistanceSquared(target.getLocation(),ship.getLocation()) / Math.pow(ship.getCollisionRadius(),2));
		}
    	if(distToCarrier < 15.0f && rearm) 
		{
			Global.getCombatEngine().spawnExplosion(ship.getLocation(), new Vector2f(), Color.red, 100f, 1f);
			Global.getCombatEngine().spawnExplosion(ship.getLocation(), new Vector2f(), Color.red, 50f, 1f);
			float bonusDamage = ship.getHitpoints();
			DamagingExplosionSpec blast = new DamagingExplosionSpec(0.1f,
					75f,
					50f,
					bonusDamage,
					bonusDamage/2f,
					CollisionClass.PROJECTILE_FF,
					CollisionClass.PROJECTILE_FIGHTER,
					10f,
					10f,
					0f,
					0,
					Color.red,
					null);
			blast.setDamageType(DamageType.ENERGY);
			blast.setShowGraphic(false);
			//WeaponAPI weapon = beam.getWeapon();
			Global.getCombatEngine().spawnDamagingExplosion(blast,ship,ship.getLocation(),false);			
			ship.setHitpoints(0f);
            float f= 1.0f-Math.min(1,distToCarrier);
            if(returning == false) f = f*0.1f;
            ship.getLocation().x = (to.x * (f*0.1f) + ship.getLocation().x * (2 - f*0.1f)) / 2;
            ship.getLocation().y = (to.y * (f*0.1f) + ship.getLocation().y * (2 - f*0.1f)) / 2;
			if(!ship.isLanding() && !ship.isFinishedLanding())
			ship.beginLandingAnimation(parent);

        }else {
        	targetFacingOffset = Float.MIN_VALUE;
            float angleDif = MathUtils.getShortestRotation(ship.getFacing(), VectorUtils.getAngle(ship.getLocation(), to));

            if(Math.abs(angleDif) < 30){
                accelerate();
            } else {
                turnToward(to);
                //decelerate();
            }        
            strafeToward(to);
			
        }		
    }

    @Override
    public ShipwideAIFlags getAIFlags() {
        return flags;
    }

    @Override
    public void setDoNotFireDelay(float amount) {
    }

    @Override
    public ShipAIConfig getConfig() {
        return config;
    }
    
    public void init() {
    	
			
    }
    
}
