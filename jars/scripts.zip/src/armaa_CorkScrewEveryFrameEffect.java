package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lwjgl.util.vector.Vector2f;
import org.lazywizard.lazylib.combat.CombatUtils;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.MathUtils;
import data.scripts.weapons.armaa_CorkScrewProjectileScript;

import java.util.Random;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;


public class armaa_CorkScrewEveryFrameEffect extends BaseCombatLayeredRenderingPlugin implements OnFireEffectPlugin,
																					OnHitEffectPlugin,
																					EveryFrameWeaponEffectPlugin {

    private int lastAmmo = 0;
	private boolean soundPlayed = false;
    private boolean windingUp = true;
    private IntervalUtil cockSound = new IntervalUtil(0.33f,0.38f);
    private IntervalUtil reloadTime = new IntervalUtil(2.8f,2.85f);
	private DamagingProjectileAPI  dummy;
    private List<DamagingProjectileAPI> alreadyRegisteredProjectiles = new ArrayList<DamagingProjectileAPI>();
	private int firedProj = 0;

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) 
	{
		if(weapon.getAmmo() == 0)
			firedProj = 0;

    }
	
		
	public void onHit(DamagingProjectileAPI projectile, CombatEntityAPI target, Vector2f point, boolean shieldHit, ApplyDamageResultAPI damageResult, CombatEngineAPI engine) 
	{
      
		
	}
	
    private static final int SMOKE_SIZE_MIN = 5;
    private static final int SMOKE_SIZE_MAX = 30;
	
	public void onFire(DamagingProjectileAPI projectile, WeaponAPI weapon, CombatEngineAPI engine) 
	{
		ShipAPI source = weapon.getShip();
		CombatEntityAPI target1 = null;
		firedProj++;
		
		if(source.getWeaponGroupFor(weapon)!=null ){
			//WEAPON IN AUTOFIRE
			if(source.getWeaponGroupFor(weapon).isAutofiring()  //weapon group is autofiring
					&& source.getSelectedGroupAPI()!=source.getWeaponGroupFor(weapon)){ //weapon group is not the selected group
				target1 = source.getWeaponGroupFor(weapon).getAutofirePlugin(weapon).getTargetShip();
			}
			else {
				target1 = source.getShipTarget();
			}
		}
		if(firedProj%2==0)
		{
			String weaponId = "armaa_leynosCorkScrew_kin";	
			DamagingProjectileAPI proj = (DamagingProjectileAPI)engine.spawnProjectile(weapon.getShip(),weapon,weaponId,projectile.getLocation(),projectile.getFacing(),weapon.getShip().getVelocity());
			engine.addPlugin(new armaa_CorkScrewProjectileScript(proj, target1));
			alreadyRegisteredProjectiles.add(proj);
			engine.removeEntity(projectile);
		}		
		else if(projectile.getWeapon() == weapon && !alreadyRegisteredProjectiles.contains(projectile) && engine.isEntityInPlay(projectile) && !projectile.didDamage()) 
		{
			engine.addPlugin(new armaa_vajraProjectileScript(projectile, target1));
			alreadyRegisteredProjectiles.add(projectile);
		}
		
		List<DamagingProjectileAPI> cloneList = new ArrayList<>(alreadyRegisteredProjectiles);
		for (DamagingProjectileAPI proj : cloneList) {
			if (!engine.isEntityInPlay(proj) || proj.didDamage()) {
				alreadyRegisteredProjectiles.remove(proj);
			}
		}		
	}

}