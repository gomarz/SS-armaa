package data.scripts.weapons;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.graphics.SpriteAPI;
import data.scripts.util.MagicAnim;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.FaderUtil;

/**
 *Base script by
 * Tartiflette
 * additional modifications by shoi
 */
public class armaa_VXEffect implements EveryFrameWeaponEffectPlugin {

    private boolean runOnce = false, lockNloaded = false;
    private ShipSystemAPI system;
    private ShipAPI ship;
    private SpriteAPI sprite;
    private AnimationAPI anim, aGlow, aGlow2;
    private WeaponAPI head, armL, armR, pauldronL, pauldronR, torso,vernier,gun, shoulderwep, headGlow;	
    private final Vector2f ZERO = new Vector2f();
    private int limbInit = 0;
	
	private float swingLevel = 0f;
	private boolean swinging = false;
	private boolean cooldown = false;
	
		private float swingLevelR = 0f;
	private boolean swingingR = false;
	private boolean cooldownR = false;
	private IntervalUtil animInterval = new IntervalUtil(0.012f, 0.012f);

    private float overlap = 0, heat = 0, originalRArmPos = 0f, originalArmPos = 0f, originalShoulderPos = 0f, originalVernierPos = 0f;
    private final float TORSO_OFFSET = -45, LEFT_ARM_OFFSET = -60, RIGHT_ARM_OFFSET = -25, MAX_OVERLAP = 10, LPAULDRONOFFSET = -5;

    public void init()
    {
        runOnce = true;
        for (WeaponAPI w : ship.getAllWeapons()) {
            switch (w.getSlot().getId()) {
                case "A_GUN":
                    if(gun==null) {
                        gun = w;
						if(w.getBarrelSpriteAPI() != null)
						originalRArmPos = w.getBarrelSpriteAPI().getCenterY();
                        limbInit++;
                    }
                    break;
                case "C_ARML":
                    if(armL==null) {
                        armL = w;
						originalArmPos = armL.getSprite().getCenterY();
                        limbInit++;
                    }
                    break;
                case "C_ARMR":
                    if(armR==null) {
                        armR = w;
                        limbInit++;
                    }
                    break;
                case "D_PAULDRONL":
                    if(pauldronL == null) {
                        pauldronL = w;
						originalShoulderPos = pauldronL.getSprite().getCenterY();
                        limbInit++;
                    }
                    break;
                case "D_PAULDRONR":
                    if(pauldronR == null) {
                        pauldronR = w;
                        limbInit++;
                    }
                    break;
                case "E_HEAD":
                    if(head == null) {
                        head = w;
                        limbInit++;
                    }
                    break;
				case "WS001":
                   		shoulderwep = w;
                    break;
				case "H_GLOW":
                   		headGlow = w;
                    break;
            }
        }
    }
    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) 
	{

        ship = weapon.getShip();
        sprite = ship.getSpriteAPI();
        system = ship.getSystem();
		
		if(!runOnce)
        init();
		if(gun == null) return;
		if(engine.isPaused())
			return;
        anim = gun.getAnimation();
		ship.syncWeaponDecalsWithArmorDamage();
		
		if (ship.getEngineController().isAccelerating()) {
			if (overlap > (MAX_OVERLAP - 0.1f)) {
				overlap = MAX_OVERLAP;
			} else {
				overlap = Math.min(MAX_OVERLAP, overlap + ((MAX_OVERLAP - overlap) * amount * 5));
			}
		} else if (ship.getEngineController().isDecelerating() || ship.getEngineController().isAcceleratingBackwards()) {
			if (overlap < -(MAX_OVERLAP - 0.1f)) {
				overlap = -MAX_OVERLAP;
			} else {
				overlap = Math.max(-MAX_OVERLAP, overlap + ((-MAX_OVERLAP + overlap) * amount * 5));
			}
		} else {
			if (Math.abs(overlap) < 0.1f) {
				overlap = 0;
			} else {
				overlap -= (overlap / 2) * amount * 3;
			}
		}

		float sineA = 0, sinceB = 0, sineC=0, sinceD=0;	
		float global = ship.getFacing();
		float aim = MathUtils.getShortestRotation(global, gun.getCurrAngle());
		float aim2 = MathUtils.getShortestRotation(global, armL.getCurrAngle());
		boolean noanim = false;
		if(armL.getSpec().getWeaponId().equals("armaa_aleste_rifle_left") || armL.getSpec().getWeaponId().equals("armaa_aleste_grenade_left"))
			noanim  = true;
		if(armL != null && !noanim)
		{
			if(armL.getChargeLevel()<1)
			{
				sineA=MagicAnim.SO(armL.getChargeLevel(),0.3f,0.9f);
				sinceB=MagicAnim.SO(armL.getChargeLevel(),0.3f,1f);
			} 
			else 
			{                
				sineA =1;
				sinceB =1;
			}
			armL.getSprite().setCenterY(originalArmPos-(16*sinceB));
		}

		if (armR != null)
		{
			armR.setCurrAngle(gun.getCurrAngle() + RIGHT_ARM_OFFSET);
//
			if(gun.getChargeLevel()<1)
			{
				sineC=MagicAnim.SO(gun.getChargeLevel(),0.3f,0.9f);
				sinceD=MagicAnim.SO(gun.getChargeLevel(),0.3f,1f);
			} 
			else 
			{                
				sineC =1;
				sinceD =1;
			}


		}			
//
		if (pauldronR != null)
		{
			pauldronR.setCurrAngle(global + sineA * (TORSO_OFFSET-(TORSO_OFFSET*(swingLevel/9f))) * 0.5f + aim * 0.75f + RIGHT_ARM_OFFSET * 0.5f);
			if(gun.getBarrelSpriteAPI() != null)
			pauldronR.getSprite().setCenterY(gun.getBarrelSpriteAPI().getCenterY()-40f);
		}
	
		if (pauldronL != null)
		{
			if(armL != null)
			pauldronL.setCurrAngle(global + sineA * TORSO_OFFSET * 0.5f + aim2 * 0.75f - RIGHT_ARM_OFFSET * 0.5f);
			pauldronL.getSprite().setCenterY(originalShoulderPos-(8*sinceB));
		}
		
		if(headGlow != null)
		{
			headGlow.setCurrAngle(head.getCurrAngle());
		}
    }
}
