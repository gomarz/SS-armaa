package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipEngineControllerAPI.ShipEngineAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import data.scripts.util.MagicIncompatibleHullmods;
import data.scripts.util.MagicUI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import org.lazywizard.lazylib.FastTrig;
import org.lwjgl.util.vector.Vector2f;
import data.scripts.util.MagicRender;
import com.fs.starfarer.api.graphics.SpriteAPI;
import java.awt.*;
import java.util.*; 
import java.util.List;
import java.util.Collection;
//import java.util.Set;
import org.lazywizard.lazylib.combat.CombatUtils;

public class armaa_KarmaMod_Command extends BaseHullMod 
{

	protected float karma = 0;
	private static final float BONUS_AMT = 30f;
	protected static int karmaThreshold = 2000;
	private static final Color AFTERIMAGE_COLOR = new Color(149, 206, 240, 102);
	private static final float AFTERIMAGE_THRESHOLD = 0.4f;
	private static final List<String> SAFE_MODS = new ArrayList<>();
	private List<ShipAPI> targets = new ArrayList<>();
	private List<ShipAPI> toRemove = new ArrayList<>();

    static 
	{
        /* No shields on my modules */
        SAFE_MODS.add("armaa_legmodule");
        SAFE_MODS.add("reduced_explosion");
		SAFE_MODS.add("always_detaches");
        SAFE_MODS.add("novent");
        SAFE_MODS.add("leg_engine");
	}


    @Override
    public void advanceInCombat(ShipAPI ship, float amount) 
	{
		
		if(!(Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?"+ship.getId()) instanceof Boolean))
		{
			//boolean value = (boolean)Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?"+ship.getId());
		
			//Global.getCombatEngine().maintainStatusForPlayerShip(ship.getId(), "graphics/icons/hullsys/entropy_amplifier.png","DEBUG",(Boolean.toString(value)), false);
		Global.getCombatEngine().getCustomData().put("armaa_hullmodsDone?"+ship.getId(),false);

		}
		
		if(Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?"+ship.getId()) instanceof Boolean)
		{
			//if((boolean)Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?"+ship.getId()) != true)
			//Global.getCombatEngine().maintainStatusForPlayerShip(ship.getId(), "graphics/icons/hullsys/entropy_amplifier.png","DEBUG","TRUE", false);	
			if((boolean)Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?"+ship.getId()) != true)
			{
				List<ShipAPI> children = ship.getChildModulesCopy();
				if(children != null && !children.isEmpty()) 
				{
					for (ShipAPI module : children) 
					{
						module.ensureClonedStationSlotSpec();

						Collection<String> hmods = ship.getVariant().getHullMods();
						List<String> hmod = new ArrayList<>();
						hmod.addAll(hmods);
						
						Collection<String> mhmods = module.getVariant().getHullMods();
						List<String> mhmod = new ArrayList<>();
						mhmod.addAll(mhmods);
						mhmod.removeAll(SAFE_MODS);


						if(hmods.isEmpty())
							continue;
						for(int i = 0; i < hmod.size();i++)
						{
							if(!module.getVariant().hasHullMod(hmod.get(i)))
							{
								module.getVariant().addMod(hmod.get(i));
							}
						}
						if(mhmod.isEmpty())
							continue;
						for(int i = 0; i < mhmod.size();i++)
						{
							if(!ship.getVariant().hasHullMod(mhmod.get(i)))
							{
								module.getVariant().removeMod(mhmod.get(i));
							}
						}
					}
					Global.getCombatEngine().getCustomData().put("armaa_hullmodsDone?"+ship.getId(),true);
					Global.getCombatEngine().getCustomData().put("armaa_hullmodsDoneCheck"+ship.getId(),true);
				}
			}
		
		}
				
		if(Global.getCombatEngine().getCustomData().get("armaa_karmaTotal"+ship.getId()) instanceof Float)
		{
			String id = "armaa_karma"+ship.getId();
			float total = (float)Global.getCombatEngine().getCustomData().get("armaa_karmaTotal"+ship.getId());
			float mult = total * BONUS_AMT;
			//nearbyShips = CombatUtils.getShipsWithinRange(ship.getLocation(), 1000f);
			
			if(total > 0)
			{
				for (ShipAPI target : CombatUtils.getShipsWithinRange(ship.getLocation(), 1000f))
				{	
					if(target.getOwner() != ship.getOwner()) continue;
					
					else if(target.isHulk()) continue;
					
					else
					{
						targets.add(target);
					}
				}
				
				for (ShipAPI target : targets)
				{
					//if CombatUtils.getShipsWithinRange
					boolean player = target == Global.getCombatEngine().getPlayerShip();
					MutableShipStatsAPI stats = target.getMutableStats();
					
					if (player)
					{
						Global.getCombatEngine().maintainStatusForPlayerShip(ship.getId(), "graphics/icons/hullsys/entropy_amplifier.png", "Enlightened","+"+(int)mult+"% WEP ROF / " + "-"+(int)mult+"% WEP FLUX COST", false);		
					}
					
					stats.getTimeMult().modifyMult(id,1f+(1.50f-1f)*total);
					if(player)
					{
						Global.getCombatEngine().getTimeMult().modifyMult(id, 1f/3.55f);
					}
					stats.getEnergyRoFMult().modifyPercent(id, mult);
				
					stats.getBallisticWeaponFluxCostMod().modifyPercent(id, -mult);
					stats.getEnergyWeaponFluxCostMod().modifyPercent(id, -mult);
				
					//afterimage shit from tahlan
					target.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerNullerID", -1);
					target.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerID",
					target.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() + amount);
				
					if (target.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() > AFTERIMAGE_THRESHOLD) 
					{

						// Sprite offset fuckery - Don't you love trigonometry?
						SpriteAPI sprite = target.getSpriteAPI();
						float offsetX = sprite.getWidth()/2 - sprite.getCenterX();
						float offsetY = sprite.getHeight()/2 - sprite.getCenterY();

						float trueOffsetX = (float)FastTrig.cos(Math.toRadians(ship.getFacing()-90f))*offsetX - (float)FastTrig.sin(Math.toRadians(ship.getFacing()-90f))*offsetY;
						float trueOffsetY = (float)FastTrig.sin(Math.toRadians(ship.getFacing()-90f))*offsetX + (float)FastTrig.cos(Math.toRadians(ship.getFacing()-90f))*offsetY;
						if(!ship.isHulk())
						{
							MagicRender.battlespace(
									Global.getSettings().getSprite(target.getHullSpec().getSpriteName()),
									new Vector2f(target.getLocation().getX()+trueOffsetX,target.getLocation().getY()+trueOffsetY),
									new Vector2f(0, 0),
									new Vector2f(target.getSpriteAPI().getWidth(), target.getSpriteAPI().getHeight()),
									new Vector2f(0, 0),
									target.getFacing()-90f,
									0f,
									AFTERIMAGE_COLOR,
									true,
									0.1f,
									0.1f,
									1f,
									CombatEngineLayers.BELOW_SHIPS_LAYER);
						}
								
						for(ShipAPI m:target.getChildModulesCopy())
						{
							if(m != null && Global.getCombatEngine().isEntityInPlay(m))
							{
								float modtrueOffsetX = (float)FastTrig.cos(Math.toRadians(m.getFacing()-90f))*offsetX - (float)FastTrig.sin(Math.toRadians(m.getFacing()-90f))*offsetY;
								float modtrueOffsetY = (float)FastTrig.sin(Math.toRadians(m.getFacing()-90f))*offsetX + (float)FastTrig.cos(Math.toRadians(m.getFacing()-90f))*offsetY;

								MagicRender.battlespace(
									Global.getSettings().getSprite(m.getHullSpec().getSpriteName()),
									new Vector2f(m.getLocation().getX()+modtrueOffsetX,m.getLocation().getY()+modtrueOffsetY),
									new Vector2f(0, 0),
									new Vector2f(m.getSpriteAPI().getWidth(), m.getSpriteAPI().getHeight()),
									new Vector2f(0, 0),
									m.getFacing()-90f,
									0f,
									AFTERIMAGE_COLOR,
									true,
									0.1f,
									0.1f,
									1f,
									CombatEngineLayers.BELOW_SHIPS_LAYER);
							}
							
						}

						target.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerID",
						target.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() - AFTERIMAGE_THRESHOLD);
					}	
					
				//	toRemove.add(target);
				}
			}
			
			List<ShipAPI> shipsinRange = CombatUtils.getShipsWithinRange(ship.getLocation(), 1000f);
			//List<ShipAPI> outofrange = toRemove;

				for(ShipAPI s:targets)
				{
										boolean player = s == Global.getCombatEngine().getPlayerShip();
					MutableShipStatsAPI stats = s.getMutableStats();

					if(!shipsinRange.contains(s) || total <= 0)
					{
						stats.getBallisticRoFMult().unmodify(id);
						stats.getEnergyRoFMult().unmodify(id);
				
						stats.getBallisticWeaponFluxCostMod().unmodify(id);
						stats.getEnergyWeaponFluxCostMod().unmodify(id);
						stats.getTimeMult().unmodify(id);
						if(player)
						Global.getCombatEngine().getTimeMult().unmodify(id);
					
						toRemove.add(s);
					}

				}

				targets.removeAll(toRemove);
			
			MagicUI.drawSystemBar(
				ship,
				Color.red,
				total,
				0f
				);
				
				
		}
		
		if(Global.getCombatEngine().getCustomData().get("armaa_hasGainedKarma"+ship.getId()) instanceof Boolean)
			if((boolean)Global.getCombatEngine().getCustomData().get("armaa_hasGainedKarma"+ship.getId()))
			{
				float value = (float)Global.getCombatEngine().getCustomData().get("armaa_gainedKarmaAount"+ship.getId());
				//addKarma(value);
				
				if(Global.getCombatEngine().getCustomData().get("armaa_karmaTotal"+ship.getId()) instanceof Float)
				{
					float oldTotal = (float)Global.getCombatEngine().getCustomData().get("armaa_karmaTotal"+ship.getId());
					float newTotal = oldTotal+value;
					Global.getCombatEngine().getCustomData().put("armaa_karmaTotal"+ship.getId(),newTotal);
					
				}
				
				Global.getCombatEngine().getCustomData().put("armaa_hasGainedKarma"+ship.getId(),false);
				Global.getCombatEngine().getCustomData().put("armaa_gainedKarmaAount"+ship.getId(),0f);
			}
			
		
	}

    

	@Override
	public void applyEffectsAfterShipCreation(ShipAPI ship, String id) 
	{
		if(Global.getCombatEngine() != null)
		{
			Global.getCombatEngine().getCustomData().put("armaa_hullmodsDone?"+ship.getId(),false);

			Global.getCombatEngine().getCustomData().put("armaa_karmaTotal"+ship.getId(),0f);
		}
	}
	
	public static void addKarma(float value)
	{
		//karma = karma + value;
	}
	
	public static float getKarma(String id)
	{
		float value = 0f;
				if(Global.getCombatEngine().getCustomData().get("armaa_karmaTotal"+id) instanceof Float)
				{
					value = (float)Global.getCombatEngine().getCustomData().get("armaa_karmaTotal"+id);					
				}
		return value;
	}
	
	public static float getKarmaThreshold()
	{
		return karmaThreshold;
	}
	
}

