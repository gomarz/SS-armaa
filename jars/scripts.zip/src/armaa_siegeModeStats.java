package data.scripts.shipsystems;

import java.util.HashMap;
import java.util.Map;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;

public class armaa_siegeModeStats extends BaseShipSystemScript {

	public static final float SENSOR_RANGE_PERCENT = 50f;
	public static final float WEAPON_RANGE_PERCENT = 50f;
	public static float shieldArc = 0f;
	public boolean runOnce = false;
	
	public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
		
		if(!runOnce)
		{
			if(stats.getEntity().getShield().getArc() != 0)
			{
				shieldArc=stats.getEntity().getShield().getArc();
				runOnce = true;
			}
		}
		
		float sensorRangePercent = SENSOR_RANGE_PERCENT * effectLevel;
		float weaponRangePercent = WEAPON_RANGE_PERCENT * effectLevel;
		
		stats.getSightRadiusMod().modifyPercent(id, sensorRangePercent);
		stats.getMaxSpeed().modifyPercent(id,-40f);
		stats.getMaxTurnRate().modifyPercent(id,-50f);
		float arc = shieldArc*2*effectLevel;
		if(stats.getEntity().getShield().getArc() < shieldArc)
			arc = shieldArc;
		stats.getEntity().getShield().setArc(arc); 
		stats.getBallisticWeaponRangeBonus().modifyPercent(id, weaponRangePercent);
		stats.getEnergyWeaponRangeBonus().modifyPercent(id, weaponRangePercent);
		stats.getAutofireAimAccuracy().modifyFlat(id, (1f/3f) * effectLevel);
		
		stats.getShieldDamageTakenMult().modifyMult(id, 1f - .1f * effectLevel);		
		stats.getShieldUpkeepMult().modifyMult(id, 0f);
	}
	public void unapply(MutableShipStatsAPI stats, String id) {
		stats.getSightRadiusMod().unmodify(id);
		
		stats.getBallisticWeaponRangeBonus().unmodify(id);
		stats.getEnergyWeaponRangeBonus().unmodify(id);
		stats.getMaxSpeed().unmodify(id);
		stats.getMaxTurnRate().unmodify(id);
		stats.getShieldArcBonus().unmodify(id);
		stats.getShieldDamageTakenMult().unmodify(id);
		stats.getShieldUnfoldRateMult().unmodify(id);
		stats.getShieldUpkeepMult().unmodify(id);
		stats.getAutofireAimAccuracy().unmodify(id);		
		if(stats.getEntity().getShield().getArc() < shieldArc)
			stats.getEntity().getShield().setArc(shieldArc); 
		
	}
	
	public StatusData getStatusData(int index, State state, float effectLevel) {
		float sensorRangePercent = SENSOR_RANGE_PERCENT * effectLevel;
		float weaponRangePercent = WEAPON_RANGE_PERCENT * effectLevel;
		if (index == 0) {
			return new StatusData("SHIELD DAMAGE TAKEN REDUCED BY +" + (int) sensorRangePercent + "%", false);
		} else if (index == 1) {
			//return new StatusData("increased energy weapon range", false);
			return null;
		} else if (index == 2) {
			return new StatusData("WPN/SENSOR range +" + (int) weaponRangePercent + "%", false);
		}
		return null;
	}
	
}
