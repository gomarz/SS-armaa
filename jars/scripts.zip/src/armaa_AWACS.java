package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.impl.campaign.ids.Skills;
import java.awt.*;

import java.util.*;
import java.util.List;
import com.fs.starfarer.api.combat.MissileAPI;

import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;

import static org.lwjgl.opengl.GL11.*;

public class armaa_AWACS implements EveryFrameWeaponEffectPlugin {
    private static final float[] COLOR_NORMAL = {255f / 255f, 100f / 255f, 20f / 255f};
    private static final float MAX_JITTER_DISTANCE = 0.2f;
    private static final float MAX_OPACITY = 1f;
    private static final float RANGE_BOOST = 100f;
    private static final float DAMAGE_MALUS = .80f;
    private static float EFFECT_RANGE = 2000f;
   //public static final String SPRITE_PATH = "graphics/fx/eis_revengeance.png";
    public static final float ROTATION_SPEED = 5f;
    public static final Color COLOR = new Color(15, 215, 55, 200);
	private static final String AWACS_ID = "AWACS_ID";	   
    //private final boolean basedonwhat = Global.getSettings().getBoolean("VengeanceSFX");
    //private boolean loaded = false;
    private float rotation = 0f;
    private float opacity = 0f;
    private SpriteAPI sprite = Global.getSettings().getSprite("misc", "eis_ceylonrad");
	private List<ShipAPI> targetList = new ArrayList<ShipAPI>();
	private List<ShipAPI> enemyList = new ArrayList<ShipAPI>();
	//private List<ShipAPI> mList = new ArrayList<MissileAPI>();
    private static final EnumSet<WeaponAPI.WeaponType> WEAPON_TYPES = EnumSet.of(WeaponAPI.WeaponType.MISSILE,WeaponAPI.WeaponType.BALLISTIC,WeaponAPI.WeaponType.ENERGY);

    private IntervalUtil interval = new IntervalUtil(0.05f,0.1f);

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) 
	{
        if (engine == null || !engine.isUIShowingHUD() || engine.isUIShowingDialog() || engine.getCombatUI().isShowingCommandUI()) {
            return;
        }
        
        ShipAPI ship = weapon.getShip();
        if (ship == null) {
            return;
        }
			//if(!ship.getAllWings().isEmpty())
			//Global.getCombatEngine().maintainStatusForPlayerShip("adrenal", "graphics/ui/icons/icon_search_and_destroy.png","Wing Members","" +ship.getAllWings().get(0).getWingMembers().size(),false);
			//Global.getCombatEngine().maintainStatusForPlayerShip("adrenal2", "graphics/ui/icons/icon_search_and_destroy.png","Grazed","DMG +" + (int)(GRAZE_DAMAGE_BONUS*(1f-effectLevel))+"%",false);
        float effectLevel = ship.getAllWings().isEmpty() ? 0.25f : Math.max(0.25f,ship.getAllWings().get(0).getWingMembers().size()/ ship.getAllWings().get(0).getSpec().getNumFighters());

		if(!ship.getAllWings().isEmpty())
			Global.getCombatEngine().maintainStatusForPlayerShip("adrenal", "graphics/ui/icons/icon_search_and_destroy.png","Wing Members","" +ship.getAllWings().get(0).getWingMembers().size()/ ship.getAllWings().get(0).getSpec().getNumFighters(),false);

        boolean player = ship == engine.getPlayerShip();
	
        if (ship.getSystem().isActive() || !player || ship.isHulk() || ship.isPiece() || !ship.isAlive() || ship.getSystem().isOutOfAmmo()) {
            opacity = Math.max(0f,opacity-2f*amount);
        } else {
            opacity = Math.min(1f,opacity+4f*amount);
        }

        final Vector2f loc = ship.getLocation();
        final ViewportAPI view = Global.getCombatEngine().getViewport();
        if (view.isNearViewport(loc, EFFECT_RANGE*effectLevel)) {
            glPushAttrib(GL_ENABLE_BIT);
            glMatrixMode(GL_PROJECTION);
            glPushMatrix();
            glViewport(0, 0, Display.getWidth(), Display.getHeight());
            glOrtho(0.0, Display.getWidth(), 0.0, Display.getHeight(), -1.0, 1.0);
            glEnable(GL_TEXTURE_2D);
            glEnable(GL_BLEND);
            float scale = Global.getSettings().getScreenScaleMult();
            float adjustedRange = ship.getMutableStats().getSystemRangeBonus().computeEffective(EFFECT_RANGE*effectLevel);
            if (ship.isFrigate() || ship.isDestroyer()) {adjustedRange *= 0.75;}
            float radius = ((adjustedRange+ship.getCollisionRadius()) * 2f * scale / view.getViewMult());
            sprite.setSize(radius, radius);
		
            sprite.setColor(ship.getOwner() == 0 ? COLOR : new Color(215,21,16,186));
            sprite.setAdditiveBlend();
            sprite.setAlphaMult(0.4f*opacity);
            sprite.renderAtCenter(view.convertWorldXtoScreenX(loc.x) * scale, view.convertWorldYtoScreenY(loc.y) * scale);
            sprite.setAngle(rotation);
            glPopMatrix();
            glPopAttrib();
        }

        // We can just jump out here. Stops the rotation while paused and none of the other stuff needs to run while paused
        if (Global.getCombatEngine().isPaused()) {
            return;
        }

        // Spin it
        rotation += ROTATION_SPEED * amount;
        if (rotation > 360f){
            rotation -= 360f;
        }

        for (ShipAPI target : CombatUtils.getShipsWithinRange(ship.getLocation(), EFFECT_RANGE*effectLevel)) 
		{
			if (target.getOwner() == ship.getOwner() && !targetList.contains(target))
			{
				targetList.add(target);
			}
			
			else if (target.getOwner() != ship.getOwner() && !target.isHulk() && !enemyList.contains(target))
			{
				enemyList.add(target);
			}
        }
		
        List<ShipAPI> purgeList = new ArrayList<ShipAPI>();
        for (ShipAPI target : targetList) 
		{
            if (MathUtils.getDistance(target.getLocation(), ship.getLocation()) <= EFFECT_RANGE*effectLevel) 
			{
				if(!ship.getVariant().hasHullMod("fourteenth"))
				{
					target.getMutableStats().getEnergyWeaponRangeBonus().modifyFlat(AWACS_ID, RANGE_BOOST);
					target.getMutableStats().getBallisticWeaponRangeBonus().modifyFlat(AWACS_ID, RANGE_BOOST);
				}
					
				else
				{
					target.getMutableStats().getMaxSpeed().modifyPercent(AWACS_ID,15f); 
				}
				
				if(ship.getSystem() != null && ship.getSystem().isActive())
				{
					///target.getMutableStats().getAutofireAimAccuracy().modifyFlat(AWACS_ID, AUTOAIM_BONUS * 0.01f);
					///target.getMutableStats().getProjectileSpeedMult().modifyPercent(AWACS_ID, SPEED_BOOST);
				}

                target.setWeaponGlow(0.7f,COLOR, WEAPON_TYPES);

            } 
			else 
			{
                target.getMutableStats().getEnergyWeaponRangeBonus().unmodify(AWACS_ID);
                target.getMutableStats().getBallisticWeaponRangeBonus().unmodify(AWACS_ID);
                target.getMutableStats().getAutofireAimAccuracy().unmodify(AWACS_ID);
                target.getMutableStats().getProjectileSpeedMult().unmodify(AWACS_ID);
                target.getMutableStats().getMaxSpeed().unmodify(AWACS_ID);
                target.setWeaponGlow(0f,COLOR, WEAPON_TYPES);
                purgeList.add(target);
            }

        }
		if(ship.getSystem() != null && ship.getSystem().isActive())
		{
			for (MissileAPI m : CombatUtils.getMissilesWithinRange(ship.getLocation(), EFFECT_RANGE*effectLevel)) 
			{
				if (m.getOwner() != ship.getOwner())
				{
					m.getVelocity().setX(m.getVelocity().x/2);
					m.getVelocity().setY(m.getVelocity().y/2);					
				}
			}
			
			for (ShipAPI target : enemyList) 
			{
				if (MathUtils.getDistance(target.getLocation(), ship.getLocation()) <= EFFECT_RANGE*effectLevel) 
				{
			
					if(!ship.getVariant().hasHullMod("fourteenth"))
					{
						target.getMutableStats().getEnergyWeaponDamageMult().modifyMult(AWACS_ID, DAMAGE_MALUS);
						target.getMutableStats().getBallisticWeaponDamageMult().modifyMult(AWACS_ID, DAMAGE_MALUS);
						target.getMutableStats().getMissileWeaponDamageMult().modifyMult(AWACS_ID, DAMAGE_MALUS);					
					}
					target.setWeaponGlow(0.7f,COLOR, WEAPON_TYPES);
				} 
				
				else 
				{
					target.getMutableStats().getEnergyWeaponDamageMult().unmodify(AWACS_ID);
					target.getMutableStats().getBallisticWeaponDamageMult().unmodify(AWACS_ID);
					target.getMutableStats().getMissileWeaponDamageMult().unmodify(AWACS_ID);

					purgeList.add(target);
				}
			}
		}
		
        for (ShipAPI purge : purgeList) {
			targetList.remove(purge);
        }

    }
}