package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import org.lwjgl.util.vector.Vector2f;
import org.lazywizard.lazylib.MathUtils;
import java.awt.Color;
import org.lazywizard.lazylib.VectorUtils;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.util.MagicRender;
import data.scripts.util.MagicLensFlare;



import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;

public class armaa_fluxBeamEffect implements EveryFrameWeaponEffectPlugin{ 
    // -- stuff for tweaking particle characteristics ------------------------
    // color of spawned particles
    private static final Color PARTICLE_COLOR = new Color(50,142,255,255);
    // size of spawned particles (possibly in pixels?)
    private static final float PARTICLE_SIZE = 5f;
    // brightness of spawned particles (i have no idea what this ranges from)
    private static final float PARTICLE_BRIGHTNESS = 150f;
    // how long the particles last (i'm assuming this is in seconds)
    private static final float PARTICLE_DURATION = 2f;
    private static final int PARTICLE_COUNT = 6;

    // -- particle geometry --------------------------------------------------
    // cone angle in degrees
    private static final float CONE_ANGLE = 150f;
    // constant that effects the lower end of the particle velocity
    private static final float VEL_MIN = 0.1f;
    // constant that effects the upper end of the particle velocity
    private static final float VEL_MAX = 0.3f;

    // one half of the angle. used internally, don't mess with thos
    private static final float A_2 = CONE_ANGLE / 2;

    @Override
    public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) 
	{
		if(engine.isPaused() || weapon.getShip().getOriginalOwner()==-1)
		{
			
		if(MagicRender.screenCheck(0.2f, point))
		{
			MagicLensFlare.createSharpFlare(
					engine,
					projectile.getSource(),
					point,
					6,
					300,
					0,
					new Color(50,142,255),
					new Color(255,20,255)
					);

            float speed = projectile.getVelocity().length();
            float facing = projectile.getFacing();
			
            for (int i = 0; i <= PARTICLE_COUNT; i++)
            {
                float angle = MathUtils.getRandomNumberInRange(facing - A_2,
                        facing + A_2);
                float vel = MathUtils.getRandomNumberInRange(speed * -VEL_MIN,
                        speed * -VEL_MAX);
                Vector2f vector = MathUtils.getPointOnCircumference(null,
                        vel,
                        angle);
                engine.addHitParticle(point,
                        vector,
                        PARTICLE_SIZE,
                        PARTICLE_BRIGHTNESS,
                        PARTICLE_DURATION,
                        PARTICLE_COLOR);
            }
	}
			
		}
			
		
	
	
	}
