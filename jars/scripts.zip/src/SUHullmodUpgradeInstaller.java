package data.scripts.everyframe;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.SpecialItemData;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.EveryFrameScript;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import data.hullmods.SUCorruptedNanoforgeUpgrades;
import data.hullmods.SUPristineNanoforgeUpgrades;
import data.hullmods.SUHypershuntTapUpgrades;
import data.hullmods.SUCatalyticCoreUpgrades;
import data.hullmods.SUPlasmaDynamoUpgrades;
import data.hullmods.SUCryoarithmeticEngineUpgrades;
import data.hullmods.SUCombatDroneReplicatorUpgrades;
import data.hullmods.SUSynchrotonCoreUpgrades;
import data.hullmods.SUSoilNanitesUpgrades;
import data.hullmods.SUMantleBoreUpgrades;
import data.hullmods.SUFusionLampUpgrades;
import data.hullmods.SUBiofactoryEmbryoUpgrades;
import data.hullmods.SUFullereneSpoolUpgrades;
import data.hullmods.SUDealmakerHolosuiteUpgrades;
import data.hullmods.SUAlphaCoreUpgrades;
import data.hullmods.SUBetaCoreUpgrades;
import data.hullmods.SUGammaCoreUpgrades;
import org.apache.log4j.Logger;
// imagine using abstract again for this travesty
@SuppressWarnings("MismatchedReadAndWriteOfArray") // (lol)
public class SUHullmodUpgradeInstaller extends BaseEveryFrameCombatPlugin implements EveryFrameScript {
//. 　　　。　　　　•　 　ﾟ　　。 　　.   。　. .
//
//　　　.　　　 　　.　　　　　。　　 。　. 　 。　.
//
//.　　 。　　　　　 ඞ 。 . 　　 • 　　　　•
//
//　　ﾟ　　 techpriest was not An Impostor.　 。　.
//
//　　'　　　     2 Impostors remain 　 　　。
//
//　　ﾟ　　　.　　　. ,　　　　.　 .	
//////////////////////////////////////////////////////
    private static final Logger Log = Logger.getLogger(SUHullmodUpgradeInstaller.class);    
    public static final int NOT_PLAYER = 0;
    public static final int IS_PLAYER = 1;
    public static final int HAS_HULLMOD = 2;
    public static final int CORRUPTED_NANOFORGE = 0;
    public static final int PRISTINE_NANOFORGE = 1;
    public static final int HYPERSHUNT_TAP = 2;
    public static final int CATALYTIC_CORE = 3;
    public static final int PLASMA_DYNAMO = 4;
    public static final int CRYOARITHMETHIC_ENGINE = 5;
    public static final int COMBATDRONE_REPLICATOR = 6;
    public static final int SYNCHROTON_CORE = 7;
    public static final int SOIL_NANITES = 8;
    public static final int MANTLE_BORE = 9;
    public static final int FUSION_LAMP = 10;
    public static final int BIOFACTORY_EMBRYO = 11;
    public static final int FULLERENE_SPOOL = 12;
    public static final int DEALMAKER_HOLOSUITE = 13;
    public static final int ALPHA_CORE = 14;
    public static final int BETA_CORE = 15;
    public static final int GAMMA_CORE = 16;    
    private static final String[] PREFIXES = {
        SUCorruptedNanoforgeUpgrades.DATA_PREFIX,
        SUPristineNanoforgeUpgrades.DATA_PREFIX,
        SUHypershuntTapUpgrades.DATA_PREFIX,
        SUCatalyticCoreUpgrades.DATA_PREFIX,
        SUPlasmaDynamoUpgrades.DATA_PREFIX,
        SUCryoarithmeticEngineUpgrades.DATA_PREFIX,
        SUCombatDroneReplicatorUpgrades.DATA_PREFIX,
        SUSynchrotonCoreUpgrades.DATA_PREFIX,
        SUSoilNanitesUpgrades.DATA_PREFIX,
        SUMantleBoreUpgrades.DATA_PREFIX,
        SUFusionLampUpgrades.DATA_PREFIX,
        SUBiofactoryEmbryoUpgrades.DATA_PREFIX,
        SUFullereneSpoolUpgrades.DATA_PREFIX,
        SUDealmakerHolosuiteUpgrades.DATA_PREFIX,
        SUAlphaCoreUpgrades.DATA_PREFIX,
        SUBetaCoreUpgrades.DATA_PREFIX,
        SUGammaCoreUpgrades.DATA_PREFIX           
    };
    private static final String[] ITEMS = {
        SUCorruptedNanoforgeUpgrades.ITEM,
        SUPristineNanoforgeUpgrades.ITEM,
        SUHypershuntTapUpgrades.ITEM,
        SUCatalyticCoreUpgrades.ITEM,
        SUPlasmaDynamoUpgrades.ITEM,
        SUCryoarithmeticEngineUpgrades.ITEM,
        SUCombatDroneReplicatorUpgrades.ITEM,
        SUSynchrotonCoreUpgrades.ITEM,
        SUSoilNanitesUpgrades.ITEM,
        SUMantleBoreUpgrades.ITEM,
        SUFusionLampUpgrades.ITEM,
        SUBiofactoryEmbryoUpgrades.ITEM,
        SUFullereneSpoolUpgrades.ITEM,
        SUDealmakerHolosuiteUpgrades.ITEM,
        SUAlphaCoreUpgrades.ITEM,
        SUBetaCoreUpgrades.ITEM,
        SUGammaCoreUpgrades.ITEM
    };
    private static final String[][] HULLMODS = {
        {"specialsphmod_corruptednanoforge_upgrades"},
        {"specialsphmod_pristinenanoforge_upgrades"},
        {"specialsphmod_hypershunt_upgrades"},
        {"specialsphmod_catalyticcore_upgrades"},
        {"specialsphmod_plasmadynamo_upgrades"},
        {"specialsphmod_cryoarithmeticengine_upgrades"},
        {"specialsphmod_combatdronereplicator_upgrades"},
        {"specialsphmod_synchrotoncore_upgrades"},
        {"specialsphmod_soilnanites_upgrades"},
        {"specialsphmod_mantlebore_upgrades"},
        {"specialsphmod_fusionlampreactor_upgrades"},
        {"specialsphmod_biofactoryembryo_upgrades"},
        {"specialsphmod_fullerenespool_upgrades"},
        {"specialsphmod_dealmakerholosuite_upgrades"},
        {"specialsphmod_alpha_core_upgrades"},
        {"specialsphmod_beta_core_upgrades"},
        {"specialsphmod_gamma_core_upgrades"}        
    };	
    //private static final int SPECIAL_SIZE = 14; // sneeed
    //private static final int TOTAL_SIZE = 17;

    public static String[] getMods(final int index) {
        return HULLMODS[index];
    }

    public static void removeHullmod(final FleetMemberAPI ship, final int type) {
        if (ship.getVariant() == null) {
            return;
        }
        final Map<String, Object> data = Global.getSector().getPersistentData();     
        data.remove(PREFIXES[type] + ship.getId());
        for (final String id : HULLMODS[type]) {
            if (ship.getVariant().getHullMods().contains(id)) {
                ship.getVariant().removeMod(id);
            }
        }
    }

    @Override
    public void advance(final float amount) {
//        final Map<String, Object> data = Global.getSector().getPersistentData();
//            for (int i = 0; i < TOTAL_SIZE; i++) {
//                if (data.containsKey(PREFIXES[i] + playerShip.getId()) && playerShip.getVariant() != null) {
//                    boolean hasMod = false;
//                    for (int j = 0; j < HULLMODS[i].length; j++) {
//                        hasMod = hasMod || playerShip.getVariant().getHullMods().contains(HULLMODS[i][j]);
//                    }
//                    if (!hasMod) {
//                        data.remove(PREFIXES[i] + playerShip.getId());
//                        if (i < SPECIAL_SIZE) {
//                            playerFleet.getCargo().addSpecial(new SpecialItemData(ITEMS[i], null), 1);
//                        }
//                        else {
//                            playerFleet.getCargo().addCommodity(ITEMS[i], 1);
//                        }
//                    }
//                    break;
//                }
//            }
        // a reminder that I need to harass techpriest to help me make the item refund seamless
        // nevermind, I did it myself
    }

    public static int isPlayerShip(final ShipAPI ship, final String hullmodID) {
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return NOT_PLAYER;
        }
        final List<FleetMemberAPI> playerShips = playerFleet.getFleetData().getMembersListCopy();
        final String memberId = ship.getFleetMemberId();
        boolean isPlayerShip = false;
        boolean hasCurrentMod = false;
        for (final FleetMemberAPI playerShip : playerShips) {
            // old janky shit was here
            if (playerShip.getId().equals(memberId)) {
                isPlayerShip = true;
                if (playerShip.getVariant() != null && playerShip.getVariant().getHullMods().contains(hullmodID)) {
                    hasCurrentMod = true;
                }
                break;
            }
        }
        if (isPlayerShip && hasCurrentMod) {
            playerFleet.getCargo().updateSpaceUsed();
            return HAS_HULLMOD;
        }
        return isPlayerShip ? IS_PLAYER : NOT_PLAYER;
    }

    public static void removePlayerSpecialItem(final String id) {
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return;
        }
        final List<CargoStackAPI> playerCargoStacks = playerFleet.getCargo().getStacksCopy();
        for (final CargoStackAPI cargoStack : playerCargoStacks) {
            if (cargoStack.isSpecialStack() && cargoStack.getSpecialDataIfSpecial().getId().equals(id) ||
                cargoStack.isCommodityStack() && cargoStack.getCommodityId().equals(id)) {
                cargoStack.subtract(1);
                if (cargoStack.getSize() <= 0) {
                    System.out.println("Removing the " + id + " from the cargo...");
                    Log.debug("Removing the " + id + " from the cargo...");
                    playerFleet.getCargo().removeStack(cargoStack);
                }
                return;
            }
        }
    }

    public static void removePlayerCommodity(final String id) {
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return;
        }
        final List<CargoStackAPI> playerCargoStacks = playerFleet.getCargo().getStacksCopy();
        for (final CargoStackAPI cargoStack : playerCargoStacks) {
            if (cargoStack.isCommodityStack() && cargoStack.getCommodityId().equals(id)) {
                cargoStack.subtract(1);
                if (cargoStack.getSize() <= 0) {
                    System.out.println("Removing the AI core from the cargo...");
                    Log.debug("Removing the AI core from the cargo...");
                    playerFleet.getCargo().removeStack(cargoStack);
                }
                return;
            }
        }
    }

    public static void addPlayerCommodityItem(final String id, final int amount) {
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return;
        }
        final CargoAPI playerFleetCargo = playerFleet.getCargo();
        System.out.println("Adding the AI core into the cargo...");
        Log.debug("Adding the AI core into the cargo...");
        playerFleetCargo.addCommodity(id, amount);
    }

    public static void addPlayerSpecialItem(final String id, final int amount) {
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return;
        }
        final CargoAPI playerFleetCargo = playerFleet.getCargo();
        System.out.println("Adding special item into the cargo...");
        Log.debug("Adding special item into the cargo...");
        playerFleetCargo.addSpecial(new SpecialItemData(id, (String)null), amount);
    }

    public static boolean playerHasSpecialItem(final String id) {
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return false;
        }
        final List<CargoStackAPI> playerCargoStacks = playerFleet.getCargo().getStacksCopy();
        System.out.println("Searching for special item " + id + "...");
        Log.debug("Searching for special item " + id + "...");
        for (final CargoStackAPI cargoStack : playerCargoStacks) {
            if (cargoStack.isSpecialStack() && cargoStack.getSpecialDataIfSpecial().getId().equals(id) && cargoStack.getSize() > 0) {
                System.out.println("Found special item " + cargoStack.getDisplayName() + ", with size " + cargoStack.getSize() + ".");
                Log.debug("Found special item " + cargoStack.getDisplayName() + ", with size " + cargoStack.getSize() + ".");
                return true;
            }
        }
        return false;
    }

    public static boolean playerHasCommodity(final String id) {
        final CampaignFleetAPI playerFleet = Global.getSector().getPlayerFleet();
        if (playerFleet == null) {
            return false;
        }
        final List<CargoStackAPI> playerCargoStacks = playerFleet.getCargo().getStacksCopy();
        System.out.println("Searching for AI Core" + id + "...");
        Log.debug("Searching for AI Core " + id + "...");        
        for (final CargoStackAPI cargoStack : playerCargoStacks) {
            if (cargoStack.isCommodityStack() && cargoStack.getCommodityId().equals(id) && cargoStack.getSize() > 0) {
                System.out.println("Found AI core " + cargoStack.getDisplayName() + ", with size " + cargoStack.getSize() + ".");
                Log.debug("Found AI core " + cargoStack.getDisplayName() + ", with size " + cargoStack.getSize() + ".");
                return true;
            }
        }
        return false;
    }

    public static boolean listContainsAny(final Collection list, final Object... objects) {
        if (objects == null) {
            return false;
        }
        for (int i = 0; i<objects.length; i++) {
            if (list.contains(objects[i])) {
                return true;
            }
        }
        return false;
    }
    
    @Override
    public boolean isDone() {
        return false;
    }
    
    @Override
    public boolean runWhilePaused() {
        return false;
    }

}