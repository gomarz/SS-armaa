package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import org.lwjgl.util.vector.Vector2f;
import org.lazywizard.lazylib.MathUtils;
import com.fs.starfarer.api.combat.FighterWingAPI;
import java.awt.Color;
import org.lazywizard.lazylib.VectorUtils;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.IntervalUtil;

import java.util.List;



import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;

public class armaa_bitWeaponAssignment implements EveryFrameWeaponEffectPlugin{ 
	private ShipAPI parent;	
	private ShipAPI dummySelector;
	
public void init(ShipAPI ship)
{
	List<ShipAPI> modules = ship.getChildModulesCopy();
	parent = ship.getParentStation();
	
//	for(ShipAPI module : modules)
//	{
//		if(module.getId().equals("armaa_einhander"))
//		dummySelector = module;
//	}
	
}

		@Override
		public void advance(float amount, CombatEngineAPI engine, WeaponAPI weapon) 
		{
			init(weapon.getShip());
			
			if(parent.getAllWings() != null)
			{
				List<FighterWingAPI> wings = parent.getAllWings();
				
				for(FighterWingAPI wing : wings)
				{
					if(!wing.getWingId().equals("armaa_bit_wing"))
					{
						continue;
					}
					
					List<ShipAPI> fighters = wing.getWingMembers();
					
					for(ShipAPI fighter : fighters)
				{
					fighter.getVariant().addWeapon("WS0001",weapon.getShip().getVariant().getWeaponId("WS0001"));
					
				}
			
			
			}
			}
		
		
		
	}
}
