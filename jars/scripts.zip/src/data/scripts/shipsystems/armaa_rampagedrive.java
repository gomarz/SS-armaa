package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import org.lazywizard.lazylib.FastTrig;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import org.magiclib.util.MagicFakeBeam;
import static org.magiclib.util.MagicFakeBeam.getShipCollisionPoint;
import java.awt.Color;
import java.util.HashMap;
import java.util.List;
import org.magiclib.util.MagicRender;
import java.util.Map;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_rampagedrive extends BaseShipSystemScript {
    public static Map bugs = new HashMap();
    private static Map wide = new HashMap();
    private static Map damage = new HashMap();
    private static Map SPEED_BOOST = new HashMap();
	private float AFTERIMAGE_THRESHOLD = 0.09f;
    static {

        bugs.put(HullSize.FIGHTER, 50f);
        bugs.put(HullSize.FRIGATE, 80f);
        bugs.put(HullSize.DESTROYER, 100f);
        bugs.put(HullSize.CRUISER, 160f);
        bugs.put(HullSize.CAPITAL_SHIP, 1f);
        wide.put(HullSize.FIGHTER, 50f);
        wide.put(HullSize.FRIGATE, 126f);
        wide.put(HullSize.DESTROYER, 136f);
        wide.put(HullSize.CRUISER, 177f);
        wide.put(HullSize.CAPITAL_SHIP, 1f);
        damage.put(HullSize.FIGHTER, 50f);
        damage.put(HullSize.FRIGATE, 1000f);
        damage.put(HullSize.DESTROYER, 1500f);
        damage.put(HullSize.CRUISER, 2250f);
        damage.put(HullSize.CAPITAL_SHIP, 1f);
        SPEED_BOOST.put(HullSize.FIGHTER, 150f);
        SPEED_BOOST.put(HullSize.FRIGATE, 300f);
        SPEED_BOOST.put(HullSize.DESTROYER, 275f);
        SPEED_BOOST.put(HullSize.CRUISER, 250f);
        SPEED_BOOST.put(HullSize.CAPITAL_SHIP, 1f);
    }
    private static final Color color = new Color(255, 255, 255, 200);
    public static final float MASS_MULT = 1.2f;
    public static final float DAMAGE_MULT = 0.15f;
    public static final float ROF_MULT = 0.5f;
    
    private boolean reset = true;
    private float activeTime = 0f;
    private float jitterLevel;
    private boolean DidRam = false;
    private float PARTICLE_ANGLE_SPREAD = 150f;
	private final float A_2 = PARTICLE_ANGLE_SPREAD / 2;
    private float CHARGEUP_PARTICLE_BRIGHTNESS = 1f;
    private float CHARGEUP_PARTICLE_DISTANCE_MAX = 200f;
    private float CHARGEUP_PARTICLE_DISTANCE_MIN = 150f;
    private float CHARGEUP_PARTICLE_DURATION = 0.8f;
    private float CHARGEUP_PARTICLE_SIZE_MAX = 5f;
    private float CHARGEUP_PARTICLE_SIZE_MIN = 2f;
    
    private Float mass = null;

    @Override
    public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) {
        CombatEngineAPI engine =  Global.getCombatEngine();
        ShipAPI ship = (ShipAPI) stats.getEntity();
        if (engine.isPaused() || ship == null) {
            return;
        }

        if (mass == null) {
            mass = ship.getMass();
        }
        
        if (reset) {
            reset = false;
            activeTime = 0f;
            jitterLevel = 0f;
            DidRam = false;
        }

        ShipAPI target = ship.getShipTarget();
        float turnrate = ship.getMaxTurnRate()*2;

        if (state == State.OUT) {
            stats.getMaxSpeed().unmodify(id); // to slow down ship to its regular top speed while powering drive down
            ship.setMass(mass);
            DidRam = false;
        } else {
            if (ship.getMass() == mass) {
                ship.setMass(mass * MASS_MULT);
            }
            stats.getMaxSpeed().modifyFlat(id, (Float) SPEED_BOOST.get(ship.getVariant().getHullSize()));
            stats.getAcceleration().modifyFlat(id, (Float) SPEED_BOOST.get(ship.getHullSize()) * 3);
            stats.getEmpDamageTakenMult().modifyMult(id, DAMAGE_MULT);
            stats.getArmorDamageTakenMult().modifyMult(id, DAMAGE_MULT);
            stats.getHullDamageTakenMult().modifyMult(id, DAMAGE_MULT);

            stats.getBallisticRoFMult().modifyMult(id, ROF_MULT);
            stats.getEnergyRoFMult().modifyMult(id, ROF_MULT);
            if (!DidRam) {
                Vector2f from = ship.getLocation();
                float angle = ship.getFacing();
                Vector2f end = MathUtils.getPoint(from, (Float) bugs.get(ship.getHullSize()), angle);
                List <CombatEntityAPI> entity = CombatUtils.getEntitiesWithinRange(ship.getLocation(), (Float) bugs.get(ship.getHullSize())+25f);
                if (!entity.isEmpty()) {
                    for (CombatEntityAPI e : entity) {
                        if (e.getCollisionClass() == CollisionClass.NONE){continue;}
                        if (e.getOwner() == ship.getOwner()) {continue;}
                        Vector2f col = new Vector2f(1000000,1000000);                  
                        if (e instanceof ShipAPI ){                    
                            if(e!=ship && ((ShipAPI)e).getParentStation()!=e && (e.getCollisionClass()!=CollisionClass.NONE && e.getCollisionClass() != CollisionClass.FIGHTER) && CollisionUtils.getCollides(ship.getLocation(), end, e.getLocation(), e.getCollisionRadius())) {
                                            //&&
                                            //!(e.getCollisionClass()==CollisionClass.FIGHTER && e.getOwner()==ship.getOwner() && !((ShipAPI)e).getEngineController().isFlamedOut())               
                                ShipAPI s = (ShipAPI) e;
                                Vector2f hitPoint = getShipCollisionPoint(from, end, s, angle);
                                if (hitPoint != null ){col = hitPoint;}
                            }
                            if (col.x != 1000000 && MathUtils.getDistanceSquared(from, col) < MathUtils.getDistanceSquared(from, end)) {
                                DidRam = true;
                                MagicFakeBeam.spawnFakeBeam(engine, ship.getLocation(), (Float) bugs.get(ship.getHullSize()), ship.getFacing(), (Float) wide.get(ship.getHullSize()), 0.1f, 0.1f, 25, color, color, (Float) damage.get(ship.getHullSize()), DamageType.HIGH_EXPLOSIVE, 0, ship);
                                Global.getSoundPlayer().playSound("collision_ships", 1f, 0.5f, ship.getLocation(), ship.getVelocity());
								SpriteAPI waveSprite = Global.getSettings().getSprite("misc", "armaa_sfxpulse");
								CombatUtils.applyForce(ship,ship.getFacing()-180,ship.getMaxSpeed()*.7f);
								if (waveSprite != null)
								{
									MagicRender.battlespace(
												waveSprite,
												col,
												new Vector2f(),
												new Vector2f(20f,20f),
												new Vector2f(350f,350f),
												15f,
												15f,
												new Color(255,255,255,200), 
												true,
												0.3f,
												0.0f,
												0.3f
										);
								}
								float facing = ship.getFacing();
								int count = 1 + (int) (effectLevel * 20);
								for (int i = 0; i < count; i++) 
								{
											float distance = MathUtils.getRandomNumberInRange(CHARGEUP_PARTICLE_DISTANCE_MIN+1f,
											CHARGEUP_PARTICLE_DISTANCE_MAX+1f)
											* effectLevel;
									
									float speed = 0.75f * distance / CHARGEUP_PARTICLE_DURATION*effectLevel;

									float angle2 = MathUtils.getRandomNumberInRange(facing - A_2,
											facing + A_2);
									float vel = MathUtils.getRandomNumberInRange(speed * -1.5f,
											speed * -2f);
									Vector2f vector = MathUtils.getPointOnCircumference(null,
											vel,
											angle2);

									float size = MathUtils.getRandomNumberInRange(CHARGEUP_PARTICLE_SIZE_MIN+1f, CHARGEUP_PARTICLE_SIZE_MAX+1f)*effectLevel;
								   // float angle = MathUtils.getRandomNumberInRange(-0.5f * CHARGEUP_PARTICLE_ANGLE_SPREAD, 0.5f
									 //       * CHARGEUP_PARTICLE_ANGLE_SPREAD);
								   // Vector2f particleVelocity = MathUtils.getPointOnCircumference(shipVelocity, speed, angle + shipFacing
										  //  + 180f);
									engine.addHitParticle(col, vector, size, CHARGEUP_PARTICLE_BRIGHTNESS * Math.min(
											effectLevel + 0.5f, 1f)
													* MathUtils.getRandomNumberInRange(0.75f, 1.25f), CHARGEUP_PARTICLE_DURATION,
											new Color(255,255,200,255));
								}								
                            }
                        }
                    }
                }
            }
            
            if((target != null && target.isAlive() && !target.isAlly()) && ship.getSystem().isActive()){
                float facing = ship.getFacing();
                facing=MathUtils.getShortestRotation(
                        facing,
                        VectorUtils.getAngle(ship.getLocation(), target.getLocation())
                );
                if (!target.isFighter() && !target.isDrone()) {
                    ship.setAngularVelocity(Math.min(turnrate, Math.max(-turnrate, facing*5)));
                } else {ship.setAngularVelocity(Math.min(turnrate, Math.max(-turnrate, facing*2)));}
               activeTime += engine.getElapsedInLastFrame();
                if (activeTime <= 3f) {
                    jitterLevel = Math.max(1 - activeTime/1.0f, 1.0f);
                    stats.getEmpDamageTakenMult().modifyMult(id, DAMAGE_MULT);
                    stats.getArmorDamageTakenMult().modifyMult(id, DAMAGE_MULT);
                    stats.getHullDamageTakenMult().modifyMult(id, DAMAGE_MULT);
                    //ship.setJitter(this, new Color (255,140,60,65), jitterLevel, 1, 0, 5f);
                    //ship.setJitterUnder(this, new Color (255,80,30,135), jitterLevel, 10, 0f, 8f);
                }
                if (activeTime > 3f) {
                    jitterLevel = 0f;
                    stats.getEmpDamageTakenMult().unmodifyMult(id);
                    stats.getArmorDamageTakenMult().unmodifyMult(id);
                    stats.getHullDamageTakenMult().unmodifyMult(id);
                }
            }
			float amount = Global.getCombatEngine().getElapsedInLastFrame();
			//afterimage shit from tahlan
			ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerNullerID", -1);
			ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerID",
			ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() + amount);
				
			if(ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() > AFTERIMAGE_THRESHOLD) 
			{

				// Sprite offset fuckery - Don't you love trigonometry?
				SpriteAPI sprite = ship.getSpriteAPI();
				float offsetX = sprite.getWidth()/2 - sprite.getCenterX();
				float offsetY = sprite.getHeight()/2 - sprite.getCenterY();

				float trueOffsetX = (float)FastTrig.cos(Math.toRadians(ship.getFacing()-90f))*offsetX - (float)FastTrig.sin(Math.toRadians(ship.getFacing()-90f))*offsetY;
				float trueOffsetY = (float)FastTrig.sin(Math.toRadians(ship.getFacing()-90f))*offsetX + (float)FastTrig.cos(Math.toRadians(ship.getFacing()-90f))*offsetY;
				if(!ship.isHulk())
				{
					for(WeaponAPI w : ship.getAllWeapons())
					{
						if(!w.getSlot().isBuiltIn() && !w.getSlot().isDecorative())
							continue;
						//armaa_valkazardEffect;
						if(w.getSpec().getType() == WeaponAPI.WeaponType.MISSILE && w.getAmmo() < 0)
							continue;
						
						if(w.getSprite() == null)
							continue;
						Color sysColo = ship.getSystem().getSpecAPI().getJitterEffectColor();
						if(!w.getSlot().getId().equals("F_LEGS"))
						{
							MagicRender.battlespace(
									Global.getSettings().getSprite(w.getSpec().getTurretSpriteName()),
									new Vector2f(w.getLocation().getX()+trueOffsetX,w.getLocation().getY()+trueOffsetY),
									new Vector2f(0, 0),
									new Vector2f(w.getSprite().getWidth(), w.getSprite().getHeight()),
									new Vector2f(0, 0),
									ship.getFacing()-90f,
									0f,
									sysColo,
									true,
									0f,
									0f,
									0f,
									0f,
									0f,
									0.1f,
									0.1f,
									0.3f,
									CombatEngineLayers.BELOW_SHIPS_LAYER);
						}
						
						else
						{
							int frame = w.getAnimation().getFrame();
							SpriteAPI spr = Global.getSettings().getSprite("graphics/armaa/ships/valkazard/armaa_valkazard_legs0"+frame+".png");
						
							if(frame >= 10)
							spr = Global.getSettings().getSprite("graphics/armaa/ships/valkazard/armaa_valkazard_legs"+frame+".png");				
							
							MagicRender.battlespace(
									spr,
									new Vector2f(w.getLocation().getX()+trueOffsetX,w.getLocation().getY()+trueOffsetY),
									new Vector2f(0, 0),
									new Vector2f(w.getSprite().getWidth(), w.getSprite().getHeight()),
									new Vector2f(0, 0),
									ship.getFacing()-90f,
									0f,
									sysColo,
									true,
									0f,
									0f,
									0f,
									0f,
									0f,
									0.1f,
									0.1f,
									0.3f,
									CombatEngineLayers.BELOW_SHIPS_LAYER);								
						}							
						
						if(w.getBarrelSpriteAPI() != null)
						{
							if(!w.getSlot().getId().equals("C_ARML") && (!w.getSlot().getId().equals("A_GUN")))
								continue;
							
							//Explicitly for Valkazard compat, since apparently can't access barrelsprite id through api and using the api itself also modifies the color of the original
							SpriteAPI spr = Global.getSettings().getSprite(w.getSpec().getHardpointSpriteName());
							
							MagicRender.battlespace(
									spr,
									new Vector2f(w.getLocation().getX()+trueOffsetX,w.getLocation().getY()+trueOffsetY),
									new Vector2f(0, 0),
									new Vector2f(w.getBarrelSpriteAPI().getWidth(), w.getBarrelSpriteAPI().getHeight()),
									new Vector2f(0, 0),
									w.getCurrAngle()-90f,
									0f,
									sysColo,
									true,
									0f,
									0f,
									0f,
									0f,
									0f,
									0.1f,
									0.1f,
									0.3f,
									CombatEngineLayers.BELOW_SHIPS_LAYER);
						}
					}
				}
							ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerID",
							ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() - AFTERIMAGE_THRESHOLD);
			}
        }
    }

    @Override
    public void unapply(MutableShipStatsAPI stats, String id) {
        reset = true;
        ShipAPI ship = (ShipAPI) stats.getEntity();
        if (ship == null) {
            return;
        }

        if (mass == null) {
            mass = ship.getMass();
        }
        if (ship.getMass() != mass) {
            ship.setMass(mass);
        }

        stats.getMaxSpeed().unmodify(id);
        stats.getAcceleration().unmodify(id);
        stats.getEmpDamageTakenMult().unmodify(id);
        stats.getHullDamageTakenMult().unmodify(id);
        stats.getArmorDamageTakenMult().unmodify(id);

        stats.getBallisticRoFMult().unmodify(id);
        stats.getEnergyRoFMult().unmodify(id);
    }

    public StatusData getStatusData(int index, State state, float effectLevel) {
        if (index == 0) {
            return null;
        } else if (index == 1) {
            return null;
        }
        return null;
    }

    @Override
    public String getInfoText(ShipSystemAPI system, ShipAPI ship) {
        if (system.isOutOfAmmo()) return null;
        if (system.getState() != ShipSystemAPI.SystemState.IDLE) return null;

        return "READY";
    }
}
