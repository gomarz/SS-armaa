package com.fs.starfarer.api.impl.campaign.rulecmd;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.Script;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.rules.MemoryAPI;
import com.fs.starfarer.api.characters.OfficerDataAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.fleets.ArmaaHunterFleetManager;
import com.fs.starfarer.api.impl.campaign.rulecmd.BaseCommandPlugin;
import com.fs.starfarer.api.util.Misc.Token;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class armaa_Hikaru_Utada extends BaseCommandPlugin {

   public boolean execute(String var1, InteractionDialogAPI var2, List var3, Map var4) {
      String var5 = ((Token)var3.get(0)).getString(var4);
      CampaignFleetAPI var6 = Global.getSector().getPlayerFleet();
      MemoryAPI var7 = (MemoryAPI)var4.get("local");
      if(var7 == null) {
         return false;
      } else {
         if("findValk".equals(var5)) {
            Iterator var8 = var6.getFleetData().getMembersListCopy().iterator();

            while(var8.hasNext()) {
               FleetMemberAPI var9 = (FleetMemberAPI)var8.next();
               if(var9.getHullSpec().getHullId().equals("armaa_valkazard")) {
                  var7.set("$foundValkId", var9.getId(), 1.0F);
                  var7.set("$foundValkClass", var9.getHullSpec().getNameWithDesignationWithDashClass(), 1.0F);
                  var7.set("$foundValkName", var9.getShipName(), 1.0F);
                  return true;
               }
            }
         } else {
            String var12;
            if("giveSSMech".equals(var5)) {
               var12 = "armaa_vx_silversword_Hull";
               ShipVariantAPI var19 = Global.getSettings().getVariant(var12).clone();
               FleetMemberAPI var18 = Global.getFactory().createFleetMember(FleetMemberType.SHIP, var19);
               var7.set("$armaa_giftMech", var18, 1.0F);
               return true;
            }

            if("spawnValkHunters".equals(var5)) {
               if(!Global.getSector().hasScript(ArmaaHunterFleetManager.class)) {
                  Global.getSector().addScript(new ArmaaHunterFleetManager());
                  Global.getSector().getCampaignUI().addMessage("You get an ominous feeling..");
               }

               return true;
            }

            CampaignFleetAPI var13;
            if("getHireCost".equals(var5)) {
               var13 = (CampaignFleetAPI)var2.getInteractionTarget();
               int var16 = 0;

               FleetMemberAPI var11;
               for(Iterator var17 = var13.getFleetData().getMembersListCopy().iterator(); var17.hasNext(); var16 = (int)((float)var16 + var11.getBaseValue())) {
                  var11 = (FleetMemberAPI)var17.next();
               }

               var16 /= 12;
               var7.set("$armaa_mercCost", Integer.valueOf(var16), 1.0F);
               return true;
            }

            if("followMe".equals(var5)) {
               var13 = (CampaignFleetAPI)var2.getInteractionTarget();
               if(Global.getSector().getPlayerFleet() != null) {
                  var13.removeFirstAssignment();
               }

               var13.addAssignmentAtStart(FleetAssignment.ORBIT_PASSIVE, Global.getSector().getPlayerFleet(), 10.0F, "Following player", (Script)null);
               return true;
            }

            if("getSeraphRel".equals(var5)) {
               var12 = ((Token)var3.get(1)).getString(var4);
               PersonAPI var15 = Global.getSector().getImportantPeople().getPerson(var12);
               Global.getSector().getCampaignUI().addMessage(((Token)var3.get(1)).getString(var4));
               return (double)var15.getRelToPlayer().getRel() >= 0.1D;
            }

            if("playMusic".equals(var5)) {
               var12 = ((Token)var3.get(1)).getString(var4);
               Global.getSoundPlayer().playCustomMusic(0, 5, var12, true);
               return true;
            }

            if("hasOfficer".equals(var5)) {
               var12 = ((Token)var3.get(1)).getString(var4);
               Iterator var14 = Global.getSector().getPlayerFleet().getFleetData().getOfficersCopy().iterator();

               while(var14.hasNext()) {
                  OfficerDataAPI var10 = (OfficerDataAPI)var14.next();
                  if(var10.getPerson().getId().equals(var12)) {
                     return true;
                  }
               }
            }
         }

         return false;
      }
   }
}
