package data.scripts.plugins;

import com.fs.starfarer.api.BaseModPlugin;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import java.util.Iterator;
import java.util.List;

public class CataphractCheck extends BaseModPlugin {

   boolean NewChange;
   boolean NewChange2;



   public class CataphractCheckMarket extends BaseCampaignEventListener {

      public CataphractCheckMarket() {
         super(false);
      }

      public void reportPlayerOpenedMarket(MarketAPI var1) {
         CataphractCheck.this.NewChange = false;
         CampaignFleetAPI var2 = Global.getSector().getPlayerFleet();

         FleetMemberAPI var4;
         for(Iterator var3 = var2.getFleetData().getMembersListCopy().iterator(); var3.hasNext(); var4.updateStats()) {
            var4 = (FleetMemberAPI)var3.next();
            List var5 = var4.getVariant().getWings();
            ShipVariantAPI var6 = var4.getVariant();
            boolean var7 = false;
            if(!var5.isEmpty()) {
               for(int var8 = 0; var8 < var5.size() && var6.getWing(var8) != null; ++var8) {
                  if(var6.getWing(var8).getTags().contains("cataphract")) {
                     var7 = true;
                     if(!var6.hasHullMod("cataphractBonus")) {
                        var6.addMod("cataphractBonus");
                        CataphractCheck.this.NewChange = true;
                     }
                  }
               }
            }

            if(!var7) {
               var6.removeMod("cataphractBonus");
            }
         }

         if(CataphractCheck.this.NewChange) {
            Global.getSoundPlayer().playUISound("ui_cargo_handweapons_drop", 1.0F, 0.5F);
         }

      }
   }
}
