package data.scripts.plugins;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatAssignmentType;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatFleetManagerAPI;
import com.fs.starfarer.api.combat.CombatTaskManagerAPI;
import com.fs.starfarer.api.combat.CombatUIAPI;
import com.fs.starfarer.api.combat.DeployedFleetMemberAPI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.combat.ai.FighterAI;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_EinhanderHaxPlugin extends BaseEveryFrameCombatPlugin {

   protected CombatEngineAPI engine;
   protected List cataphrachtii = new ArrayList();
   protected List toRemove = new ArrayList();
   protected CombatTaskManagerAPI ctm;
   protected CombatFleetManagerAPI cfm;
   protected CombatUIAPI ui;
   private String origPersonality = "steady";
   boolean canEnd = false;
   private IntervalUtil interval = new IntervalUtil(0.025F, 0.05F);
   private IntervalUtil interval2 = new IntervalUtil(0.05F, 0.05F);


   public void advance(float var1, List var2) {
      if(this.engine != null) {
         this.cfm = this.engine.getFleetManager(FleetSide.PLAYER);
         this.ctm = this.cfm.getTaskManager(false);
         this.ui = this.engine.getCombatUI();
         this.interval.advance(var1);
         Iterator var3;
         if(this.interval.intervalElapsed()) {
            var3 = this.engine.getMissiles().iterator();

            while(var3.hasNext()) {
               MissileAPI var4 = (MissileAPI)var3.next();
               if(var4.getWeapon() != null && var4.getWeapon().getId().equals("armaa_sprigganTorso") && (var4.isFizzling() || var4.isFading())) {
                  if(MagicRender.screenCheck(0.25F, var4.getLocation())) {
                     this.engine.addSmoothParticle(var4.getLocation(), new Vector2f(), 50.0F, 0.5F, 0.15F, Color.blue);
                     this.engine.addHitParticle(var4.getLocation(), new Vector2f(), 50.0F, 1.0F, 0.25F, new Color(250, 192, 250, 255));
                  }

                  this.engine.removeEntity(var4);
                  return;
               }
            }
         }

         if(this.cataphrachtii.isEmpty() || this.engine.isEnemyInFullRetreat() || this.engine.isCombatOver() || this.engine.getFleetManager(0).getTaskManager(false).isInFullRetreat()) {
            this.engine.setDoNotEndCombat(false);
            this.canEnd = true;
         }

         if(!this.cataphrachtii.isEmpty()) {
            if(!this.cataphrachtii.isEmpty()) {
               if((!this.engine.isEnemyInFullRetreat() || !this.engine.getFleetManager(0).getTaskManager(false).isInFullRetreat()) && !this.canEnd) {
                  this.engine.setDoNotEndCombat(true);
               }

               var3 = this.cataphrachtii.iterator();

               while(var3.hasNext()) {
                  ShipAPI var9 = (ShipAPI)var3.next();
                  if(var9.getShipAI() instanceof FighterAI || var9.getShipAI() == null && (var9 != this.engine.getPlayerShip() || !Global.getCombatEngine().isUIAutopilotOn())) {
                     var9.setHullSize(HullSize.FRIGATE);
                     var9.resetDefaultAI();
                  }

                  if(this.ui != null) {
                     this.interval2.advance(var1);
                     if(this.interval2.intervalElapsed() && this.ui.isShowingCommandUI()) {
                        CombatFleetManagerAPI var5 = Global.getCombatEngine().getFleetManager(var9.getOwner());
                        boolean var6 = var9.isAlly();
                        CombatTaskManagerAPI var7 = var5.getTaskManager(var6);
                        if(var9.getOwner() == 0 && !var9.getVariant().hasHullMod("armaa_strikeCraftFrig") && var7.getAssignmentFor(var9) != null && (var7.getAssignmentFor(var9).getType() == CombatAssignmentType.CAPTURE || var7.getAssignmentFor(var9).getType() == CombatAssignmentType.ASSAULT || var7.getAssignmentFor(var9).getType() == CombatAssignmentType.CONTROL) && var9.getHullSize() == HullSize.FRIGATE) {
                           DeployedFleetMemberAPI var8 = var5.getDeployedFleetMember(var9);
                           Global.getCombatEngine().getCombatUI().addMessage(1, new Object[]{Global.getSettings().getColor("textFriendColor"), var9.getName(), Color.red, " is incapable of capturing objectives due to being a strikecraft."});
                           Global.getSoundPlayer().playUISound("cr_allied_critical", 0.5F, 1.0F);
                           var7.orderSearchAndDestroy(var8, false);
                        }

                        if(var9.getHullSize() != HullSize.FRIGATE && !var9.isFinishedLanding()) {
                           var9.setHullSize(HullSize.FRIGATE);
                        }
                     }
                  }

                  if(var9 == null || var9.isRetreating()) {
                     this.toRemove.add(var9);
                  }

                  if(var9.getHitpoints() <= 0.0F || var9.isHulk() || var9.getOwner() == 100) {
                     this.toRemove.add(var9);
                  }
               }
            }

            if(!this.toRemove.isEmpty()) {
               this.cataphrachtii.removeAll(this.toRemove);
            }

         }
      }
   }

   public void init(CombatEngineAPI var1) {
      this.engine = var1;
   }
}
