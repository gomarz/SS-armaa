package data.scripts.plugins;

import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatFleetManagerAPI;
import com.fs.starfarer.api.combat.CombatTaskManagerAPI;
import com.fs.starfarer.api.combat.CombatUIAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.mission.FleetSide;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class armaa_FighterHaxPlugin extends BaseEveryFrameCombatPlugin {

   protected CombatEngineAPI engine;
   protected List cataphrachtii = new ArrayList();
   protected List toRemove = new ArrayList();
   protected CombatTaskManagerAPI ctm;
   protected CombatFleetManagerAPI cfm;
   protected CombatUIAPI ui;
   private String origPersonality = "steady";
   boolean canEnd = false;


   public void advance(float var1, List var2) {
      if(this.engine != null) {
         this.cfm = this.engine.getFleetManager(FleetSide.PLAYER);
         this.ctm = this.cfm.getTaskManager(false);
         this.ui = this.engine.getCombatUI();
         Iterator var3 = this.engine.getShips().iterator();

         while(var3.hasNext()) {
            ShipAPI var4 = (ShipAPI)var3.next();
            if(var4.isFighter() && var4.getWing() != null && (var4.getHullLevel() <= 0.3F || var4.getWing().getSourceShip().isPullBackFighters() && var4.getHullLevel() < 0.8F)) {
               var4.getWing().orderReturn(var4);
            }
         }

      }
   }

   public void init(CombatEngineAPI var1) {
      this.engine = var1;
   }
}
