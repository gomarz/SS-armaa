package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponSize;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_crusherEffect implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin, OnHitEffectPlugin {

   private boolean runOnce = false;
   private boolean hasFired = false;
   public float TURRET_OFFSET = 45.0F;
   private final IntervalUtil particle = new IntervalUtil(0.025F, 0.05F);
   float charge = 0.0F;
   private static final int SMOKE_SIZE_MIN = 10;
   private static final int SMOKE_SIZE_MAX = 30;
   private static final Color MUZZLE_FLASH_COLOR = new Color(0, 171, 128, 255);
   private static final Color MUZZLE_FLASH_COLOR_ALT = new Color(255, 255, 255, 100);
   private static final Color MUZZLE_FLASH_COLOR_GLOW = new Color(0, 255, 0, 50);
   private static final float MUZZLE_FLASH_DURATION = 0.2F;
   private static final float MUZZLE_FLASH_SIZE = 30.0F;
   private static final Color PARTICLE_COLOR = new Color(50, 255, 50, 174);
   private static final Color BLAST_COLOR = new Color(255, 16, 16, 255);
   private static final Color CORE_COLOR = new Color(119, 194, 255);
   private static final Color FLASH_COLOR = new Color(152, 255, 225);
   private static final int NUM_PARTICLES = 15;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      int var4 = var3.getSpec().getTurretFireOffsets().size();
      if(var3.isFiring() && this.charge != 1.0F) {
         for(int var5 = 0; var5 < var4; ++var5) {
            this.TURRET_OFFSET = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(var5)).x;
            float var7 = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(var5)).y;
            float var8 = var3.getChargeLevel();
            float var9 = 1.0F;
            if(var3.getSize() == WeaponSize.LARGE) {
               var9 = 2.0F;
            }

            if(!this.hasFired) {
               Global.getSoundPlayer().playLoop("beamchargeM", var3, 1.5F, 1.0F, var3.getLocation(), var3.getShip().getVelocity());
               this.particle.advance(var1);
               if(this.particle.intervalElapsed()) {
                  Vector2f var10 = new Vector2f(var3.getLocation());
                  Vector2f var11 = new Vector2f(this.TURRET_OFFSET, var7);
                  VectorUtils.rotate(var11, var3.getCurrAngle(), var11);
                  Vector2f.add(var11, var10, var10);
                  Vector2f var12 = MathUtils.getPoint(var3.getLocation(), 18.5F, var3.getCurrAngle());
                  Vector2f var13 = var3.getShip().getVelocity();
                  var2.addHitParticle(var10, var13, MathUtils.getRandomNumberInRange(20.0F * var9, var8 * var9 * 60.0F + 20.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var8), MathUtils.getRandomNumberInRange(0.1F, 0.1F + var8 / 10.0F), new Color(0.0F, var8 / 1.5F, var8 / 2.0F));
                  Vector2f var14 = MathUtils.getRandomPointInCircle(new Vector2f(), 35.0F * var8);
                  Vector2f var15 = new Vector2f();
                  Vector2f.sub(var10, new Vector2f(var14), var15);
                  Vector2f.add(var13, var14, var14);

                  for(int var16 = 0; var16 < 5; ++var16) {
                     var2.addHitParticle(var15, var14, MathUtils.getRandomNumberInRange(1.0F, var8 * 2.0F + 1.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var8), MathUtils.getRandomNumberInRange(0.75F, 0.75F + var8 / 4.0F), new Color(var8 / 2.0F, var8, var8 / 1.5F));
                  }
               }
            }

            if(var8 == 1.0F) {
               this.hasFired = true;
               if(var5 >= 1) {
                  boolean var6 = false;
               } else {
                  int var17 = var5 + 1;
               }
            }
         }
      } else {
         this.hasFired = false;
      }

   }

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      if(MagicRender.screenCheck(0.2F, var1.getLocation())) {
         var3.addSmoothParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 75.0F, 2.0F, 0.1F, Color.white);
         var3.addSmoothParticle(var1.getLocation(), new Vector2f(), 100.0F, 0.5F, 0.1F, MUZZLE_FLASH_COLOR_GLOW);
         var3.addHitParticle(var1.getLocation(), new Vector2f(), 75.0F, 0.5F, 0.25F, MUZZLE_FLASH_COLOR);

         for(int var4 = 0; var4 < 5; ++var4) {
            var3.addHitParticle(var1.getLocation(), MathUtils.getPointOnCircumference((Vector2f)null, MathUtils.getRandomNumberInRange(100.0F, 150.0F), (float)Math.random() * 360.0F), 5.0F, 1.0F, MathUtils.getRandomNumberInRange(0.6F, 1.0F), MUZZLE_FLASH_COLOR);
         }
      }

      if(Math.random() > 0.75D) {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 3.0F, 0.2F);
      } else {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 30.0F, 0.2F);
      }

      var3.addSmoothParticle(var1.getLocation(), var1.getVelocity(), 90.0F, 1.0F, 0.4F, MUZZLE_FLASH_COLOR_GLOW);
   }

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      var6.spawnExplosion(var3, new Vector2f(), PARTICLE_COLOR, 75.0F, 1.0F);
      var6.spawnExplosion(var3, new Vector2f(), CORE_COLOR, 50.0F, 1.0F);
      if(MagicRender.screenCheck(0.2F, var3)) {
         var6.addSmoothParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 75.0F, 2.0F, 0.1F, Color.white);
         var6.addSmoothParticle(var3, new Vector2f(), 100.0F, 0.5F, 0.1F, PARTICLE_COLOR);
         var6.addHitParticle(var3, new Vector2f(), 75.0F, 0.5F, 0.25F, FLASH_COLOR);

         for(int var7 = 0; var7 < 15; ++var7) {
            var6.addHitParticle(var3, MathUtils.getPointOnCircumference((Vector2f)null, MathUtils.getRandomNumberInRange(100.0F, 150.0F), (float)Math.random() * 360.0F), 5.0F, 1.0F, MathUtils.getRandomNumberInRange(0.6F, 1.0F), PARTICLE_COLOR);
         }
      }

   }

}
