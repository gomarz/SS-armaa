package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.List;
import org.jetbrains.annotations.NotNull;
import org.lazywizard.lazylib.FastTrig;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_BoomerangShieldGuidance extends BaseEveryFrameCombatPlugin {

   private static final float SWAY_AMOUNT_PRIMARY = 5.0F;
   private static final float SWAY_AMOUNT_SECONDARY = 5.0F;
   private static final float SWAY_PERIOD_PRIMARY = 0.5F;
   private static final float SWAY_PERIOD_SECONDARY = 0.5F;
   private static final float SWAY_FALLOFF_FACTOR = 1.0F;
   private static final int INTERCEPT_ITERATIONS = 5;
   private static final float INTERCEPT_ACCURACY_FACTOR = 1.0F;
   private static final float GUIDANCE_DELAY_MAX = 0.0F;
   private static final float GUIDANCE_DELAY_MIN = 0.0F;
   private static final boolean BROKEN_BY_PHASE = true;
   private static final boolean RETARGET_ON_SIDE_SWITCH = false;
   private final DamagingProjectileAPI proj;
   private CombatEntityAPI target;
   private final Vector2f targetPoint;
   private float swayCounter1;
   private float swayCounter2;
   private float lifeCounter;
   private final float estimateMaxLife;
   private float delayCounter;
   private final float actualGuidanceDelay;


   public armaa_BoomerangShieldGuidance(@NotNull DamagingProjectileAPI var1, CombatEntityAPI var2) {
      this.proj = var1;
      this.target = var2;
      this.swayCounter1 = MathUtils.getRandomNumberInRange(0.0F, 1.0F);
      this.swayCounter2 = MathUtils.getRandomNumberInRange(0.0F, 1.0F);
      this.lifeCounter = 0.0F;
      this.estimateMaxLife = var1.getWeapon().getRange() / (new Vector2f(var1.getVelocity().x - var1.getSource().getVelocity().x, var1.getVelocity().y - var1.getSource().getVelocity().y)).length();
      this.delayCounter = 0.0F;
      this.actualGuidanceDelay = MathUtils.getRandomNumberInRange(0.0F, 0.0F);
      this.targetPoint = new Vector2f(Misc.ZERO);
   }

   public void advance(float var1, List var2) {
      if(Global.getCombatEngine() != null) {
         if(Global.getCombatEngine().isPaused()) {
            var1 = 0.0F;
         }

         if(this.proj != null && !this.proj.didDamage() && !this.proj.isFading() && Global.getCombatEngine().isEntityInPlay(this.proj)) {
            this.lifeCounter += var1;
            if(this.lifeCounter > this.estimateMaxLife) {
               this.lifeCounter = this.estimateMaxLife;
            }

            if(this.delayCounter < this.actualGuidanceDelay) {
               this.delayCounter += var1;
            } else {
               this.swayCounter1 += var1 * 0.5F;
               this.swayCounter2 += var1 * 0.5F;
               float var3 = (float)Math.pow((double)(1.0F - this.lifeCounter / this.estimateMaxLife), 1.0D) * ((float)(FastTrig.sin(6.283185307179586D * (double)this.swayCounter1) * 5.0D) + (float)(FastTrig.sin(6.283185307179586D * (double)this.swayCounter2) * 5.0D));
               if(this.target != null) {
                  if(!Global.getCombatEngine().isEntityInPlay(this.target)) {
                     this.target = null;
                  }

                  if(this.target instanceof ShipAPI) {
                     if(!((ShipAPI)this.target).isHulk() && !((ShipAPI)this.target).isPhased()) {
                        if(this.target.getOwner() == this.proj.getOwner()) {
                           ;
                        }
                     } else {
                        this.target = null;
                     }
                  }
               }

               if(this.target == null) {
                  Global.getCombatEngine().removePlugin(this);
               } else {
                  byte var4 = 5;
                  float var5 = this.proj.getFacing() - var3;
                  Vector2f var6 = VectorUtils.rotate(new Vector2f(this.targetPoint), this.target.getFacing());
                  float var7 = VectorUtils.getAngle(this.proj.getLocation(), Vector2f.add(this.getApproximateInterception(var4), var6, new Vector2f(Misc.ZERO)));

                  float var8;
                  for(var8 = Math.abs(var7 - var5); var8 > 180.0F; var8 = Math.abs(var8 - 360.0F)) {
                     ;
                  }

                  float var9 = 75.0F;
                  if("vayra_medium_boomerangshield".equals(this.proj.getProjectileSpecId())) {
                     var9 = 25.0F;
                  }

                  if(MathUtils.getDistance(this.proj.getLocation(), this.target.getLocation()) < 20.0F) {
                     this.proj.getWeapon().setAmmo(1);
                     Global.getSoundPlayer().playSound("mechmoveRev", 1.0F, 1.0F, this.proj.getLocation(), new Vector2f());

                     for(int var10 = 0; var10 < 6; ++var10) {
                        float var11 = (float)MathUtils.getRandomNumberInRange(15, 30);
                        float var12 = (float)MathUtils.getRandomNumberInRange(-44, 44);
                        float var13 = (float)MathUtils.getRandomNumberInRange(-48, 48);
                        Global.getCombatEngine().addSmokeParticle(this.proj.getLocation(), new Vector2f(var12, var13), var11, 0.5F, 0.5F, Color.gray);
                     }

                     Global.getCombatEngine().removeEntity(this.proj);
                     Global.getCombatEngine().removePlugin(this);
                  }

                  var5 += Misc.getClosestTurnDirection(var5, var7) * Math.min(var8, var9 * var1);
                  this.proj.setFacing(var5 + var3);
                  this.proj.getVelocity().x = MathUtils.getPoint(new Vector2f(Misc.ZERO), this.proj.getVelocity().length(), var5 + var3).x;
                  this.proj.getVelocity().y = MathUtils.getPoint(new Vector2f(Misc.ZERO), this.proj.getVelocity().length(), var5 + var3).y;
               }
            }
         } else {
            Global.getCombatEngine().removePlugin(this);
         }
      }
   }

   private Vector2f getApproximateInterception(int var1) {
      Vector2f var2 = new Vector2f(this.target.getLocation());

      for(int var3 = 0; var3 < var1; ++var3) {
         float var4 = MathUtils.getDistance(this.proj.getLocation(), var2) / this.proj.getVelocity().length();
         var2.x = this.target.getLocation().x + this.target.getVelocity().x * var4 * 1.0F;
         var2.y = this.target.getLocation().y + this.target.getVelocity().y * var4 * 1.0F;
      }

      return var2;
   }
}
