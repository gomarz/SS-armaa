package data.scripts.weapons;

import com.fs.starfarer.api.combat.BaseCombatLayeredRenderingPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import data.scripts.ai.armaa_kineticGrenadeEffect;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;

public class armaa_kineticGrenadeEF extends BaseCombatLayeredRenderingPlugin implements OnFireEffectPlugin, EveryFrameWeaponEffectPlugin {

   private static final Color AFTERIMAGE_COLOR = new Color(255, 165, 90, 155);
   private static final float AFTERIMAGE_THRESHOLD = 0.4F;
   private static final List FIST_TRACKER = new ArrayList();
   private static final Color MUZZLE_FLASH_COLOR = new Color(100, 200, 255, 50);
   private static final Color MUZZLE_FLASH_COLOR_ALT = new Color(255, 255, 255, 100);
   private static final Color MUZZLE_FLASH_COLOR_GLOW = new Color(0, 75, 255, 50);


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {}

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      var3.addPlugin(new armaa_kineticGrenadeEffect(var1, var2.getShip()));
   }

}
