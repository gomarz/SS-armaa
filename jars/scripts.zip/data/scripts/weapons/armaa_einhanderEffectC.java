package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicAnim;

public class armaa_einhanderEffectC implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private ShipSystemAPI system;
   private ShipAPI ship;
   private SpriteAPI sprite;
   private AnimationAPI anim;
   private AnimationAPI aGlow;
   private AnimationAPI aGlow2;
   private WeaponAPI head;
   private WeaponAPI armL;
   private WeaponAPI armR;
   private WeaponAPI pauldronL;
   private WeaponAPI pauldronR;
   private WeaponAPI torso;
   private WeaponAPI cannon;
   private boolean charging = false;
   private boolean cooling = false;
   private boolean firing = false;
   private final IntervalUtil interval = new IntervalUtil(0.015F, 0.015F);
   private final IntervalUtil interval2 = new IntervalUtil(0.0F, 20.0F);
   private float level = 0.0F;
   private static final Vector2f ZERO = new Vector2f();
   private int lastAmmo = 0;
   private SpriteAPI HAND;
   private SpriteAPI SHOULDER;
   private float HAND_WIDTH;
   private float HAND_HEIGHT;
   private float CHARGEUP_PARTICLE_ANGLE_SPREAD = 360.0F;
   private float CHARGEUP_PARTICLE_BRIGHTNESS = 1.0F;
   private float CHARGEUP_PARTICLE_DISTANCE_MAX = 200.0F;
   private float CHARGEUP_PARTICLE_DISTANCE_MIN = 100.0F;
   private float CHARGEUP_PARTICLE_DURATION = 0.5F;
   private float CHARGEUP_PARTICLE_SIZE_MAX = 6.0F;
   private float CHARGEUP_PARTICLE_SIZE_MIN = 1.0F;
   public float TURRET_OFFSET = 30.0F;
   private int limbInit = 0;
   private float overlap = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -75.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;
   private List registeredProjectiles = new ArrayList();
   private List explodingProjectiles = new ArrayList();
   private List toRemove = new ArrayList();
   private final Color EMP_COLOR = new Color(200, 200, 0);
   private final Color FLASH_COLOR = new Color(255, 255, 255);


   public void init() {
      this.runOnce = true;
      Iterator var1 = this.ship.getAllWeapons().iterator();

      while(var1.hasNext()) {
         WeaponAPI var2 = (WeaponAPI)var1.next();
         String var3 = var2.getSlot().getId();
         byte var4 = -1;
         switch(var3.hashCode()) {
         case -6931076:
            if(var3.equals("D_PAULDRONL")) {
               var4 = 3;
            }
            break;
         case -6931070:
            if(var3.equals("D_PAULDRONR")) {
               var4 = 4;
            }
            break;
         case 1245480854:
            if(var3.equals("B_TORSO")) {
               var4 = 0;
            }
            break;
         case 2007905292:
            if(var3.equals("C_ARML")) {
               var4 = 1;
            }
            break;
         case 2007905298:
            if(var3.equals("C_ARMR")) {
               var4 = 2;
            }
            break;
         case 2065359258:
            if(var3.equals("E_HEAD")) {
               var4 = 5;
            }
         }

         switch(var4) {
         case 0:
            if(this.torso == null) {
               this.torso = var2;
               ++this.limbInit;
            }
            break;
         case 1:
            if(this.armL == null) {
               this.armL = var2;
               this.HAND = var2.getSprite();
               this.HAND_WIDTH = this.HAND.getWidth() / 2.0F;
               this.HAND_HEIGHT = this.HAND.getHeight() / 2.0F;
               ++this.limbInit;
            }
            break;
         case 2:
            if(this.armR == null) {
               this.armR = var2;
               ++this.limbInit;
            }
            break;
         case 3:
            if(this.pauldronL == null) {
               this.pauldronL = var2;
               ++this.limbInit;
            }
            break;
         case 4:
            if(this.pauldronR == null) {
               this.pauldronR = var2;
               this.SHOULDER = var2.getSprite();
               ++this.limbInit;
            }
            break;
         case 5:
            if(this.head == null) {
               this.head = var2;
               ++this.limbInit;
            }
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.ship = var3.getShip();
      this.sprite = this.ship.getSpriteAPI();
      this.system = this.ship.getSystem();
      this.anim = var3.getAnimation();
      this.init();
      if(this.runOnce && this.limbInit == 6) {
         if(this.ship.getEngineController().isAccelerating()) {
            if(this.overlap > 9.9F) {
               this.overlap = 10.0F;
            } else {
               this.overlap = Math.min(10.0F, this.overlap + (10.0F - this.overlap) * var1 * 5.0F);
            }
         } else if(!this.ship.getEngineController().isDecelerating() && !this.ship.getEngineController().isAcceleratingBackwards()) {
            if(Math.abs(this.overlap) < 0.1F) {
               this.overlap = 0.0F;
            } else {
               this.overlap -= this.overlap / 2.0F * var1 * 3.0F;
            }
         } else if(this.overlap < -9.9F) {
            this.overlap = -10.0F;
         } else {
            this.overlap = Math.max(-10.0F, this.overlap + (-10.0F + this.overlap) * var1 * 5.0F);
         }

         float var4 = 0.0F;
         float var5 = 0.0F;
         this.SHOULDER.setCenterY(var3.getBarrelSpriteAPI().getCenterY() - 23.0F);
         if(this.system.isActive()) {
            if(var3.getChargeLevel() > 0.0F && this.system.getEffectLevel() == 1.0F) {
               this.HAND.setCenterY(var3.getBarrelSpriteAPI().getCenterY() - 15.0F);
            }

            if(this.system.getEffectLevel() < 1.0F) {
               if(!this.lockNloaded) {
                  this.lockNloaded = true;
               }

               var4 = MagicAnim.smoothNormalizeRange(this.system.getEffectLevel(), 0.0F, 0.7F);
               var5 = MagicAnim.smoothNormalizeRange(this.system.getEffectLevel(), 0.3F, 1.0F);
            } else {
               var4 = 1.0F;
               var5 = 1.0F;
            }
         } else if(this.lockNloaded) {
            this.lockNloaded = false;
         }

         float var6 = this.ship.getFacing();
         float var7 = MathUtils.getShortestRotation(var6, var3.getCurrAngle());
         if(this.torso != null) {
            this.torso.setCurrAngle(var6 + var4 * -45.0F + var7 * 0.3F);
         }

         if(this.armR != null) {
            this.armR.setCurrAngle(var3.getCurrAngle() + -25.0F);
         }

         if(this.pauldronR != null) {
            this.pauldronR.setCurrAngle(var6 + var4 * -45.0F * 0.5F + var7 * 0.75F + -12.5F);
         }

         this.ship.syncWeaponDecalsWithArmorDamage();
         if(this.armL != null) {
            this.armL.setCurrAngle(var6 + (var7 + -75.0F) * var5 + (this.overlap + var7 * 0.25F) * (1.0F - var5));
         }

         if(this.pauldronL != null) {
            this.pauldronL.setCurrAngle(this.torso.getCurrAngle() + MathUtils.getShortestRotation(this.torso.getCurrAngle(), this.armL.getCurrAngle()) * 0.6F);
         }

         Iterator var8;
         DamagingProjectileAPI var9;
         if(this.system.isActive()) {
            this.chargeFx(var2, var3, var1, this.system);
            var8 = CombatUtils.getProjectilesWithinRange(this.ship.getLocation(), 80.0F).iterator();

            while(var8.hasNext()) {
               var9 = (DamagingProjectileAPI)var8.next();
               if(var3 == var9.getWeapon() && !this.registeredProjectiles.contains(var9) && !this.explodingProjectiles.contains(var9)) {
                  this.registeredProjectiles.add(var9);
                  float var10 = var3.getCooldownRemaining() * var3.getShip().getMutableStats().getTimeMult().getMult();
                  Color var11 = Color.red;
                  if(var2.getPlayerShip() == var3.getShip()) {
                     var10 = var3.getCooldownRemaining() * (1.0F / var3.getShip().getMutableStats().getTimeMult().getMult());
                     var10 -= var10;
                     if(var10 > 0.7F) {
                        var10 = 0.0F;
                     }

                     var11 = Color.yellow;
                  }

                  if(var10 <= 0.0F) {
                     FluxTrackerAPI var12 = var3.getShip().getFluxTracker();
                     DamagingProjectileAPI var13 = (DamagingProjectileAPI)var2.spawnProjectile(this.ship, var3, "armaa_einhanderGun2", var9.getLocation(), var9.getFacing(), this.ship.getVelocity());
                     if(var12.getCurrFlux() + var3.getFluxCostToFire() <= var12.getMaxFlux()) {
                        var12.setCurrFlux(var12.getCurrFlux() + var3.getFluxCostToFire() * 1.21F);
                     }

                     this.explodingProjectiles.add(var13);
                     this.registeredProjectiles.add(var13);
                     Global.getSoundPlayer().playSound("plasma_cannon_fire", 1.0F, 0.7F, var13.getLocation(), var13.getVelocity());
                  }

                  Global.getCombatEngine().removeEntity(var9);
               }
            }
         }

         this.level = var3.getChargeLevel();
         this.interval2.advance(var1);
         if(this.interval2.intervalElapsed()) {
            var8 = this.registeredProjectiles.iterator();

            while(var8.hasNext()) {
               var9 = (DamagingProjectileAPI)var8.next();
               if(!Global.getCombatEngine().isEntityInPlay(var9)) {
                  this.toRemove.add(var9);
               }
            }

            this.registeredProjectiles.removeAll(this.toRemove);
         }

         if(!this.explodingProjectiles.isEmpty()) {
            var8 = this.explodingProjectiles.iterator();

            while(var8.hasNext()) {
               var9 = (DamagingProjectileAPI)var8.next();
               if(var9.isFading() || !Global.getCombatEngine().isEntityInPlay(var9)) {
                  this.toRemove.add(var9);
                  var2.addSmoothParticle(var9.getLocation(), new Vector2f(), 70.0F, 0.5F, 0.3F, Color.yellow);
                  var2.addHitParticle(var9.getLocation(), new Vector2f(), 50.0F, 1.0F, 0.1F, Color.white);
               }
            }
         }

         this.explodingProjectiles.removeAll(this.toRemove);
      }
   }

   private void chargeFx(CombatEngineAPI var1, WeaponAPI var2, float var3, ShipSystemAPI var4) {
      Vector2f var5 = new Vector2f(var2.getLocation());
      Vector2f var6 = new Vector2f(this.TURRET_OFFSET, -15.0F);
      VectorUtils.rotate(var6, var2.getCurrAngle(), var6);
      Vector2f.add(var6, var5, var5);
      float var7 = var2.getCurrAngle();
      Vector2f var8 = this.ship.getVelocity();
      float var9 = 1.0F * var2.getChargeLevel();
      Color var10 = new Color(0.78431374F * var9, 0.21568628F * var9, 0.78431374F * var9, var9);
      Color var11 = new Color(0.78431374F, 0.21568628F, 0.78431374F, 1.0F);
      Color var12 = new Color(1.0F * var9, 1.0F * var9, 1.0F * var9, var9);
      Color var13 = new Color(1.0F * var9, 0.0F, 1.0F * var9, var9);
      if(var4.isActive()) {
         var10 = new Color(0.98039216F, 0.9254902F, 0.15686275F, var9);
      }

      float var14;
      if(var2.isFiring() && var2.getChargeLevel() > 0.0F) {
         var14 = 30.0F + var2.getChargeLevel() * var2.getChargeLevel() * MathUtils.getRandomNumberInRange(25.0F, 75.0F);
         if(Math.random() > 0.5D) {
            var1.addHitParticle(var5, ZERO, (var14 - 10.0F) * var2.getChargeLevel(), 0.1F + var2.getChargeLevel() * 0.3F, 0.2F, var10);
         } else {
            var1.addHitParticle(var5, ZERO, (var14 - 10.0F) * var2.getChargeLevel(), 0.1F + var2.getChargeLevel() * 0.3F, 0.2F, var13);
         }

         var1.addHitParticle(var5, ZERO, (var14 - 10.0F) / 2.0F, 0.1F + var2.getChargeLevel() * 0.3F, 0.2F, var12);
      }

      if(this.charging) {
         if(this.firing && var2.getChargeLevel() < 1.0F) {
            this.charging = false;
            this.cooling = true;
            this.firing = false;
         } else if(var2.getChargeLevel() < 1.0F) {
            this.interval.advance(var3);
            if(this.interval.intervalElapsed()) {
               var14 = 20.0F + var2.getChargeLevel() * var2.getChargeLevel() * MathUtils.getRandomNumberInRange(25.0F, 75.0F);
               if(Math.random() > 0.5D) {
                  var1.addHitParticle(var5, ZERO, (var14 - 10.0F) * var2.getChargeLevel(), 0.1F + var2.getChargeLevel() * 0.3F, 0.2F, var10);
               } else {
                  var1.addHitParticle(var5, ZERO, (var14 - 10.0F) * var2.getChargeLevel(), 0.1F + var2.getChargeLevel() * 0.3F, 0.2F, var13);
               }

               var1.addHitParticle(var5, ZERO, (var14 - 10.0F) / 2.0F * var2.getChargeLevel(), 0.1F + var2.getChargeLevel() * 0.3F, 0.2F, var12);
               int var15 = 2 + (int)(var2.getChargeLevel() * 5.0F);

               for(int var16 = 0; var16 < var15; ++var16) {
                  float var17 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_DISTANCE_MIN, this.CHARGEUP_PARTICLE_DISTANCE_MAX) * var2.getChargeLevel();
                  float var18 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_SIZE_MIN, this.CHARGEUP_PARTICLE_SIZE_MAX) * var2.getChargeLevel();
                  float var19 = MathUtils.getRandomNumberInRange(-0.5F * this.CHARGEUP_PARTICLE_ANGLE_SPREAD, 0.5F * this.CHARGEUP_PARTICLE_ANGLE_SPREAD);
                  float var20 = 0.75F * var17 / this.CHARGEUP_PARTICLE_DURATION * var2.getChargeLevel();
                  Vector2f var21 = MathUtils.getPointOnCircumference(var8, var20, var19 + var7 + 180.0F);
                  var1.addHitParticle(var5, var21, var18, this.CHARGEUP_PARTICLE_BRIGHTNESS * Math.min(var2.getChargeLevel() + 0.5F, var2.getChargeLevel() + 1.0F) * MathUtils.getRandomNumberInRange(0.75F, 1.25F), this.CHARGEUP_PARTICLE_DURATION, var11);
               }
            }
         } else {
            this.firing = true;
         }
      } else if(this.cooling) {
         if(var2.getChargeLevel() <= 0.0F) {
            this.cooling = false;
         }
      } else if(var2.getChargeLevel() > this.level) {
         this.charging = true;
      }

   }

}
