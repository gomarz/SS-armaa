package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import data.scripts.util.MagicRender;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;

public class armaa_harpoonSecondaryEffect implements OnHitEffectPlugin {

   private static final Color COLOR1 = new Color(255, 0, 0, 255);
   private static final Color COLOR2 = new Color(245, 188, 44, 255);
   private static final Vector2f ZERO = new Vector2f();


   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      if(var2 instanceof ShipAPI) {
         ShipAPI var7 = (ShipAPI)var2;
         float var8 = 0.0F;
         float var9 = var1.getEmpAmount();
         float var10 = var1.getWeapon().getDamage().getDamage() * 0.5F;

         for(int var11 = 0; var11 < 3; ++var11) {
            var8 += 0.25F;
            var6.spawnEmpArcPierceShields(var1.getSource(), var3, var7, var7, DamageType.ENERGY, var10, var9, 100000.0F, (String)null, 10.0F, COLOR1, COLOR2);
         }

         if(var8 > 0.0F) {
            if(MagicRender.screenCheck(0.2F, var3)) {
               var6.addSmoothParticle(var3, ZERO, 150.0F * var8 / 2.0F, var8, 0.75F, COLOR1);
               var6.addSmoothParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 300.0F, 2.0F, 0.1F, Color.white);
               var6.addHitParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 79.0F, 1.0F, 0.4F, new Color(200, 100, 25));
               var6.spawnExplosion(var1.getLocation(), new Vector2f(0.0F, 0.0F), Color.BLACK, 90.0F, 3.0F);
               var6.spawnExplosion(var1.getLocation(), new Vector2f(0.0F, 0.0F), COLOR2, 75.0F, 1.5F);
            }

            Global.getSoundPlayer().playSound("armaa_buster_hit", 1.0F, 1.0F * var8 * 0.5F, var3, ZERO);
         }
      }

   }

}
