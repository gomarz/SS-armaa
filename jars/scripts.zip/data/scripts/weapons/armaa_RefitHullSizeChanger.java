package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;

public class armaa_RefitHullSizeChanger implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private WeaponAPI torso;
   public int frame = 7;
   private IntervalUtil interval = new IntervalUtil(0.08F, 0.08F);
   private IntervalUtil interval2;
   private Color ogColor;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      ShipAPI var4 = var3.getShip();
      if(var4.getHullSize() != HullSize.FRIGATE) {
         var4.setHullSize(HullSize.FRIGATE);
         var4.resetDefaultAI();
         this.runOnce = true;
      }
   }
}
