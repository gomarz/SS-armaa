package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicLensFlare;
import org.magiclib.util.MagicRender;

public class armaa_gBusterOnHitEffect implements OnHitEffectPlugin {

   private static final Color COLOR1 = new Color(255, 0, 0, 255);
   private static final Color COLOR2 = new Color(245, 188, 44, 255);
   private static final Vector2f ZERO = new Vector2f();


   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      boolean var7 = var4;
      if(var3 != null) {
         if(var2 instanceof ShipAPI) {
            ShipAPI var8 = (ShipAPI)var2;
            float var9 = 0.0F;
            float var10 = var1.getEmpAmount() * 0.25F;
            float var11 = var1.getDamageAmount() * 0.25F;

            for(int var12 = 0; var12 < 4; ++var12) {
               float var13 = ((ShipAPI)var2).getHardFluxLevel() - 0.1F;
               var13 *= var8.getMutableStats().getDynamic().getValue("shield_pierced_mult");
               boolean var14 = var7 && (float)Math.random() < var13;
               if(!var7 || var14) {
                  var9 += 0.25F;
                  var6.spawnEmpArcPierceShields(var1.getSource(), var3, var8, var8, DamageType.ENERGY, var11, var10, 100000.0F, (String)null, 15.0F, COLOR1, COLOR2);
               }
            }

            if(var9 > 0.0F) {
               if(MagicRender.screenCheck(0.2F, var3)) {
                  var6.addSmoothParticle(var3, ZERO, 150.0F * var9, var9, 0.75F, COLOR1);
                  var6.addSmoothParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 300.0F, 2.0F, 0.15F, Color.white);
                  var6.addHitParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 159.0F, 1.0F, 0.4F, new Color(200, 100, 25));
                  var6.spawnExplosion(var1.getLocation(), new Vector2f(0.0F, 0.0F), Color.BLACK, 180.0F, 3.0F);
                  var6.spawnExplosion(var1.getLocation(), new Vector2f(0.0F, 0.0F), COLOR2, 150.0F, 1.5F);
                  MagicLensFlare.createSmoothFlare(var6, var1.getSource(), var3, var9 * 6.0F, 400.0F, var1.getFacing() - 90.0F, COLOR1, COLOR2);
               }

               Global.getSoundPlayer().playSound("armaa_buster_hit", 1.0F, 1.0F * var9, var3, ZERO);
            }
         }

      }
   }

}
