package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipEngineControllerAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.ShipEngineControllerAPI.ShipEngineAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import java.awt.Color;
import java.util.Iterator;
import org.lazywizard.lazylib.FastTrig;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class MagicVectorThrusterSelkie3 implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean accel = false;
   private boolean turn = false;
   private ShipAPI SHIP;
   private ShipEngineAPI thruster;
   private ShipEngineControllerAPI EMGINES;
   private float time = 0.0F;
   private float previousThrust = 0.0F;
   private final float FREQ = 0.05F;
   private final float SMOOTH_THRUSTING = 0.25F;
   private float TURN_RIGHT_ANGLE = 0.0F;
   private float THRUST_TO_TURN = 0.0F;
   private float NEUTRAL_ANGLE = 0.0F;
   private float FRAMES = 0.0F;
   private float OFFSET = 0.0F;
   private Vector2f size = new Vector2f(8.0F, 82.0F);


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!this.runOnce) {
         this.runOnce = true;
         this.SHIP = var3.getShip();
         this.EMGINES = this.SHIP.getEngineController();
         if(var3.getAnimation() != null) {
            this.FRAMES = (float)var3.getAnimation().getNumFrames();
         }

         Iterator var4 = this.SHIP.getEngineController().getShipEngines().iterator();

         while(var4.hasNext()) {
            ShipEngineAPI var5 = (ShipEngineAPI)var4.next();
            if(MathUtils.isWithinRange(var5.getLocation(), var3.getLocation(), 2.0F)) {
               this.thruster = var5;
            }
         }

         this.OFFSET = (float)(Math.random() * 3.1415927410125732D);
         this.NEUTRAL_ANGLE = var3.getSlot().getAngle();
         this.TURN_RIGHT_ANGLE = MathUtils.clampAngle(VectorUtils.getAngle(this.SHIP.getLocation(), var3.getLocation()));
         this.TURN_RIGHT_ANGLE = MathUtils.getShortestRotation(this.SHIP.getFacing(), this.TURN_RIGHT_ANGLE) + 90.0F;
         this.THRUST_TO_TURN = this.smooth(MathUtils.getDistance(this.SHIP.getLocation(), var3.getLocation()) / this.SHIP.getCollisionRadius());
      }

      if(!var2.isPaused() && this.SHIP.getOriginalOwner() != -1) {
         if(this.SHIP.isAlive() && (this.thruster == null || !this.thruster.isDisabled())) {
            this.time += var1;
            if(this.time >= 0.05F) {
               this.time = 0.0F;
               float var12 = this.NEUTRAL_ANGLE;
               float var13 = this.NEUTRAL_ANGLE;
               float var6 = 0.0F;
               if(this.EMGINES.isAccelerating()) {
                  var12 = 180.0F;
                  var6 = 1.5F;
                  this.accel = true;
               } else if(this.EMGINES.isAcceleratingBackwards()) {
                  var12 = 0.0F;
                  var6 = 1.5F;
                  this.accel = true;
               } else if(this.EMGINES.isDecelerating()) {
                  var12 = this.NEUTRAL_ANGLE;
                  var6 = 0.5F;
                  this.accel = true;
               } else {
                  this.accel = false;
               }

               if(this.EMGINES.isStrafingLeft()) {
                  if(var6 == 0.0F) {
                     var12 = -90.0F;
                  } else {
                     var12 += MathUtils.getShortestRotation(var12, -90.0F) / 2.0F;
                  }

                  var6 = Math.max(1.0F, var6);
                  this.accel = true;
               } else if(this.EMGINES.isStrafingRight()) {
                  if(var6 == 0.0F) {
                     var12 = 90.0F;
                  } else {
                     var12 += MathUtils.getShortestRotation(var12, 90.0F) / 2.0F;
                  }

                  var6 = Math.max(1.0F, var6);
                  this.accel = true;
               }

               if(this.EMGINES.isTurningRight()) {
                  var13 = this.TURN_RIGHT_ANGLE;
                  var6 = Math.max(1.0F, var6);
                  this.turn = true;
               } else if(this.EMGINES.isTurningLeft()) {
                  var13 = MathUtils.clampAngle(180.0F + this.TURN_RIGHT_ANGLE);
                  var6 = Math.max(1.0F, var6);
                  this.turn = true;
               } else {
                  this.turn = false;
               }

               if(var6 > 0.0F) {
                  Vector2f var7 = new Vector2f(var3.getLocation().x - this.SHIP.getLocation().x, var3.getLocation().y - this.SHIP.getLocation().y);
                  VectorUtils.rotate(var7, -this.SHIP.getFacing(), var7);
                  if(!this.turn) {
                     if(this.FRAMES == 0.0F) {
                        this.rotate(var3, var12, var6 * this.SHIP.getMutableStats().getAcceleration().computeMultMod(), 0.25F);
                     } else {
                        this.thrust(var3, var12, var6 * this.SHIP.getMutableStats().getAcceleration().computeMultMod(), 0.25F);
                     }
                  } else if(!this.accel) {
                     if(this.FRAMES == 0.0F) {
                        this.rotate(var3, var13, var6 * this.SHIP.getMutableStats().getTurnAcceleration().computeMultMod(), 0.25F);
                     } else {
                        this.thrust(var3, var13, var6 * this.SHIP.getMutableStats().getTurnAcceleration().computeMultMod(), 0.25F);
                     }
                  } else {
                     float var8 = this.THRUST_TO_TURN * Math.min(1.0F, Math.abs(this.SHIP.getAngularVelocity()) / 10.0F);
                     var8 = this.smooth(var8);
                     float var9 = this.NEUTRAL_ANGLE;
                     var9 = MathUtils.clampAngle(var9 + MathUtils.getShortestRotation(this.NEUTRAL_ANGLE, var12));
                     var9 = MathUtils.clampAngle(var9 + var8 * MathUtils.getShortestRotation(var12, var13));
                     float var10 = var6 * ((this.SHIP.getMutableStats().getTurnAcceleration().computeMultMod() + this.SHIP.getMutableStats().getAcceleration().computeMultMod()) / 2.0F);
                     float var11 = Math.abs(MathUtils.getShortestRotation(var13, var12));
                     var11 = Math.max(0.0F, var11 - 90.0F);
                     var11 /= 45.0F;
                     var10 *= 1.0F - Math.max(0.0F, Math.min(1.0F, var11));
                     if(this.FRAMES == 0.0F) {
                        this.rotate(var3, var9, var10, 0.125F);
                     } else {
                        this.thrust(var3, var9, var10, 0.125F);
                     }
                  }
               } else if(this.FRAMES == 0.0F) {
                  this.rotate(var3, this.NEUTRAL_ANGLE, 0.0F, 0.25F);
               } else {
                  this.thrust(var3, this.NEUTRAL_ANGLE, 0.0F, 0.25F);
               }
            }

         } else {
            var3.getAnimation().setFrame(0);
            this.previousThrust = 0.0F;
         }
      }
   }

   private void rotate(WeaponAPI var1, float var2, float var3, float var4) {
      float var5 = var2 + this.SHIP.getFacing();
      var5 = MathUtils.getShortestRotation(var1.getCurrAngle(), var5);
      var5 = (float)((double)var5 + 5.0D * FastTrig.cos((double)(this.SHIP.getFullTimeDeployed() * 5.0F * var3 + this.OFFSET)));
      var5 *= var4;
      var1.setCurrAngle(MathUtils.clampAngle(var1.getCurrAngle() + var5));
   }

   private void thrust(WeaponAPI var1, float var2, float var3, float var4) {
      int var5 = (int)(Math.random() * (double)(this.FRAMES - 1.0F)) + 1;
      if(var5 == var1.getAnimation().getNumFrames()) {
         var5 = 1;
      }

      var1.getAnimation().setFrame(var5);
      SpriteAPI var6 = var1.getSprite();
      float var7 = var2 + this.SHIP.getFacing();
      var7 = MathUtils.getShortestRotation(var1.getCurrAngle(), var7);
      float var8 = var3 * Math.max(0.0F, 1.0F - Math.abs(var7) / 90.0F);
      var8 -= this.previousThrust;
      var8 *= var4;
      var8 += this.previousThrust;
      this.previousThrust = var8;
      var7 = (float)((double)var7 + 5.0D * FastTrig.cos((double)(this.SHIP.getFullTimeDeployed() * 5.0F * var3 + this.OFFSET)));
      var7 *= var4;
      var1.setCurrAngle(MathUtils.clampAngle(var1.getCurrAngle() + var7));
      float var9 = var8 * this.size.x / 2.0F + this.size.x / 2.0F;
      float var10 = var8 * this.size.y + (float)Math.random() * 3.0F + 3.0F;
      var6.setSize(var9, var10);
      var6.setCenter(var9 / 2.0F, var10 / 2.0F);
      var8 = Math.max(0.0F, Math.min(1.0F, var8));
      var6.setColor(new Color(1.0F, 0.5F + var8 / 2.0F, 0.75F + var8 / 4.0F));
   }

   public float smooth(float var1) {
      return 0.5F - (float)(Math.cos((double)(var1 * 3.1415927F)) / 2.0D);
   }
}
