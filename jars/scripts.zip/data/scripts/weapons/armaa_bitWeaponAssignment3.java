package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatUIAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.FighterWingAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.awt.Color;
import java.util.Iterator;
import java.util.List;

public class armaa_bitWeaponAssignment3 implements EveryFrameWeaponEffectPlugin {

   private boolean isWeaponSwapped = false;


   public boolean isBattling() {
      boolean var1 = false;
      CombatEngineAPI var2 = Global.getCombatEngine();
      CombatUIAPI var3 = var2.getCombatUI();
      if(var3 != null) {
         var1 = true;
      }

      return var1;
   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      ShipAPI var4 = var3.getShip();
      WeaponAPI var5 = null;
      Iterator var6 = var4.getAllWeapons().iterator();

      while(var6.hasNext()) {
         WeaponAPI var7 = (WeaponAPI)var6.next();
         if(var7.getSlot().getId().equals("DUMMYBIT")) {
            var5 = var7;
         }
      }

      if(var4.getOriginalOwner() == -1) {
         var3.getSprite().setColor(new Color(255, 255, 255, 255));
         if(var3.getBarrelSpriteAPI() != null) {
            var3.getBarrelSpriteAPI().setColor(new Color(255, 255, 255, 255));
         }
      } else {
         Color var16 = new Color(0.0F, 0.0F, 0.0F, 0.0F);
         if(var5 != null) {
            if(var5.getSprite() != null) {
               var5.getSprite().setColor(var16);
            }

            if(var5.getUnderSpriteAPI() != null) {
               var5.getUnderSpriteAPI().setColor(var16);
            }

            if(var5.getBarrelSpriteAPI() != null) {
               var5.getBarrelSpriteAPI().setColor(var16);
            }

            if(var5.getGlowSpriteAPI() != null) {
               var5.getGlowSpriteAPI().setColor(var16);
            }
         }

         if(var3 != null) {
            var3.getSprite().setColor(new Color(255, 255, 255, 0));
         }
      }

      if(var4.isAlive() && !this.isWeaponSwapped && var5 != null) {
         List var17 = var4.getAllWings();
         Iterator var18 = var17.iterator();

         while(var18.hasNext()) {
            FighterWingAPI var8 = (FighterWingAPI)var18.next();
            if(var8 != null && var8.getWingMembers() != null && !var8.getWingMembers().isEmpty()) {
               ShipAPI var9 = var8.getLeader();
               if(var9 != null) {
                  for(int var10 = 0; var10 < var8.getWingMembers().size(); ++var10) {
                     var9 = (ShipAPI)var8.getWingMembers().get(var10);
                     if(var9 != null && !var9.getAllWeapons().isEmpty() && var8.getWingId().equals("armaa_bit_wing")) {
                        MutableShipStatsAPI var11 = var9.getMutableStats();
                        ShipVariantAPI var12 = var11.getVariant().clone();
                        ShipVariantAPI var13 = var11.getVariant().clone();
                        String var14 = (String)Global.getCombatEngine().getCustomData().get("armaa_modularDroneWeaponId" + var4.getId());
                        if(var14 == null) {
                           var14 = "No weapon";
                        }

                        if(var2.getPlayerShip() == var4) {
                           Global.getCombatEngine().maintainStatusForPlayerShip("AceSystem444", "graphics/ui/icons/icon_repair_refit.png", "Drone Weapon", var14 + " installed. ", true);
                        }

                        if(!((WeaponAPI)var9.getAllWeapons().get(0)).getId().equals(var14) && var4.getVariant().getWeaponSpec("DUMMYBIT") != null) {
                           Global.getCombatEngine().getCustomData().put("armaa_modularDroneWeaponId" + var4.getId(), var4.getVariant().getWeaponId("DUMMYBIT"));
                           var9.getFleetMember().setVariant(var13, true, true);
                           var5.disable(true);
                           Color var15 = new Color(0.0F, 0.0F, 0.0F, 0.0F);
                           if(var5.getSprite() != null) {
                              var5.getSprite().setColor(var15);
                           }

                           if(var5.getUnderSpriteAPI() != null) {
                              var5.getUnderSpriteAPI().setColor(var15);
                           }

                           if(var5.getBarrelSpriteAPI() != null) {
                              var5.getBarrelSpriteAPI().setColor(var15);
                           }

                           if(var5.getGlowSpriteAPI() != null) {
                              var5.getGlowSpriteAPI().setColor(var15);
                           }

                           var11.getVariant().clearSlot("WS0001");
                           var11.getVariant().addWeapon("WS0001", var4.getVariant().getWeaponId("DUMMYBIT"));
                           var11.getVariant().getWeaponSpec("WS0001").addTag("FIRE_WHEN_INEFFICIENT");
                           var4.removeWeaponFromGroups(var5);
                           var8.orderReturn(var9);
                        }
                     }
                  }
               }
            }
         }
      }

   }
}
