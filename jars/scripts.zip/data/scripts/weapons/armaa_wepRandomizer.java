package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class armaa_wepRandomizer implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private final ArrayList weaponsL = new ArrayList();
   private final ArrayList weaponsR;


   public armaa_wepRandomizer() {
      this.weaponsL.add("armaa_aleste_blade_LeftArm");
      this.weaponsL.add("armaa_aleste_grenade_left");
      this.weaponsL.add("armaa_aleste_rifle_left");
      this.weaponsL.add("armaa_koutoBazooka");
      this.weaponsL.add("armaa_leynos_ppc");
      this.weaponsL.add("armaa_leynosBazooka");
      this.weaponsR = new ArrayList();
      this.weaponsR.add("armaa_aleste_blade_RightArm");
      this.weaponsR.add("armaa_aleste_heavyrifle_right");
      this.weaponsR.add("armaa_leynos_minigun_right");
      this.weaponsR.add("armaa_kouto_minigun_right");
      this.weaponsR.add("armaa_aleste_rightArm");
      this.weaponsR.add("armaa_leynos_shotgun_right");
      this.weaponsR.add("armaa_leynos_crusher_right");
   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      var3.getShip().getMutableStats().getBallisticRoFMult().modifyMult("armaa_wepRandomizer", 0.7F);
      var3.getShip().getMutableStats().getMissileRoFMult().modifyMult("armaa_wepRandomizer", 0.7F);
      var3.getShip().getMutableStats().getEnergyRoFMult().modifyMult("armaa_wepRandomizer", 0.7F);
      if(!this.runOnce) {
         Collections.shuffle(this.weaponsR);
         Collections.shuffle(this.weaponsL);
         Random var4 = new Random();
         int var5 = var4.nextInt(this.weaponsL.size());
         var3.getShip().getVariant().clearSlot("C_ARML");
         var3.getShip().getVariant().addWeapon("C_ARML", (String)this.weaponsL.get(var5));
         new Random();
         var3.getShip().getVariant().clearSlot("A_GUN");
         var3.getShip().getVariant().addWeapon("A_GUN", (String)this.weaponsR.get(var5));
         this.runOnce = true;
         if(Math.random() <= 0.25D) {
            var3.getShip().getWing().orderReturn(var3.getShip());
         }
      }

   }
}
