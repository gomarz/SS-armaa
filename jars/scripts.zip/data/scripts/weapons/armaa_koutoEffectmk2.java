package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.BaseCombatLayeredRenderingPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import data.scripts.util.MagicAnim;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_koutoEffectmk2 extends BaseCombatLayeredRenderingPlugin implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private ShipSystemAPI system;
   private ShipAPI ship;
   private SpriteAPI sprite;
   private AnimationAPI anim;
   private AnimationAPI aGlow;
   private AnimationAPI aGlow2;
   private WeaponAPI head;
   private WeaponAPI armL;
   private WeaponAPI armR;
   private WeaponAPI pauldronL;
   private WeaponAPI pauldronR;
   private WeaponAPI torso;
   private WeaponAPI vernier;
   private WeaponAPI gun;
   private WeaponAPI shoulderwep;
   private WeaponAPI headGlow;
   private final Vector2f ZERO = new Vector2f();
   private int limbInit = 0;
   private float currentRotateL = 0.0F;
   private float currentRotateR = 0.0F;
   private final float maxlegRotate = 22.5F;
   private float reverse = 1.0F;
   private boolean windingup = false;
   private float overlap = 0.0F;
   private float heat = 0.0F;
   private float originalRArmPos = 0.0F;
   private float originalArmPos = 0.0F;
   private float originalShoulderPos = 0.0F;
   private float originalVernierPos = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -60.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;
   private final float LPAULDRONOFFSET = -5.0F;


   public void init() {
      this.runOnce = true;
      Iterator var1 = this.ship.getAllWeapons().iterator();

      while(var1.hasNext()) {
         WeaponAPI var2 = (WeaponAPI)var1.next();
         String var3 = var2.getSlot().getId();
         byte var4 = -1;
         switch(var3.hashCode()) {
         case -2143743196:
            if(var3.equals("H_GLOW")) {
               var4 = 7;
            }
            break;
         case -6931076:
            if(var3.equals("D_PAULDRONL")) {
               var4 = 3;
            }
            break;
         case -6931070:
            if(var3.equals("D_PAULDRONR")) {
               var4 = 4;
            }
            break;
         case 62929954:
            if(var3.equals("A_GUN")) {
               var4 = 0;
            }
            break;
         case 82866645:
            if(var3.equals("WS001")) {
               var4 = 6;
            }
            break;
         case 2007905292:
            if(var3.equals("C_ARML")) {
               var4 = 1;
            }
            break;
         case 2007905298:
            if(var3.equals("C_ARMR")) {
               var4 = 2;
            }
            break;
         case 2065359258:
            if(var3.equals("E_HEAD")) {
               var4 = 5;
            }
         }

         switch(var4) {
         case 0:
            if(this.gun == null) {
               this.gun = var2;
               if(var2.getBarrelSpriteAPI() != null) {
                  this.originalRArmPos = var2.getBarrelSpriteAPI().getCenterY();
               }

               ++this.limbInit;
            }
            break;
         case 1:
            if(this.armL == null) {
               this.armL = var2;
               this.originalArmPos = this.armL.getSprite().getCenterY();
               ++this.limbInit;
            }
            break;
         case 2:
            if(this.armR == null) {
               this.armR = var2;
               ++this.limbInit;
            }
            break;
         case 3:
            if(this.pauldronL == null) {
               this.pauldronL = var2;
               this.originalShoulderPos = this.pauldronL.getSprite().getCenterY();
               ++this.limbInit;
            }
            break;
         case 4:
            if(this.pauldronR == null) {
               this.pauldronR = var2;
               ++this.limbInit;
            }
            break;
         case 5:
            if(this.head == null) {
               this.head = var2;
               ++this.limbInit;
            }
            break;
         case 6:
            this.shoulderwep = var2;
            break;
         case 7:
            this.headGlow = var2;
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.ship = var3.getShip();
      this.sprite = this.ship.getSpriteAPI();
      this.system = this.ship.getSystem();
      if(!this.runOnce) {
         this.init();
      }

      if(this.gun != null) {
         if(!var2.isPaused()) {
            this.anim = this.gun.getAnimation();
            this.ship.syncWeaponDecalsWithArmorDamage();
            if(this.ship.getEngineController().isAccelerating()) {
               if(this.overlap > 9.9F) {
                  this.overlap = 10.0F;
               } else {
                  this.overlap = Math.min(10.0F, this.overlap + (10.0F - this.overlap) * var1 * 5.0F);
               }
            } else if(!this.ship.getEngineController().isDecelerating() && !this.ship.getEngineController().isAcceleratingBackwards()) {
               if(Math.abs(this.overlap) < 0.1F) {
                  this.overlap = 0.0F;
               } else {
                  this.overlap -= this.overlap / 2.0F * var1 * 3.0F;
               }
            } else if(this.overlap < -9.9F) {
               this.overlap = -10.0F;
            } else {
               this.overlap = Math.max(-10.0F, this.overlap + (-10.0F + this.overlap) * var1 * 5.0F);
            }

            float var4 = 0.0F;
            float var5 = 0.0F;
            if(this.ship.getEngineController().isTurningLeft()) {
               var4 -= 11.25F;
               var5 -= 11.25F;
            } else if(this.ship.getEngineController().isTurningRight()) {
               var4 += 11.25F;
               var5 += 11.25F;
            }

            float var6 = MathUtils.getShortestRotation(this.currentRotateL, var4);
            if(Math.abs(var6) < 0.5F) {
               this.currentRotateL = var4;
            } else if(var6 > 0.0F) {
               this.currentRotateL += 0.4F;
            } else {
               this.currentRotateL -= 0.4F;
            }

            float var7 = MathUtils.getShortestRotation(this.currentRotateR, var5);
            if(Math.abs(var7) < 0.5F) {
               this.currentRotateR = var5;
            } else if(var7 > 0.0F) {
               this.currentRotateR += 0.4F;
            } else {
               this.currentRotateR -= 0.4F;
            }

            float var8 = 0.0F;
            float var9 = 0.0F;
            float var10 = 0.0F;
            float var11 = 0.0F;
            float var12 = 0.0F;
            float var13 = this.ship.getFacing();
            float var14 = MathUtils.getShortestRotation(var13, this.gun.getCurrAngle());
            float var15 = MathUtils.getShortestRotation(var13, this.armL.getCurrAngle());
            boolean var16 = false;
            var16 = true;
            if(this.armL != null && !var16) {
               if(this.armL.getChargeLevel() < 1.0F) {
                  var8 = MagicAnim.smoothNormalizeRange(this.armL.getChargeLevel(), 0.5F, 1.0F);
                  var9 = MagicAnim.smoothNormalizeRange(this.armL.getChargeLevel(), 0.5F, 1.0F);
               } else {
                  var8 = 1.0F;
                  var9 = 1.0F;
               }

               this.armL.getSprite().setCenterY(this.originalArmPos - 16.0F * var9 + 8.0F * var12);
            }

            if(var3 != null && this.armL != null) {
               if(!var16) {
                  var3.setCurrAngle(var13 + var8 * -45.0F - var12 * -45.0F + var10 * -45.0F + var14 * 0.3F + this.currentRotateR);
                  this.armL.setCurrAngle(this.armL.getCurrAngle() + var8 * -6.428571F * 0.7F - var12 * -45.0F * 0.5F + var10 * -45.0F);
               } else {
                  var3.setCurrAngle(var13 + var8 * -45.0F + var14 * 0.3F + this.currentRotateR);
               }
            }

            if(this.armR != null) {
               this.armR.setCurrAngle(this.gun.getCurrAngle() + -25.0F + var10 * -45.0F);
            }

            if(this.pauldronR != null) {
               this.pauldronR.setCurrAngle(var13 + var8 * -45.0F - var12 * -45.0F + var10 * -45.0F * 0.5F + var14 * 0.75F + -12.5F + this.currentRotateR * 0.75F);
               if(this.gun.getBarrelSpriteAPI() != null) {
                  this.pauldronR.getSprite().setCenterY(this.gun.getBarrelSpriteAPI().getCenterY() - 40.0F);
               }

               if(var10 > 0.0F) {
                  this.gun.setCurrAngle(this.gun.getCurrAngle() + var10 * -45.0F * 0.7F);
               }
            }

            if(this.pauldronL != null) {
               if(this.armL != null) {
                  this.pauldronL.setCurrAngle(var13 + var8 * -45.0F - var12 * -45.0F * 0.5F + var10 * -45.0F + var15 * 0.75F - -12.5F + this.currentRotateL * 0.75F);
               }

               this.pauldronL.getSprite().setCenterY(this.originalShoulderPos - 8.0F * var9);
            }

            if(this.headGlow != null) {
               this.headGlow.setCurrAngle(this.head.getCurrAngle());
            }

         }
      }
   }
}
