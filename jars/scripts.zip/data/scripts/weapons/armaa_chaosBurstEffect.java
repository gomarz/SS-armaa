package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponSize;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import java.awt.Color;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_chaosBurstEffect implements EveryFrameWeaponEffectPlugin {

   private static final Vector2f ZERO = new Vector2f();
   private float CHARGEUP_PARTICLE_ANGLE_SPREAD = 360.0F;
   private float CHARGEUP_PARTICLE_BRIGHTNESS = 1.0F;
   private float CHARGEUP_PARTICLE_DISTANCE_MAX = 200.0F;
   private float CHARGEUP_PARTICLE_DISTANCE_MIN = 100.0F;
   private float CHARGEUP_PARTICLE_DURATION = 0.5F;
   private float CHARGEUP_PARTICLE_SIZE_MAX = 5.0F;
   private float CHARGEUP_PARTICLE_SIZE_MIN = 1.0F;
   public float TURRET_OFFSET = 30.0F;
   private boolean charging = false;
   private boolean cooling = false;
   private boolean firing = false;
   private final IntervalUtil interval = new IntervalUtil(0.015F, 0.015F);
   protected IntervalUtil interval2 = new IntervalUtil(0.015F, 0.25F);
   private float level = 0.0F;
   public static float TARGET_RANGE = 100.0F;
   public static float RIFT_RANGE = 50.0F;
   private boolean runOnce = false;
   private boolean hasFired = false;
   private final IntervalUtil particle = new IntervalUtil(0.025F, 0.05F);
   private final IntervalUtil particle2 = new IntervalUtil(0.1F, 0.2F);
   float charge = 0.0F;
   private static final int SMOKE_SIZE_MIN = 10;
   private static final int SMOKE_SIZE_MAX = 30;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      ShipAPI var4 = var3.getShip();
      new Color(247, 176, 52, 255);
      new Color(247, 226, 188, 255);
      if(!var2.isPaused() && var3.getShip().getOriginalOwner() != -1 && !var4.getFluxTracker().isOverloaded() && !var3.isDisabled()) {
         this.TURRET_OFFSET = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(0)).x;
         float var7 = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(0)).y;
         if(var3.getChargeLevel() > 0.0F && var3.getCooldownRemaining() > 0.0F) {
            this.particle2.advance(var1);
            if(this.particle2.intervalElapsed()) {
               Vector2f var8 = new Vector2f(var3.getLocation());
               Vector2f var9 = new Vector2f(this.TURRET_OFFSET, var7);
               VectorUtils.rotate(var9, var3.getCurrAngle(), var9);
               Vector2f.add(var9, var8, var8);
               float var10 = (float)MathUtils.getRandomNumberInRange(10, 30);
               float var11 = (float)MathUtils.getRandomNumberInRange(-20, 20);
               float var12 = (float)MathUtils.getRandomNumberInRange(-20, 20);
               Global.getCombatEngine().addSmokeParticle(var8, var9, var10 * var3.getChargeLevel(), 1.0F * var3.getChargeLevel(), 1.0F * var3.getChargeLevel(), new Color(1.0F, 1.0F, 1.0F, 0.7F));
            }
         }

         Vector2f var13;
         Vector2f var20;
         Vector2f var24;
         if(var3.isFiring()) {
            float var17 = var3.getChargeLevel();
            float var19 = 1.0F;
            if(var3.getSize() == WeaponSize.LARGE) {
               var19 = 2.0F;
            }

            Vector2f var22;
            if(!this.hasFired) {
               Global.getSoundPlayer().playLoop("beamchargeMeso", var3, 1.0F, 1.0F, var3.getLocation(), var3.getShip().getVelocity());
               this.particle.advance(var1);
               if(this.particle.intervalElapsed()) {
                  var20 = new Vector2f(var3.getLocation());
                  var22 = new Vector2f(this.TURRET_OFFSET, var7);
                  VectorUtils.rotate(var22, var3.getCurrAngle(), var22);
                  Vector2f.add(var22, var20, var20);
                  var24 = MathUtils.getPoint(var3.getLocation(), 18.5F, var3.getCurrAngle());
                  var13 = var3.getShip().getVelocity();
                  var2.addHitParticle(var20, var13, MathUtils.getRandomNumberInRange(20.0F * var19, var17 * var19 * 60.0F + 20.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var17), MathUtils.getRandomNumberInRange(0.1F, 0.1F + var17 / 10.0F), new Color(var17, var17 / 1.5F, var17 / 2.0F));
                  var2.addSwirlyNebulaParticle(var20, new Vector2f(0.0F, 0.0F), MathUtils.getRandomNumberInRange(20.0F * var19, var17 * var19 * 60.0F + 20.0F), 1.2F, 0.15F, 0.0F, 0.35F * var17, new Color(var17, var17 / 1.3F, var17 / 1.7F), false);
                  Vector2f var14 = MathUtils.getRandomPointInCircle(new Vector2f(), 35.0F * var17);
                  Vector2f var15 = new Vector2f();
                  Vector2f.sub(var20, new Vector2f(var14), var15);
                  Vector2f.add(var13, var14, var14);

                  for(int var16 = 0; var16 < 5; ++var16) {
                     var2.addHitParticle(var15, var14, MathUtils.getRandomNumberInRange(2.0F, var17 * 2.0F + 2.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var17), MathUtils.getRandomNumberInRange(0.75F, 0.75F + var17 / 4.0F), new Color(var17, var17 / 1.5F, var17 / 2.0F));
                  }
               }
            }

            if(var17 == 1.0F) {
               var20 = new Vector2f(var3.getLocation());
               var22 = new Vector2f(this.TURRET_OFFSET, var7);
               VectorUtils.rotate(var22, var3.getCurrAngle(), var22);
               Vector2f.add(var22, var20, var20);
               var24 = MathUtils.getPoint(var3.getLocation(), 18.5F, var3.getCurrAngle());
               var13 = var3.getShip().getVelocity();
               this.hasFired = true;
               var2.addHitParticle(var20, var13, MathUtils.getRandomNumberInRange(20.0F * var19, var17 * var19 * 60.0F + 20.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var17), MathUtils.getRandomNumberInRange(0.1F, 0.1F + var17 / 10.0F), new Color(var17, var17 / 1.5F, var17 / 2.0F));
            }
         } else {
            this.hasFired = false;
         }

         List var18 = var3.getBeams();
         if(!var18.isEmpty()) {
            BeamAPI var21 = (BeamAPI)var18.get(0);
            if(var21.getBrightness() >= 1.0F) {
               this.interval2.advance(var1 * 2.0F);
               if(this.interval2.intervalElapsed()) {
                  if(var21.getLengthPrevFrame() < 10.0F) {
                     return;
                  }

                  CombatEntityAPI var23 = this.findTarget(var21, var21.getWeapon(), var2);
                  if(var23 != null && Math.random() >= 0.25D) {
                     var20 = var23.getLocation();
                  } else {
                     var20 = this.pickNoTargetDest(var21, var21.getWeapon(), var2);
                  }

                  var24 = Misc.closestPointOnSegmentToPoint(var21.getFrom(), var21.getRayEndPrevFrame(), var20);
                  var13 = Misc.getUnitVectorAtDegreeAngle(Misc.getAngleInDegrees(var24, var20));
                  var13.scale(Math.min(Misc.getDistance(var24, var20), RIFT_RANGE));
                  Vector2f.add(var24, var13, var13);
                  this.spawnMine(var21.getSource(), var13);
               }

            }
         }
      }
   }

   public void spawnMine(ShipAPI var1, Vector2f var2) {
      CombatEngineAPI var3 = Global.getCombatEngine();
      MissileAPI var4 = (MissileAPI)var3.spawnProjectile(var1, (WeaponAPI)null, "armaa_valkazard_torso_chaosburst_minelayer", var2, (float)Math.random() * 360.0F, (Vector2f)null);
      if(var1 != null) {
         Global.getCombatEngine().applyDamageModifiersToSpawnedProjectileWithNullWeapon(var1, WeaponType.MISSILE, false, var4.getDamage());
      }

      float var5 = 0.05F;
      var4.getVelocity().scale(0.0F);
      var4.fadeOutThenIn(var5);
      float var6 = 0.0F;
      var4.setFlightTime(var4.getMaxFlightTime() - var6);
      var4.addDamagedAlready(var1);
      var4.setNoMineFFConcerns(true);
   }

   public Vector2f pickNoTargetDest(BeamAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      Vector2f var4 = var1.getFrom();
      Vector2f var5 = var1.getRayEndPrevFrame();
      float var6 = var1.getLengthPrevFrame();
      float var7 = 0.25F + (float)Math.random() * 0.75F;
      Vector2f var8 = Misc.getUnitVectorAtDegreeAngle(Misc.getAngleInDegrees(var4, var5));
      var8.scale(var6 * var7);
      Vector2f.add(var4, var8, var8);
      return Misc.getPointWithinRadius(var8, RIFT_RANGE);
   }

   public CombatEntityAPI findTarget(BeamAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      Vector2f var4 = var1.getRayEndPrevFrame();
      Iterator var5 = Global.getCombatEngine().getAllObjectGrid().getCheckIterator(var4, RIFT_RANGE * 2.0F, RIFT_RANGE * 2.0F);
      int var6 = var2.getShip().getOwner();
      WeightedRandomPicker var7 = new WeightedRandomPicker();

      while(var5.hasNext()) {
         Object var8 = var5.next();
         if(var8 instanceof MissileAPI || var8 instanceof ShipAPI) {
            CombatEntityAPI var9 = (CombatEntityAPI)var8;
            if(var9.getOwner() != var6) {
               if(var9 instanceof ShipAPI) {
                  ShipAPI var10 = (ShipAPI)var9;
                  if(!var10.isFighter() && !var10.isDrone()) {
                     continue;
                  }
               }

               float var13 = Misc.getTargetingRadius(var4, var9, false);
               Vector2f var11 = Misc.closestPointOnSegmentToPoint(var1.getFrom(), var1.getRayEndPrevFrame(), var9.getLocation());
               float var12 = Misc.getDistance(var11, var9.getLocation()) - var13;
               if(var12 <= TARGET_RANGE) {
                  var7.add(var9);
               }
            }
         }
      }

      return (CombatEntityAPI)var7.pick();
   }

}
