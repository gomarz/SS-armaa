package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_javelin implements EveryFrameWeaponEffectPlugin {

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(var3.getChargeLevel() == 1.0F) {
         Vector2f.add(MathUtils.getPoint(new Vector2f(), 180.0F, var3.getCurrAngle() + 180.0F), var3.getShip().getVelocity(), var3.getShip().getVelocity());
         Vector2f var4 = MathUtils.getPoint(new Vector2f(), (float)MathUtils.getRandomNumberInRange(0, 150), var3.getCurrAngle());
         Vector2f.add(var4, new Vector2f(var3.getShip().getVelocity()), var4);
      }

   }
}
