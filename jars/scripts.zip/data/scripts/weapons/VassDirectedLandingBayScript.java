package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class VassDirectedLandingBayScript implements EveryFrameWeaponEffectPlugin {

   private static final float ACCEL_BOOST = 3.0F;
   private static final float SPEED_BOOST = 2.0F;
   private static final float TURNRATE_BOOST = 1.5F;
   private static final float START_OFFSET_LENGTH = 450.0F;
   private static final float MOVE_DURATION = 3.0F;
   private Map timers = new HashMap();
   private static final float CLEAN_WAIT = 10.0F;
   private float cleanTimer = 0.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      ShipAPI var4 = var3.getShip();
      if(var4 != null && !var4.isHulk()) {
         this.cleanTimer += var1;
         if(this.cleanTimer > 10.0F) {
            this.cleanTimer = 0.0F;
            ArrayList var5 = new ArrayList();
            Iterator var6 = this.timers.keySet().iterator();

            ShipAPI var7;
            while(var6.hasNext()) {
               var7 = (ShipAPI)var6.next();
               if(!var2.isEntityInPlay(var7) || var7.isHulk() || !var7.isLanding() || var7.isFinishedLanding()) {
                  var5.add(var7);
               }
            }

            var6 = var5.iterator();

            while(var6.hasNext()) {
               var7 = (ShipAPI)var6.next();
               this.timers.remove(var7);
            }
         }

         Iterator var9 = CombatUtils.getShipsWithinRange(var4.getLocation(), var4.getCollisionRadius() * 1.5F).iterator();

         ShipAPI var10;
         while(var9.hasNext()) {
            var10 = (ShipAPI)var9.next();
            if(var2.isEntityInPlay(var10) && !var10.isHulk() && var10.isLanding() && !var10.isFinishedLanding() && !this.timers.containsKey(var10) && var10.getWing() != null && var10.getWing().getSourceShip() == var4) {
               this.timers.put(var10, Float.valueOf(0.0F));
            }
         }

         var9 = this.timers.keySet().iterator();

         while(var9.hasNext()) {
            var10 = (ShipAPI)var9.next();
            float var11 = var1 * var10.getMutableStats().getTimeMult().getModifiedValue() / var4.getMutableStats().getTimeMult().getModifiedValue();
            this.timers.put(var10, Float.valueOf(((Float)this.timers.get(var10)).floatValue() + var11));
            Vector2f var8 = MathUtils.getPoint(var3.getLocation(), 450.0F * (1.0F - ((Float)this.timers.get(var10)).floatValue() / 3.0F), var3.getCurrAngle());
            this.moveFighter(var11, var10, var8, var4.getFacing());
         }

      }
   }

   private void moveFighter(float var1, ShipAPI var2, Vector2f var3, float var4) {
      float var5 = var1 * var2.getAcceleration() * 3.0F;
      float var6 = var1 * var2.getMaxTurnRate() * 1.5F;
      float var7 = MathUtils.getDistance(var2.getLocation(), var3);
      float var8 = VectorUtils.getAngle(var2.getLocation(), var3);
      float var9 = var6 * Math.signum(MathUtils.getShortestRotation(var2.getFacing(), var4));
      if(Math.abs(var9) > Math.abs(MathUtils.getShortestRotation(var2.getFacing(), var4))) {
         var9 = MathUtils.getShortestRotation(var2.getFacing(), var4);
      }

      var2.setFacing(var2.getFacing() + var9);
      Vector2f var10;
      if(var2.getVelocity().length() / (var2.getAcceleration() * 3.0F) > var7 / var2.getVelocity().length()) {
         var10 = MathUtils.getPoint(Misc.ZERO, var5, VectorUtils.getAngle(var2.getVelocity(), Misc.ZERO));
         Vector2f var10000 = var2.getVelocity();
         var10000.x += var10.x;
         var10000 = var2.getVelocity();
         var10000.y += var10.y;
      } else {
         var10 = MathUtils.getPoint(var2.getVelocity(), var5, var8);
         var2.getVelocity().x = var10.x;
         var2.getVelocity().y = var10.y;
         if(var2.getVelocity().length() > var2.getMaxSpeed() * 2.0F) {
            var10 = MathUtils.getPoint(Misc.ZERO, var2.getMaxSpeed() * 2.0F, VectorUtils.getAngle(Misc.ZERO, var2.getVelocity()));
            var2.getVelocity().x = var10.x;
            var2.getVelocity().y = var10.y;
         }
      }

   }
}
