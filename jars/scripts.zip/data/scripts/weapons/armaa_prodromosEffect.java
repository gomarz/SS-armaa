package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;

public class armaa_prodromosEffect implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private ShipAPI ship;
   private AnimationAPI anim;
   private AnimationAPI aGlow;
   private AnimationAPI aGlow2;
   private WeaponAPI head;
   private WeaponAPI armL;
   private WeaponAPI armR;
   private WeaponAPI pauldronL;
   private WeaponAPI pauldronR;
   private WeaponAPI torso;
   private WeaponAPI wGlow;
   private WeaponAPI hGlow;
   private WeaponAPI cannon;
   private int limbInit = 0;
   private float overlap = 0.0F;
   private float heat = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -75.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;


   public void init() {
      this.runOnce = true;
      Iterator var1 = this.ship.getAllWeapons().iterator();

      while(var1.hasNext()) {
         WeaponAPI var2 = (WeaponAPI)var1.next();
         String var3 = var2.getSlot().getId();
         byte var4 = -1;
         switch(var3.hashCode()) {
         case 1245480854:
            if(var3.equals("B_TORSO")) {
               var4 = 0;
            }
            break;
         case 2007905292:
            if(var3.equals("C_ARML")) {
               var4 = 1;
            }
         }

         switch(var4) {
         case 0:
            if(this.torso == null) {
               this.torso = var2;
               ++this.limbInit;
            }
            break;
         case 1:
            if(this.armL == null) {
               this.armL = var2;
               ++this.limbInit;
            }
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.ship = var3.getShip();
      this.init();
      if(this.ship.getEngineController().isAccelerating()) {
         if(this.overlap > 9.9F) {
            this.overlap = 10.0F;
         } else {
            this.overlap = Math.min(10.0F, this.overlap + (10.0F - this.overlap) * var1 * 5.0F);
         }
      } else if(!this.ship.getEngineController().isDecelerating() && !this.ship.getEngineController().isAcceleratingBackwards()) {
         if(Math.abs(this.overlap) < 0.1F) {
            this.overlap = 0.0F;
         } else {
            this.overlap -= this.overlap / 2.0F * var1 * 3.0F;
         }
      } else if(this.overlap < -9.9F) {
         this.overlap = -10.0F;
      } else {
         this.overlap = Math.max(-10.0F, this.overlap + (-10.0F + this.overlap) * var1 * 5.0F);
      }

      float var4 = 0.0F;
      float var5 = 0.0F;
      float var6 = this.ship.getFacing();
      float var7 = MathUtils.getShortestRotation(var6, var3.getCurrAngle());
      if(this.torso != null) {
         this.torso.setCurrAngle(var6 + var4 * -45.0F + var7 * 0.3F);
      }

      this.ship.syncWeaponDecalsWithArmorDamage();
   }
}
