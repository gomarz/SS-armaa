package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicLensFlare;
import org.magiclib.util.MagicRender;

public class HomingLaserOnHit implements OnHitEffectPlugin {

   private static final int CRIT_DAMAGE_MIN = 5;
   private static final int CRIT_DAMAGE_MAX = 30;
   private static final float CRIT_CHANCE = 0.25F;
   private ShipAPI ship;
   private static final Color EXPLOSION_COLOR = new Color(255, 182, 64, 255);
   private static final Color PARTICLE_COLOR = new Color(130, 100, 255, 255);
   private static final float PARTICLE_SIZE = 5.0F;
   private static final float PARTICLE_BRIGHTNESS = 150.0F;
   private static final float PARTICLE_DURATION = 3.0F;
   private static final int PARTICLE_COUNT = 6;
   private static final float CONE_ANGLE = 150.0F;
   private static final float VEL_MIN = 0.1F;
   private static final float VEL_MAX = 0.15F;
   private static final float A_2 = 75.0F;


   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      if(var2 instanceof ShipAPI && !var4 && Math.random() <= 0.25D) {
         var6.applyDamage(var2, var3, (float)MathUtils.getRandomNumberInRange(5, 30), DamageType.HIGH_EXPLOSIVE, 0.0F, false, false, var1.getSource());
         if(MagicRender.screenCheck(0.2F, var3)) {
            MagicLensFlare.createSmoothFlare(var6, var1.getSource(), var3, 50.0F, 400.0F, 0.0F, new Color(23, 25, 255), new Color(200, 200, 200));
         }
      }

      if(MagicRender.screenCheck(0.2F, var3)) {
         MagicLensFlare.createSharpFlare(var6, var1.getSource(), var3, 6.0F, 300.0F, 0.0F, new Color(155, 20, 255), new Color(255, 20, 255));
         float var7 = var1.getVelocity().length();
         float var8 = var1.getFacing();

         for(int var9 = 0; var9 <= 6; ++var9) {
            float var10 = MathUtils.getRandomNumberInRange(var8 - 75.0F, var8 + 75.0F);
            float var11 = MathUtils.getRandomNumberInRange(var7 * -0.1F, var7 * -0.15F);
            Vector2f var12 = MathUtils.getPointOnCircumference((Vector2f)null, var11, var10);
            var6.addHitParticle(var3, var12, 5.0F, 150.0F, 3.0F, PARTICLE_COLOR);
         }
      }

   }

}
