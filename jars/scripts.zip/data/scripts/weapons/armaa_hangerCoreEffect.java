package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.ShipAIPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import data.scripts.util.armaa_utils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class armaa_hangerCoreEffect implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin {

   private List alreadyRegisteredBits = new ArrayList();


   public void init(ShipAPI var1) {}

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      ShipAPI var4 = var3.getShip();
      ArrayList var5 = new ArrayList(this.alreadyRegisteredBits);
      if(var5.size() > 0) {
         var3.setAmmo(0);
      }

      Iterator var6 = var5.iterator();

      while(var6.hasNext()) {
         ShipAPI var7 = (ShipAPI)var6.next();
         if(var2.isEntityInPlay(var7) && var7.isAlive()) {
            if(!var4.isAlive() || var4.getHitpoints() <= 0.0F || !Global.getCombatEngine().isEntityInPlay(var4)) {
               var7.setHitpoints(0.0F);
               Global.getCombatEngine().removeEntity(var7);
            }

            var7.getSpriteAPI().setColor(new Color(0.0F, 0.0F, 0.0F, 0.0F));
            var7.setFacing(var4.getFacing());
            var7.setCollisionClass(CollisionClass.NONE);
            var7.getVelocity().set(var4.getVelocity());
            armaa_utils.setLocation(var7, var4.getShieldCenterEvenIfNoShield());
            if(var7.getSystem().getAmmo() > 0) {
               var7.useSystem();
            }

            var7.setShipAI((ShipAIPlugin)null);
         } else {
            this.alreadyRegisteredBits.remove(var7);
         }
      }

   }

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      var3.getFleetManager(var2.getShip().getOwner()).setSuppressDeploymentMessages(true);
      ShipAPI var4 = var3.getFleetManager(var2.getShip().getOwner()).spawnShipOrWing("eis_havoc_wing_dummy", var2.getShip().getLocation(), var2.getShip().getFacing(), 0.0F, var2.getShip().getCaptain());
      var4.setAnimatedLaunch();
      if(!this.alreadyRegisteredBits.contains(var4) && var3.isEntityInPlay(var4) && var4.isAlive()) {
         this.alreadyRegisteredBits.add(var4);
      }

      var3.getFleetManager(var2.getShip().getOwner()).setSuppressDeploymentMessages(false);
   }
}
