package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponSize;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_sylphAMWSEffect implements EveryFrameWeaponEffectPlugin {

   private static final Vector2f ZERO = new Vector2f();
   private float CHARGEUP_PARTICLE_ANGLE_SPREAD = 360.0F;
   private float CHARGEUP_PARTICLE_BRIGHTNESS = 1.0F;
   private float CHARGEUP_PARTICLE_DISTANCE_MAX = 200.0F;
   private float CHARGEUP_PARTICLE_DISTANCE_MIN = 100.0F;
   private float CHARGEUP_PARTICLE_DURATION = 0.5F;
   private float CHARGEUP_PARTICLE_SIZE_MAX = 5.0F;
   private float CHARGEUP_PARTICLE_SIZE_MIN = 1.0F;
   public float TURRET_OFFSET = 30.0F;
   private float level = 0.0F;
   private boolean runOnce = false;
   private boolean hasFired = false;
   private final IntervalUtil particle = new IntervalUtil(0.025F, 0.05F);
   private final IntervalUtil particle2 = new IntervalUtil(0.1F, 0.2F);
   float charge = 0.0F;
   private static final int SMOKE_SIZE_MIN = 30;
   private static final int SMOKE_SIZE_MAX = 60;
   private boolean isAnimating = false;
   private IntervalUtil interval = new IntervalUtil(1.0F, 20.0F);
   private IntervalUtil animInterval = new IntervalUtil(0.06F, 0.08F);
   private int target = 0;
   private int currFrame = 0;


   public int getAngle(int var1, int var2) {
      int var3 = var1 + var2;
      if(var3 > 360) {
         var3 %= 360;
      }

      return var3;
   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      ShipAPI var4 = var3.getShip();
      new Color(247, 176, 52, 255);
      new Color(0, 226, 188, 255);
      if(var3.getBeams() != null && !var3.getBeams().isEmpty()) {
         Color var5 = ((BeamAPI)var3.getBeams().get(0)).getCoreColor();
         var5 = ((BeamAPI)var3.getBeams().get(0)).getFringeColor();
      }

      if(!var2.isPaused() && var3.getShip().getOriginalOwner() != -1 && !var4.getFluxTracker().isOverloaded() && !var3.isDisabled()) {
         this.TURRET_OFFSET = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(0)).x;
         float var7 = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(0)).y;
         float var8;
         float var9;
         if(var3.isFiring()) {
            var8 = var3.getChargeLevel();
            var9 = 1.0F;
            if(var3.getSize() == WeaponSize.LARGE) {
               var9 = 3.0F;
            }

            Vector2f var10;
            Vector2f var11;
            Vector2f var12;
            Vector2f var13;
            if(!this.hasFired) {
               Global.getSoundPlayer().playLoop("beamchargeMeso", var3, 0.8F, 1.0F, var3.getLocation(), var3.getShip().getVelocity());
               this.particle.advance(var1);
               if(this.particle.intervalElapsed()) {
                  var10 = new Vector2f(var3.getLocation());
                  var11 = new Vector2f(this.TURRET_OFFSET, var7);
                  VectorUtils.rotate(var11, var3.getCurrAngle(), var11);
                  Vector2f.add(var11, var10, var10);
                  var12 = MathUtils.getPoint(var3.getLocation(), 18.5F, var3.getCurrAngle());
                  var13 = var3.getShip().getVelocity();
                  var2.addHitParticle(var10, var13, MathUtils.getRandomNumberInRange(30.0F * var9, var8 * var9 * 30.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var8), MathUtils.getRandomNumberInRange(0.1F, 0.1F + var8 / 10.0F), new Color(var8, var8, var8 / 10.0F));
                  Vector2f var14 = MathUtils.getRandomPointInCircle(new Vector2f(), 35.0F * var8);
                  Vector2f var15 = new Vector2f();
                  Vector2f.sub(var10, new Vector2f(var14), var15);
                  Vector2f.add(var13, var14, var14);

                  for(int var16 = 0; var16 < 3; ++var16) {
                     var2.addHitParticle(var15, var14, MathUtils.getRandomNumberInRange(1.0F, var8 * 3.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var8), MathUtils.getRandomNumberInRange(0.75F, 0.75F + var8 / 4.0F), new Color(var8, var8, var8 / 10.0F));
                  }
               }
            }

            if(var8 == 1.0F) {
               var10 = new Vector2f(var3.getLocation());
               var11 = new Vector2f(this.TURRET_OFFSET, var7);
               VectorUtils.rotate(var11, var3.getCurrAngle(), var11);
               Vector2f.add(var11, var10, var10);
               var12 = MathUtils.getPoint(var3.getLocation(), 18.5F, var3.getCurrAngle());
               var13 = var3.getShip().getVelocity();
               this.hasFired = true;
               var2.addHitParticle(var10, var13, MathUtils.getRandomNumberInRange(20.0F * var9, var8 * var9 * 20.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var8), MathUtils.getRandomNumberInRange(0.1F, 0.1F + var8 / 10.0F), new Color(var8, var8, var8 / 10.0F));
            }
         } else {
            this.hasFired = false;
         }

         if(this.interval.intervalElapsed() && !this.isAnimating) {
            this.isAnimating = true;
            this.currFrame = var3.getAnimation().getFrame();
            this.target = this.currFrame <= 4?8:0;
            this.animInterval = new IntervalUtil(0.055F, 0.08F);
            if(var3.getShip().getShipTarget() != null) {
               var8 = var3.getCurrAngle();
               var9 = VectorUtils.getAngle(var3.getShip().getLocation(), var3.getShip().getShipTarget().getLocation());
               float var17 = Math.abs(var8 - var9);
               float var18 = 4.0F;
               if(var8 > var9) {
                  this.target = (int)Math.floor((double)Math.min(5.0F + var17 / 25.0F, 8.0F));
               } else if(var8 < var9) {
                  this.target = (int)Math.floor((double)Math.max(3.0F - var17 / 25.0F, 0.0F));
               }
            } else if(Math.random() <= 0.25D) {
               if(this.target == 8) {
                  this.target = MathUtils.getRandomNumberInRange(4, 6);
               } else {
                  this.target = MathUtils.getRandomNumberInRange(0, 4);
               }
            }

            if(Math.random() <= 0.25D) {
               Global.getSoundPlayer().playSound("armaa_monoeye_move", 0.8F, 0.8F, var3.getLocation(), var3.getShip().getVelocity());
            }
         }

         if(!this.isAnimating) {
            this.interval.advance(var1);
         } else {
            this.animInterval.advance(var1);
            if(this.animInterval.intervalElapsed()) {
               this.currFrame = var3.getAnimation().getFrame();
               if(this.currFrame == this.target) {
                  this.interval = new IntervalUtil(5.0F, 15.0F);
                  this.isAnimating = false;
               } else if(this.currFrame < this.target) {
                  var3.getAnimation().setFrame(Math.min(this.currFrame + 1, 8));
               } else {
                  var3.getAnimation().setFrame(Math.max(0, this.currFrame - 1));
               }
            }
         }

      }
   }

}
