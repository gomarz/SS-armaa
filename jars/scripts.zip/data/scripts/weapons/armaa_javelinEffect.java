package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicLensFlare;
import org.magiclib.util.MagicRender;

public class armaa_javelinEffect implements OnHitEffectPlugin {

   private final int NUM_PARTICLES = 14;
   private final Color PARTICLE_COLOR = new Color(50, 142, 255, 255);


   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      if(MagicRender.screenCheck(0.2F, var3)) {
         var6.addSmoothParticle(var3, new Vector2f(), 200.0F, 2.0F, 0.3F, Color.WHITE);
         var6.addSmoothParticle(var3, new Vector2f(), 200.0F, 2.0F, 0.2F, Color.WHITE);
         var6.addSmoothParticle(var3, new Vector2f(), 200.0F, 2.0F, 0.1F, Color.WHITE);
         MagicLensFlare.createSmoothFlare(var6, var1.getSource(), var3, 15.0F, 400.0F, 0.0F, new Color(0, 150, 255), Color.DARK_GRAY);

         int var7;
         for(var7 = 0; var7 < 30; ++var7) {
            int var8 = MathUtils.getRandomNumberInRange(20, 100);
            var6.addSmokeParticle(MathUtils.getRandomPointInCircle(var3, 40.0F), MathUtils.getRandomPointInCone(new Vector2f(), 30.0F, var1.getFacing() + 90.0F, var1.getFacing() + 270.0F), (float)MathUtils.getRandomNumberInRange(30, 60), 1.0F, (float)MathUtils.getRandomNumberInRange(2, 5), new Color(var8 / 10, var8, (int)((float)var8 / MathUtils.getRandomNumberInRange(1.5F, 2.0F)), MathUtils.getRandomNumberInRange(8, 32)));
         }

         for(var7 = 0; var7 < 14; ++var7) {
            var6.addHitParticle(var3, MathUtils.getRandomPointInCone(new Vector2f(), (float)(var7 * 10), var1.getFacing() + 90.0F, var1.getFacing() + 270.0F), 7.0F, 1.0F, (float)(2 - var7 / 10), this.PARTICLE_COLOR);
         }
      }

   }
}
