package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.Iterator;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_legAnim implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private WeaponAPI torso;
   public int frame = 7;
   private IntervalUtil interval = new IntervalUtil(0.07F, 0.07F);
   private IntervalUtil interval2;
   private Color ogColor;


   public void init(WeaponAPI var1, float var2) {
      this.runOnce = true;
      Iterator var3 = var1.getShip().getAllWeapons().iterator();

      while(var3.hasNext()) {
         WeaponAPI var4 = (WeaponAPI)var3.next();
         String var5 = var4.getSlot().getId();
         byte var6 = -1;
         switch(var5.hashCode()) {
         case 1245480854:
            if(var5.equals("B_TORSO")) {
               var6 = 0;
            }
         }

         switch(var6) {
         case 0:
            if(this.torso == null) {
               this.torso = var4;
            }
         }
      }

      this.ogColor = new Color((float)var1.getSprite().getColor().getRed() / 255.0F, (float)var1.getSprite().getColor().getGreen() / 255.0F, (float)var1.getSprite().getColor().getBlue() / 255.0F);
      this.interval2 = new IntervalUtil(var2, var2);
   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(Global.getCombatEngine().isEntityInPlay(var3.getShip())) {
         if(MagicRender.screenCheck(0.1F, var3.getLocation()) && !Global.getCombatEngine().isPaused()) {
            ShipAPI var4 = var3.getShip();
            if(var4.isAlive()) {
               if(!var4.getHullSpec().getHullId().equals("armaa_valkazard")) {
                  if(var4.getOwner() == -1) {
                     var3.getAnimation().setFrame(7);
                  } else {
                     if(!this.runOnce) {
                        this.init(var3, var1);
                     }

                     if(this.torso != null) {
                        this.interval.advance(var1);
                        if(!var4.getEngineController().isAcceleratingBackwards() && !var4.getEngineController().isDecelerating()) {
                           if(var4.getEngineController().isAccelerating()) {
                              if(this.interval.intervalElapsed() && this.frame != 16) {
                                 ++this.frame;
                              }

                              if(this.frame > 16) {
                                 this.frame = 16;
                              }
                           } else if(this.interval.intervalElapsed()) {
                              if(this.frame > 7) {
                                 --this.frame;
                              } else if(this.frame != 7) {
                                 ++this.frame;
                              }
                           }
                        } else {
                           if(this.interval.intervalElapsed() && this.frame != 1) {
                              --this.frame;
                           }

                           if(this.frame < 1) {
                              this.frame = 1;
                           }
                        }

                        SpriteAPI var5 = Global.getSettings().getSprite("graphics/armaa/ships/legs/armaa_ht_legs0" + this.frame + ".png");
                        Color var6 = this.torso.getSprite().getAverageColor();
                        Color var7 = new Color(var6.getRed() + 60, var6.getGreen() + 60, var6.getBlue() + 60);
                        if(this.frame >= 10) {
                           var5 = Global.getSettings().getSprite("graphics/armaa/ships/legs/armaa_ht_legs" + this.frame + ".png");
                        }

                        var3.getAnimation().setFrame(this.frame);
                        if(var4.getHullSpec().getBaseHullId().equals("armaa_leynos_frig") || var4.getHullSpec().getBaseHullId().equals("armaa_leynos_frig_lt")) {
                           var5 = Global.getSettings().getSprite("graphics/armaa/ships/legs/armaa_ml_legs0" + this.frame + ".png");
                           if(var4.getHullSpec().getBaseHullId().equals("armaa_leynos_frig")) {
                              var7 = new Color(Color.white.getRed() - 50, Color.white.getGreen() - 50, Color.white.getBlue() - 50, 255);
                           } else {
                              var7 = new Color(var6.getRed() + 50, var6.getGreen() + 20, var6.getBlue() + 20);
                           }

                           if(this.frame >= 10) {
                              var5 = Global.getSettings().getSprite("graphics/armaa/ships/legs/armaa_ml_legs" + this.frame + ".png");
                           }
                        }

                        if(var4.getVariant().getWeaponSpec("F_LEGS").getWeaponId().equals("armaa_valkazard_legs")) {
                           var7 = new Color((float)this.ogColor.getRed() / 255.0F * 0.85F, (float)this.ogColor.getGreen() / 255.0F, (float)this.ogColor.getBlue() / 255.0F, 1.0F * var4.getCombinedAlphaMult());
                           var5 = Global.getSettings().getSprite("graphics/armaa/ships/valkazard/armaa_valkazard_legs0" + this.frame + ".png");
                           if(this.frame >= 10) {
                              var5 = Global.getSettings().getSprite("graphics/armaa/ships/valkazard/armaa_valkazard_legs" + this.frame + ".png");
                           }
                        }

                        var7 = new Color((float)var7.getRed() / 255.0F, (float)var7.getGreen() / 255.0F, (float)var7.getBlue() / 255.0F, (float)var7.getAlpha() / 255.0F * var4.getCombinedAlphaMult());
                        MagicRender.singleframe(var5, new Vector2f(var3.getLocation().getX(), var3.getLocation().getY()), new Vector2f(var5.getWidth(), var5.getHeight()), var4.getFacing() - 90.0F, var7, false, CombatEngineLayers.BELOW_SHIPS_LAYER);
                        var3.getSprite().setColor(new Color(0.0F, 0.0F, 0.0F, 0.0F));
                     }
                  }
               }
            }
         }
      }
   }
}
