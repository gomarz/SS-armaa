package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;

public class armaa_spinEffect implements EveryFrameWeaponEffectPlugin {

   private float spinSpeed = 1.0F;
   private float counterSpeed = 0.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!var2.isPaused()) {
         ShipAPI var4 = var3.getShip();
         if(var4.isAlive()) {
            float var5 = var3.getCurrAngle();
            if(var4.getFluxTracker().isVenting()) {
               this.counterSpeed -= var1;
            } else {
               this.counterSpeed += this.counterSpeed >= 1.0F?0.0F:var1;
            }

            var5 += this.spinSpeed + Math.max(-1.0F, this.counterSpeed);
            var3.setCurrAngle(var5);
         }
      }
   }
}
