package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class armaa_spikeThrowerEffect implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean empty = false;
   private Map detonation = new HashMap();
   private List hit = new ArrayList();


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!this.runOnce) {
         this.runOnce = true;
         this.detonation.clear();
         this.hit.clear();
      }

      if(!var2.isPaused()) {
         if(!this.detonation.isEmpty()) {
            Iterator var4 = this.detonation.keySet().iterator();

            while(var4.hasNext()) {
               CombatEntityAPI var5 = (CombatEntityAPI)var4.next();
               if(((Boolean)this.detonation.get(var5)).booleanValue()) {
                  var4.remove();
               }
            }
         }

         if(var3.getAmmo() == 0) {
            if(!this.empty) {
               this.empty = true;
               Global.getSoundPlayer().playSound("armaa_stake_empty", 1.0F, 2.0F, var3.getLocation(), var3.getShip().getVelocity());
            }
         } else if(this.empty) {
            this.empty = false;
         }

      }
   }

   public void putHIT(CombatEntityAPI var1) {
      this.hit.add(var1);
   }

   public List getHITS() {
      return this.hit;
   }

   public void setDetonation(CombatEntityAPI var1) {
      if(this.hit.contains(var1)) {
         this.hit.remove(var1);
      }

      if(!this.detonation.containsKey(var1)) {
         this.detonation.put(var1, Boolean.valueOf(false));
      }

   }

   public boolean getDetonation(CombatEntityAPI var1) {
      return this.detonation.containsKey(var1)?((Boolean)this.detonation.get(var1)).booleanValue():true;
   }

   public void applyDetonation(CombatEntityAPI var1) {
      if(this.detonation.containsKey(var1)) {
         this.detonation.put(var1, Boolean.valueOf(true));
      }

   }
}
