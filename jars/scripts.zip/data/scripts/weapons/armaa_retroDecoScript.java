package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.util.Iterator;

public class armaa_retroDecoScript implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private WeaponAPI vernier;


   public void init(WeaponAPI var1) {
      this.runOnce = true;
      String var2 = var1.getSlot().getId();
      var2 = var2.replaceAll("[^0-9]", "");
      int var3 = Integer.parseInt(var2);
      String var4 = "VERNIER_" + var3;
      Iterator var5 = var1.getShip().getAllWeapons().iterator();

      while(var5.hasNext()) {
         WeaponAPI var6 = (WeaponAPI)var5.next();
         if(var6.getSlot().getId().equals(var4) && this.vernier == null) {
            this.vernier = var6;
            break;
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!this.runOnce) {
         this.init(var3);
      }

      if(this.vernier != null) {
         var3.setCurrAngle(this.vernier.getCurrAngle());
      }
   }
}
