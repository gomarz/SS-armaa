package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.ProximityExplosionEffect;
import com.fs.starfarer.api.impl.combat.NegativeExplosionVisual;
import com.fs.starfarer.api.impl.combat.NegativeExplosionVisual.NEParams;
import com.fs.starfarer.api.loading.MissileSpecAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;

public class armaa_chaosBurstMineExplosion extends NEParams implements ProximityExplosionEffect {

   public void onExplosion(DamagingProjectileAPI var1, DamagingProjectileAPI var2) {
      NEParams var3 = createStandardRiftParams("armaa_valkazard_torso_chaosburst_minelayer", 10.0F);
      var3.thickness = 50.0F;
      CombatEngineAPI var4 = Global.getCombatEngine();
      var4.addSmoothParticle(var2.getLocation(), new Vector2f(0.0F, 0.0F), 200.0F, 2.0F, 0.07F, Color.white);
      var4.addHitParticle(var2.getLocation(), new Vector2f(0.0F, 0.0F), 150.0F, 1.5F, 0.4F, new Color(245, 184, 54, 255));
      var4.addHitParticle(var2.getLocation(), new Vector2f(0.0F, 0.0F), 75.0F, 1.5F, 0.4F, Color.white);
   }

   public static void spawnStandardRift(DamagingProjectileAPI var0, NEParams var1) {
      CombatEngineAPI var2 = Global.getCombatEngine();
      var0.addDamagedAlready(var0.getSource());
      Object var3 = null;

      for(int var4 = 0; var4 < 2; ++var4) {
         NEParams var5 = createStandardRiftParams("armaa_valkazard_torso_chaosburst_minelayer", 10.0F);
         var5.radius *= 0.75F + 0.5F * (float)Math.random();
         var5.withHitGlow = var3 == null;
         Vector2f var6 = new Vector2f(var0.getLocation());
         var6 = Misc.getPointAtRadius(var6, var5.radius * 0.4F);
         CombatEntityAPI var7 = var2.addLayeredRenderingPlugin(new NegativeExplosionVisual(var5));
         var7.getLocation().set(var6);
         if(var3 != null) {
            float var8 = Misc.getDistance(((CombatEntityAPI)var3).getLocation(), var6);
            Vector2f var9 = Misc.getUnitVectorAtDegreeAngle(Misc.getAngleInDegrees(var6, ((CombatEntityAPI)var3).getLocation()));
            var9.scale(var8 / (var5.fadeIn + var5.fadeOut) * 0.7F);
            var7.getVelocity().set(var9);
         }
      }

   }

   public static NEParams createStandardRiftParams(String var0, float var1) {
      Color var2 = new Color(220, 125, 55, 155);
      Object var3 = Global.getSettings().getWeaponSpec(var0).getProjectileSpec();
      if(var3 instanceof MissileSpecAPI) {
         MissileSpecAPI var4 = (MissileSpecAPI)var3;
         var2 = var4.getGlowColor();
      }

      NEParams var5 = createStandardRiftParams(var2, var1);
      return var5;
   }

   public static NEParams createStandardRiftParams(Color var0, float var1) {
      NEParams var2 = new NEParams();
      var2.hitGlowSizeMult = 0.75F;
      var2.spawnHitGlowAt = 0.0F;
      var2.noiseMag = 1.0F;
      var2.fadeIn = 0.1F;
      var2.underglow = new Color(225, 125, 25, 100);
      var2.withHitGlow = true;
      var2.radius = var1;
      var2.color = var0;
      return var2;
   }
}
