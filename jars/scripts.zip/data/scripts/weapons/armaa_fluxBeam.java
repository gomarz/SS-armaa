package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_fluxBeam implements BeamEffectPlugin {

   private IntervalUtil fireInterval = new IntervalUtil(0.2F, 0.3F);
   private boolean wasZero = true;
   private final Vector2f ZERO = new Vector2f();
   private float CHARGEUP_PARTICLE_ANGLE_SPREAD = 150.0F;
   private final float A_2;
   private float CHARGEUP_PARTICLE_BRIGHTNESS;
   private float CHARGEUP_PARTICLE_DISTANCE_MAX;
   private float CHARGEUP_PARTICLE_DISTANCE_MIN;
   private float CHARGEUP_PARTICLE_DURATION;
   private float CHARGEUP_PARTICLE_SIZE_MAX;
   private float CHARGEUP_PARTICLE_SIZE_MIN;
   public float TURRET_OFFSET;
   private boolean charging;
   private boolean cooling;
   private boolean firing;
   private final IntervalUtil interval;
   private final IntervalUtil interval2;
   private float level;
   private final float VEL_MIN;
   private final float VEL_MAX;
   private boolean runOnce;
   private static final Color PARTICLE_COLOR = new Color(200, 200, 200, 255);
   private static final float PARTICLE_SIZE_MIN = 5.0F;
   private static final float PARTICLE_SIZE_MAX = 10.0F;
   private static final float PARTICLE_DURATION_MIN = 0.4F;
   private static final float PARTICLE_DURATION_MAX = 0.9F;
   private static final float PARTICLE_INERTIA_MULT = 0.5F;
   private static final float PARTICLE_DRIFT = 50.0F;
   private static final float PARTICLE_DENSITY = 0.05F;
   private static final float PARTICLE_SPAWN_WIDTH_MULT = 0.5F;


   public armaa_fluxBeam() {
      this.A_2 = this.CHARGEUP_PARTICLE_ANGLE_SPREAD / 2.0F;
      this.CHARGEUP_PARTICLE_BRIGHTNESS = 1.0F;
      this.CHARGEUP_PARTICLE_DISTANCE_MAX = 150.0F;
      this.CHARGEUP_PARTICLE_DISTANCE_MIN = 100.0F;
      this.CHARGEUP_PARTICLE_DURATION = 0.5F;
      this.CHARGEUP_PARTICLE_SIZE_MAX = 5.0F;
      this.CHARGEUP_PARTICLE_SIZE_MIN = 1.0F;
      this.TURRET_OFFSET = 20.0F;
      this.charging = false;
      this.cooling = false;
      this.firing = false;
      this.interval = new IntervalUtil(0.015F, 0.015F);
      this.interval2 = new IntervalUtil(0.075F, 0.075F);
      this.level = 0.0F;
      this.VEL_MIN = 1.0F;
      this.VEL_MAX = 1.5F;
      this.runOnce = false;
   }

   public void advance(float var1, CombatEngineAPI var2, BeamAPI var3) {
      CombatEntityAPI var4 = var3.getDamageTarget();
      WeaponAPI var5 = var3.getWeapon();
      float var6 = var3.getWidth();
      ShipAPI var7 = var5.getShip();
      if(var5.getChargeLevel() >= 1.0F && !this.runOnce) {
         this.runOnce = true;
      }

      if(MagicRender.screenCheck(0.2F, var5.getLocation()) && !Global.getCombatEngine().isPaused()) {
         float var8;
         Vector2f var10;
         if(var4 instanceof CombatEntityAPI) {
            var8 = var3.getDamage().getDpsDuration();
            if(!this.wasZero) {
               var8 = 0.0F;
            }

            this.wasZero = var3.getDamage().getDpsDuration() <= 0.0F;
            this.fireInterval.advance(var8);
            Vector2f var9 = new Vector2f(var5.getLocation());
            var10 = new Vector2f(this.TURRET_OFFSET, -0.0F);
            VectorUtils.rotate(var10, var5.getCurrAngle(), var10);
            Vector2f.add(var10, var9, var9);
            float var11 = var5.getCurrAngle();
            Vector2f var12 = var5.getShip().getVelocity();
            Vector2f var13 = Vector2f.sub(var3.getTo(), var3.getFrom(), new Vector2f());
            if(var13.lengthSquared() > 0.0F) {
               var13.normalise();
            }

            var13.scale(50.0F);
            Vector2f.sub(var3.getTo(), var13, new Vector2f());
            if(var5.isFiring() || var5.getChargeLevel() > 0.0F) {
               float var15 = 30.0F + var5.getChargeLevel() * var5.getChargeLevel() * MathUtils.getRandomNumberInRange(25.0F, 75.0F);
               float var16 = var3.getWeapon().getCurrAngle();
               if((float)Math.random() <= 0.5F) {
                  int var17 = 1 + (int)(var5.getChargeLevel() * 3.0F);

                  for(int var18 = 0; var18 < var17; ++var18) {
                     Color var19 = Math.random() <= 0.75D?var3.getFringeColor():new Color(255, 255, 200, 255);
                     float var20 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_DISTANCE_MIN + 1.0F, this.CHARGEUP_PARTICLE_DISTANCE_MAX + 1.0F) * var5.getChargeLevel();
                     float var21 = 0.75F * var20 / this.CHARGEUP_PARTICLE_DURATION * var5.getChargeLevel();
                     float var22 = MathUtils.getRandomNumberInRange(var16 - this.A_2, var16 + this.A_2);
                     float var23 = MathUtils.getRandomNumberInRange(var21 * -1.0F, var21 * -1.5F);
                     Vector2f var24 = MathUtils.getPointOnCircumference((Vector2f)null, var23, var22);
                     float var25 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_SIZE_MIN + 1.0F, this.CHARGEUP_PARTICLE_SIZE_MAX + 5.0F) * var5.getChargeLevel();
                     var2.addHitParticle(var3.getTo(), var24, var25, this.CHARGEUP_PARTICLE_BRIGHTNESS * Math.min(var5.getChargeLevel() + 0.5F, 1.0F) * MathUtils.getRandomNumberInRange(0.75F, 1.25F), this.CHARGEUP_PARTICLE_DURATION, new Color((float)(var19.getRed() / 255), (float)(var19.getGreen() / 255), (float)(var19.getBlue() / 255), (float)(var19.getAlpha() / 255) * var5.getChargeLevel()));
                  }
               }

               if(Math.random() <= 0.05000000074505806D) {
                  var2.addHitParticle(var3.getTo(), this.ZERO, var15 * 1.75F, 0.1F + var5.getChargeLevel() * 0.3F, 0.2F, var3.getCoreColor());
               }
            }

            if(this.cooling && var5.getChargeLevel() <= 0.0F) {
               this.cooling = false;
            }
         }

         this.level = var5.getChargeLevel();
         if(this.runOnce) {
            var8 = var6 * 0.5F * MathUtils.getDistance(var3.getTo(), var3.getFrom()) * var1 * 0.05F * var5.getChargeLevel();
            if(Math.random() < 0.5D) {
               for(int var26 = 0; (float)var26 < var8; ++var26) {
                  var10 = MathUtils.getRandomPointOnLine(var3.getFrom(), var3.getTo());
                  var10 = MathUtils.getRandomPointInCircle(var10, var6 * 0.5F);
                  if(Global.getCombatEngine().getViewport().isNearViewport(var10, 30.0F)) {
                     Vector2f var27 = new Vector2f(var7.getVelocity().x * 0.5F, var7.getVelocity().y * 0.5F);
                     var27 = MathUtils.getRandomPointInCircle(var27, 50.0F);
                     var2.addSmoothParticle(var10, var27, MathUtils.getRandomNumberInRange(5.0F, 10.0F), var5.getChargeLevel(), MathUtils.getRandomNumberInRange(0.4F, 0.9F), PARTICLE_COLOR);
                  }
               }
            }
         }

      }
   }

}
