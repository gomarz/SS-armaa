package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;

public class armaa_shotgunEveryFrameEffect implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin {

   public static final int SHOTS = 35;
   public static final float SPREAD = 15.0F;
   public static final float PUSH_CONSTANT = 12800.0F;
   private int lastAmmo = 0;
   private boolean init = false;
   private boolean reloading = true;
   private IntervalUtil cockSound = new IntervalUtil(0.33F, 0.38F);
   private IntervalUtil reloadTime = new IntervalUtil(2.8F, 2.85F);
   private DamagingProjectileAPI dummy;
   private static final Color MUZZLE_FLASH_COLOR = new Color(255, 200, 100, 50);
   private static final Color MUZZLE_FLASH_COLOR_ALT = new Color(255, 255, 255, 100);
   private static final Color MUZZLE_FLASH_COLOR_GLOW = new Color(255, 75, 0, 50);
   private static final float MUZZLE_FLASH_DURATION = 0.1F;
   private static final float MUZZLE_FLASH_SIZE = 15.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {}

   private Vector2f calculateMuzzle(WeaponAPI var1) {
      float var2;
      if(var1.getSlot().isHardpoint()) {
         var2 = ((Vector2f)var1.getSpec().getHardpointFireOffsets().get(0)).getX();
      } else {
         var2 = ((Vector2f)var1.getSpec().getTurretFireOffsets().get(0)).getX();
      }

      double var3 = Math.toRadians((double)var1.getCurrAngle());
      Vector2f var5 = new Vector2f((float)Math.cos(var3), (float)Math.sin(var3));
      if(var5.lengthSquared() > 0.0F) {
         var5.normalise();
      }

      var5.scale(var2);
      Vector2f var6 = new Vector2f(var1.getLocation().getX(), var1.getLocation().getY() - 20.0F);
      return Vector2f.add(var6, var5, new Vector2f());
   }

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      if(Math.random() > 0.75D) {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 1.5F, 0.1F);
      } else {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 15.0F, 0.1F);
      }

      var3.addSmoothParticle(var1.getLocation(), var1.getVelocity(), 45.0F, 1.0F, 0.2F, MUZZLE_FLASH_COLOR_GLOW);

      for(int var4 = 0; var4 < 35; ++var4) {
         float var5 = (float)Math.random() * 15.0F - (float)Math.random() * 15.0F * 0.5F;
         float var6 = var2.getCurrAngle() + var5;
         String var7 = "armaa_einhanderGunS";
         Vector2f var8 = (Vector2f)var2.getSpec().getTurretFireOffsets().get(0);
         DamagingProjectileAPI var9 = (DamagingProjectileAPI)var3.spawnProjectile(var2.getShip(), var2, var7, var1.getLocation(), var6, var2.getShip().getVelocity());
         float var10 = (float)Math.random() * 0.4F + 0.8F;
         var9.getVelocity().scale(var10);
      }

      Global.getCombatEngine().removeEntity(var1);
   }

}
