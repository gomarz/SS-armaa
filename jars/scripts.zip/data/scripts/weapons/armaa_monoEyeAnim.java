package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;

public class armaa_monoEyeAnim implements EveryFrameWeaponEffectPlugin {

   private boolean isAnimating = false;
   private IntervalUtil interval = new IntervalUtil(1.0F, 20.0F);
   private IntervalUtil animInterval = new IntervalUtil(0.06F, 0.08F);
   private int target = 0;
   private int currFrame = 0;


   public int getAngle(int var1, int var2) {
      int var3 = var1 + var2;
      if(var3 > 360) {
         var3 %= 360;
      }

      return var3;
   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(this.interval.intervalElapsed() && !this.isAnimating) {
         this.isAnimating = true;
         this.currFrame = var3.getAnimation().getFrame();
         this.target = this.currFrame <= 4?8:0;
         this.animInterval = new IntervalUtil(0.055F, 0.08F);
         if(var3.getShip().getShipTarget() != null) {
            float var4 = var3.getCurrAngle();
            float var5 = VectorUtils.getAngle(var3.getShip().getLocation(), var3.getShip().getShipTarget().getLocation());
            float var6 = Math.abs(var4 - var5);
            float var7 = 4.0F;
            if(var4 > var5) {
               this.target = (int)Math.floor((double)Math.min(5.0F + var6 / 25.0F, 8.0F));
            } else if(var4 < var5) {
               this.target = (int)Math.floor((double)Math.max(3.0F - var6 / 25.0F, 0.0F));
            }
         } else if(Math.random() <= 0.25D) {
            if(this.target == 8) {
               this.target = MathUtils.getRandomNumberInRange(4, 6);
            } else {
               this.target = MathUtils.getRandomNumberInRange(0, 4);
            }
         }

         if(Math.random() <= 0.25D) {
            Global.getSoundPlayer().playSound("armaa_monoeye_move", 0.8F, 0.8F, var3.getLocation(), var3.getShip().getVelocity());
         }
      }

      if(!this.isAnimating) {
         this.interval.advance(var1);
      } else {
         this.animInterval.advance(var1);
         if(this.animInterval.intervalElapsed()) {
            this.currFrame = var3.getAnimation().getFrame();
            if(this.currFrame == this.target) {
               this.interval = new IntervalUtil(5.0F, 15.0F);
               this.isAnimating = false;
            } else if(this.currFrame < this.target) {
               var3.getAnimation().setFrame(Math.min(this.currFrame + 1, 8));
            } else {
               var3.getAnimation().setFrame(Math.max(0, this.currFrame - 1));
            }
         }
      }

   }
}
