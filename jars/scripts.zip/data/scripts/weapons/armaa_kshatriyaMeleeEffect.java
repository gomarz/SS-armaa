package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicAnim;

public class armaa_kshatriyaMeleeEffect implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private ShipSystemAPI system;
   private ShipAPI ship;
   private SpriteAPI sprite;
   private AnimationAPI anim;
   private float currentRotateL = 0.0F;
   private float currentRotateR = 0.0F;
   private float sway = 0.0F;
   private final float maxbinderrotate = 40.0F;
   private WeaponAPI head;
   private WeaponAPI armL;
   private WeaponAPI armL2;
   private WeaponAPI armR;
   private WeaponAPI pauldronL;
   private WeaponAPI pauldronR;
   private WeaponAPI torso;
   private WeaponAPI vernier;
   private WeaponAPI gun;
   private WeaponAPI shoulderwep;
   private WeaponAPI headGlow;
   private final Vector2f ZERO = new Vector2f();
   private int limbInit = 0;
   private float swingLevel = 0.0F;
   private boolean swinging = false;
   private boolean cooldown = false;
   private float swingLevelR = 0.0F;
   private boolean swingingR = false;
   private boolean cooldownR = false;
   private IntervalUtil animInterval = new IntervalUtil(0.012F, 0.012F);
   private float overlap = 0.0F;
   private float heat = 0.0F;
   private float originalRArmPos = 0.0F;
   private float originalArmPos = 0.0F;
   private float originalArmPos2 = 0.0F;
   private float originalShoulderPos = 0.0F;
   private float originalVernierPos = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -60.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;
   private final float LPAULDRONOFFSET = -5.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.ship = var3.getShip();
      this.sprite = this.ship.getSpriteAPI();
      this.system = this.ship.getSystem();
      if(!var2.isPaused()) {
         float var4 = 0.0F;
         float var5 = 0.0F;
         if(this.ship.getEngineController().isAccelerating()) {
            var4 += 20.0F;
            var5 -= 20.0F;
            if(this.sway > -1.0F) {
               this.sway = (float)((double)this.sway - 0.08D);
            }
         } else if(this.ship.getEngineController().isDecelerating() || this.ship.getEngineController().isAcceleratingBackwards()) {
            var4 -= 20.0F;
            var5 += 20.0F;
            if(this.sway < 1.0F) {
               this.sway = (float)((double)this.sway + 0.08D);
            }
         }

         if(this.ship.getEngineController().isStrafingLeft()) {
            var4 += 13.333333F;
            var5 += 26.666666F;
         } else if(this.ship.getEngineController().isStrafingRight()) {
            var4 -= 26.666666F;
            var5 -= 13.333333F;
         }

         if(this.ship.getEngineController().isTurningLeft()) {
            var4 -= 20.0F;
            var5 -= 20.0F;
         } else if(this.ship.getEngineController().isTurningRight()) {
            var4 += 20.0F;
            var5 += 20.0F;
         }

         float var6 = MathUtils.getShortestRotation(this.currentRotateL, var4);
         if(Math.abs(var6) < 0.5F) {
            this.currentRotateL = var4;
         } else if(var6 > 0.0F) {
            this.currentRotateL += 0.4F;
         } else {
            this.currentRotateL -= 0.4F;
         }

         float var7 = MathUtils.getShortestRotation(this.currentRotateR, var5);
         if(Math.abs(var7) < 0.5F) {
            this.currentRotateR = var5;
         } else if(var7 > 0.0F) {
            this.currentRotateR += 0.4F;
         } else {
            this.currentRotateR -= 0.4F;
         }

         if(this.sway > 0.0F) {
            this.sway = (float)((double)this.sway - 0.05D);
         } else {
            this.sway = (float)((double)this.sway + 0.05D);
         }

         float var8 = 0.0F;
         float var9 = 0.0F;
         float var10 = 0.0F;
         float var11 = 0.0F;
         if(var3 != null) {
            if(var3.getChargeLevel() < 1.0F) {
               var10 = MagicAnim.smoothNormalizeRange(var3.getChargeLevel(), 0.3F, 0.9F);
               var11 = MagicAnim.smoothNormalizeRange(var3.getChargeLevel(), 0.3F, 1.0F);
            } else {
               var10 = 1.0F;
               var11 = 1.0F;
            }

            if(var3.getCooldownRemaining() <= 0.0F && !var3.isFiring()) {
               this.cooldownR = false;
            }

            if(!this.swingingR && !this.cooldownR && var3.getChargeLevel() > 0.0F) {
               var3.setCurrAngle(var3.getCurrAngle() + var10 * -45.0F * 0.3F * var3.getChargeLevel());
            }

            if(var3.getChargeLevel() >= 1.0F) {
               this.swingingR = true;
            }

            if(this.swingingR && var3.getCurrAngle() != var3.getShip().getFacing() + 90.0F) {
               this.animInterval.advance(var1);
               var3.setCurrAngle(Math.min(var3.getCurrAngle() + this.swingLevelR, var3.getCurrAngle() + var3.getArc() / 2.0F));
            }

            if(this.swingingR && var3.getChargeLevel() <= 0.0F) {
               this.swingingR = false;
               this.swingLevelR = 0.0F;
               this.cooldownR = true;
            }

            if(this.animInterval.intervalElapsed()) {
               this.swingLevelR = (float)((double)this.swingLevelR + 0.5D);
            }

            if(this.swingLevelR > 9.0F) {
               this.swingLevelR = 9.0F;
            }

            if(!this.swingingR) {
               this.swingLevelR = 0.0F;
            }
         }

         List var12 = this.ship.getChildModulesCopy();
         if(var12 != null) {
            Iterator var13 = var12.iterator();

            while(var13.hasNext()) {
               ShipAPI var14 = (ShipAPI)var13.next();
               var14.ensureClonedStationSlotSpec();
               if(var14.getLayer() != CombatEngineLayers.ABOVE_SHIPS_AND_MISSILES_LAYER) {
                  var14.setLayer(CombatEngineLayers.ABOVE_SHIPS_AND_MISSILES_LAYER);
               }
            }
         }

      }
   }
}
