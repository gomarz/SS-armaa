package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponSize;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_shineCoreEveryFrameEffect implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin, OnHitEffectPlugin {

   private boolean runOnce = false;
   private boolean hasFired = false;
   public float TURRET_OFFSET = 45.0F;
   private final IntervalUtil particle = new IntervalUtil(0.025F, 0.05F);
   private final IntervalUtil particle2 = new IntervalUtil(0.1F, 0.2F);
   float charge = 0.0F;
   private static final int SMOKE_SIZE_MIN = 10;
   private static final int SMOKE_SIZE_MAX = 30;
   private boolean soundPlayed = false;
   private boolean windingUp = true;


   public void init(ShipAPI var1) {}

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.TURRET_OFFSET = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(0)).x;
      float var4 = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(0)).y;
      ShipAPI var5 = var3.getShip();
      if(var3.getChargeLevel() > 0.0F) {
         this.windingUp = true;
      } else {
         this.windingUp = false;
         this.soundPlayed = false;
      }

      if(!this.soundPlayed && this.windingUp) {
         Global.getSoundPlayer().playSound("mechmove", 1.0F, 1.0F, var3.getLocation(), var3.getShip().getVelocity());
         this.soundPlayed = true;
      }

      if(var3.isFiring() && this.charge != 1.0F) {
         float var6 = var3.getChargeLevel();
         float var7 = 2.0F;
         if(var3.getSize() == WeaponSize.LARGE) {
            var7 = 2.0F;
         }

         float var8;
         if(!this.hasFired) {
            Global.getSoundPlayer().playLoop("beamchargeM", var3, 1.0F, 1.0F, var3.getLocation(), var3.getShip().getVelocity());
            this.particle.advance(var1);
            if(this.particle.intervalElapsed()) {
               var8 = var3.getShip().getFacing() - 180.0F;
               CombatUtils.applyForce(var3.getShip(), var8, 10.0F * var3.getChargeLevel());
               Vector2f var9 = new Vector2f(var3.getLocation());
               Vector2f var10 = MathUtils.getPoint(var3.getLocation(), 18.5F, var3.getCurrAngle());
               Vector2f var11 = var3.getShip().getVelocity();
               var2.addHitParticle(var9, var11, MathUtils.getRandomNumberInRange(20.0F * var7, var6 * var7 * 60.0F + 20.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var6), MathUtils.getRandomNumberInRange(0.1F, 0.1F + var6 / 10.0F), new Color(var6 / 1.0F, var6 / 2.0F, var6 / 1.0F));
               var2.addSwirlyNebulaParticle(var9, new Vector2f(0.0F, 0.0F), MathUtils.getRandomNumberInRange(20.0F * var7, var6 * var7 * 60.0F + 20.0F), 1.2F, 0.15F, 0.0F, 0.35F * var6, new Color(var6 / 1.0F, var6 / 3.0F, var6 / 1.0F, 0.5F * var6), false);
               var3.getShip().setJitter(var3.getShip(), new Color(1.0F, 0.26666668F, 0.8F, var3.getChargeLevel() * 0.8F), var3.getChargeLevel(), 4, 25.0F);
               Vector2f var12 = MathUtils.getRandomPointInCircle(new Vector2f(), 35.0F * var6);
               Vector2f var13 = new Vector2f();
               Vector2f.sub(var9, new Vector2f(var12), var13);
               Vector2f.add(var11, var12, var12);

               for(int var14 = 0; var14 < 5; ++var14) {
                  var2.addHitParticle(var13, var12, MathUtils.getRandomNumberInRange(20.0F, var6 * 20.0F + 20.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var6), MathUtils.getRandomNumberInRange(0.75F, 0.75F + var6 / 4.0F), new Color(var6 / 1.0F, var6 / 3.0F, var6 / 1.0F));
               }
            }
         }

         if(var6 == 1.0F && !this.hasFired) {
            Global.getSoundPlayer().playSound("explosion_from_damage", 1.0F, 1.0F, var3.getLocation(), var3.getShip().getVelocity());
            var8 = var3.getShip().getFacing();
            CombatUtils.applyForce(var3.getShip(), var8, 1000.0F);
            var2.spawnExplosion(var3.getLocation(), new Vector2f(), new Color(255, 0, 255), 200.0F, 1.0F);
            var2.addSmoothParticle(var3.getLocation(), new Vector2f(0.0F, 0.0F), 300.0F, 2.0F, 0.1F, Color.white);
            var2.addHitParticle(var3.getLocation(), new Vector2f(0.0F, 0.0F), 300.0F, 1.0F, 0.4F, new Color(200, 100, 255));
            var2.spawnExplosion(var3.getLocation(), new Vector2f(0.0F, 0.0F), Color.DARK_GRAY, 125.0F, 2.0F);
            var2.spawnExplosion(var3.getLocation(), new Vector2f(0.0F, 0.0F), Color.BLACK, 300.0F, 3.0F);
            this.hasFired = true;
         }
      } else {
         this.hasFired = false;
      }

   }

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {}

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {}
}
