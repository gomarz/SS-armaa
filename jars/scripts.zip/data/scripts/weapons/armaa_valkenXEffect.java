package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicAnim;

public class armaa_valkenXEffect implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private ShipSystemAPI system;
   private ShipAPI ship;
   private SpriteAPI sprite;
   private AnimationAPI anim;
   private AnimationAPI aGlow;
   private AnimationAPI aGlow2;
   private WeaponAPI head;
   private WeaponAPI armL;
   private WeaponAPI armR;
   private WeaponAPI pauldronL;
   private WeaponAPI pauldronR;
   private WeaponAPI torso;
   private WeaponAPI bunker;
   private float delay = 0.1F;
   private float timer = 0.0F;
   private float SPINUP = 0.02F;
   private float SPINDOWN = 10.0F;
   private boolean charging = false;
   private boolean cooling = false;
   private boolean firing = false;
   private IntervalUtil interval = new IntervalUtil(0.6F, 1.0F);
   private float level = 0.0F;
   private float glowLevel = 1.0F;
   private int glowEffect = 0;
   float eyeG = 0.0F;
   private final Vector2f ZERO = new Vector2f();
   public float TURRET_OFFSET = 30.0F;
   private int limbInit = 0;
   private float swingLevel = 0.0F;
   private boolean windingUp = false;
   private boolean swinging = false;
   private boolean cooldown = false;
   private IntervalUtil animInterval = new IntervalUtil(0.012F, 0.012F);
   private float overlap = 0.0F;
   private float heat = 0.0F;
   private float originalRArmPos = 0.0F;
   private float originalArmPos = 0.0F;
   private float originalShoulderPos = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -60.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;
   private final float LPAULDRONOFFSET = -5.0F;


   public void init() {
      this.runOnce = true;
      Iterator var1 = this.ship.getAllWeapons().iterator();

      while(var1.hasNext()) {
         WeaponAPI var2 = (WeaponAPI)var1.next();
         String var3 = var2.getSlot().getId();
         byte var4 = -1;
         switch(var3.hashCode()) {
         case -1377875459:
            if(var3.equals("bunker")) {
               var4 = 7;
            }
            break;
         case -6931076:
            if(var3.equals("D_PAULDRONL")) {
               var4 = 3;
            }
            break;
         case -6931070:
            if(var3.equals("D_PAULDRONR")) {
               var4 = 4;
            }
            break;
         case 62929954:
            if(var3.equals("A_GUN")) {
               var4 = 6;
            }
            break;
         case 1245480854:
            if(var3.equals("B_TORSO")) {
               var4 = 0;
            }
            break;
         case 2007905292:
            if(var3.equals("C_ARML")) {
               var4 = 1;
            }
            break;
         case 2007905298:
            if(var3.equals("C_ARMR")) {
               var4 = 2;
            }
            break;
         case 2065359258:
            if(var3.equals("E_HEAD")) {
               var4 = 5;
            }
         }

         switch(var4) {
         case 0:
            if(this.torso == null) {
               this.torso = var2;
               ++this.limbInit;
            }
            break;
         case 1:
            if(this.armL == null) {
               this.armL = var2;
               this.originalArmPos = this.armL.getSprite().getCenterY();
               ++this.limbInit;
            }
            break;
         case 2:
            if(this.armR == null) {
               this.armR = var2;
               ++this.limbInit;
            }
            break;
         case 3:
            if(this.pauldronL == null) {
               this.pauldronL = var2;
               this.originalShoulderPos = this.pauldronL.getSprite().getCenterY();
               ++this.limbInit;
            }
            break;
         case 4:
            if(this.pauldronR == null) {
               this.pauldronR = var2;
               ++this.limbInit;
            }
            break;
         case 5:
            if(this.head == null) {
               this.head = var2;
               ++this.limbInit;
            }
         case 6:
         default:
            break;
         case 7:
            this.bunker = var2;
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.ship = var3.getShip();
      this.sprite = this.ship.getSpriteAPI();
      this.system = this.ship.getSystem();
      this.anim = var3.getAnimation();
      ShipwideAIFlags var4 = this.ship.getAIFlags();
      this.init();
      this.ship.syncWeaponDecalsWithArmorDamage();
      if(this.ship.getEngineController().isAccelerating()) {
         if(this.overlap > 9.9F) {
            this.overlap = 10.0F;
         } else {
            this.overlap = Math.min(10.0F, this.overlap + (10.0F - this.overlap) * var1 * 5.0F);
         }
      } else if(!this.ship.getEngineController().isDecelerating() && !this.ship.getEngineController().isAcceleratingBackwards()) {
         if(Math.abs(this.overlap) < 0.1F) {
            this.overlap = 0.0F;
         } else {
            this.overlap -= this.overlap / 2.0F * var1 * 3.0F;
         }
      } else if(this.overlap < -9.9F) {
         this.overlap = -10.0F;
      } else {
         this.overlap = Math.max(-10.0F, this.overlap + (-10.0F + this.overlap) * var1 * 5.0F);
      }

      float var5 = 0.0F;
      float var6 = 0.0F;
      if(this.armL.getChargeLevel() < 1.0F) {
         var5 = MagicAnim.smoothNormalizeRange(this.armL.getChargeLevel(), 0.3F, 0.9F);
         var6 = MagicAnim.smoothNormalizeRange(this.armL.getChargeLevel(), 0.3F, 1.0F);
      } else {
         var5 = 1.0F;
         var6 = 1.0F;
      }

      float var7 = this.ship.getFacing();
      float var8 = MathUtils.getShortestRotation(var7, var3.getCurrAngle());
      MathUtils.getShortestRotation(var7, this.armL.getCurrAngle());
      if(this.armL != null) {
         this.armL.getSprite().setCenterY(this.originalArmPos - 16.0F * var6);
         if(this.torso != null) {
            if(this.armL.getCooldownRemaining() <= 0.0F && !this.armL.isFiring()) {
               this.cooldown = false;
            }

            if(!this.swinging && !this.cooldown && this.armL.getChargeLevel() > 0.0F) {
               this.armL.setCurrAngle(this.armL.getCurrAngle() + var5 * -45.0F * 0.3F * this.armL.getChargeLevel());
            }

            if(this.armL.getChargeLevel() >= 1.0F) {
               this.swinging = true;
            }

            if(this.swinging && this.armL.getCurrAngle() != this.armL.getShip().getFacing() + 45.0F) {
               this.animInterval.advance(var1);
               this.armL.setCurrAngle(Math.min(this.armL.getCurrAngle() + this.swingLevel, this.armL.getCurrAngle() + this.armL.getArc() / 2.0F));
            }

            if(this.swinging && this.armL.getChargeLevel() <= 0.0F) {
               this.swinging = false;
               this.swingLevel = 0.0F;
               this.cooldown = true;
            }

            if(this.animInterval.intervalElapsed()) {
               this.swingLevel = (float)((double)this.swingLevel + 0.5D);
            }

            if(this.swingLevel > 9.0F) {
               this.swingLevel = 9.0F;
            }

            if(!this.swinging) {
               this.swingLevel = 0.0F;
            }
         }
      }

      if(this.torso != null) {
         this.torso.setCurrAngle(var7 + (var5 * (-45.0F - -45.0F * (this.swingLevel / 9.0F)) + var8 * 0.3F) * this.armL.getChargeLevel());
      }

      if(this.armR != null) {
         this.armR.setCurrAngle(var3.getCurrAngle() + -25.0F);
      }

      if(this.pauldronR != null) {
         this.pauldronR.setCurrAngle(var7 + var5 * (-45.0F - -45.0F * (this.swingLevel / 9.0F)) * 0.5F + var8 * 0.75F + -12.5F);
      }

      Vector2f var10 = new Vector2f(var3.getLocation());
      Vector2f var11 = new Vector2f(this.TURRET_OFFSET, -15.0F);
      VectorUtils.rotate(var11, var3.getCurrAngle(), var11);
      Vector2f.add(var11, var10, var10);
      float var12 = var3.getCurrAngle();
      Vector2f var13 = this.ship.getVelocity();
      if(this.pauldronL != null) {
         this.pauldronL.setCurrAngle(this.torso.getCurrAngle() + -5.0F * var5 + MathUtils.getShortestRotation(this.torso.getCurrAngle(), this.armL.getCurrAngle()) * 0.7F);
         this.pauldronL.getSprite().setCenterY(this.originalShoulderPos - 8.0F * var6);
      }

   }
}
