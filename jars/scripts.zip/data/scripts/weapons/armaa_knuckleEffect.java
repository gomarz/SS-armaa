package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseCombatLayeredRenderingPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import data.scripts.weapons.armaa_BoomerangShieldGuidance;
import data.scripts.weapons.armaa_boostHammerProjectileScript;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_knuckleEffect extends BaseCombatLayeredRenderingPlugin implements OnFireEffectPlugin, OnHitEffectPlugin, EveryFrameWeaponEffectPlugin {

   private static final Color AFTERIMAGE_COLOR = new Color(255, 165, 90, 155);
   private static final float AFTERIMAGE_THRESHOLD = 0.4F;
   private static final List FIST_TRACKER = new ArrayList();
   private boolean soundPlayed = false;
   private boolean windingUp = true;
   private boolean hasFired = false;
   public float TURRET_OFFSET = 40.0F;
   float charge = 0.0F;
   private static final Color PARTICLE_COLOR = new Color(250, 236, 111, 255);
   private static final float PARTICLE_SIZE = 4.0F;
   private static final float PARTICLE_BRIGHTNESS = 150.0F;
   private static final float PARTICLE_DURATION = 0.8F;
   private static final int PARTICLE_COUNT = 4;
   private static final float CONE_ANGLE = 150.0F;
   private static final float VEL_MIN = 0.1F;
   private static final float VEL_MAX = 0.3F;
   private static final float A_2 = 75.0F;
   private static final Color MUZZLE_FLASH_COLOR = new Color(250, 146, 0, 255);
   private static final Color MUZZLE_FLASH_COLOR_ALT = new Color(255, 255, 255, 100);
   private static final Color MUZZLE_FLASH_COLOR_GLOW = new Color(255, 0, 0, 100);
   private static final float MUZZLE_FLASH_DURATION = 1.0F;
   private static final float MUZZLE_FLASH_SIZE = 50.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.TURRET_OFFSET = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(0)).x;
      float var4 = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(0)).y;
      ShipAPI var5 = var3.getShip();
      if(var3.isFiring()) {
         this.charge = var3.getChargeLevel();
      }

      if(var3.getChargeLevel() > 0.0F && this.charge != 1.0F) {
         if(!this.hasFired && var3.getCooldownRemaining() <= 0.0F) {
            Vector2f var6 = new Vector2f(var3.getLocation());
            Vector2f var7 = new Vector2f(this.TURRET_OFFSET, var4);
            VectorUtils.rotate(var7, var3.getCurrAngle(), var7);
            Vector2f.add(var7, var6, var6);
            Vector2f var8 = MathUtils.getPoint(var3.getLocation(), 18.5F, var3.getCurrAngle());
            Vector2f var9 = var3.getShip().getVelocity();
            float var10 = 1.2F;
            this.windingUp = true;
         }
      } else {
         this.windingUp = false;
         this.soundPlayed = false;
      }

      if(!this.soundPlayed && this.windingUp) {
         Global.getSoundPlayer().playSound("mechmove", 1.0F, 1.0F, var3.getLocation(), var3.getShip().getVelocity());
         this.soundPlayed = true;
      }

      if(var3.getAmmo() == 0) {
         this.hasFired = true;
         var3.getSprite().setColor(new Color(0, 0, 0, 0));
         var5.getMutableStats().getMaxSpeed().modifyMult(var5.getId() + "_powerfist", 1.1F);
      } else {
         this.hasFired = false;
         var3.getSprite().setColor(new Color(255, 255, 255, 255));
         var5.getMutableStats().getMaxSpeed().unmodify(var5.getId() + "_powerfist");
      }

   }

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      ShipAPI var7 = var1.getSource();
      WeaponAPI var8 = var1.getWeapon();
      if(MagicRender.screenCheck(0.2F, var3)) {
         if(Math.random() > 0.75D) {
            var6.spawnExplosion(var3, new Vector2f(), MUZZLE_FLASH_COLOR, 5.0F, 1.0F);
         } else {
            var6.spawnExplosion(var3, new Vector2f(), MUZZLE_FLASH_COLOR, 50.0F, 1.0F);
         }

         var6.addSmoothParticle(var3, new Vector2f(), 150.0F, 1.0F, 2.0F, MUZZLE_FLASH_COLOR_GLOW);
         var6.addSmoothParticle(var3, new Vector2f(0.0F, 0.0F), 300.0F, 2.0F, 0.15F, Color.white);
         var6.spawnExplosion(var3, new Vector2f(0.0F, 0.0F), Color.DARK_GRAY, 125.0F, 2.0F);
         var6.spawnExplosion(var3, new Vector2f(0.0F, 0.0F), Color.BLACK, 300.0F, 3.0F);

         for(int var9 = 0; var9 < 15; ++var9) {
            var6.addHitParticle(var3, MathUtils.getPointOnCircumference((Vector2f)null, MathUtils.getRandomNumberInRange(150.0F, 325.0F), (float)Math.random() * 360.0F), 6.0F, 1.0F, MathUtils.getRandomNumberInRange(0.6F, 1.0F), Color.white);
         }
      }

      if(var7 != null) {
         float var11 = VectorUtils.getAngle(var3, var7.getLocation());
         DamagingProjectileAPI var10 = (DamagingProjectileAPI)var6.spawnProjectile(var7, var8, var8.getId() + "_return", MathUtils.getPointOnCircumference(var3, 20.0F, var11), var11 + MathUtils.getRandomNumberInRange(-45.0F, 45.0F), var2.getVelocity());
         var6.addPlugin(new armaa_BoomerangShieldGuidance(var10, var7));
      }
   }

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      var3.addHitParticle(var1.getLocation(), var1.getVelocity(), 100.0F, 1.0F, 0.2F, new Color(1.0F, 0.6666667F, 0.1F));
      ShipAPI var4 = var2.getShip();
      Vector2f.add(MathUtils.getPoint(new Vector2f(), 50.0F, var1.getFacing() + 180.0F), var4.getVelocity(), var4.getVelocity());
      Vector2f var5 = MathUtils.getPoint(new Vector2f(), (float)MathUtils.getRandomNumberInRange(0, 75), var1.getFacing());
      Vector2f.add(var5, new Vector2f(var4.getVelocity()), var5);
      ShipAPI var6 = null;
      if(var4.getWeaponGroupFor(var2) != null) {
         if(var4.getWeaponGroupFor(var2).isAutofiring() && var4.getSelectedGroupAPI() != var4.getWeaponGroupFor(var2)) {
            var6 = var4.getWeaponGroupFor(var2).getAutofirePlugin(var2).getTargetShip();
         } else {
            var6 = var4.getShipTarget();
         }
      }

      if(!var1.isFromMissile()) {
         var3.addPlugin(new armaa_boostHammerProjectileScript(var1, var6));
      }

   }

}
