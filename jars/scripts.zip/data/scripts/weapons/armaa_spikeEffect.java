package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import data.scripts.weapons.armaa_spikeThrowerEffect;
import org.lwjgl.util.vector.Vector2f;

public class armaa_spikeEffect implements OnHitEffectPlugin {

   private final String ID = "armaa_pikeSecondary";


   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      if(!var1.isFading() && !var4) {
         ((armaa_spikeThrowerEffect)var1.getWeapon().getEffectPlugin()).putHIT(var2);
         var6.spawnProjectile(var1.getSource(), var1.getWeapon(), "armaa_pikeSecondary", var3, var1.getFacing(), var2.getVelocity());
      }

   }
}
