package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;

public class armaa_acOnHitEffect implements OnHitEffectPlugin {

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      if(var2 instanceof ShipAPI) {
         ShipAPI var7 = (ShipAPI)var2;
         float var8 = ((ShipAPI)var2).getHardFluxLevel() - 0.3F;
         var8 *= var7.getMutableStats().getDynamic().getValue("shield_pierced_mult");
         boolean var9 = var4 && (float)Math.random() < var8;
         if(!var4 || var9) {
            float var10 = var1.getEmpAmount();
            float var11 = 0.0F;
            var6.spawnEmpArcPierceShields(var1.getSource(), var3, var2, var2, DamageType.ENERGY, var11, var10, 100000.0F, "tachyon_lance_emp_impact", 20.0F, new Color(235, 255, 215, 255), new Color(255, 255, 255, 255));
         }

      }
   }
}
