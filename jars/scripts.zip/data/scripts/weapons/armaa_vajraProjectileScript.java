package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.util.Misc;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.jetbrains.annotations.NotNull;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.FastTrig;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_vajraProjectileScript extends BaseEveryFrameCombatPlugin {

   private static final String GUIDANCE_MODE_PRIMARY = "INTERCEPT_SWARM";
   private static final String GUIDANCE_MODE_SECONDARY = "REACQUIRE_NEAREST_PROJ";
   private static final List VALID_TARGET_TYPES = new ArrayList();
   private static final float TARGET_REACQUIRE_RANGE = 1250.0F;
   private static final float TARGET_REACQUIRE_ANGLE = 90.0F;
   private static final float TURN_RATE = 50.0F;
   private static final float SWAY_AMOUNT_PRIMARY = 5.0F;
   private static final float SWAY_AMOUNT_SECONDARY = 5.0F;
   private static final float SWAY_PERIOD_PRIMARY = 1.4F;
   private static final float SWAY_PERIOD_SECONDARY = 3.0F;
   private static final float SWAY_FALLOFF_FACTOR = 0.0F;
   private static final float ONE_TURN_DUMB_INACCURACY = 0.0F;
   private static final float ONE_TURN_TARGET_INACCURACY = 0.0F;
   private static final int INTERCEPT_ITERATIONS = 3;
   private static final float INTERCEPT_ACCURACY_FACTOR = 1.0F;
   private static final float GUIDANCE_DELAY_MAX = 0.1F;
   private static final float GUIDANCE_DELAY_MIN = 0.6F;
   private static final boolean BROKEN_BY_PHASE = true;
   private static final boolean RETARGET_ON_SIDE_SWITCH = false;
   private DamagingProjectileAPI proj;
   private CombatEntityAPI target;
   private Vector2f targetPoint;
   private float targetAngle;
   private float swayCounter1;
   private float swayCounter2;
   private float lifeCounter;
   private float estimateMaxLife;
   private float delayCounter;
   private Vector2f offsetVelocity;
   private Vector2f lastTargetPos;
   private float actualGuidanceDelay;


   public armaa_vajraProjectileScript(@NotNull DamagingProjectileAPI var1, CombatEntityAPI var2) {
      this.proj = var1;
      this.target = var2;
      this.lastTargetPos = var2 != null?var2.getLocation():new Vector2f(var1.getLocation());
      this.swayCounter1 = MathUtils.getRandomNumberInRange(0.0F, 1.0F);
      this.swayCounter2 = MathUtils.getRandomNumberInRange(0.0F, 1.0F);
      this.lifeCounter = 0.0F;
      this.estimateMaxLife = var1.getWeapon().getRange() / (new Vector2f(var1.getVelocity().x - var1.getSource().getVelocity().x, var1.getVelocity().y - var1.getSource().getVelocity().y)).length();
      this.delayCounter = 0.0F;
      this.actualGuidanceDelay = MathUtils.getRandomNumberInRange(0.6F, 0.1F);
      if("INTERCEPT_SWARM".equals("ONE_TURN_DUMB")) {
         this.targetAngle = var1.getWeapon().getCurrAngle() + MathUtils.getRandomNumberInRange(-0.0F, 0.0F);
         this.offsetVelocity = var1.getSource().getVelocity();
      } else if("INTERCEPT_SWARM".equals("ONE_TURN_TARGET")) {
         this.targetPoint = MathUtils.getRandomPointInCircle(this.getApproximateInterception(25), 0.0F);
      } else if("INTERCEPT_SWARM".contains("SWARM") && var2 != null) {
         this.applySwarmOffset();
      } else {
         this.targetPoint = new Vector2f(Misc.ZERO);
      }

   }

   public void advance(float var1, List var2) {
      if(Global.getCombatEngine() != null) {
         if(Global.getCombatEngine().isPaused()) {
            var1 = 0.0F;
         }

         if(this.proj != null && !this.proj.didDamage() && !this.proj.isFading() && Global.getCombatEngine().isEntityInPlay(this.proj)) {
            this.lifeCounter += var1;
            if(this.lifeCounter > this.estimateMaxLife) {
               this.lifeCounter = this.estimateMaxLife;
            }

            if(this.delayCounter < this.actualGuidanceDelay) {
               this.delayCounter += var1;
            } else {
               this.swayCounter1 += var1 * 1.4F;
               this.swayCounter2 += var1 * 3.0F;
               float var3 = (float)Math.pow((double)(1.0F - this.lifeCounter / this.estimateMaxLife), 0.0D) * ((float)(FastTrig.sin(6.283185307179586D * (double)this.swayCounter1) * 5.0D) + (float)(FastTrig.sin(6.283185307179586D * (double)this.swayCounter2) * 5.0D));
               if(!"INTERCEPT_SWARM".contains("ONE_TURN")) {
                  if(this.target != null) {
                     if(!Global.getCombatEngine().isEntityInPlay(this.target)) {
                        this.target = null;
                     }

                     if(this.target instanceof ShipAPI) {
                        if(!((ShipAPI)this.target).isHulk() && !((ShipAPI)this.target).isPhased()) {
                           if(this.target.getOwner() == this.proj.getOwner()) {
                              ;
                           }
                        } else {
                           this.target = null;
                        }
                     }
                  }

                  if(this.target == null) {
                     if("REACQUIRE_NEAREST_PROJ".equals("NONE")) {
                        Global.getCombatEngine().removePlugin(this);
                        return;
                     }

                     if("REACQUIRE_NEAREST_PROJ".equals("DISAPPEAR")) {
                        Global.getCombatEngine().removeEntity(this.proj);
                        Global.getCombatEngine().removePlugin(this);
                        return;
                     }

                     this.reacquireTarget();
                  } else {
                     this.lastTargetPos = new Vector2f(this.target.getLocation());
                  }
               }

               if("INTERCEPT_SWARM".contains("ONE_TURN") || this.target != null) {
                  float var4;
                  float var5;
                  Vector2f var6;
                  if("INTERCEPT_SWARM".equals("ONE_TURN_DUMB")) {
                     var4 = this.proj.getFacing() - var3;

                     for(var5 = Math.abs(this.targetAngle - var4); var5 > 180.0F; var5 = Math.abs(var5 - 360.0F)) {
                        ;
                     }

                     var4 += Misc.getClosestTurnDirection(var4, this.targetAngle) * Math.min(var5, 50.0F * var1);
                     var6 = new Vector2f(this.proj.getVelocity());
                     var6.x -= this.offsetVelocity.x;
                     var6.y -= this.offsetVelocity.y;
                     this.proj.setFacing(var4 + var3);
                     this.proj.getVelocity().x = MathUtils.getPoint(new Vector2f(Misc.ZERO), var6.length(), var4 + var3).x + this.offsetVelocity.x;
                     this.proj.getVelocity().y = MathUtils.getPoint(new Vector2f(Misc.ZERO), var6.length(), var4 + var3).y + this.offsetVelocity.y;
                  } else {
                     float var11;
                     if("INTERCEPT_SWARM".equals("ONE_TURN_TARGET")) {
                        var4 = this.proj.getFacing() - var3;
                        var5 = VectorUtils.getAngle(this.proj.getLocation(), this.targetPoint);

                        for(var11 = Math.abs(var5 - var4); var11 > 180.0F; var11 = Math.abs(var11 - 360.0F)) {
                           ;
                        }

                        var4 += Misc.getClosestTurnDirection(var4, var5) * Math.min(var11, 50.0F * var1);
                        this.proj.setFacing(var4 + var3);
                        this.proj.getVelocity().x = MathUtils.getPoint(new Vector2f(Misc.ZERO), this.proj.getVelocity().length(), var4 + var3).x;
                        this.proj.getVelocity().y = MathUtils.getPoint(new Vector2f(Misc.ZERO), this.proj.getVelocity().length(), var4 + var3).y;
                     } else {
                        float var7;
                        if("INTERCEPT_SWARM".contains("DUMBCHASER")) {
                           var4 = this.proj.getFacing() - var3;
                           Vector2f var9 = VectorUtils.rotate(new Vector2f(this.targetPoint), this.target.getFacing());
                           var11 = VectorUtils.getAngle(this.proj.getLocation(), Vector2f.add(this.target.getLocation(), var9, new Vector2f(Misc.ZERO)));

                           for(var7 = Math.abs(var11 - var4); var7 > 180.0F; var7 = Math.abs(var7 - 360.0F)) {
                              ;
                           }

                           var4 += Misc.getClosestTurnDirection(var4, var11) * Math.min(var7, 50.0F * var1);
                           this.proj.setFacing(var4 + var3);
                           this.proj.getVelocity().x = MathUtils.getPoint(new Vector2f(Misc.ZERO), this.proj.getVelocity().length(), var4 + var3).x;
                           this.proj.getVelocity().y = MathUtils.getPoint(new Vector2f(Misc.ZERO), this.proj.getVelocity().length(), var4 + var3).y;
                        } else if("INTERCEPT_SWARM".contains("INTERCEPT")) {
                           byte var10 = 3;
                           var5 = this.proj.getFacing() - var3;
                           var6 = VectorUtils.rotate(new Vector2f(this.targetPoint), this.target.getFacing());
                           var7 = VectorUtils.getAngle(this.proj.getLocation(), Vector2f.add(this.getApproximateInterception(var10), var6, new Vector2f(Misc.ZERO)));

                           float var8;
                           for(var8 = Math.abs(var7 - var5); var8 > 180.0F; var8 = Math.abs(var8 - 360.0F)) {
                              ;
                           }

                           var5 += Misc.getClosestTurnDirection(var5, var7) * Math.min(var8, 50.0F * var1);
                           this.proj.setFacing(var5 + var3);
                           this.proj.getVelocity().x = MathUtils.getPoint(new Vector2f(Misc.ZERO), this.proj.getVelocity().length(), var5 + var3).x;
                           this.proj.getVelocity().y = MathUtils.getPoint(new Vector2f(Misc.ZERO), this.proj.getVelocity().length(), var5 + var3).y;
                        }
                     }
                  }

               }
            }
         } else {
            Global.getCombatEngine().removePlugin(this);
         }
      }
   }

   private void reacquireTarget() {
      CombatEntityAPI var1 = null;
      Vector2f var2 = this.lastTargetPos;
      if("REACQUIRE_NEAREST_PROJ".contains("_PROJ")) {
         var2 = this.proj.getLocation();
      }

      ArrayList var3 = new ArrayList();
      Iterator var4;
      CombatEntityAPI var5;
      if(VALID_TARGET_TYPES.contains("ASTEROID")) {
         var4 = CombatUtils.getAsteroidsWithinRange(var2, 1250.0F).iterator();

         while(var4.hasNext()) {
            var5 = (CombatEntityAPI)var4.next();
            if(var5.getOwner() != this.proj.getOwner() && Math.abs(VectorUtils.getAngle(this.proj.getLocation(), var5.getLocation()) - this.proj.getFacing()) < 90.0F) {
               var3.add(var5);
            }
         }
      }

      if(VALID_TARGET_TYPES.contains("MISSILE")) {
         var4 = CombatUtils.getMissilesWithinRange(var2, 1250.0F).iterator();

         while(var4.hasNext()) {
            var5 = (CombatEntityAPI)var4.next();
            if(var5.getOwner() != this.proj.getOwner() && Math.abs(VectorUtils.getAngle(this.proj.getLocation(), var5.getLocation()) - this.proj.getFacing()) < 90.0F) {
               var3.add(var5);
            }
         }
      }

      var4 = CombatUtils.getShipsWithinRange(var2, 1250.0F).iterator();

      while(var4.hasNext()) {
         ShipAPI var6 = (ShipAPI)var4.next();
         if(var6.getOwner() != this.proj.getOwner() && Math.abs(VectorUtils.getAngle(this.proj.getLocation(), var6.getLocation()) - this.proj.getFacing()) <= 90.0F && !var6.isHulk() && !var6.isPhased()) {
            if(var6.getHullSize().equals(HullSize.FIGHTER) && VALID_TARGET_TYPES.contains("FIGHTER")) {
               var3.add(var6);
            }

            if(var6.getHullSize().equals(HullSize.FRIGATE) && VALID_TARGET_TYPES.contains("FRIGATE")) {
               var3.add(var6);
            }

            if(var6.getHullSize().equals(HullSize.DESTROYER) && VALID_TARGET_TYPES.contains("DESTROYER")) {
               var3.add(var6);
            }

            if(var6.getHullSize().equals(HullSize.CRUISER) && VALID_TARGET_TYPES.contains("CRUISER")) {
               var3.add(var6);
            }

            if(var6.getHullSize().equals(HullSize.CAPITAL_SHIP) && VALID_TARGET_TYPES.contains("CAPITAL")) {
               var3.add(var6);
            }
         }
      }

      if(!var3.isEmpty()) {
         if("REACQUIRE_NEAREST_PROJ".contains("REACQUIRE_NEAREST")) {
            var4 = var3.iterator();

            while(var4.hasNext()) {
               var5 = (CombatEntityAPI)var4.next();
               if(var1 == null) {
                  var1 = var5;
               } else if(MathUtils.getDistance(var1, var2) > MathUtils.getDistance(var5, var2)) {
                  var1 = var5;
               }
            }
         } else if("REACQUIRE_NEAREST_PROJ".contains("REACQUIRE_RANDOM")) {
            var1 = (CombatEntityAPI)var3.get(MathUtils.getRandomNumberInRange(0, var3.size() - 1));
         }

         this.target = var1;
         if("INTERCEPT_SWARM".contains("SWARM")) {
            this.applySwarmOffset();
         }
      }

   }

   private Vector2f getApproximateInterception(int var1) {
      Vector2f var2 = new Vector2f(this.target.getLocation());

      for(int var3 = 0; var3 < var1; ++var3) {
         float var4 = MathUtils.getDistance(this.proj.getLocation(), var2) / this.proj.getVelocity().length();
         var2.x = this.target.getLocation().x + this.target.getVelocity().x * var4 * 1.0F;
         var2.y = this.target.getLocation().y + this.target.getVelocity().y * var4 * 1.0F;
      }

      return var2;
   }

   private void applySwarmOffset() {
      int var1 = 40;
      boolean var2 = false;

      while(var1 > 0 && this.target != null) {
         --var1;
         Vector2f var3 = MathUtils.getRandomPointInCircle(this.target.getLocation(), this.target.getCollisionRadius());
         if(CollisionUtils.isPointWithinBounds(var3, this.target)) {
            var3.x -= this.target.getLocation().x;
            var3.y -= this.target.getLocation().y;
            var3 = VectorUtils.rotate(var3, -this.target.getFacing());
            this.targetPoint = new Vector2f(var3);
            var2 = true;
            break;
         }
      }

      if(!var2) {
         this.targetPoint = new Vector2f(Misc.ZERO);
      }

   }

   static {
      VALID_TARGET_TYPES.add("FRIGATE");
      VALID_TARGET_TYPES.add("DESTROYER");
      VALID_TARGET_TYPES.add("CRUISER");
      VALID_TARGET_TYPES.add("CAPITAL");
   }
}
