package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_magnaBeam implements BeamEffectPlugin {

   private IntervalUtil fireInterval = new IntervalUtil(0.2F, 0.3F);
   private boolean wasZero = true;
   private final Vector2f ZERO = new Vector2f();
   private float CHARGEUP_PARTICLE_ANGLE_SPREAD = 120.0F;
   private final float A_2;
   private float CHARGEUP_PARTICLE_BRIGHTNESS;
   private float CHARGEUP_PARTICLE_DISTANCE_MAX;
   private float CHARGEUP_PARTICLE_DISTANCE_MIN;
   private float CHARGEUP_PARTICLE_DURATION;
   private float CHARGEUP_PARTICLE_SIZE_MAX;
   private float CHARGEUP_PARTICLE_SIZE_MIN;
   public float TURRET_OFFSET;
   private boolean charging;
   private boolean cooling;
   private boolean firing;
   private final IntervalUtil interval;
   private final IntervalUtil interval2;
   private float level;
   private final float VEL_MIN;
   private final float VEL_MAX;
   private boolean runOnce;
   private static final Color PARTICLE_COLOR = new Color(200, 0, 200, 255);
   private static final float PARTICLE_SIZE_MIN = 5.0F;
   private static final float PARTICLE_SIZE_MAX = 10.0F;
   private static final float PARTICLE_DURATION_MIN = 0.4F;
   private static final float PARTICLE_DURATION_MAX = 0.9F;
   private static final float PARTICLE_INERTIA_MULT = 0.5F;
   private static final float PARTICLE_DRIFT = 50.0F;
   private static final float PARTICLE_DENSITY = 0.15F;
   private static final float PARTICLE_SPAWN_WIDTH_MULT = 0.1F;


   public armaa_magnaBeam() {
      this.A_2 = this.CHARGEUP_PARTICLE_ANGLE_SPREAD / 2.0F;
      this.CHARGEUP_PARTICLE_BRIGHTNESS = 1.0F;
      this.CHARGEUP_PARTICLE_DISTANCE_MAX = 200.0F;
      this.CHARGEUP_PARTICLE_DISTANCE_MIN = 150.0F;
      this.CHARGEUP_PARTICLE_DURATION = 0.5F;
      this.CHARGEUP_PARTICLE_SIZE_MAX = 5.0F;
      this.CHARGEUP_PARTICLE_SIZE_MIN = 1.0F;
      this.TURRET_OFFSET = 20.0F;
      this.charging = false;
      this.cooling = false;
      this.firing = false;
      this.interval = new IntervalUtil(0.015F, 0.015F);
      this.interval2 = new IntervalUtil(0.015F, 1.0F);
      this.level = 0.0F;
      this.VEL_MIN = 1.0F;
      this.VEL_MAX = 1.5F;
      this.runOnce = false;
   }

   public void advance(float var1, CombatEngineAPI var2, BeamAPI var3) {
      CombatEntityAPI var4 = var3.getDamageTarget();
      WeaponAPI var5 = var3.getWeapon();
      float var6 = var3.getWidth();
      ShipAPI var7 = var5.getShip();
      new Color(255, 0, 0, 255);
      if(var5.getChargeLevel() >= 1.0F && !this.runOnce) {
         this.runOnce = true;
      }

      float var9;
      Vector2f var11;
      Vector2f var13;
      if(var4 instanceof CombatEntityAPI) {
         var9 = var3.getDamage().getDpsDuration();
         if(!this.wasZero) {
            var9 = 0.0F;
         }

         this.wasZero = var3.getDamage().getDpsDuration() <= 0.0F;
         this.fireInterval.advance(var9);
         Vector2f var10 = new Vector2f(var5.getLocation());
         var11 = new Vector2f(this.TURRET_OFFSET, -0.0F);
         VectorUtils.rotate(var11, var5.getCurrAngle(), var11);
         Vector2f.add(var11, var10, var10);
         float var12 = var5.getCurrAngle();
         var13 = var5.getShip().getVelocity();
         Vector2f var14 = Vector2f.sub(var3.getTo(), var3.getFrom(), new Vector2f());
         if(var14.lengthSquared() > 0.0F) {
            var14.normalise();
         }

         var14.scale(50.0F);
         Vector2f.sub(var3.getTo(), var14, new Vector2f());
         if(var5.isFiring() || var5.getChargeLevel() > 0.0F) {
            float var16 = 60.0F + var5.getChargeLevel() * var5.getChargeLevel() * MathUtils.getRandomNumberInRange(25.0F, 75.0F);
            float var17 = var3.getWeapon().getCurrAngle();
            if((float)Math.random() <= 0.25F) {
               int var18 = 2 + (int)(var5.getChargeLevel() * 5.0F);

               for(int var19 = 0; var19 < var18; ++var19) {
                  float var20 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_DISTANCE_MIN + 1.0F, this.CHARGEUP_PARTICLE_DISTANCE_MAX + 1.0F) * var5.getChargeLevel();
                  float var21 = 0.8F * var20 / this.CHARGEUP_PARTICLE_DURATION * var5.getChargeLevel();
                  float var22 = MathUtils.getRandomNumberInRange(var17 - this.A_2, var17 + this.A_2);
                  float var23 = MathUtils.getRandomNumberInRange(var21 * -1.0F, var21 * -1.5F);
                  Vector2f var24 = MathUtils.getPointOnCircumference((Vector2f)null, var23, var22);
                  float var25 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_SIZE_MIN + 2.0F, this.CHARGEUP_PARTICLE_SIZE_MAX + 5.0F) * var5.getChargeLevel();
                  var2.addHitParticle(var3.getTo(), var24, var25, this.CHARGEUP_PARTICLE_BRIGHTNESS * Math.min(var5.getChargeLevel() + 0.5F, 1.0F) * MathUtils.getRandomNumberInRange(0.75F, 1.25F), this.CHARGEUP_PARTICLE_DURATION, new Color(255, 255, 180, 255));
               }
            }

            if(Math.random() <= 0.05000000074505806D) {
               var2.addHitParticle(var3.getTo(), this.ZERO, var16, 0.1F + var5.getChargeLevel() * 0.3F, 0.2F, var3.getCoreColor());
               var2.addHitParticle(var3.getTo(), this.ZERO, var16 / 2.0F, 0.1F + var5.getChargeLevel() * 0.3F, 0.2F, var3.getFringeColor());
            }
         }

         if(this.cooling && var5.getChargeLevel() <= 0.0F) {
            this.cooling = false;
         }
      }

      this.level = var5.getChargeLevel();
      if(this.runOnce) {
         var9 = var6 * 0.1F * MathUtils.getDistance(var3.getTo(), var3.getFrom()) * var1 * 0.15F * var5.getChargeLevel();

         for(int var26 = 0; (float)var26 < var9; ++var26) {
            var11 = MathUtils.getRandomPointOnLine(var3.getFrom(), var3.getTo());
            var11 = MathUtils.getRandomPointInCircle(var11, var6 * 0.1F);
            Vector2f var27 = MathUtils.getRandomPointOnLine(var3.getFrom(), var3.getTo());
            if(Global.getCombatEngine().getViewport().isNearViewport(var11, 30.0F)) {
               var13 = new Vector2f(var7.getVelocity().x * 0.5F, var7.getVelocity().y * 0.5F);
               var13 = MathUtils.getRandomPointInCircle(var13, 50.0F);
               if((float)Math.random() <= 0.05F) {
                  var2.addNebulaParticle(var11, var13, 40.0F * (0.75F + (float)Math.random() * 0.5F), MathUtils.getRandomNumberInRange(1.0F, 3.0F), 0.0F, 0.0F, 1.0F, new Color(var3.getFringeColor().getRed(), var3.getFringeColor().getGreen(), var3.getFringeColor().getBlue(), 100), true);
               }

               if((float)Math.random() <= 0.01F) {
                  Global.getCombatEngine().spawnEmpArcVisual(var11, (CombatEntityAPI)null, var27, (CombatEntityAPI)null, 15.0F, Color.blue, Color.white);
               }

               var2.addSmoothParticle(var11, var13, MathUtils.getRandomNumberInRange(5.0F, 10.0F), var5.getChargeLevel(), MathUtils.getRandomNumberInRange(0.4F, 0.9F), var3.getFringeColor());
            }
         }
      }

   }

}
