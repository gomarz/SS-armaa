package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class valkenGunEffect2 implements OnHitEffectPlugin {

   private final Color PARTICLE_COLOR = new Color(255, 166, 239);
   private final float PARTICLE_SIZE = 4.0F;
   private final float PARTICLE_BRIGHTNESS = 150.0F;
   private final float PARTICLE_DURATION = 1.0F;
   private static final int PARTICLE_COUNT = 8;
   private final int max = 40;
   private final int min = 10;
   private final Color EMP_COLOR = new Color(255, 0, 255);
   private static final float VEL_MIN = 0.25F;
   private static final float VEL_MAX = 0.35F;
   private static final float CONE_ANGLE = 150.0F;
   private static final float A_2 = 75.0F;
   private static final Color COLOR1 = new Color(255, 0, 0, 255);
   private static final Color COLOR2 = new Color(245, 188, 44, 255);
   private static final Vector2f ZERO = new Vector2f();
   private final Color FLASH_COLOR = new Color(255, 255, 20);


   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      float var7 = var1.getEmpAmount();
      float var8 = var1.getDamageAmount();
      if(MagicRender.screenCheck(0.2F, var3)) {
         if((float)Math.random() >= 0.5F) {
            var6.addSmoothParticle(var3, ZERO, 150.0F, 1.0F, 0.75F, COLOR1);
            var6.addSmoothParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 130.0F, 2.0F, 0.15F, Color.white);
            var6.addHitParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 109.0F, 1.0F, 0.4F, new Color(200, 100, 25));
            var6.spawnExplosion(var1.getLocation(), new Vector2f(0.0F, 0.0F), Color.BLACK, 120.0F, 3.0F);
            var6.spawnExplosion(var1.getLocation(), new Vector2f(0.0F, 0.0F), Color.blue, 100.0F, 1.0F);
         }

         float var9 = var1.getVelocity().length();
         float var10 = var1.getFacing();

         for(int var11 = 0; var11 <= 8; ++var11) {
            float var12 = MathUtils.getRandomNumberInRange(var10 - 75.0F, var10 + 75.0F);
            float var13 = MathUtils.getRandomNumberInRange(var9 * -0.25F, var9 * -0.35F);
            Vector2f var14 = MathUtils.getPointOnCircumference((Vector2f)null, var13, var12);
            var6.addHitParticle(var3, var14, 4.0F, 150.0F, 1.0F, this.EMP_COLOR);
         }
      }

      for(int var15 = 0; var15 < 2; ++var15) {
         if((float)Math.random() > 0.75F && var2 instanceof ShipAPI && !var4) {
            var6.spawnEmpArc(var1.getSource(), var3, var2, var2, DamageType.ENERGY, var8, var7, 100000.0F, "tachyon_lance_emp_impact", 15.0F, this.EMP_COLOR, this.FLASH_COLOR);
            var6.spawnEmpArc(var1.getSource(), var3, var1, var1, DamageType.ENERGY, 0.0F, 0.0F, 100000.0F, "tachyon_lance_emp_impact", 10.0F, this.EMP_COLOR, this.FLASH_COLOR);
         }
      }

   }

}
