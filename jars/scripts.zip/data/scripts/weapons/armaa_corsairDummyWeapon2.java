package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import data.scripts.util.armaa_utils;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;

public class armaa_corsairDummyWeapon2 implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean runOnce2 = false;
   private WeaponAPI trueWeapon;
   private float originalArmPos = 0.0F;
   private float increment = 0.0F;
   private final float TORSO_OFFSET = 1.0F;
   private final float LEFT_ARM_OFFSET = -10.0F;


   public void init(WeaponAPI var1) {
      this.runOnce = true;
      Iterator var2 = var1.getShip().getAllWeapons().iterator();

      while(var2.hasNext()) {
         WeaponAPI var3 = (WeaponAPI)var2.next();
         String var4 = var3.getSlot().getId();
         byte var5 = -1;
         switch(var4.hashCode()) {
         case -132046045:
            if(var4.equals("TRUE_GUN2")) {
               var5 = 0;
            }
         }

         switch(var5) {
         case 0:
            if(this.trueWeapon == null) {
               this.trueWeapon = var3;
            }
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!this.runOnce) {
         this.init(var3);
      }

      if(this.trueWeapon != null) {
         var3.setCurrAngle(this.trueWeapon.getCurrAngle());
         Iterator var4 = var3.getShip().getChildModulesCopy().iterator();

         while(var4.hasNext()) {
            ShipAPI var5 = (ShipAPI)var4.next();
            var5.ensureClonedStationSlotSpec();
            if(var5.getStationSlot() != null) {
               if(var5.getStationSlot().getId().equals("WS0004")) {
                  float var6 = var3.getShip().getFacing();
                  float var7 = MathUtils.getShortestRotation(var6, this.trueWeapon.getCurrAngle());
                  if(var5.getHullLevel() <= 0.5F || var3.getShip().getHullLevel() <= 0.5F) {
                     var5.setFacing(var6 - 1.0F * (0.5F - var7 * 0.3F - -2.5F));
                     var5.getShield().forceFacing(var3.getShip().getFacing() - 90.0F + this.increment);
                     var5.getShield().toggleOn();
                  }

                  this.increment += 1.0F + 5.0F * (1.0F - var5.getHullLevel());
               }

               if(armaa_utils.estimateIncomingDamage(var5) > 200.0F && (var5.getFluxLevel() > 0.6F || var5.getHullLevel() < 0.55F)) {
                  var5.useSystem();
               }
            }
         }

      }
   }
}
