package data.scripts.util;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.FighterLaunchBayAPI;
import com.fs.starfarer.api.combat.MissileRenderDataAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponGroupAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.util.armaa_utils;
import java.awt.Color;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_takeOffScript extends BaseEveryFrameCombatPlugin {

   private ShipAPI ship;
   private ShipAPI carrier;
   private WeaponSlotAPI w;
   private IntervalUtil interval = new IntervalUtil(10.0F, 10.0F);
   private boolean stayInPlace = true;
   private boolean runOnce = false;
   private boolean hasLaunched = false;


   public armaa_takeOffScript(ShipAPI var1, ShipAPI var2) {
      this.ship = var1;
      this.carrier = var2;
   }

   public void advance(float var1, List var2) {
      Vector2f var3 = this.carrier.getLocation();
      Iterator var4;
      if(!this.runOnce) {
         var4 = this.carrier.getLaunchBaysCopy().iterator();

         while(var4.hasNext()) {
            FighterLaunchBayAPI var5 = (FighterLaunchBayAPI)var4.next();
            if(var5.getWeaponSlot() != null) {
               this.w = var5.getWeaponSlot();
               if(Math.random() <= 0.25D) {
                  break;
               }
            }
         }
      }

      if(!this.runOnce) {
         this.runOnce = true;
      }

      if(this.w != null) {
         var3 = new Vector2f(this.carrier.getLocation().x + this.w.getLocation().y, this.carrier.getLocation().y + this.w.getLocation().x);
      }

      VectorUtils.rotate(var3, this.carrier.getFacing());
      armaa_utils.setLocation(this.ship, var3);
      if(this.stayInPlace) {
         this.ship.getTravelDrive().deactivate();
      }

      if(this.ship.isFinishedLanding()) {
         var4 = this.ship.getAllWeapons().iterator();

         while(var4.hasNext()) {
            WeaponAPI var8 = (WeaponAPI)var4.next();
            if(var8.getSprite() != null) {
               var8.getSprite().setColor(new Color(255, 255, 255, 255));
            }

            if(var8.getBarrelSpriteAPI() != null) {
               var8.getBarrelSpriteAPI().setColor(new Color(255, 255, 255, 255));
            }

            if(var8.getUnderSpriteAPI() != null) {
               var8.getUnderSpriteAPI().setColor(new Color(255, 255, 255, 255));
            }

            if(var8.getMissileRenderData() != null) {
               Iterator var6 = var8.getMissileRenderData().iterator();

               while(var6.hasNext()) {
                  MissileRenderDataAPI var7 = (MissileRenderDataAPI)var6.next();
                  if(var7.getSprite() != null) {
                     var7.getSprite().setColor(new Color(255, 255, 255, 255));
                  }
               }
            }
         }

         this.ship.getSpriteAPI().setColor(new Color(255, 255, 255, 255));
         Global.getSoundPlayer().playSound("fighter_takeoff", 1.0F, 1.0F, this.ship.getLocation(), new Vector2f());
         this.ship.setAnimatedLaunch();
         this.stayInPlace = false;
         if(this.w != null) {
            this.ship.setFacing(this.carrier.getFacing() + this.w.getAngle());
         } else {
            this.ship.setFacing(this.carrier.getFacing());
         }

         if(Global.getCombatEngine().getPlayerShip() == this.ship) {
            this.carrier.getFluxTracker().showOverloadFloatyIfNeeded("Good luck out there!", Misc.getBasePlayerColor(), 2.0F, true);
            Global.getSoundPlayer().playSound("ui_noise_static", 1.0F + MathUtils.getRandomNumberInRange(-0.3F, 0.3F), 1.0F, this.carrier.getLocation(), new Vector2f());
         }

         Vector2f.add(this.carrier.getVelocity(), this.ship.getVelocity(), this.ship.getVelocity());
         var4 = this.ship.getWeaponGroupsCopy().iterator();

         while(var4.hasNext()) {
            WeaponGroupAPI var9 = (WeaponGroupAPI)var4.next();
            if(!var9.getActiveWeapon().usesAmmo() || var9.getActiveWeapon().getAmmoPerSecond() != 0.0F) {
               var9.toggleOn();
            }
         }

         if(this.ship.getVariant().hasHullMod("armaa_strikeCraftFrig")) {
            this.ship.setHullSize(HullSize.FRIGATE);
         }

         this.hasLaunched = true;
      }

      if(this.ship.getCombinedAlphaMult() >= 0.5F && this.hasLaunched) {
         this.ship.getFluxTracker().setCurrFlux(0.0F);
         Global.getCombatEngine().removePlugin(this);
      }

   }
}
