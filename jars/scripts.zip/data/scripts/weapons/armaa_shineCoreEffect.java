package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponSize;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicLensFlare;
import org.magiclib.util.MagicRender;

public class armaa_shineCoreEffect implements BeamEffectPlugin {

   private boolean runOnce = false;
   private boolean hasFired = false;
   public float TURRET_OFFSET = 45.0F;
   private final IntervalUtil particle = new IntervalUtil(0.025F, 0.05F);
   private final IntervalUtil particle2 = new IntervalUtil(0.1F, 0.2F);
   private static final Color PARTICLE_COLOR = new Color(250, 50, 255, 174);
   private static final Color BLAST_COLOR = new Color(255, 255, 26, 255);
   private static final Color CORE_COLOR = new Color(200, 200, 255);
   private static final Color FLASH_COLOR = new Color(152, 225, 255);
   private static final int NUM_PARTICLES = 15;
   private boolean firstStrike = false;
   float charge = 0.0F;
   private static final int SMOKE_SIZE_MIN = 10;
   private static final int SMOKE_SIZE_MAX = 30;
   private List targets = new ArrayList();
   private List hitTargets = new ArrayList();


   public void init(ShipAPI var1) {}

   public void advance(float var1, CombatEngineAPI var2, BeamAPI var3) {
      WeaponAPI var4 = var3.getWeapon();
      CombatEntityAPI var5 = var3.getDamageTarget();
      if(!this.targets.contains(var5)) {
         this.targets.add(var5);
      }

      float var9;
      if(var4.isFiring()) {
         var4.getShip().setCollisionClass(CollisionClass.SHIP);
         Iterator var6 = this.targets.iterator();

         while(var6.hasNext()) {
            CombatEntityAPI var7 = (CombatEntityAPI)var6.next();
            if(var7 == var3.getDamageTarget() && !this.hitTargets.contains(var3.getDamageTarget())) {
               boolean var8 = true;
               if(var4.getDamage().isForceHardFlux() || var4.getShip().getVariant().getHullMods().contains("high_scatter_amp")) {
                  var8 = false;
               }

               var9 = var4.getDamage().getDamage() * var4.getSpec().getBurstDuration();
               float var10 = var4.getShip().getFluxBasedEnergyWeaponDamageMultiplier() - 1.0F;
               if(var10 > 0.0F) {
                  var9 *= 1.0F + var10;
               }

               var2.applyDamage(var7, var3.getTo(), var9, var4.getDamageType(), var9, false, var8, var4.getShip());
               this.hitTargets.add(var7);
               if(var7 instanceof ShipAPI) {
                  ShipAPI var11 = (ShipAPI)var7;

                  for(int var12 = 0; var12 < 2; ++var12) {
                     var2.spawnEmpArc(var4.getShip(), var3.getTo(), var4.getShip(), var11, DamageType.ENERGY, var9 / 2.0F, var9 / 2.0F, 10000.0F, (String)null, 10.0F, Color.yellow, Color.white);
                  }
               }
            }
         }
      }

      float var14 = var4.getChargeLevel();
      float var15 = 2.0F;
      if(var4.getSize() == WeaponSize.LARGE) {
         var15 = 2.0F;
      }

      float var17;
      if(!this.hasFired) {
         this.particle.advance(var1);
         if(this.particle.intervalElapsed()) {
            Vector2f var16 = new Vector2f(var4.getLocation());
            Vector2f var18 = MathUtils.getPoint(var4.getLocation(), 18.5F, var4.getCurrAngle());
            Vector2f var19 = var4.getShip().getVelocity();
            var2.addHitParticle(var16, var19, MathUtils.getRandomNumberInRange(20.0F * var15, var14 * var15 * 60.0F + 20.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var14), MathUtils.getRandomNumberInRange(0.1F, 0.1F + var14 / 10.0F), new Color(var14 / 1.0F, var14 / 2.0F, var14 / 1.0F));
            var2.addSwirlyNebulaParticle(var16, new Vector2f(0.0F, 0.0F), MathUtils.getRandomNumberInRange(20.0F * var15, var14 * var15 * 60.0F + 20.0F), 1.2F, 0.15F, 0.0F, 0.35F * var14, new Color(var14 / 1.0F, var14 / 3.0F, var14 / 1.0F, 0.5F * var14), false);
            var4.getShip().setJitter(var4.getShip(), new Color(1.0F, 0.26666668F, 0.8F, var4.getChargeLevel() * 0.8F), var4.getChargeLevel(), 4, 25.0F);
            Vector2f var21 = MathUtils.getRandomPointInCircle(new Vector2f(), 35.0F * var14);
            Vector2f var23 = new Vector2f();
            Vector2f.sub(var16, new Vector2f(var21), var23);
            Vector2f.add(var19, var21, var21);
            var2.addHitParticle(var23, var21, MathUtils.getRandomNumberInRange(2.0F, var14 * 2.0F + 2.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var14), MathUtils.getRandomNumberInRange(0.75F, 0.75F + var14 / 4.0F), new Color(var14 / 1.0F, var14 / 3.0F, var14 / 1.0F));
         }

         if(var14 == 1.0F) {
            var17 = var4.getShip().getFacing();
            this.hasFired = true;
         }
      } else {
         this.hasFired = false;
      }

      if(var5 instanceof CombatEntityAPI) {
         if(!this.firstStrike) {
            Global.getSoundPlayer().playSound("explosion_ship", 1.0F, 1.0F, var4.getLocation(), var4.getShip().getVelocity());
            this.firstStrike = true;
         }

         this.particle.advance(var1);
         var17 = var4.getShip().getFacing() - 180.0F;
         CombatUtils.applyForce(var4.getShip(), var17, 1200.0F);
         if(this.particle.intervalElapsed()) {
            var2.spawnExplosion(var3.getTo(), new Vector2f(), PARTICLE_COLOR, 100.0F, 1.0F);
            var2.spawnExplosion(var3.getTo(), new Vector2f(), CORE_COLOR, 50.0F, 1.0F);
            MagicLensFlare.createSharpFlare(var2, var3.getSource(), var3.getTo(), 8.0F, 400.0F, 0.0F, new Color(186, 240, 255), new Color(255, 255, 255));
            var9 = var3.getDamage().getDamage() / 2.0F;
            DamagingExplosionSpec var20 = new DamagingExplosionSpec(0.1F, 75.0F, 50.0F, var9, var9 / 2.0F, CollisionClass.PROJECTILE_FF, CollisionClass.PROJECTILE_FIGHTER, 10.0F, 10.0F, 0.0F, 0, BLAST_COLOR, (Color)null);
            var20.setDamageType(DamageType.ENERGY);
            var20.setShowGraphic(false);
            var2.spawnDamagingExplosion(var20, var3.getSource(), var3.getTo(), false);
            if(MagicRender.screenCheck(0.2F, var3.getTo())) {
               var2.addSmoothParticle(var3.getTo(), new Vector2f(0.0F, 0.0F), 200.0F, 2.0F, 0.1F, Color.white);
               var2.addSmoothParticle(var3.getTo(), new Vector2f(), 400.0F, 0.5F, 0.1F, PARTICLE_COLOR);
               var2.addHitParticle(var3.getTo(), new Vector2f(), 200.0F, 0.5F, 0.25F, FLASH_COLOR);

               for(int var22 = 0; var22 < 15; ++var22) {
                  var2.addHitParticle(var3.getTo(), MathUtils.getPointOnCircumference((Vector2f)null, MathUtils.getRandomNumberInRange(150.0F, 300.0F), (float)Math.random() * 360.0F), 5.0F, 1.0F, MathUtils.getRandomNumberInRange(0.6F, 1.0F), PARTICLE_COLOR);
               }
            }
         }
      }

   }

}
