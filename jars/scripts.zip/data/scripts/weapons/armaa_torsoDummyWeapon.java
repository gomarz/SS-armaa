package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.awt.Color;
import java.util.Iterator;

public class armaa_torsoDummyWeapon implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private WeaponAPI falseWeapon;
   private WeaponAPI trueWeapon;


   public void init(WeaponAPI var1) {
      this.runOnce = true;
      Iterator var2 = var1.getShip().getAllWeapons().iterator();

      while(var2.hasNext()) {
         WeaponAPI var3 = (WeaponAPI)var2.next();
         String var4 = var3.getSlot().getId();
         byte var5 = -1;
         switch(var4.hashCode()) {
         case -1726101283:
            if(var4.equals("WS0001")) {
               var5 = 1;
            }
            break;
         case 1245480854:
            if(var4.equals("B_TORSO")) {
               var5 = 0;
            }
         }

         switch(var5) {
         case 0:
            if(this.falseWeapon == null) {
               this.falseWeapon = var3;
            }
            break;
         case 1:
            if(this.trueWeapon == null) {
               this.trueWeapon = var3;
            }
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!this.runOnce) {
         this.init(var3);
      }

      if(this.trueWeapon != null && this.falseWeapon != null) {
         Color var4 = new Color(0.0F, 0.0F, 0.0F, 0.0F);
         this.trueWeapon.ensureClonedSpec();
         if(this.trueWeapon.getSprite() != null) {
            this.trueWeapon.getSprite().setColor(var4);
         }

         if(this.trueWeapon.getUnderSpriteAPI() != null) {
            this.trueWeapon.getUnderSpriteAPI().setColor(var4);
         }

         if(this.trueWeapon.getBarrelSpriteAPI() != null) {
            this.trueWeapon.getBarrelSpriteAPI().setColor(var4);
         }

         if(this.trueWeapon.getGlowSpriteAPI() != null) {
            this.trueWeapon.getGlowSpriteAPI().setColor(var4);
         }

      }
   }
}
