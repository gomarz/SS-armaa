package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;

public class armaa_blinker implements EveryFrameWeaponEffectPlugin {

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      AnimationAPI var4 = var3.getAnimation();
      ShipAPI var5 = var3.getShip();
      var3.getSprite().setAdditiveBlend();
      if(var5.isAlive() && !var5.getFluxTracker().isOverloadedOrVenting()) {
         var4.setAlphaMult(1.0F);
      } else {
         var4.setAlphaMult(0.0F);
      }

   }
}
