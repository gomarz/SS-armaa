package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.plugins.MagicTrailPlugin;
import org.magiclib.util.MagicRender;

public class armaa_valkenBlade implements BeamEffectPlugin {

   private IntervalUtil fireInterval = new IntervalUtil(0.05F, 0.05F);
   private final Vector2f ZERO = new Vector2f();
   private final float BLADE_KNOCKBACK_MAX = 200.0F;
   private static final Color PARTICLE_COLOR = new Color(250, 236, 111, 255);
   private static final float PARTICLE_SIZE = 8.0F;
   private static final float PARTICLE_BRIGHTNESS = 150.0F;
   private static final float PARTICLE_DURATION = 0.8F;
   private static final int PARTICLE_COUNT = 8;
   private static final float PARTICLE_SIZE_MIN = 1.0F;
   private static final float PARTICLE_SIZE_MAX = 5.0F;
   private static final float PARTICLE_DURATION_MIN = 0.4F;
   private static final float PARTICLE_DURATION_MAX = 0.9F;
   private static final float PARTICLE_INERTIA_MULT = 0.5F;
   private static final float PARTICLE_DRIFT = 50.0F;
   private static final float PARTICLE_DENSITY = 0.15F;
   private static final float PARTICLE_SPAWN_WIDTH_MULT = 0.1F;
   private static final float CONE_ANGLE = 150.0F;
   private static final float VEL_MIN = 0.1F;
   private static final float VEL_MAX = 0.3F;
   private static final float A_2 = 75.0F;
   private float arc = 20.0F;
   private float level = 0.0F;
   private boolean firstStrike = false;
   private boolean firstTrail = false;
   private float id;
   private float id2;
   private boolean runOnce = false;
   private boolean runOnce2 = false;
   private WeaponAPI weapon;
   private List targets = new ArrayList();
   private List hitTargets = new ArrayList();


   public void advance(float var1, CombatEngineAPI var2, BeamAPI var3) {
      this.weapon = var3.getWeapon();
      ShipAPI var4 = this.weapon.getShip();
      if(!this.runOnce) {
         this.id = MagicTrailPlugin.getUniqueID();
         this.id2 = MagicTrailPlugin.getUniqueID();
         this.runOnce = true;
      }

      if(this.weapon.getChargeLevel() >= 1.0F && !this.runOnce2) {
         this.runOnce2 = true;
      }

      float var5 = var3.getWidth();
      boolean var6 = this.weapon.getShip().getHullSpec().getHullId().equals("armaa_pa_mid");
      var3.getDamage().setDamage(0.0F);
      CombatEntityAPI var7 = var3.getDamageTarget();
      if(!this.targets.contains(var7)) {
         this.targets.add(var7);
      }

      Vector2f var8 = MathUtils.getRandomPointOnLine(var3.getFrom(), var3.getTo());
      Vector2f var9 = Vector2f.sub(var3.getTo(), var3.getFrom(), new Vector2f());
      Vector2f var10 = Vector2f.sub(var3.getTo(), var9, new Vector2f());
      float var14;
      float var24;
      if(this.weapon.isFiring()) {
         if(Math.random() >= 0.75D && var3.getBrightness() >= 0.8F) {
            for(int var11 = 0; var11 < 2; ++var11) {
               var2.addHitParticle(var3.getFrom(), MathUtils.getPointOnCircumference(this.weapon.getShip().getVelocity(), MathUtils.getRandomNumberInRange(100.0F, 150.0F), MathUtils.getRandomNumberInRange(this.weapon.getCurrAngle() - 30.0F, this.weapon.getCurrAngle() + 30.0F)), 5.0F, 1.0F, MathUtils.getRandomNumberInRange(0.1F, 0.6F), var3.getFringeColor());
            }
         }

         Iterator var23 = this.targets.iterator();

         while(var23.hasNext()) {
            CombatEntityAPI var12 = (CombatEntityAPI)var23.next();
            if(var12 == var3.getDamageTarget() && !this.hitTargets.contains(var3.getDamageTarget())) {
               boolean var13 = true;
               if(this.weapon.getDamage().isForceHardFlux() || this.weapon.getShip().getVariant().getHullMods().contains("high_scatter_amp")) {
                  var13 = false;
               }

               var14 = this.weapon.getDamage().getDamage() * this.weapon.getSpec().getBurstDuration() * (this.weapon.getShip().getMutableStats().getBeamWeaponDamageMult().computeMultMod() + this.weapon.getShip().getMutableStats().getBeamWeaponDamageMult().getPercentMod() / 100.0F) * (this.weapon.getShip().getMutableStats().getEnergyWeaponDamageMult().computeMultMod() + this.weapon.getShip().getMutableStats().getEnergyWeaponDamageMult().getPercentMod() / 100.0F);
               float var15 = this.weapon.getShip().getFluxBasedEnergyWeaponDamageMultiplier() - 1.0F;
               if(var15 > 0.0F) {
                  var14 *= 1.0F + var15;
               }

               if(var3.getLength() > var3.getWeapon().getOriginalSpec().getMaxRange() * 1.5F) {
                  var14 *= Math.max(0.5F, var3.getWeapon().getOriginalSpec().getMaxRange() / var3.getLength());
               }

               var2.applyDamage(var12, var3.getTo(), var14, this.weapon.getDamageType(), var14 / 2.0F, false, var13, this.weapon.getShip());
               this.hitTargets.add(var12);
            }
         }

         this.fireInterval.advance(var1);
         if(this.fireInterval.intervalElapsed() && var3.getBrightness() == 1.0F) {
            var24 = this.weapon.getCurrAngle() - 90.0F;
            if(this.weapon.getSpec().getWeaponId().equals("armaa_aleste_blade_RightArm")) {
               var24 = this.weapon.getCurrAngle() + 90.0F;
            }

            if(MagicRender.screenCheck(0.2F, var3.getFrom())) {
               Vector2f var25 = new Vector2f((var3.getFrom().x + var3.getTo().x) / 2.0F, (var3.getFrom().y + var3.getTo().y) / 2.0F);
               MagicTrailPlugin.addTrailMemberAdvanced(this.weapon.getShip(), this.id2, Global.getSettings().getSprite("fx", "base_trail_smooth"), var25, 0.0F, 0.0F, var24, this.weapon.getShip().getAngularVelocity(), 0.0F, var3.getLength() * 2.0F, var3.getLength() * 2.0F, var3.getCoreColor(), var3.getFringeColor(), 1.0F, var1, var1, 0.1F, true, 256.0F, 0.0F, 0.0F, (Vector2f)null, (Map)null, (CombatEngineLayers)null, 2.0F);
            }
         }
      }

      Vector2f var29;
      if(var7 instanceof CombatEntityAPI) {
         var24 = var3.getDamage().getDpsDuration();
         float var26;
         if(!this.firstStrike) {
            var10 = var3.getTo();
            var26 = MathUtils.getRandomNumberInRange(-0.3F, 0.3F);
            Global.getSoundPlayer().playSound("armaa_saber_slash", 1.1F + var26, 1.0F + var26, var10, this.ZERO);
            this.firstStrike = true;
            float var28 = 500.0F;
            var14 = var3.getWeapon().getCurrAngle();
            if(MagicRender.screenCheck(0.2F, var10)) {
               SpriteAPI var30 = Global.getSettings().getSprite("misc", "armaa_sfxpulse");
               if(var30 != null) {
                  MagicRender.battlespace(var30, var3.getTo(), new Vector2f(), new Vector2f(10.0F, 10.0F), new Vector2f(150.0F, 150.0F), 15.0F, 15.0F, var3.getFringeColor(), true, 0.3F, 0.0F, 0.3F);
               }

               Color var16 = var3.getFringeColor();
               Color var17 = var3.getCoreColor();

               for(int var18 = 0; var18 <= 8; ++var18) {
                  float var19 = 10.0F + this.weapon.getChargeLevel() * this.weapon.getChargeLevel() * MathUtils.getRandomNumberInRange(25.0F, 75.0F);
                  float var20 = MathUtils.getRandomNumberInRange(var14 - 75.0F, var14 + 75.0F);
                  float var21 = MathUtils.getRandomNumberInRange(var28 * -0.1F, var28 * -0.3F);
                  Vector2f var22 = MathUtils.getPointOnCircumference((Vector2f)null, var21, var20);
                  var2.addHitParticle(var3.getTo(), var22, 8.0F, 150.0F, 0.8F, PARTICLE_COLOR);
                  var19 = 10.0F + this.weapon.getChargeLevel() * this.weapon.getChargeLevel() * MathUtils.getRandomNumberInRange(25.0F, 75.0F);
                  var20 = MathUtils.getRandomNumberInRange(var14 - 75.0F, var14 + 75.0F);
                  var21 = MathUtils.getRandomNumberInRange(var28 * -0.1F, var28 * -0.3F);
                  var22 = MathUtils.getPointOnCircumference((Vector2f)null, var21, var20);
                  var2.addSmoothParticle(var3.getTo(), var22, var19, 0.1F + this.weapon.getChargeLevel() * 0.25F, 0.1F, var16);
                  var19 = 10.0F + this.weapon.getChargeLevel() * this.weapon.getChargeLevel() * MathUtils.getRandomNumberInRange(25.0F, 75.0F);
                  var20 = MathUtils.getRandomNumberInRange(var14 - 75.0F, var14 + 75.0F);
                  var21 = MathUtils.getRandomNumberInRange(var28 * -0.1F, var28 * -0.3F);
                  var22 = MathUtils.getPointOnCircumference((Vector2f)null, var21, var20);
                  var2.addHitParticle(var3.getTo(), var22, var19 * 0.7F, 0.1F + this.weapon.getChargeLevel() * 0.1F, 0.1F, var17);
               }
            }

            if(!var6) {
               CombatUtils.applyForce(this.weapon.getShip(), this.weapon.getShip().getFacing() - 180.0F, Math.min(var7.getMass() / 2.0F, 200.0F));
            }
         }

         var26 = this.weapon.getCurrAngle();
         var29 = this.weapon.getShip().getVelocity();
         if(var9.lengthSquared() > 0.0F) {
            var9.normalise();
         }

         var9.scale(50.0F);
      }

      if(MagicRender.screenCheck(0.2F, var10) && this.runOnce2) {
         var24 = var5 * 0.1F * MathUtils.getDistance(var3.getTo(), var3.getFrom()) * var1 * 0.15F * this.weapon.getChargeLevel();

         for(int var27 = 0; (float)var27 < var24; ++var27) {
            var8 = MathUtils.getRandomPointInCircle(var8, var5 * 0.1F);
            var29 = MathUtils.getRandomPointOnLine(var3.getFrom(), var3.getTo());
            if(Global.getCombatEngine().getViewport().isNearViewport(var8, 15.0F)) {
               Vector2f var31 = new Vector2f(var4.getVelocity().x * 0.5F, var4.getVelocity().y * 0.5F);
               var31 = MathUtils.getRandomPointInCircle(var31, 50.0F);
               if((float)Math.random() <= 0.05F) {
                  var2.addNebulaParticle(var8, var31, 40.0F * (0.75F + (float)Math.random() * 0.5F), MathUtils.getRandomNumberInRange(1.0F, 3.0F), 0.0F, 0.0F, 1.0F, new Color(var3.getFringeColor().getRed(), var3.getFringeColor().getGreen(), var3.getFringeColor().getBlue(), 100), true);
               }

               var2.addSmoothParticle(var8, var31, MathUtils.getRandomNumberInRange(1.0F, 5.0F), this.weapon.getChargeLevel(), MathUtils.getRandomNumberInRange(0.4F, 0.9F), var3.getFringeColor());
            }
         }
      }

   }

}
