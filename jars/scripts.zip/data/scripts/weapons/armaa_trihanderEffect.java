package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.awt.Color;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;

public class armaa_trihanderEffect implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private WeaponAPI reference;
   private ShipAPI ship;
   private WeaponAPI armL;
   private WeaponAPI armR;
   private WeaponAPI shoulderR;
   private WeaponAPI head;
   private WeaponAPI headGlow;
   private float overlap = 0.0F;
   private float overlap2 = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -75.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!this.runOnce) {
         this.runOnce = true;
         this.ship = var3.getShip();
         Iterator var4 = this.ship.getAllWeapons().iterator();

         while(var4.hasNext()) {
            WeaponAPI var5 = (WeaponAPI)var4.next();
            String var6 = var5.getSlot().getId();
            byte var7 = -1;
            switch(var6.hashCode()) {
            case 1630742648:
               if(var6.equals("E_RSHOULDER")) {
                  var7 = 2;
               }
               break;
            case 1672492306:
               if(var6.equals("E_HEAD_GLOW")) {
                  var7 = 3;
               }
               break;
            case 2065359258:
               if(var6.equals("E_HEAD")) {
                  var7 = 4;
               }
               break;
            case 2065475114:
               if(var6.equals("E_LARM")) {
                  var7 = 0;
               }
               break;
            case 2065653860:
               if(var6.equals("E_RARM")) {
                  var7 = 1;
               }
            }

            switch(var7) {
            case 0:
               if(this.armL == null) {
                  this.armL = var5;
               }
               break;
            case 1:
               if(this.armR == null) {
                  this.armR = var5;
               }
               break;
            case 2:
               this.shoulderR = var5;
               break;
            case 3:
               if(this.headGlow == null) {
                  this.headGlow = var5;
               }
               break;
            case 4:
               if(this.head == null) {
                  this.head = var5;
               }
            }
         }
      }

      if(this.armL != null) {
         List var11 = this.ship.getChildModulesCopy();
         if(this.ship.getEngineController().isAccelerating()) {
            if(this.overlap > 9.9F) {
               this.overlap = 10.0F;
            } else {
               this.overlap = Math.min(10.0F, this.overlap + (10.0F - this.overlap) * var1 * 5.0F);
            }
         } else if(!this.ship.getEngineController().isDecelerating() && !this.ship.getEngineController().isAcceleratingBackwards()) {
            if(Math.abs(this.overlap) < 0.1F) {
               this.overlap = 0.0F;
            } else {
               this.overlap -= this.overlap / 2.0F * var1 * 3.0F;
            }
         } else if(this.overlap < -9.9F) {
            this.overlap = -10.0F;
         } else {
            this.overlap = Math.max(-10.0F, this.overlap + (-10.0F + this.overlap) * var1 * 5.0F);
         }

         if(this.ship.getEngineController().isStrafingLeft()) {
            if(this.overlap2 > 9.9F) {
               this.overlap2 = 10.0F;
            } else {
               this.overlap2 = Math.min(10.0F, this.overlap2 + (10.0F - this.overlap2) * var1 * 5.0F);
            }
         }

         float var12 = 0.0F;
         float var13 = 0.0F;
         float var14 = this.ship.getFacing();
         float var8 = MathUtils.getShortestRotation(var14, var3.getCurrAngle());
         this.armL.setCurrAngle(var14 + (var8 + -75.0F) * var13 + (this.overlap + var8 * 0.25F) * (1.0F - var13));
         if(var11 != null) {
            Iterator var9 = var11.iterator();

            while(var9.hasNext()) {
               ShipAPI var10 = (ShipAPI)var9.next();
               var10.ensureClonedStationSlotSpec();
               if(var10.getStationSlot() != null) {
                  if(var10.getStationSlot().getId().equals("WS0001")) {
                     var10.setFacing(var14 - (var8 + -75.0F) * var13 - (this.overlap + this.overlap2 + var8 * 0.25F) * (1.0F - var13));
                  } else if(var10.getStationSlot().getId().equals("WS0002")) {
                     var10.setFacing(this.armL.getCurrAngle());
                  }
               }
            }
         }

         var3.setCurrAngle(this.ship.getFacing() + MathUtils.getShortestRotation(this.ship.getFacing(), this.armL.getCurrAngle()) * 0.7F);
         this.shoulderR.setCurrAngle(this.ship.getFacing() + MathUtils.getShortestRotation(this.ship.getFacing(), this.armR.getCurrAngle()) * 0.7F);
         this.shoulderR.getSprite().setCenterY(this.armR.getBarrelSpriteAPI().getCenterY());
         this.headGlow.setCurrAngle(this.head.getCurrAngle());
         this.ship.syncWeaponDecalsWithArmorDamage();
         if(!this.ship.isHulk()) {
            this.headGlow.getSprite().setAlphaMult(2.0F);
            this.headGlow.getSprite().setColor(new Color(255, 0, 0, 255));
         } else {
            this.headGlow.getSprite().setColor(new Color(0, 0, 0, 255));
         }

      }
   }
}
