package data.scripts.weapons;

import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.util.Misc;
import java.util.Iterator;
import org.lwjgl.util.vector.Vector2f;

public class armaa_amwsEffect implements BeamEffectPlugin {

   private boolean done = false;


   public void advance(float var1, CombatEngineAPI var2, BeamAPI var3) {
      if(!this.done) {
         CombatEntityAPI var4 = var3.getDamageTarget();
         boolean var5 = var3.getWeapon().getBeams().indexOf(var3) == 0;
         if(var4 != null && var3.getBrightness() >= 1.0F && var5) {
            Vector2f var6 = var3.getTo();
            float var7 = 0.0F;

            BeamAPI var9;
            for(Iterator var8 = var3.getWeapon().getBeams().iterator(); var8.hasNext(); var7 = Math.max(var7, Misc.getDistance(var6, var9.getTo()))) {
               var9 = (BeamAPI)var8.next();
            }

            if(var7 < 15.0F) {
               DamagingProjectileAPI var10 = var2.spawnDamagingExplosion(this.createExplosionSpec(var3), var3.getSource(), var6);
               var10.addDamagedAlready(var4);
               this.done = true;
            }
         }

      }
   }

   public DamagingExplosionSpec createExplosionSpec(BeamAPI var1) {
      float var2 = 25.0F;
      DamagingExplosionSpec var3 = new DamagingExplosionSpec(0.1F, 50.0F, 25.0F, var2, var2 / 2.0F, CollisionClass.PROJECTILE_FF, CollisionClass.PROJECTILE_FIGHTER, 1.0F, 2.0F, 0.5F, 100, var1.getCoreColor(), var1.getFringeColor());
      var3.setDamageType(DamageType.FRAGMENTATION);
      var3.setUseDetailedExplosion(false);
      var3.setSoundSetId("explosion_guardian");
      return var3;
   }
}
