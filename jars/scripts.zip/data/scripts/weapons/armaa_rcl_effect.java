package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicLensFlare;
import org.magiclib.util.MagicRender;

public class armaa_rcl_effect implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin, OnHitEffectPlugin {

   private float count = 1.5F;
   private boolean recoiling = false;
   private IntervalUtil recoilTracker = new IntervalUtil(1.0F, 1.0F);


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(this.recoiling && this.count > 0.0F) {
         this.count -= var1;
         var3.getShip().setFacing(var3.getShip().getFacing() - this.count);
      }

      if(this.count <= 0.0F) {
         this.count = 1.5F;
         this.recoiling = false;
      }

   }

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      if(var2.getChargeLevel() == 1.0F) {
         if(!this.recoiling) {
            this.recoiling = true;
         }

         CombatUtils.applyForce(var2.getShip(), var2.getShip().getFacing() - 180.0F, 75.0F);
      }

      float var4 = 180.0F + var2.getCurrAngle();
      Vector2f var5 = MathUtils.getPoint(var2.getFirePoint(0), 45.0F, var4);

      int var6;
      Vector2f var7;
      for(var6 = 0; var6 < 20; ++var6) {
         var7 = MathUtils.getRandomPointInCone(new Vector2f(), 100.0F, var4 - 20.0F, var4 + 20.0F);
         var7.scale((float)Math.random());
         Vector2f.add(var7, var2.getShip().getVelocity(), var7);
         float var8 = MathUtils.getRandomNumberInRange(0.5F, 0.75F);
         var3.addSmokeParticle(MathUtils.getRandomPointInCircle(var5, 5.0F), var7, (float)MathUtils.getRandomNumberInRange(5, 20), MathUtils.getRandomNumberInRange(0.25F, 0.75F), MathUtils.getRandomNumberInRange(0.25F, 1.0F), new Color(var8, var8, var8, MathUtils.getRandomNumberInRange(0.25F, 0.75F)));
      }

      for(var6 = 0; var6 < 10; ++var6) {
         var7 = MathUtils.getRandomPointInCone(new Vector2f(), 250.0F, var4 - 20.0F, var4 + 20.0F);
         Vector2f.add(var7, var2.getShip().getVelocity(), var7);
         var3.addHitParticle(var5, var7, (float)MathUtils.getRandomNumberInRange(2, 4), 1.0F, MathUtils.getRandomNumberInRange(0.05F, 0.25F), new Color(255, 125, 50));
      }

      Vector2f var9 = MathUtils.getRandomPointInCone(new Vector2f(), 100.0F, var4 - 20.0F, var4 + 20.0F);
      var9.scale((float)Math.random());
      Vector2f.add(var9, var2.getShip().getVelocity(), var9);
      var3.addHitParticle(var5, var9, 100.0F, 0.5F, 0.5F, new Color(255, 20, 10));
      var3.addHitParticle(var5, var9, 80.0F, 0.75F, 0.15F, new Color(255, 200, 50));
      var3.addHitParticle(var5, var9, 50.0F, 1.0F, 0.05F, new Color(255, 200, 150));
      var5 = MathUtils.getPoint(var2.getFirePoint(0), 0.0F, var4);
      var3.addHitParticle(var5, var1.getVelocity(), 100.0F, 0.5F, 0.5F, new Color(255, 20, 10));
      var3.addHitParticle(var5, var1.getVelocity(), 80.0F, 0.75F, 0.15F, new Color(255, 200, 50));
      var3.addHitParticle(var5, var1.getVelocity(), 50.0F, 1.0F, 0.05F, new Color(255, 200, 150));
   }

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      var6.addNebulaSmokeParticle(var1.getLocation(), new Vector2f(), 40.0F * (0.75F + (float)Math.random() * 0.5F), 5.0F + 3.0F * Misc.getHitGlowSize(75.0F, var1.getDamage().getBaseDamage(), var5) / 100.0F, 0.0F, 0.0F, 1.0F, new Color(175, 100, 100, 255));
      if(MagicRender.screenCheck(0.2F, var3)) {
         var6.addSmoothParticle(var3, new Vector2f(), 200.0F, 2.0F, 0.3F, Color.WHITE);
         var6.addSmoothParticle(var3, new Vector2f(), 200.0F, 2.0F, 0.2F, Color.WHITE);
         var6.addSmoothParticle(var3, new Vector2f(), 300.0F, 2.0F, 0.1F, Color.WHITE);
         MagicLensFlare.createSmoothFlare(var6, var1.getSource(), var3, 15.0F, 400.0F, 0.0F, new Color(255, 150, 75), Color.DARK_GRAY);

         int var7;
         for(var7 = 0; var7 < 30; ++var7) {
            int var8 = MathUtils.getRandomNumberInRange(20, 100);
            var6.addSmokeParticle(MathUtils.getRandomPointInCircle(var3, 40.0F), MathUtils.getRandomPointInCone(new Vector2f(), 30.0F, var1.getFacing() + 90.0F, var1.getFacing() + 270.0F), (float)MathUtils.getRandomNumberInRange(30, 60), 1.0F, (float)MathUtils.getRandomNumberInRange(2, 5), new Color(var8 / 10, var8, (int)((float)var8 / MathUtils.getRandomNumberInRange(1.5F, 2.0F)), MathUtils.getRandomNumberInRange(8, 32)));
         }

         for(var7 = 0; var7 < 15; ++var7) {
            var6.addHitParticle(var3, MathUtils.getRandomPointInCone(new Vector2f(), (float)(var7 * 10), var1.getFacing() + 90.0F, var1.getFacing() + 270.0F), 5.0F, 1.0F, (float)(2 - var7 / 10), new Color(255, 125, 20, 200));
         }
      }

   }
}
