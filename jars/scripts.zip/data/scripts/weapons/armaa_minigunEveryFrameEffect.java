package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseCombatLayeredRenderingPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_minigunEveryFrameEffect extends BaseCombatLayeredRenderingPlugin implements OnFireEffectPlugin, OnHitEffectPlugin, EveryFrameWeaponEffectPlugin {

   private int lastAmmo = 0;
   private boolean soundPlayed = false;
   private boolean windingUp = true;
   private IntervalUtil cockSound = new IntervalUtil(0.33F, 0.38F);
   private IntervalUtil reloadTime = new IntervalUtil(2.8F, 2.85F);
   private DamagingProjectileAPI dummy;
   private List registeredProjectiles = new ArrayList();
   private static final int EXPLOSION_DAMAGE_MIN = 0;
   private static final int EXPLOSION_DAMAGE_MAX = 10;
   private static final Color EXPLOSION_COLOR = new Color(255, 105, 100, 200);
   private static final float EXPLOSION_RADIUS = 30.0F;
   private static final float EXPLOSION_DURATION = 0.07F;
   private static final String SFX = "magellan_bonesaw_crit";
   private static Random rng = new Random();
   private static final int SMOKE_SIZE_MIN = 5;
   private static final int SMOKE_SIZE_MAX = 30;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(var3.getChargeLevel() > 0.0F) {
         this.windingUp = true;
      } else {
         this.windingUp = false;
         this.soundPlayed = false;
      }

      if(!this.soundPlayed && this.windingUp) {
         ;
      }

   }

   private static float explosionDamage() {
      return (float)(rng.nextInt(11) + 0);
   }

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      if(var2 instanceof ShipAPI && !var4) {
         var6.applyDamage(var2, var3, explosionDamage(), DamageType.HIGH_EXPLOSIVE, 0.0F, false, false, var1.getSource());
         Vector2f var7 = new Vector2f(var2.getVelocity());
         var6.spawnExplosion(var3, var7, EXPLOSION_COLOR, 30.0F, 0.07F);
      }

   }

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      float var4 = (float)MathUtils.getRandomNumberInRange(5, 30);
      float var5 = (float)MathUtils.getRandomNumberInRange(-44, 44);
      float var6 = (float)MathUtils.getRandomNumberInRange(-48, 48);
      Global.getCombatEngine().addSmokeParticle(var1.getLocation(), new Vector2f(var5, var6), var4, 0.5F, 0.5F, Color.gray);
   }

}
