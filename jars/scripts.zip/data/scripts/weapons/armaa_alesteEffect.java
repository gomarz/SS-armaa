package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicAnim;

public class armaa_alesteEffect implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private ShipSystemAPI system;
   private ShipAPI ship;
   private SpriteAPI sprite;
   private AnimationAPI anim;
   private WeaponAPI head;
   private WeaponAPI armL;
   private WeaponAPI armL2;
   private WeaponAPI armR;
   private WeaponAPI pauldronL;
   private WeaponAPI pauldronR;
   private WeaponAPI torso;
   private WeaponAPI gun;
   private WeaponAPI shoulderwep;
   private WeaponAPI headGlow;
   private WeaponAPI trueWeapon;
   private final Vector2f ZERO = new Vector2f();
   private int limbInit = 0;
   private float swingLevel = 0.0F;
   private boolean swinging = false;
   private boolean cooldown = false;
   private float swingLevelR = 0.0F;
   private boolean swingingR = false;
   private boolean cooldownR = false;
   private IntervalUtil animInterval = new IntervalUtil(0.012F, 0.012F);
   private float overlap = 0.0F;
   private float heat = 0.0F;
   private float originalRArmPos = 0.0F;
   private float originalArmPos = 0.0F;
   private float originalArmPos2 = 0.0F;
   private float originalShoulderPos = 0.0F;
   private float originalRShoulderPos = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -60.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;
   private final float LPAULDRONOFFSET = -5.0F;


   public void init() {
      this.runOnce = true;
      Iterator var1 = this.ship.getAllWeapons().iterator();

      while(var1.hasNext()) {
         WeaponAPI var2 = (WeaponAPI)var1.next();
         String var3 = var2.getSlot().getId();
         byte var4 = -1;
         switch(var3.hashCode()) {
         case -2143743196:
            if(var3.equals("H_GLOW")) {
               var4 = 8;
            }
            break;
         case -1666827537:
            if(var3.equals("TRUE_GUN")) {
               var4 = 9;
            }
            break;
         case -6931076:
            if(var3.equals("D_PAULDRONL")) {
               var4 = 4;
            }
            break;
         case -6931070:
            if(var3.equals("D_PAULDRONR")) {
               var4 = 5;
            }
            break;
         case 62929954:
            if(var3.equals("A_GUN")) {
               var4 = 0;
            }
            break;
         case 82866645:
            if(var3.equals("WS001")) {
               var4 = 7;
            }
            break;
         case 2007905292:
            if(var3.equals("C_ARML")) {
               var4 = 1;
            }
            break;
         case 2007905298:
            if(var3.equals("C_ARMR")) {
               var4 = 3;
            }
            break;
         case 2065359258:
            if(var3.equals("E_HEAD")) {
               var4 = 6;
            }
            break;
         case 2115521958:
            if(var3.equals("C_ARML2")) {
               var4 = 2;
            }
         }

         switch(var4) {
         case 0:
            if(this.gun == null) {
               this.gun = var2;
               this.originalRArmPos = var2.getBarrelSpriteAPI() != null?var2.getBarrelSpriteAPI().getCenterY():var2.getSprite().getCenterY();
               ++this.limbInit;
            }
            break;
         case 1:
            if(this.armL == null) {
               this.armL = var2;
               this.originalArmPos = this.armL.getSprite().getCenterY();
               ++this.limbInit;
            }
            break;
         case 2:
            if(this.armL2 == null) {
               this.armL2 = var2;
               this.originalArmPos2 = this.armL2.getSprite().getCenterY();
               ++this.limbInit;
            }
            break;
         case 3:
            if(this.armR == null) {
               this.armR = var2;
               ++this.limbInit;
            }
            break;
         case 4:
            if(this.pauldronL == null) {
               this.pauldronL = var2;
               this.originalShoulderPos = this.pauldronL.getSprite().getCenterY();
               ++this.limbInit;
            }
            break;
         case 5:
            if(this.pauldronR == null) {
               this.pauldronR = var2;
               this.originalRShoulderPos = this.pauldronR.getSprite().getCenterY();
               ++this.limbInit;
            }
            break;
         case 6:
            if(this.head == null) {
               this.head = var2;
               ++this.limbInit;
            }
            break;
         case 7:
            this.shoulderwep = var2;
            break;
         case 8:
            this.headGlow = var2;
            break;
         case 9:
            if(this.trueWeapon == null) {
               this.trueWeapon = var2;
            }
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.ship = var3.getShip();
      this.sprite = this.ship.getSpriteAPI();
      this.system = this.ship.getSystem();
      if(!this.runOnce) {
         this.init();
      }

      if(this.gun != null) {
         if(!var2.isPaused()) {
            this.anim = this.gun.getAnimation();
            this.ship.syncWeaponDecalsWithArmorDamage();
            if(this.armL != null) {
               if(this.ship.getEngineController().isAccelerating()) {
                  if(this.overlap > 9.9F) {
                     this.overlap = 10.0F;
                  } else {
                     this.overlap = Math.min(10.0F, this.overlap + (10.0F - this.overlap) * var1 * 5.0F);
                  }
               } else if(!this.ship.getEngineController().isDecelerating() && !this.ship.getEngineController().isAcceleratingBackwards()) {
                  if(Math.abs(this.overlap) < 0.1F) {
                     this.overlap = 0.0F;
                  } else {
                     this.overlap -= this.overlap / 2.0F * var1 * 3.0F;
                  }
               } else if(this.overlap < -9.9F) {
                  this.overlap = -10.0F;
               } else {
                  this.overlap = Math.max(-10.0F, this.overlap + (-10.0F + this.overlap) * var1 * 5.0F);
               }

               float var4 = 0.0F;
               float var5 = 0.0F;
               float var6 = 0.0F;
               float var7 = 0.0F;
               float var8 = this.ship.getFacing();
               float var9 = MathUtils.getShortestRotation(var8, this.gun.getCurrAngle());
               float var10 = MathUtils.getShortestRotation(var8, this.armL.getCurrAngle());
               boolean var11 = false;
               if(this.armL2 == null && (this.armL.getSpec().getWeaponId().equals("armaa_aleste_rifle_left") || this.armL.getSpec().getWeaponId().equals("armaa_aleste_grenade_left"))) {
                  var11 = true;
               }

               WeaponAPI var12;
               if(this.armL != null && !var11) {
                  var12 = this.armL2 == null?this.armL:this.armL2;
                  float var13 = var12 == this.armL?this.originalArmPos:this.originalArmPos2;
                  if(var12.getChargeLevel() < 1.0F) {
                     var4 = MagicAnim.smoothNormalizeRange(var12.getChargeLevel(), 0.3F, 0.9F);
                     var5 = MagicAnim.smoothNormalizeRange(var12.getChargeLevel(), 0.3F, 1.0F);
                  } else {
                     var4 = 1.0F;
                     var5 = 1.0F;
                  }

                  var12.getSprite().setCenterY(var13 - 16.0F * var5);
               }

               if(var3 != null && this.armL != null) {
                  var12 = this.armL2 == null?this.armL:this.armL2;
                  if(var11) {
                     var3.setCurrAngle(var8 + var4 * -45.0F + var9 * 0.3F);
                  } else {
                     var3.setCurrAngle(var8 + (var4 * (-45.0F - -45.0F * (this.swingLevel / 9.0F)) + var9 * 0.3F) * var12.getChargeLevel());
                  }

                  if(var12.getSpec().getWeaponId().equals("armaa_aleste_blade_LeftArm")) {
                     if(var12.getCooldownRemaining() <= 0.0F && !var12.isFiring()) {
                        this.cooldown = false;
                     }

                     if(!this.swinging && !this.cooldown && var12.getChargeLevel() > 0.0F) {
                        this.armL.setCurrAngle(this.armL.getCurrAngle() + var4 * -45.0F * 0.3F * var12.getChargeLevel());
                     }

                     if(var12.getChargeLevel() >= 1.0F) {
                        this.swinging = true;
                     }

                     if(this.swinging && this.armL.getCurrAngle() != this.armL.getShip().getFacing() + 45.0F) {
                        this.animInterval.advance(var1);
                        this.armL.setCurrAngle(Math.min(this.armL.getCurrAngle() + this.swingLevel, this.armL.getCurrAngle() + this.armL.getArc() / 2.0F));
                     }

                     if(this.swinging && var12.getChargeLevel() <= 0.0F) {
                        this.swinging = false;
                        this.swingLevel = 0.0F;
                        this.cooldown = true;
                     }

                     if(this.animInterval.intervalElapsed()) {
                        this.swingLevel = (float)((double)this.swingLevel + 0.5D);
                     }

                     if(this.swingLevel > 9.0F) {
                        this.swingLevel = 9.0F;
                     }

                     if(!this.swinging) {
                        this.swingLevel = 0.0F;
                     }
                  }
               }

               if(this.armL2 != null) {
                  this.armL2.setCurrAngle(this.armL.getCurrAngle());
               }

               if(this.armR != null) {
                  this.armR.setCurrAngle(this.gun.getCurrAngle() + -25.0F);
                  if(this.gun.getChargeLevel() < 1.0F) {
                     var6 = MagicAnim.smoothNormalizeRange(this.gun.getChargeLevel(), 0.3F, 0.9F);
                     var7 = MagicAnim.smoothNormalizeRange(this.gun.getChargeLevel(), 0.3F, 1.0F);
                  } else {
                     var6 = 1.0F;
                     var7 = 1.0F;
                  }

                  if(this.gun.getSpec().getWeaponId().equals("armaa_aleste_blade_RightArm")) {
                     if(this.gun.getCooldownRemaining() <= 0.0F && !this.gun.isFiring()) {
                        this.cooldownR = false;
                     }

                     if(!this.swingingR && !this.cooldownR && this.gun.getChargeLevel() > 0.0F) {
                        this.gun.setCurrAngle(this.gun.getCurrAngle() + var6 * 45.0F * 0.3F * this.gun.getChargeLevel());
                     }

                     if(this.gun.getChargeLevel() >= 1.0F) {
                        this.swingingR = true;
                     }

                     if(this.swingingR && this.gun.getCurrAngle() != this.gun.getShip().getFacing() - 45.0F) {
                        this.animInterval.advance(var1);
                        this.gun.setCurrAngle(Math.max(this.gun.getCurrAngle() - this.swingLevelR, this.gun.getCurrAngle() - this.gun.getArc() / 2.0F));
                     }

                     if(this.swingingR && this.gun.getChargeLevel() <= 0.0F) {
                        this.swingingR = false;
                        this.swingLevelR = 0.0F;
                        this.cooldownR = true;
                     }

                     if(this.animInterval.intervalElapsed()) {
                        this.swingLevelR = (float)((double)this.swingLevelR + 0.5D);
                     }

                     if(this.swingLevelR > 9.0F) {
                        this.swingLevelR = 9.0F;
                     }

                     if(!this.swingingR) {
                        this.swingLevelR = 0.0F;
                     }
                  }
               }

               if(this.pauldronR != null) {
                  this.pauldronR.setCurrAngle(var8 + var4 * (-45.0F - -45.0F * (this.swingLevel / 9.0F)) * 0.5F + var9 * 0.75F + -12.5F);
                  if(this.gun.getBarrelSpriteAPI() != null) {
                     this.pauldronR.getSprite().setCenterY(this.gun.getBarrelSpriteAPI().getCenterY() - 40.0F);
                  }

                  if(this.trueWeapon != null && this.trueWeapon.getCooldown() > 0.0F) {
                     this.gun.getSprite().setCenterY(this.originalRArmPos + 2.0F * this.trueWeapon.getCooldownRemaining() / this.trueWeapon.getCooldown());
                     this.pauldronR.getSprite().setCenterY(this.originalRShoulderPos + 2.0F * this.trueWeapon.getCooldownRemaining() / this.trueWeapon.getCooldown());
                  }
               }

               if(this.pauldronL != null) {
                  if(this.armL != null) {
                     this.pauldronL.setCurrAngle(var8 + var4 * -45.0F * 0.5F + var10 * 0.75F - -12.5F);
                  }

                  this.pauldronL.getSprite().setCenterY(this.originalShoulderPos - 8.0F * var5);
               }

               if(this.headGlow != null) {
                  this.headGlow.setCurrAngle(this.head.getCurrAngle());
               }

            }
         }
      }
   }
}
