package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.util.armaa_utils;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.ReadableVector2f;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_fluxBeamEffect implements EveryFrameWeaponEffectPlugin {

   private static final Vector2f ZERO = new Vector2f();
   private float CHARGEUP_PARTICLE_ANGLE_SPREAD = 150.0F;
   private float CHARGEUP_PARTICLE_BRIGHTNESS = 1.0F;
   private float CHARGEUP_PARTICLE_DISTANCE_MAX = 200.0F;
   private float CHARGEUP_PARTICLE_DISTANCE_MIN = 100.0F;
   private float CHARGEUP_PARTICLE_DURATION = 0.5F;
   private float CHARGEUP_PARTICLE_SIZE_MAX = 5.0F;
   private float CHARGEUP_PARTICLE_SIZE_MIN = 1.0F;
   public float TURRET_OFFSET = 40.0F;
   private boolean charging = false;
   private boolean cooling = false;
   private boolean firing = false;
   private final IntervalUtil interval = new IntervalUtil(0.015F, 0.015F);
   private final IntervalUtil interval2 = new IntervalUtil(0.075F, 0.075F);
   private float level = 0.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!var2.isPaused() && var3.getShip().getOriginalOwner() != -1) {
         if(MagicRender.screenCheck(0.2F, var3.getLocation())) {
            Vector2f var4 = new Vector2f(var3.getLocation());
            new Vector2f(this.TURRET_OFFSET, -0.0F);
            Vector2f var5;
            if(var3.getSlot().isTurret()) {
               var5 = new Vector2f((ReadableVector2f)var3.getSpec().getTurretFireOffsets().get(0));
            } else {
               var5 = new Vector2f((ReadableVector2f)var3.getSpec().getHardpointFireOffsets().get(0));
            }

            VectorUtils.rotate(var5, var3.getCurrAngle(), var5);
            Vector2f.add(var5, var4, var4);
            float var6 = var3.getCurrAngle();
            Vector2f var7 = var3.getShip().getVelocity();
            float var8 = var3.getChargeLevel();
            Color var9 = new Color(150, 150, 150, 100);
            Color var10 = new Color(255, 0, 0, 255);
            float var11 = (float)var10.getRed() / 255.0F + var8 * ((float)var9.getRed() / 255.0F) - (float)var10.getRed() / 255.0F * var8;
            float var12 = (float)var10.getGreen() / 255.0F + var8 * ((float)var9.getGreen() / 255.0F) - (float)var10.getGreen() / 255.0F * var8;
            float var13 = (float)var10.getBlue() / 255.0F + var8 * ((float)var9.getBlue() / 255.0F) - (float)var10.getBlue() / 255.0F * var8;
            if(this.charging || !this.charging && var3.getChargeLevel() < 1.0F && var3.getChargeLevel() > 0.0F) {
               float var14 = 25.0F + var8 * var8 * MathUtils.getRandomNumberInRange(25.0F, 50.0F);
               var2.addHitParticle(var4, ZERO, var14, var8 * 0.3F, 0.2F, new Color(var11 * var8, var13 * var8, var12 * var8, var8));
            }

            if(this.charging) {
               if(this.firing && var8 < 1.0F) {
                  this.charging = false;
                  this.cooling = true;
                  this.firing = false;
               } else if(var8 < 1.0F) {
                  armaa_utils.createChargeParticle(var8, var4, var3.getShip(), var9, 3.0F);
               } else {
                  this.firing = true;
                  this.interval.advance(var1);
                  int var26 = 1 + (int)(var3.getChargeLevel() * 2.0F);
                  if(this.interval.intervalElapsed()) {
                     for(int var15 = 0; var15 < var26; ++var15) {
                        float var16 = this.CHARGEUP_PARTICLE_ANGLE_SPREAD / 2.0F;
                        float var17 = var3.getCurrAngle();
                        float var18 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_DISTANCE_MIN + 1.0F, this.CHARGEUP_PARTICLE_DISTANCE_MAX + 1.0F) * var3.getChargeLevel();
                        float var19 = 0.5F;
                        float var20 = 1.0F;
                        float var21 = 0.5F * var18 / this.CHARGEUP_PARTICLE_DURATION * var3.getChargeLevel();
                        float var22 = MathUtils.getRandomNumberInRange(var17 - var16, var17 + var16);
                        float var23 = MathUtils.getRandomNumberInRange(var21 * -var19, var21 * -var20);
                        Vector2f var24 = MathUtils.getPointOnCircumference(var3.getShip().getVelocity(), var23, var22);
                        float var25 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_SIZE_MIN + 1.0F, this.CHARGEUP_PARTICLE_SIZE_MAX + 3.0F) * var3.getChargeLevel();
                        var2.addHitParticle(var4, var24, var25, this.CHARGEUP_PARTICLE_BRIGHTNESS * Math.min(var3.getChargeLevel() + 0.5F, 1.0F) * MathUtils.getRandomNumberInRange(0.75F, 1.25F), this.CHARGEUP_PARTICLE_DURATION, var9);
                     }
                  }
               }
            } else if(this.cooling) {
               if(var8 <= 0.0F) {
                  this.cooling = false;
               }
            } else if(var8 > this.level) {
               Global.getSoundPlayer().playSound("beamchargeM", 0.95F, 1.05F, var4, var3.getShip().getVelocity());
               this.charging = true;
            }

            this.level = var8;
         }
      }
   }

}
