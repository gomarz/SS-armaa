package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_BarrettaOnFireEffect implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin {

   private static final List USED_IDS = new ArrayList();
   private static final Map ON_SHOT_PARTICLE_COUNT;
   private static final Map SPAWN_POINT_ANCHOR_ALTERNATION;
   private static final Map PARTICLE_SPAWN_POINT_TURRET;
   private static final Map PARTICLE_SPAWN_POINT_HARDPOINT;
   private static final Map PARTICLE_TYPE;
   private static final Map PARTICLE_COLOR;
   private static final Map PARTICLE_SIZE_MIN;
   private static final Map PARTICLE_SIZE_MAX;
   private static final Map PARTICLE_VELOCITY_MIN;
   private static final Map PARTICLE_VELOCITY_MAX;
   private static final Map PARTICLE_DURATION_MIN;
   private static final Map PARTICLE_DURATION_MAX;
   private static final Map PARTICLE_OFFSET_MIN;
   private static final Map PARTICLE_OFFSET_MAX;
   private static final Map PARTICLE_ARC;
   private static final Map PARTICLE_ARC_FACING;
   private static final Map PARTICLE_SCREENSPACE_CULL_DISTANCE;
   private int currentBarrel = 0;


   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      var3.spawnExplosion(var1.getLocation(), var2.getShip().getVelocity(), new Color(255, 150, 80, 10), 60.0F, 0.1F);
      Iterator var4 = USED_IDS.iterator();

      while(var4.hasNext()) {
         String var5 = (String)var4.next();
         float var6 = ((Float)PARTICLE_SCREENSPACE_CULL_DISTANCE.get("default")).floatValue();
         if(PARTICLE_SCREENSPACE_CULL_DISTANCE.containsKey(var5)) {
            var6 = ((Float)PARTICLE_SCREENSPACE_CULL_DISTANCE.get(var5)).floatValue();
         }

         if(var3.getViewport().isNearViewport(var2.getLocation(), var6)) {
            boolean var7 = ((Boolean)SPAWN_POINT_ANCHOR_ALTERNATION.get("default")).booleanValue();
            if(SPAWN_POINT_ANCHOR_ALTERNATION.containsKey(var5)) {
               var7 = ((Boolean)SPAWN_POINT_ANCHOR_ALTERNATION.get(var5)).booleanValue();
            }

            Vector2f var8 = (Vector2f)PARTICLE_SPAWN_POINT_TURRET.get("default");
            if(var2.getSlot().isHardpoint()) {
               var8 = (Vector2f)PARTICLE_SPAWN_POINT_HARDPOINT.get("default");
               if(PARTICLE_SPAWN_POINT_HARDPOINT.containsKey(var5)) {
                  var8 = (Vector2f)PARTICLE_SPAWN_POINT_HARDPOINT.get(var5);
               }
            } else if(PARTICLE_SPAWN_POINT_TURRET.containsKey(var5)) {
               var8 = (Vector2f)PARTICLE_SPAWN_POINT_TURRET.get(var5);
            }

            String var9 = (String)PARTICLE_TYPE.get("default");
            if(PARTICLE_TYPE.containsKey(var5)) {
               var9 = (String)PARTICLE_TYPE.get(var5);
            }

            Color var10 = (Color)PARTICLE_COLOR.get("default");
            if(PARTICLE_COLOR.containsKey(var5)) {
               var10 = (Color)PARTICLE_COLOR.get(var5);
            }

            float var11 = ((Float)PARTICLE_SIZE_MIN.get("default")).floatValue();
            if(PARTICLE_SIZE_MIN.containsKey(var5)) {
               var11 = ((Float)PARTICLE_SIZE_MIN.get(var5)).floatValue();
            }

            float var12 = ((Float)PARTICLE_SIZE_MAX.get("default")).floatValue();
            if(PARTICLE_SIZE_MAX.containsKey(var5)) {
               var12 = ((Float)PARTICLE_SIZE_MAX.get(var5)).floatValue();
            }

            float var13 = ((Float)PARTICLE_VELOCITY_MIN.get("default")).floatValue();
            if(PARTICLE_VELOCITY_MIN.containsKey(var5)) {
               var13 = ((Float)PARTICLE_VELOCITY_MIN.get(var5)).floatValue();
            }

            float var14 = ((Float)PARTICLE_VELOCITY_MAX.get("default")).floatValue();
            if(PARTICLE_VELOCITY_MAX.containsKey(var5)) {
               var14 = ((Float)PARTICLE_VELOCITY_MAX.get(var5)).floatValue();
            }

            float var15 = ((Float)PARTICLE_DURATION_MIN.get("default")).floatValue();
            if(PARTICLE_DURATION_MIN.containsKey(var5)) {
               var15 = ((Float)PARTICLE_DURATION_MIN.get(var5)).floatValue();
            }

            float var16 = ((Float)PARTICLE_DURATION_MAX.get("default")).floatValue();
            if(PARTICLE_DURATION_MAX.containsKey(var5)) {
               var16 = ((Float)PARTICLE_DURATION_MAX.get(var5)).floatValue();
            }

            float var17 = ((Float)PARTICLE_OFFSET_MIN.get("default")).floatValue();
            if(PARTICLE_OFFSET_MIN.containsKey(var5)) {
               var17 = ((Float)PARTICLE_OFFSET_MIN.get(var5)).floatValue();
            }

            float var18 = ((Float)PARTICLE_OFFSET_MAX.get("default")).floatValue();
            if(PARTICLE_OFFSET_MAX.containsKey(var5)) {
               var18 = ((Float)PARTICLE_OFFSET_MAX.get(var5)).floatValue();
            }

            float var19 = ((Float)PARTICLE_ARC.get("default")).floatValue();
            if(PARTICLE_ARC.containsKey(var5)) {
               var19 = ((Float)PARTICLE_ARC.get(var5)).floatValue();
            }

            float var20 = ((Float)PARTICLE_ARC_FACING.get("default")).floatValue();
            if(PARTICLE_ARC_FACING.containsKey(var5)) {
               var20 = ((Float)PARTICLE_ARC_FACING.get(var5)).floatValue();
            }

            float var21 = (float)((Integer)ON_SHOT_PARTICLE_COUNT.get("default")).intValue();
            if(ON_SHOT_PARTICLE_COUNT.containsKey(var5)) {
               var21 = (float)((Integer)ON_SHOT_PARTICLE_COUNT.get(var5)).intValue();
            }

            if(var21 > 0.0F) {
               this.spawnParticles(var3, var2, var7, var21, var9, var8, var10, var11, var12, var13, var14, var15, var16, var17, var18, var19, var20);
            }
         }
      }

      ++this.currentBarrel;
      int var22 = var2.getSpec().getTurretAngleOffsets().size();
      if(var2.getSlot().isHardpoint()) {
         var22 = var2.getSpec().getHardpointAngleOffsets().size();
      } else if(var2.getSlot().isHidden()) {
         var22 = var2.getSpec().getHiddenAngleOffsets().size();
      }

      if(this.currentBarrel >= var22) {
         this.currentBarrel = 0;
      }

   }

   private void spawnParticles(CombatEngineAPI var1, WeaponAPI var2, boolean var3, float var4, String var5, Vector2f var6, Color var7, float var8, float var9, float var10, float var11, float var12, float var13, float var14, float var15, float var16, float var17) {
      Vector2f var18 = new Vector2f(var6.y, var6.x);
      float var19 = var17;
      if(var3) {
         if(var2.getSlot().isHardpoint()) {
            var18.x += ((Vector2f)var2.getSpec().getHardpointFireOffsets().get(this.currentBarrel)).x;
            var18.y += ((Vector2f)var2.getSpec().getHardpointFireOffsets().get(this.currentBarrel)).y;
            var19 = var17 + ((Float)var2.getSpec().getHardpointAngleOffsets().get(this.currentBarrel)).floatValue();
         } else if(var2.getSlot().isTurret()) {
            var18.x += ((Vector2f)var2.getSpec().getTurretFireOffsets().get(this.currentBarrel)).x;
            var18.y += ((Vector2f)var2.getSpec().getTurretFireOffsets().get(this.currentBarrel)).y;
            var19 = var17 + ((Float)var2.getSpec().getTurretAngleOffsets().get(this.currentBarrel)).floatValue();
         } else {
            var18.x += ((Vector2f)var2.getSpec().getHiddenFireOffsets().get(this.currentBarrel)).x;
            var18.y += ((Vector2f)var2.getSpec().getHiddenFireOffsets().get(this.currentBarrel)).y;
            var19 = var17 + ((Float)var2.getSpec().getHiddenAngleOffsets().get(this.currentBarrel)).floatValue();
         }
      }

      var19 += var2.getCurrAngle();
      var18 = VectorUtils.rotate(var18, var2.getCurrAngle(), new Vector2f(0.0F, 0.0F));
      var18.x += var2.getLocation().x;
      var18.y += var2.getLocation().y;
      float var20 = var4;

      while(Math.random() < (double)var20) {
         --var20;
         float var21 = MathUtils.getRandomNumberInRange(var19 - var16 / 2.0F, var19 + var16 / 2.0F);
         Vector2f var22 = MathUtils.getPointOnCircumference(var2.getShip().getVelocity(), MathUtils.getRandomNumberInRange(var10, var11), var21);
         Vector2f var23 = MathUtils.getPointOnCircumference(var18, MathUtils.getRandomNumberInRange(var14, var15), var21);
         float var24 = MathUtils.getRandomNumberInRange(var12, var13);
         float var25 = MathUtils.getRandomNumberInRange(var8, var9);
         int var26 = MathUtils.getRandomNumberInRange(-10, 10);
         var7 = new Color(clamp255(var7.getRed() + var26), clamp255(var7.getGreen() + var26), clamp255(var7.getBlue() + var26), var7.getAlpha());
         byte var28 = -1;
         switch(var5.hashCode()) {
         case -1996120257:
            if(var5.equals("NEBULA")) {
               var28 = 2;
            }
            break;
         case -1845204562:
            if(var5.equals("SMOOTH")) {
               var28 = 0;
            }
            break;
         case 79024463:
            if(var5.equals("SMOKE")) {
               var28 = 1;
            }
         }

         switch(var28) {
         case 0:
            var1.addSmoothParticle(var23, var22, var25, 1.0F, var24, var7);
            break;
         case 1:
            var1.addSmokeParticle(var23, var22, var25, 1.0F, var24, var7);
            break;
         case 2:
            var1.addNebulaParticle(var23, var22, var25, 1.4F, 0.0F, 0.3F, var24, var7);
            break;
         default:
            var1.addHitParticle(var23, var22, var25, 10.0F, var24, var7);
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {}

   private static int clamp255(int var0) {
      return Math.max(0, Math.min(255, var0));
   }

   static {
      USED_IDS.add("FLASH_ID_1");
      USED_IDS.add("FLASH_ID_2");
      USED_IDS.add("FLASH_ID_3");
      USED_IDS.add("FLASH_ID_4");
      USED_IDS.add("FLASH_ID_5");
      USED_IDS.add("FLASH_ID_6");
      USED_IDS.add("BRIGHT_L");
      USED_IDS.add("BRIGHT_R");
      USED_IDS.add("BRIGHT_C");
      ON_SHOT_PARTICLE_COUNT = new HashMap();
      ON_SHOT_PARTICLE_COUNT.put("default", Integer.valueOf(20));
      ON_SHOT_PARTICLE_COUNT.put("FLASH_ID_3", Integer.valueOf(15));
      ON_SHOT_PARTICLE_COUNT.put("FLASH_ID_4", Integer.valueOf(15));
      ON_SHOT_PARTICLE_COUNT.put("FLASH_ID_6", Integer.valueOf(34));
      ON_SHOT_PARTICLE_COUNT.put("BRIGHT_L", Integer.valueOf(5));
      ON_SHOT_PARTICLE_COUNT.put("BRIGHT_R", Integer.valueOf(5));
      ON_SHOT_PARTICLE_COUNT.put("BRIGHT_C", Integer.valueOf(10));
      SPAWN_POINT_ANCHOR_ALTERNATION = new HashMap();
      SPAWN_POINT_ANCHOR_ALTERNATION.put("default", Boolean.valueOf(true));
      PARTICLE_SPAWN_POINT_TURRET = new HashMap();
      PARTICLE_SPAWN_POINT_TURRET.put("default", new Vector2f(3.0F, -8.0F));
      PARTICLE_SPAWN_POINT_TURRET.put("FLASH_ID_2", new Vector2f(-3.0F, -8.0F));
      PARTICLE_SPAWN_POINT_TURRET.put("FLASH_ID_3", new Vector2f(3.0F, -8.0F));
      PARTICLE_SPAWN_POINT_TURRET.put("FLASH_ID_4", new Vector2f(-3.0F, -8.0F));
      PARTICLE_SPAWN_POINT_TURRET.put("FLASH_ID_5", new Vector2f(0.0F, -4.0F));
      PARTICLE_SPAWN_POINT_TURRET.put("FLASH_ID_6", new Vector2f(0.0F, -4.0F));
      PARTICLE_SPAWN_POINT_TURRET.put("BRIGHT_C", new Vector2f(0.0F, -4.0F));
      PARTICLE_SPAWN_POINT_TURRET.put("BRIGHT_L", new Vector2f(-3.0F, -8.0F));
      PARTICLE_SPAWN_POINT_TURRET.put("BRIGHT_R", new Vector2f(-3.0F, -8.0F));
      PARTICLE_SPAWN_POINT_HARDPOINT = new HashMap();
      PARTICLE_SPAWN_POINT_HARDPOINT.put("default", new Vector2f(3.0F, -8.0F));
      PARTICLE_SPAWN_POINT_HARDPOINT.put("FLASH_ID_2", new Vector2f(-3.0F, -8.0F));
      PARTICLE_SPAWN_POINT_HARDPOINT.put("FLASH_ID_3", new Vector2f(3.0F, -8.0F));
      PARTICLE_SPAWN_POINT_HARDPOINT.put("FLASH_ID_4", new Vector2f(-3.0F, -8.0F));
      PARTICLE_SPAWN_POINT_HARDPOINT.put("FLASH_ID_5", new Vector2f(0.0F, -4.0F));
      PARTICLE_SPAWN_POINT_HARDPOINT.put("FLASH_ID_6", new Vector2f(0.0F, -4.0F));
      PARTICLE_SPAWN_POINT_HARDPOINT.put("BRIGHT_C", new Vector2f(0.0F, -4.0F));
      PARTICLE_SPAWN_POINT_HARDPOINT.put("BRIGHT_L", new Vector2f(-3.0F, -8.0F));
      PARTICLE_SPAWN_POINT_HARDPOINT.put("BRIGHT_R", new Vector2f(-3.0F, -8.0F));
      PARTICLE_TYPE = new HashMap();
      PARTICLE_TYPE.put("default", "NEBULA");
      PARTICLE_TYPE.put("BRIGHT_L", "BRIGHT");
      PARTICLE_TYPE.put("BRIGHT_R", "BRIGHT");
      PARTICLE_TYPE.put("BRIGHT_C", "BRIGHT");
      PARTICLE_COLOR = new HashMap();
      PARTICLE_COLOR.put("default", new Color(110, 100, 100, 100));
      PARTICLE_COLOR.put("BRIGHT_L", new Color(255, 150, 80, 125));
      PARTICLE_COLOR.put("BRIGHT_R", new Color(255, 150, 80, 125));
      PARTICLE_COLOR.put("BRIGHT_C", new Color(255, 150, 80, 125));
      PARTICLE_SIZE_MIN = new HashMap();
      PARTICLE_SIZE_MIN.put("default", Float.valueOf(10.0F));
      PARTICLE_SIZE_MIN.put("FLASH_ID_5", Float.valueOf(15.0F));
      PARTICLE_SIZE_MIN.put("FLASH_ID_6", Float.valueOf(15.0F));
      PARTICLE_SIZE_MAX = new HashMap();
      PARTICLE_SIZE_MAX.put("default", Float.valueOf(25.0F));
      PARTICLE_SIZE_MAX.put("FLASH_ID_5", Float.valueOf(30.0F));
      PARTICLE_SIZE_MAX.put("FLASH_ID_6", Float.valueOf(30.0F));
      PARTICLE_VELOCITY_MIN = new HashMap();
      PARTICLE_VELOCITY_MIN.put("default", Float.valueOf(5.0F));
      PARTICLE_VELOCITY_MIN.put("BRIGHT_L", Float.valueOf(0.0F));
      PARTICLE_VELOCITY_MIN.put("BRIGHT_R", Float.valueOf(0.0F));
      PARTICLE_VELOCITY_MIN.put("BRIGHT_C", Float.valueOf(0.0F));
      PARTICLE_VELOCITY_MAX = new HashMap();
      PARTICLE_VELOCITY_MAX.put("default", Float.valueOf(50.0F));
      PARTICLE_VELOCITY_MAX.put("FLASH_ID_3", Float.valueOf(30.0F));
      PARTICLE_VELOCITY_MAX.put("FLASH_ID_4", Float.valueOf(30.0F));
      PARTICLE_VELOCITY_MAX.put("FLASH_ID_5", Float.valueOf(30.0F));
      PARTICLE_VELOCITY_MAX.put("FLASH_ID_6", Float.valueOf(50.0F));
      PARTICLE_VELOCITY_MAX.put("BRIGHT_L", Float.valueOf(10.0F));
      PARTICLE_VELOCITY_MAX.put("BRIGHT_R", Float.valueOf(10.0F));
      PARTICLE_VELOCITY_MAX.put("BRIGHT_C", Float.valueOf(10.0F));
      PARTICLE_DURATION_MIN = new HashMap();
      PARTICLE_DURATION_MIN.put("default", Float.valueOf(0.8F));
      PARTICLE_DURATION_MIN.put("BRIGHT_L", Float.valueOf(0.2F));
      PARTICLE_DURATION_MIN.put("BRIGHT_R", Float.valueOf(0.2F));
      PARTICLE_DURATION_MIN.put("BRIGHT_C", Float.valueOf(0.2F));
      PARTICLE_DURATION_MAX = new HashMap();
      PARTICLE_DURATION_MAX.put("default", Float.valueOf(1.6F));
      PARTICLE_DURATION_MAX.put("BRIGHT_L", Float.valueOf(0.4F));
      PARTICLE_DURATION_MAX.put("BRIGHT_R", Float.valueOf(0.4F));
      PARTICLE_DURATION_MAX.put("BRIGHT_C", Float.valueOf(0.4F));
      PARTICLE_OFFSET_MIN = new HashMap();
      PARTICLE_OFFSET_MIN.put("default", Float.valueOf(5.0F));
      PARTICLE_OFFSET_MAX = new HashMap();
      PARTICLE_OFFSET_MAX.put("default", Float.valueOf(10.0F));
      PARTICLE_OFFSET_MAX.put("FLASH_ID_5", Float.valueOf(10.0F));
      PARTICLE_OFFSET_MAX.put("FLASH_ID_6", Float.valueOf(60.0F));
      PARTICLE_OFFSET_MAX.put("BRIGHT_C", Float.valueOf(30.0F));
      PARTICLE_ARC = new HashMap();
      PARTICLE_ARC.put("default", Float.valueOf(10.0F));
      PARTICLE_ARC.put("FLASH_ID_3", Float.valueOf(80.0F));
      PARTICLE_ARC.put("FLASH_ID_4", Float.valueOf(80.0F));
      PARTICLE_ARC.put("FLASH_ID_5", Float.valueOf(60.0F));
      PARTICLE_ARC.put("BRIGHT_L", Float.valueOf(0.0F));
      PARTICLE_ARC.put("BRIGHT_R", Float.valueOf(0.0F));
      PARTICLE_ARC.put("BRIGHT_C", Float.valueOf(0.0F));
      PARTICLE_ARC_FACING = new HashMap();
      PARTICLE_ARC_FACING.put("default", Float.valueOf(90.0F));
      PARTICLE_ARC_FACING.put("FLASH_ID_2", Float.valueOf(-90.0F));
      PARTICLE_ARC_FACING.put("FLASH_ID_3", Float.valueOf(90.0F));
      PARTICLE_ARC_FACING.put("FLASH_ID_4", Float.valueOf(-90.0F));
      PARTICLE_ARC_FACING.put("FLASH_ID_5", Float.valueOf(0.0F));
      PARTICLE_ARC_FACING.put("FLASH_ID_6", Float.valueOf(0.0F));
      PARTICLE_ARC_FACING.put("BRIGHT_L", Float.valueOf(-90.0F));
      PARTICLE_ARC_FACING.put("BRIGHT_R", Float.valueOf(90.0F));
      PARTICLE_ARC_FACING.put("BRIGHT_C", Float.valueOf(0.0F));
      PARTICLE_SCREENSPACE_CULL_DISTANCE = new HashMap();
      PARTICLE_SCREENSPACE_CULL_DISTANCE.put("default", Float.valueOf(600.0F));
   }
}
