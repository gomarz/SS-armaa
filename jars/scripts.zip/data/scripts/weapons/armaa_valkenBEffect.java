package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicAnim;

public class armaa_valkenBEffect implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin, OnHitEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private ShipSystemAPI system;
   private ShipAPI ship;
   private SpriteAPI sprite;
   private AnimationAPI anim;
   private AnimationAPI aGlow;
   private AnimationAPI aGlow2;
   private WeaponAPI head;
   private WeaponAPI armL;
   private WeaponAPI armR;
   private WeaponAPI pauldronL;
   private WeaponAPI pauldronR;
   private WeaponAPI torso;
   private WeaponAPI wGlow;
   private WeaponAPI hGlow;
   private WeaponAPI cannon;
   private float delay = 0.1F;
   private float timer = 0.0F;
   private int lastWeaponAmmo = 0;
   private float swingLevel = 0.0F;
   private float swingLevel2 = 0.0F;
   private boolean swinging = false;
   private float reverse = 1.0F;
   private boolean cooldown = false;
   private static final Vector2f ZERO = new Vector2f();
   private IntervalUtil animInterval = new IntervalUtil(0.012F, 0.012F);
   public float TURRET_OFFSET = 30.0F;
   private int limbInit = 0;
   private static final Color MUZZLE_FLASH_COLOR = new Color(100, 200, 255, 50);
   private static final Color MUZZLE_FLASH_COLOR_ALT = new Color(100, 100, 255, 100);
   private static final Color MUZZLE_FLASH_COLOR_GLOW = new Color(255, 255, 255, 50);
   private static final float MUZZLE_FLASH_DURATION = 0.15F;
   private static final float MUZZLE_FLASH_SIZE = 10.0F;
   private float overlap = 0.0F;
   private float heat = 0.0F;
   private float originalRArmPos = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -60.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;


   public void init() {
      this.runOnce = true;
      Iterator var1 = this.ship.getAllWeapons().iterator();

      while(var1.hasNext()) {
         WeaponAPI var2 = (WeaponAPI)var1.next();
         String var3 = var2.getSlot().getId();
         byte var4 = -1;
         switch(var3.hashCode()) {
         case -6931076:
            if(var3.equals("D_PAULDRONL")) {
               var4 = 3;
            }
            break;
         case -6931070:
            if(var3.equals("D_PAULDRONR")) {
               var4 = 4;
            }
            break;
         case 62929954:
            if(var3.equals("A_GUN")) {
               var4 = 6;
            }
            break;
         case 1245480854:
            if(var3.equals("B_TORSO")) {
               var4 = 0;
            }
            break;
         case 2007905292:
            if(var3.equals("C_ARML")) {
               var4 = 1;
            }
            break;
         case 2007905298:
            if(var3.equals("C_ARMR")) {
               var4 = 2;
            }
            break;
         case 2065359258:
            if(var3.equals("E_HEAD")) {
               var4 = 5;
            }
         }

         switch(var4) {
         case 0:
            if(this.torso == null) {
               this.torso = var2;
               ++this.limbInit;
            }
            break;
         case 1:
            if(this.armL == null) {
               this.armL = var2;
               ++this.limbInit;
            }
            break;
         case 2:
            if(this.armR == null) {
               this.armR = var2;
               ++this.limbInit;
               this.originalRArmPos = this.armR.getSprite().getCenterY();
            }
            break;
         case 3:
            if(this.pauldronL == null) {
               this.pauldronL = var2;
               ++this.limbInit;
            }
            break;
         case 4:
            if(this.pauldronR == null) {
               this.pauldronR = var2;
               ++this.limbInit;
            }
            break;
         case 5:
            if(this.head == null) {
               this.head = var2;
               ++this.limbInit;
            }
         case 6:
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.ship = var3.getShip();
      this.sprite = this.ship.getSpriteAPI();
      this.system = this.ship.getSystem();
      this.anim = var3.getAnimation();
      this.init();
      if(this.ship.getEngineController().isAccelerating()) {
         if(this.overlap > 9.9F) {
            this.overlap = 10.0F;
         } else {
            this.overlap = Math.min(10.0F, this.overlap + (10.0F - this.overlap) * var1 * 5.0F);
         }
      } else if(!this.ship.getEngineController().isDecelerating() && !this.ship.getEngineController().isAcceleratingBackwards()) {
         if(Math.abs(this.overlap) < 0.1F) {
            this.overlap = 0.0F;
         } else {
            this.overlap -= this.overlap / 2.0F * var1 * 3.0F;
         }
      } else if(this.overlap < -9.9F) {
         this.overlap = -10.0F;
      } else {
         this.overlap = Math.max(-10.0F, this.overlap + (-10.0F + this.overlap) * var1 * 5.0F);
      }

      float var4 = this.ship.getFacing();
      float var5 = MathUtils.getShortestRotation(var4, var3.getCurrAngle());
      float var6 = 0.0F;
      float var7 = 0.0F;
      float var8 = 0.0F;
      float var9 = 0.0F;
      float var10 = 0.0F;
      if(var3.getChargeLevel() < 1.0F) {
         var6 = MagicAnim.smoothNormalizeRange(var3.getChargeLevel(), 0.25F, 1.0F);
         var7 = MagicAnim.smoothNormalizeRange(var3.getChargeLevel(), 0.25F, 1.0F);
         var10 = MagicAnim.smoothNormalizeRange(var3.getChargeLevel(), 0.0F, 0.25F) * 1.0F * this.reverse;
      } else {
         var6 = 1.0F;
         var7 = 1.0F;
      }

      var8 = 0.0F;
      if((double)var3.getChargeLevel() > 0.33D && var10 > 0.0F) {
         this.reverse = (float)((double)this.reverse - ((double)var1 + 0.08D));
      }

      if(var3.getChargeLevel() <= 0.0F) {
         this.reverse = 1.0F;
      }

      var3.getSprite().setCenterY(this.originalRArmPos - 8.0F * var7 + 8.0F * var10);
      if(this.torso != null) {
         this.torso.setCurrAngle(var4 + var6 * 45.0F + var10 * -45.0F + var5 * 0.3F);
      }

      if(var3.getCooldownRemaining() <= 0.0F && !var3.isFiring()) {
         this.cooldown = false;
      }

      if(var3 != null) {
         var3.setCurrAngle(var3.getCurrAngle() - var6 * -6.428571F * 0.7F + var10 * -45.0F * 0.5F);
      }

      if(var3.getChargeLevel() >= 1.0F) {
         this.swinging = true;
      }

      if(this.swinging && var3.getChargeLevel() <= 0.0F) {
         this.swinging = false;
         this.swingLevel = 0.0F;
         this.cooldown = true;
      }

      if(this.animInterval.intervalElapsed()) {
         this.swingLevel = (float)((double)this.swingLevel - 0.5D);
         this.swingLevel2 = (float)((double)this.swingLevel2 + 0.5D);
      }

      if(this.swingLevel > 9.0F) {
         this.swingLevel = 9.0F;
      }

      if(!this.swinging) {
         this.swingLevel = 0.0F;
      }

      if(this.armR != null) {
         this.armR.setCurrAngle(var3.getCurrAngle() + -25.0F);
      }

      if(this.pauldronR != null) {
         this.pauldronR.setCurrAngle(var4 + var6 * 45.0F + var10 * -45.0F * 0.5F + var5 * 0.75F + -12.5F);
      }

      if(this.armL != null) {
         this.armL.setCurrAngle(var4 + (var5 + -60.0F) * var7 + (this.overlap + var5 * 0.25F) * (1.0F - var7));
      }

      if(this.pauldronL != null) {
         this.pauldronL.setCurrAngle(this.torso.getCurrAngle() + MathUtils.getShortestRotation(this.torso.getCurrAngle(), this.armL.getCurrAngle()) * 0.6F);
      }

      if(this.wGlow != null) {
         this.wGlow.setCurrAngle(var3.getCurrAngle());
      }

      if(this.hGlow != null) {
         this.hGlow.setCurrAngle(this.head.getCurrAngle());
      }

   }

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {}

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      Vector2f var4 = new Vector2f(var2.getLocation());
      Vector2f var5 = new Vector2f(this.TURRET_OFFSET, -15.0F);
      VectorUtils.rotate(var5, var2.getCurrAngle(), var5);
      Vector2f.add(var5, var4, var4);
      float var6 = var2.getCurrAngle();
      Vector2f var7 = var2.getShip().getVelocity();
      var7 = MathUtils.getPointOnCircumference(this.ship.getVelocity(), (float)Math.random() * 20.0F, var2.getCurrAngle() + 90.0F - (float)Math.random() * 180.0F);
      if(Math.random() > 0.75D) {
         var3.spawnExplosion(var4, var7, MUZZLE_FLASH_COLOR_ALT, 5.0F, 0.15F);
      } else {
         var3.spawnExplosion(var4, var7, MUZZLE_FLASH_COLOR, 10.0F, 0.15F);
      }

      var3.addSmoothParticle(var4, var7, 30.0F, 1.0F, 0.3F, MUZZLE_FLASH_COLOR_GLOW);
   }

}
