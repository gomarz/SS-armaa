package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicAnim;

public class armaa_VXEffect implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private ShipSystemAPI system;
   private ShipAPI ship;
   private SpriteAPI sprite;
   private AnimationAPI anim;
   private AnimationAPI aGlow;
   private AnimationAPI aGlow2;
   private WeaponAPI head;
   private WeaponAPI armL;
   private WeaponAPI armR;
   private WeaponAPI pauldronL;
   private WeaponAPI pauldronR;
   private WeaponAPI torso;
   private WeaponAPI vernier;
   private WeaponAPI dummyGun;
   private WeaponAPI realGun;
   private WeaponAPI torsoWep;
   private WeaponAPI lArmWep;
   private WeaponAPI headGlow;
   private final Vector2f ZERO = new Vector2f();
   private float swingLevel = 0.0F;
   private boolean swinging = false;
   private boolean cooldown = false;
   private float swingLevelR = 0.0F;
   private boolean swingingR = false;
   private boolean cooldownR = false;
   private IntervalUtil animInterval = new IntervalUtil(0.012F, 0.012F);
   private float overlap = 0.0F;
   private float heat = 0.0F;
   private float originalRArmPos = 0.0F;
   private float originalArmPos = 0.0F;
   private float originalShoulderPos = 0.0F;
   private float originalRShoulderPos = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -60.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;
   private final float LPAULDRONOFFSET = -5.0F;


   public void init() {
      this.runOnce = true;
      Iterator var1 = this.ship.getAllWeapons().iterator();

      while(var1.hasNext()) {
         WeaponAPI var2 = (WeaponAPI)var1.next();
         String var3 = var2.getSlot().getId();
         byte var4 = -1;
         switch(var3.hashCode()) {
         case -2143743196:
            if(var3.equals("H_GLOW")) {
               var4 = 9;
            }
            break;
         case -1726101283:
            if(var3.equals("WS0001")) {
               var4 = 8;
            }
            break;
         case -1726101280:
            if(var3.equals("WS0004")) {
               var4 = 2;
            }
            break;
         case -1666827537:
            if(var3.equals("TRUE_GUN")) {
               var4 = 1;
            }
            break;
         case -6931076:
            if(var3.equals("D_PAULDRONL")) {
               var4 = 5;
            }
            break;
         case -6931070:
            if(var3.equals("D_PAULDRONR")) {
               var4 = 6;
            }
            break;
         case 62929954:
            if(var3.equals("A_GUN")) {
               var4 = 0;
            }
            break;
         case 2007905292:
            if(var3.equals("C_ARML")) {
               var4 = 3;
            }
            break;
         case 2007905298:
            if(var3.equals("C_ARMR")) {
               var4 = 4;
            }
            break;
         case 2065359258:
            if(var3.equals("E_HEAD")) {
               var4 = 7;
            }
         }

         switch(var4) {
         case 0:
            if(this.dummyGun == null) {
               this.dummyGun = var2;
               this.originalRArmPos = var2.getSprite().getCenterY();
            }
            break;
         case 1:
            if(this.realGun == null) {
               this.realGun = var2;
            }
            break;
         case 2:
            if(this.lArmWep == null) {
               this.lArmWep = var2;
            }
            break;
         case 3:
            if(this.armL == null) {
               this.armL = var2;
               this.originalArmPos = this.armL.getSprite().getCenterY();
            }
            break;
         case 4:
            if(this.armR == null) {
               this.armR = var2;
            }
            break;
         case 5:
            if(this.pauldronL == null) {
               this.pauldronL = var2;
               this.originalShoulderPos = this.pauldronL.getSprite().getCenterY();
            }
            break;
         case 6:
            if(this.pauldronR == null) {
               this.pauldronR = var2;
               this.originalRShoulderPos = this.pauldronL.getSprite().getCenterY();
            }
            break;
         case 7:
            if(this.head == null) {
               this.head = var2;
            }
            break;
         case 8:
            this.torsoWep = var2;
            break;
         case 9:
            this.headGlow = var2;
         }

         if(var2.getAnimation() != null && var2 != this.dummyGun) {
            int var5 = this.ship.getVariant().hasHullMod("armaa_vxSkin_AASV")?1:0;
            if(this.ship.getVariant().hasHullMod("armaa_vxSkin_midline")) {
               var5 = 2;
            }

            if(var2.getAnimation().getNumFrames() > 1) {
               var2.getAnimation().setFrame(var5);
            }
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.ship = var3.getShip();
      this.sprite = this.ship.getSpriteAPI();
      this.system = this.ship.getSystem();
      if(!this.runOnce) {
         this.init();
      }

      if(this.dummyGun != null) {
         if(!var2.isPaused()) {
            if(!this.ship.isAlive() && this.ship.getOwner() > 0) {
               this.head.getSprite().setColor(new Color(0, 0, 0, 0));
               this.dummyGun.getSprite().setColor(new Color(0, 0, 0, 0));
            } else {
               this.anim = this.dummyGun.getAnimation();
               this.ship.syncWeaponDecalsWithArmorDamage();
               float var4 = 0.0F;
               float var5 = 0.0F;
               float var6 = 0.0F;
               float var7 = 0.0F;
               float var8 = this.ship.getFacing();
               float var9 = MathUtils.getShortestRotation(var8, this.dummyGun.getCurrAngle());
               float var10 = MathUtils.getShortestRotation(var8, this.armL.getCurrAngle());
               boolean var11 = false;
               if(this.armL.getSpec().getWeaponId().equals("armaa_aleste_rifle_left") || this.armL.getSpec().getWeaponId().equals("armaa_aleste_grenade_left")) {
                  var11 = true;
               }

               if(this.armL != null && !var11) {
                  if(this.armL.getChargeLevel() < 1.0F) {
                     var4 = MagicAnim.smoothNormalizeRange(this.armL.getChargeLevel(), 0.3F, 0.9F);
                     var5 = MagicAnim.smoothNormalizeRange(this.armL.getChargeLevel(), 0.3F, 1.0F);
                  } else {
                     var4 = 1.0F;
                     var5 = 1.0F;
                  }

                  this.armL.getSprite().setCenterY(this.originalArmPos - 16.0F * var5);
               }

               if(this.armR != null) {
                  this.armR.setCurrAngle(this.dummyGun.getCurrAngle() + -25.0F);
                  if(this.dummyGun.getChargeLevel() < 1.0F) {
                     var6 = MagicAnim.smoothNormalizeRange(this.dummyGun.getChargeLevel(), 0.3F, 0.9F);
                     var7 = MagicAnim.smoothNormalizeRange(this.dummyGun.getChargeLevel(), 0.3F, 1.0F);
                  } else {
                     var6 = 1.0F;
                     var7 = 1.0F;
                  }
               }

               if(this.torsoWep != null && (this.torsoWep.getChargeLevel() != 0.0F || this.ship.getSelectedGroupAPI() == null || this.ship.getSelectedGroupAPI().getActiveWeapon() == this.torsoWep)) {
                  var3.setCurrAngle(this.torsoWep.getCurrAngle());
               } else {
                  var3.setCurrAngle(var8 + var4 * (-45.0F - -45.0F * (this.swingLevel / 9.0F)) + var9 * 0.3F);
               }

               if(this.realGun != null && this.realGun.getCooldown() > 0.0F) {
                  this.dummyGun.getSprite().setCenterY(this.originalRArmPos + 2.0F * this.realGun.getCooldownRemaining() / this.realGun.getCooldown());
                  this.pauldronR.getSprite().setCenterY(this.originalRShoulderPos + 2.0F * this.realGun.getCooldownRemaining() / this.realGun.getCooldown());
               }

               if(this.lArmWep != null && this.lArmWep.getCooldown() > 0.0F) {
                  this.armL.getSprite().setCenterY(this.originalArmPos + 2.0F * this.lArmWep.getCooldownRemaining() / this.lArmWep.getCooldown());
                  this.pauldronL.getSprite().setCenterY(this.originalShoulderPos + 2.0F * this.lArmWep.getCooldownRemaining() / this.lArmWep.getCooldown());
               }

               if(this.pauldronR != null) {
                  this.pauldronR.setCurrAngle(var8 + var4 * (-45.0F - -45.0F * (this.swingLevel / 9.0F)) * 0.5F + var9 * 0.75F + -12.5F);
               }

               if(this.pauldronL != null && this.armL != null) {
                  this.pauldronL.setCurrAngle(var8 + var4 * -45.0F * 0.5F + var10 * 0.75F - -12.5F);
               }

               if(this.headGlow != null) {
                  this.headGlow.setCurrAngle(this.head.getCurrAngle());
                  int var12 = this.ship.getVariant().hasHullMod("armaa_vxSkin_AASV")?1:0;
                  if(this.ship.getVariant().hasHullMod("armaa_vxSkin_midline")) {
                     var12 = 1;
                  }

                  if(this.headGlow.getAnimation().getNumFrames() > 1) {
                     this.headGlow.getAnimation().setFrame(var12);
                  }

                  if(var12 != 0 && var12 != 1) {
                     this.headGlow.getSprite().setColor(new Color(155, 50, 125));
                  } else {
                     this.headGlow.getSprite().setColor(new Color(155, 0, 0, 75));
                  }
               }

            }
         }
      }
   }
}
