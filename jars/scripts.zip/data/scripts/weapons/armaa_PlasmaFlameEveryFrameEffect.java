package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_PlasmaFlameEveryFrameEffect implements EveryFrameWeaponEffectPlugin {

   private static final Color MUZZLE_FLASH_COLOR = new Color(255, 200, 100, 50);
   private static final Color MUZZLE_FLASH_COLOR_ALT = new Color(100, 100, 255, 100);
   private static final Color MUZZLE_FLASH_COLOR_GLOW = new Color(255, 75, 0, 50);
   private static final float MUZZLE_FLASH_DURATION = 0.15F;
   private static final float MUZZLE_FLASH_SIZE = 25.0F;
   private static final Vector2f MUZZLE_OFFSET_HARDPOINT = new Vector2f(37.0F, -4.5F);
   private static final Vector2f MUZZLE_OFFSET_TURRET = new Vector2f(35.0F, -4.5F);
   private int lastWeaponAmmo = 0;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!var2.isPaused()) {
         int var4 = var3.getAmmo();
         if(var4 < this.lastWeaponAmmo) {
            Vector2f var5 = var3.getLocation();
            ShipAPI var6 = var3.getShip();
            float var7 = var3.getCurrAngle();
            Vector2f var8 = new Vector2f(var3.getSlot().isHardpoint()?MUZZLE_OFFSET_HARDPOINT:MUZZLE_OFFSET_TURRET);
            VectorUtils.rotate(var8, var7, var8);
            Vector2f.add(var8, var5, var8);
            if(var4 < this.lastWeaponAmmo) {
               Vector2f var9 = MathUtils.getPointOnCircumference(var6.getVelocity(), (float)Math.random() * 20.0F, var7 + 90.0F - (float)Math.random() * 180.0F);
               if(Math.random() > 0.75D) {
                  var2.spawnExplosion(var8, var9, MUZZLE_FLASH_COLOR_ALT, 12.5F, 0.15F);
               } else {
                  var2.spawnExplosion(var8, var9, MUZZLE_FLASH_COLOR, 25.0F, 0.15F);
               }

               var2.addSmoothParticle(var8, var9, 75.0F, 1.0F, 0.3F, MUZZLE_FLASH_COLOR_GLOW);
            }
         }

         this.lastWeaponAmmo = var4;
      }
   }

}
