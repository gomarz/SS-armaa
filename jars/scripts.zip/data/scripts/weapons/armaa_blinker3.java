package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.FaderUtil;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class armaa_blinker3 implements EveryFrameWeaponEffectPlugin {

   private Color base = null;
   private FaderUtil Sussy = new FaderUtil(1.0F, 1.0F, 1.0F);
   private FaderUtil Pulsating = new FaderUtil(1.0F, 2.0F, 2.0F, true, true);


   public armaa_blinker3() {
      this.Sussy.fadeIn();
      this.Pulsating.fadeIn();
   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!var2.isPaused()) {
         ShipAPI var4 = var3.getShip();
         var3.getSprite().setAdditiveBlend();
         this.Sussy.advance(var1);
         this.Pulsating.advance(var1);
         SpriteAPI var5 = var3.getSprite();
         if(this.base == null) {
            this.base = var5.getColor();
         }

         if(var4.getOriginalOwner() != -1 && var4.isAlive()) {
            if(var4.isAlive() && !var4.getFluxTracker().isOverloaded()) {
               if(var4.getFluxTracker().isVenting()) {
                  this.Sussy.fadeOut();
               } else {
                  this.Sussy.fadeIn();
               }
            }

            float var6 = this.Sussy.getBrightness() * (0.75F + this.Pulsating.getBrightness() * 0.25F);
            if(var4.getFluxTracker().isOverloaded()) {
               var6 = (float)Math.random() * this.Sussy.getBrightness();
            }

            Color var7 = Misc.scaleAlpha(this.base, var6);
            var5.setColor(var7);
         } else {
            var5.setColor(new Color(92, 92, 92, 0));
         }
      }
   }
}
