package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_javelinBeamEffect implements EveryFrameWeaponEffectPlugin {

   private static final Vector2f ZERO = new Vector2f();
   private float CHARGEUP_PARTICLE_ANGLE_SPREAD = 360.0F;
   private float CHARGEUP_PARTICLE_BRIGHTNESS = 0.75F;
   private float CHARGEUP_PARTICLE_DISTANCE_MAX = 150.0F;
   private float CHARGEUP_PARTICLE_DISTANCE_MIN = 70.0F;
   private float CHARGEUP_PARTICLE_DURATION = 0.4F;
   private float CHARGEUP_PARTICLE_SIZE_MAX = 3.0F;
   private float CHARGEUP_PARTICLE_SIZE_MIN = 2.0F;
   public float TURRET_OFFSET = 20.0F;
   private boolean charging = false;
   private boolean cooling = false;
   private boolean firing = false;
   private final IntervalUtil interval = new IntervalUtil(0.015F, 0.015F);
   private final IntervalUtil interval2 = new IntervalUtil(0.075F, 0.075F);
   private float level = 0.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      Vector2f var4;
      if((var2.isPaused() || var3.getShip().getOriginalOwner() == -1) && var3.getChargeLevel() == 1.0F) {
         Vector2f.add(MathUtils.getPoint(new Vector2f(), 6.0F, var3.getCurrAngle() + 180.0F), var3.getShip().getVelocity(), var3.getShip().getVelocity());
         var4 = MathUtils.getPoint(new Vector2f(), (float)MathUtils.getRandomNumberInRange(0, 6), var3.getCurrAngle());
         Vector2f.add(var4, new Vector2f(var3.getShip().getVelocity()), var4);
      }

      var4 = new Vector2f(var3.getLocation());
      Vector2f var5 = new Vector2f(this.TURRET_OFFSET, -0.0F);
      VectorUtils.rotate(var5, var3.getCurrAngle(), var5);
      Vector2f.add(var5, var4, var4);
      float var6 = var3.getCurrAngle();
      Vector2f var7 = var3.getShip().getVelocity();
      float var8;
      Color var9;
      if(var3.isFiring() && var3.getChargeLevel() > 0.0F && var3.getChargeLevel() < 1.0F) {
         var8 = 20.0F + var3.getChargeLevel() * var3.getChargeLevel() * MathUtils.getRandomNumberInRange(25.0F, 75.0F);
         var9 = new Color(255, 0, 255, 255);
         var2.addHitParticle(var4, ZERO, var8 - 10.0F, 0.1F + var3.getChargeLevel() * 0.3F, 0.2F, var9);
         var2.addHitParticle(var4, ZERO, var8 / 2.0F - 10.0F, 0.1F + var3.getChargeLevel() * 0.3F, 0.2F, new Color(255, 255, 255, 255));
      }

      if(this.charging) {
         var8 = 20.0F + var3.getChargeLevel() * var3.getChargeLevel() * MathUtils.getRandomNumberInRange(25.0F, 75.0F);
         var9 = new Color(255, 0, 255, 255);
         if(this.firing && var3.getChargeLevel() < 1.0F) {
            this.charging = false;
            this.cooling = true;
            this.firing = false;
         } else if(var3.getChargeLevel() < 1.0F) {
            this.interval.advance(var1);
            if(this.interval.intervalElapsed()) {
               var2.addHitParticle(var4, ZERO, var8, 0.1F + var3.getChargeLevel() * 0.3F, 0.2F, var9);
               var2.addHitParticle(var4, ZERO, var8 / 2.0F, 0.1F + var3.getChargeLevel() * 0.3F, 0.2F, new Color(255, 255, 255, 255));
               int var10 = 2 + (int)(var3.getChargeLevel() * 25.0F);

               for(int var11 = 0; var11 < var10; ++var11) {
                  float var12 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_DISTANCE_MIN, this.CHARGEUP_PARTICLE_DISTANCE_MAX) * var3.getChargeLevel();
                  float var13 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_SIZE_MIN, this.CHARGEUP_PARTICLE_SIZE_MAX) * var3.getChargeLevel();
                  float var14 = MathUtils.getRandomNumberInRange(-0.5F * this.CHARGEUP_PARTICLE_ANGLE_SPREAD, 0.5F * this.CHARGEUP_PARTICLE_ANGLE_SPREAD);
                  float var15 = 0.75F * var12 / this.CHARGEUP_PARTICLE_DURATION;
                  Vector2f var16 = MathUtils.getPointOnCircumference(var7, var15, var14 + var6 + 180.0F);
                  var2.addHitParticle(var4, var16, var13, this.CHARGEUP_PARTICLE_BRIGHTNESS * Math.min(var3.getChargeLevel() + 0.5F, 1.0F) * MathUtils.getRandomNumberInRange(0.75F, 1.25F), this.CHARGEUP_PARTICLE_DURATION, var9);
               }
            }
         } else {
            this.firing = true;
            var2.addHitParticle(var4, ZERO, var8 - 10.0F, 0.1F + var3.getChargeLevel() * 0.3F, 0.2F, var9);
            var2.addHitParticle(var4, ZERO, var8 / 2.0F - 10.0F, 0.1F + var3.getChargeLevel() * 0.3F, 0.2F, new Color(255, 255, 255, 255));
         }
      } else if(this.cooling) {
         if(var3.getChargeLevel() <= 0.0F) {
            this.cooling = false;
         }
      } else if(var3.getChargeLevel() > this.level) {
         Global.getSoundPlayer().playSound("beamcharge", 1.0F, 0.85F, var4, var3.getShip().getVelocity());
         this.charging = true;
      }

      this.level = var3.getChargeLevel();
   }

}
