package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.lazywizard.lazylib.FastTrig;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class VassDirectedTakeoffBayScript implements EveryFrameWeaponEffectPlugin {

   private static final float MAX_SPEED_BOOST = 25.0F;
   private static final float MAX_FLAT_SPEED = 300.0F;
   private static final float MOVE_DURATION = 0.1F;
   private static final float HELPER_DURATION = 1.0F;
   private static final float HELPER_DECEL_MULT = 4.0F;
   private Map timers = new HashMap();
   private static final float SPAWN_RADIUS = 15.0F;
   private static final float CLEAN_WAIT = 10.0F;
   private float cleanTimer = 0.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      ShipAPI var4 = var3.getShip();
      var4.removeWeaponFromGroups(var3);
      if(var4 != null && !var4.isHulk()) {
         this.cleanTimer += var1;
         if(this.cleanTimer > 10.0F) {
            this.cleanTimer = 0.0F;
            ArrayList var5 = new ArrayList();
            Iterator var6 = this.timers.keySet().iterator();

            ShipAPI var7;
            while(var6.hasNext()) {
               var7 = (ShipAPI)var6.next();
               if(!var2.isEntityInPlay(var7) || var7.isHulk() || var7.isLanding() || var7.isFinishedLanding()) {
                  var5.add(var7);
               }
            }

            var6 = var5.iterator();

            while(var6.hasNext()) {
               var7 = (ShipAPI)var6.next();
               this.timers.remove(var7);
            }
         }

         Iterator var9 = CombatUtils.getShipsWithinRange(var4.getLocation(), var4.getCollisionRadius() * 1.5F).iterator();

         ShipAPI var10;
         while(var9.hasNext()) {
            var10 = (ShipAPI)var9.next();
            if(var2.isEntityInPlay(var10) && !var10.isHulk() && !var10.isLanding() && !var10.isFinishedLanding() && !this.timers.containsKey(var10) && var10.getWing() != null && var10.getWing().getSourceShip() == var4 && var10.getWing().getSource().getWeaponSlot() == var3.getSlot()) {
               Vector2f var11 = MathUtils.getRandomPointInCircle(var3.getLocation(), 15.0F);
               var10.getLocation().x = var11.x;
               var10.getLocation().y = var11.y;
               this.timers.put(var10, Float.valueOf(0.0F));
            }
         }

         var9 = this.timers.keySet().iterator();

         while(var9.hasNext()) {
            var10 = (ShipAPI)var9.next();
            float var12 = var1 * var10.getMutableStats().getTimeMult().getModifiedValue() / var4.getMutableStats().getTimeMult().getModifiedValue();
            this.timers.put(var10, Float.valueOf(((Float)this.timers.get(var10)).floatValue() + var12));
            if(((Float)this.timers.get(var10)).floatValue() < 0.1F) {
               float var8 = 1.0F + 25.0F * (float)Math.pow((double)(1.0F - ((Float)this.timers.get(var10)).floatValue() / 0.1F), 2.0D);
               if(var10.getMaxSpeed() * var8 > 300.0F) {
                  var8 = 300.0F / var10.getMaxSpeed();
               }

               var10.setFacing(var3.getCurrAngle());
               var10.getVelocity().x = var10.getMaxSpeed() * (float)FastTrig.cos(Math.toRadians((double)var3.getCurrAngle())) * var8;
               var10.getVelocity().y = var10.getMaxSpeed() * (float)FastTrig.sin(Math.toRadians((double)var3.getCurrAngle())) * var8;
            } else if(((Float)this.timers.get(var10)).floatValue() < 1.0F) {
               var10.getMutableStats().getDeceleration().modifyMult("VASS_DIRECTED_TAKEOFF_BAY_DECEL_BONUS", 4.0F);
               var10.getMutableStats().getAcceleration().modifyMult("VASS_DIRECTED_TAKEOFF_BAY_DECEL_BONUS", 4.0F);
            } else {
               var10.getMutableStats().getDeceleration().unmodify("VASS_DIRECTED_TAKEOFF_BAY_DECEL_BONUS");
               var10.getMutableStats().getAcceleration().unmodify("VASS_DIRECTED_TAKEOFF_BAY_DECEL_BONUS");
            }
         }

      }
   }
}
