package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import data.scripts.weapons.armaa_BoomerangShieldGuidance;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_BoomerangShieldEffect2 implements OnHitEffectPlugin {

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      ShipAPI var7 = var1.getSource();
      if(var7 != null) {
         float var8 = VectorUtils.getAngle(var3, var7.getLocation());
         WeaponAPI var9 = var1.getWeapon();
         DamagingProjectileAPI var10 = (DamagingProjectileAPI)var6.spawnProjectile(var7, var9, var9.getId() + "_copy_copy", MathUtils.getPointOnCircumference(var3, 10.0F, var8), var8, var2.getVelocity());
         var6.addPlugin(new armaa_BoomerangShieldGuidance(var10, var2));
      }
   }
}
