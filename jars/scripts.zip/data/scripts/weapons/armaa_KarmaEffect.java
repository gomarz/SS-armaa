package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ViewportAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector2f;

public class armaa_KarmaEffect implements EveryFrameWeaponEffectPlugin {

   private static final float[] COLOR_NORMAL = new float[]{1.0F, 0.39215687F, 0.078431375F};
   private static final float MAX_JITTER_DISTANCE = 0.2F;
   private static final float MAX_OPACITY = 1.0F;
   private static float EFFECT_RANGE = 600.0F;
   public static final float ROTATION_SPEED = 5.0F;
   public static final Color COLOR = new Color(100, 155, 225, 166);
   private float rotation = 0.0F;
   private float opacity = 0.0F;
   private SpriteAPI sprite = Global.getSettings().getSprite("misc", "wormhole_ring");
   private IntervalUtil interval = new IntervalUtil(0.05F, 0.1F);


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(var2 != null && var2.isUIShowingHUD() && !var2.isUIShowingDialog() && !var2.getCombatUI().isShowingCommandUI()) {
         ShipAPI var4 = var3.getShip();
         if(var4 != null) {
            boolean var5 = var4 == var2.getPlayerShip();
            if(!var4.getSystem().isActive() && var5 && !var4.isHulk() && !var4.isPiece() && var4.isAlive() && !var4.getSystem().isOutOfAmmo()) {
               this.opacity = Math.min(1.0F, this.opacity + 4.0F * var1);
            } else {
               this.opacity = Math.max(0.0F, this.opacity - 2.0F * var1);
            }

            Vector2f var6 = var4.getLocation();
            ViewportAPI var7 = Global.getCombatEngine().getViewport();
            if(var7.isNearViewport(var6, EFFECT_RANGE)) {
               GL11.glPushAttrib(8192);
               GL11.glMatrixMode(5889);
               GL11.glPushMatrix();
               GL11.glViewport(0, 0, Display.getWidth(), Display.getHeight());
               GL11.glOrtho(0.0D, (double)Display.getWidth(), 0.0D, (double)Display.getHeight(), -1.0D, 1.0D);
               GL11.glEnable(3553);
               GL11.glEnable(3042);
               float var8 = Global.getSettings().getScreenScaleMult();
               float var9 = var4.getMutableStats().getSystemRangeBonus().computeEffective(EFFECT_RANGE);
               if(var4.isFrigate() || var4.isDestroyer()) {
                  var9 = (float)((double)var9 * 0.75D);
               }

               float var10 = (var9 + var4.getCollisionRadius()) * 2.0F * var8 / var7.getViewMult();
               this.sprite.setSize(var10, var10);
               this.sprite.setColor(COLOR);
               this.sprite.setAdditiveBlend();
               this.sprite.setAlphaMult(0.4F * this.opacity);
               this.sprite.renderAtCenter(var7.convertWorldXtoScreenX(var6.x) * var8, var7.convertWorldYtoScreenY(var6.y) * var8);
               this.sprite.setAngle(this.rotation);
               GL11.glPopMatrix();
               GL11.glPopAttrib();
            }

            if(!Global.getCombatEngine().isPaused()) {
               this.rotation += 5.0F * var1;
               if(this.rotation > 360.0F) {
                  this.rotation -= 360.0F;
               }

            }
         }
      }
   }

}
