package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.Iterator;

public class armaa_headTracker implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private WeaponAPI lArm;
   private WeaponAPI rArm;
   public int frame = 7;
   private final IntervalUtil interval = new IntervalUtil(0.06F, 0.06F);


   public void init(WeaponAPI var1) {
      this.runOnce = true;
      Iterator var2 = var1.getShip().getAllWeapons().iterator();

      while(var2.hasNext()) {
         WeaponAPI var3 = (WeaponAPI)var2.next();
         String var4 = var3.getSlot().getId();
         byte var5 = -1;
         switch(var4.hashCode()) {
         case 1950828624:
            if(var4.equals("A_GUN2")) {
               var5 = 2;
            }
            break;
         case 2065475114:
            if(var4.equals("E_LARM")) {
               var5 = 0;
            }
            break;
         case 2065653860:
            if(var4.equals("E_RARM")) {
               var5 = 1;
            }
         }

         switch(var5) {
         case 0:
            if(this.lArm == null) {
               this.lArm = var3;
            }
            break;
         case 1:
            if(this.rArm == null) {
               this.rArm = var3;
            }
            break;
         case 2:
            if(this.rArm == null) {
               this.rArm = var3;
            }
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!this.runOnce) {
         this.init(var3);
      }

      ShipAPI var4 = var3.getShip();
      if(var4.getSelectedGroupAPI() != null) {
         float var5 = this.lArm.isDecorative()?this.rArm.getCurrAngle():this.lArm.getCurrAngle();
         if(var3.getCurrAngle() != var5) {
            if(var5 > var3.getCurrAngle()) {
               var3.setCurrAngle(var3.getCurrAngle() + 0.8F);
            } else {
               var3.setCurrAngle(var3.getCurrAngle() - 0.8F);
            }
         }

      }
   }
}
