package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_valkazard_machinegunEffect implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin, OnHitEffectPlugin {

   private int lastAmmo = 0;
   private boolean soundPlayed = false;
   private boolean windingUp = true;
   private IntervalUtil cockSound = new IntervalUtil(0.33F, 0.38F);
   private IntervalUtil reloadTime = new IntervalUtil(2.8F, 2.85F);
   private DamagingProjectileAPI dummy;
   private final Color PARTICLE_COLOR = new Color(200, 200, 200);
   private final float PARTICLE_SIZE = 3.0F;
   private final float PARTICLE_BRIGHTNESS = 150.0F;
   private final float PARTICLE_DURATION = 1.0F;
   private static final int PARTICLE_COUNT = 2;
   private final float EXPLOSION_SIZE = 15.0F;
   private final Color EXPLOSION_COLOR = new Color(200, 200, 200);
   private final float FLASH_SIZE = 5.0F;
   private final Color FLASH_COLOR = new Color(255, 255, 255);
   private final float GLOW_SIZE = 10.0F;
   private static final float CONE_ANGLE = 150.0F;
   private static final float A_2 = 75.0F;
   private static final float VEL_MIN = 0.5F;
   private static final float VEL_MAX = 1.0F;
   private static final Color MUZZLE_FLASH_COLOR = new Color(100, 255, 150, 255);
   private static final Color MUZZLE_FLASH_COLOR_ALT = new Color(150, 255, 200, 100);
   private static final Color MUZZLE_FLASH_COLOR_GLOW = new Color(0, 255, 255, 50);
   private static final float MUZZLE_FLASH_DURATION = 0.15F;
   private static final float MUZZLE_FLASH_SIZE = 5.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {}

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      if(MagicRender.screenCheck(0.1F, var3)) {
         var6.addSmoothParticle(var3, new Vector2f(), 50.0F, 0.8F, 0.25F, new Color(200, 55, 200, 255));
         var6.addHitParticle(var3, new Vector2f(), 10.0F + (float)Math.random() * 5.0F, 1.0F, 0.1F, this.PARTICLE_COLOR);
         float var7 = 300.0F;
         float var8 = var1.getFacing();

         for(int var9 = 0; var9 <= 2; ++var9) {
            float var10 = MathUtils.getRandomNumberInRange(var8 - 75.0F, var8 + 75.0F);
            float var11 = MathUtils.getRandomNumberInRange(var7 * -0.5F, var7 * -1.0F);
            Vector2f var12 = MathUtils.getPointOnCircumference((Vector2f)null, var11, var10);
            var6.addHitParticle(var3, var12, 3.0F, 150.0F, 1.0F, this.PARTICLE_COLOR);
         }
      }

   }

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      ShipAPI var4 = var2.getShip();
      Object var5 = null;
      if(MagicRender.screenCheck(0.2F, var1.getLocation())) {
         var3.addSmoothParticle(var1.getLocation(), var2.getShip().getVelocity(), 75.0F, 0.5F, 0.1F, MUZZLE_FLASH_COLOR_GLOW);
         var3.addHitParticle(var1.getLocation(), var2.getShip().getVelocity(), 50.0F, 0.5F, 0.1F, Color.white);

         for(int var6 = 0; var6 < 4; ++var6) {
            var3.addHitParticle(var1.getLocation(), MathUtils.getPointOnCircumference(var2.getShip().getVelocity(), MathUtils.getRandomNumberInRange(100.0F, 200.0F), MathUtils.getRandomNumberInRange(var1.getFacing() - 45.0F, var1.getFacing() + 45.0F)), 6.0F, 1.0F, MathUtils.getRandomNumberInRange(0.1F, 0.6F), MUZZLE_FLASH_COLOR);
         }
      }

      if(Math.random() > 0.75D) {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 0.5F, 0.15F);
      } else {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 5.0F, 0.15F);
      }

      var3.addSmoothParticle(var1.getLocation(), var1.getVelocity(), 10.0F, 1.0F, 0.3F, MUZZLE_FLASH_COLOR_GLOW);
   }

}
