package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.Iterator;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_legAnimLarge implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private WeaponAPI torso;
   private WeaponAPI rShould;
   private WeaponAPI lShould;
   private WeaponAPI lTurret;
   private WeaponAPI rTurret;
   public int frame = 7;
   private IntervalUtil interval = new IntervalUtil(0.08F, 0.08F);
   private IntervalUtil interval2;
   private Color ogColor;


   public void init(WeaponAPI var1, float var2) {
      this.runOnce = true;
      Iterator var3 = var1.getShip().getAllWeapons().iterator();

      while(var3.hasNext()) {
         WeaponAPI var4 = (WeaponAPI)var3.next();
         String var5 = var4.getSlot().getId();
         byte var6 = -1;
         switch(var5.hashCode()) {
         case -1739718670:
            if(var5.equals("RSHOULDER")) {
               var6 = 2;
            }
            break;
         case -1726101282:
            if(var5.equals("WS0002")) {
               var6 = 0;
            }
            break;
         case -1726101280:
            if(var5.equals("WS0004")) {
               var6 = 4;
            }
            break;
         case -1726101279:
            if(var5.equals("WS0005")) {
               var6 = 3;
            }
            break;
         case 515073516:
            if(var5.equals("LSHOULDER")) {
               var6 = 1;
            }
         }

         switch(var6) {
         case 0:
            if(this.torso == null) {
               this.torso = var4;
            }
            break;
         case 1:
            if(this.lShould == null) {
               this.lShould = var4;
            }
            break;
         case 2:
            if(this.rShould == null) {
               this.rShould = var4;
            }
            break;
         case 3:
            if(this.lTurret == null) {
               this.lTurret = var4;
            }
            break;
         case 4:
            if(this.rTurret == null) {
               this.rTurret = var4;
            }
         }
      }

      this.ogColor = new Color((float)var1.getSprite().getColor().getRed() / 255.0F, (float)var1.getSprite().getColor().getGreen() / 255.0F, (float)var1.getSprite().getColor().getBlue() / 255.0F);
      this.interval2 = new IntervalUtil(var2, var2);
   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      ShipAPI var4 = var3.getShip();
      var3.getSprite().setColor(new Color(0.0F, 0.0F, 0.0F, 0.0F));
      if(var4.getOwner() == -1) {
         var3.getAnimation().setFrame(6);
      } else if(Global.getCombatEngine().isEntityInPlay(var3.getShip())) {
         if(MagicRender.screenCheck(0.1F, var3.getLocation()) && !Global.getCombatEngine().isPaused()) {
            if(!this.runOnce) {
               this.init(var3, var1);
            }

            Color var5 = var4.getSpriteAPI().getAverageColor();
            this.interval.advance(var1);
            if(!var4.getEngineController().isAcceleratingBackwards() && !var4.getEngineController().isDecelerating()) {
               if(var4.getEngineController().isAccelerating()) {
                  if(this.interval.intervalElapsed() && this.frame != 11) {
                     ++this.frame;
                  }

                  if(this.frame > 11) {
                     this.frame = 11;
                  }
               } else if(this.interval.intervalElapsed()) {
                  if(this.frame > 6) {
                     --this.frame;
                  } else if(this.frame != 6) {
                     ++this.frame;
                  }
               }
            } else {
               if(this.interval.intervalElapsed() && this.frame != 0) {
                  --this.frame;
               }

               if(this.frame < 0) {
                  this.frame = 0;
               }
            }

            String var6 = "0" + this.frame;
            if(this.frame >= 10) {
               var6 = this.frame + "";
            }

            SpriteAPI var7 = Global.getSettings().getSprite("graphics/armaa/ships/legs/destroyer/armaa_dd_legs" + var6 + ".png");
            if(var4.getHullSpec().getHullId().equals("armaa_kshatriya")) {
               var7 = Global.getSettings().getSprite("graphics/armaa/ships/legs/destroyer/kshatriya/armaa_dd_legs" + var6 + ".png");
            } else if(var4.getHullSpec().getHullId().equals("armaa_zanac_grey") || var4.getHullSpec().getDParentHullId() != null && var4.getHullSpec().getDParentHullId().equals("armaa_zanac_grey")) {
               var7 = Global.getSettings().getSprite("graphics/armaa/ships/legs/destroyer/grey/armaa_dd_legs" + var6 + ".png");
            }

            new Color(var5.getRed() * 2, var5.getGreen() * 2, var5.getBlue() * 2, var5.getAlpha());
            Color var8 = new Color(255, 255, 255);
            var8 = new Color((float)var8.getRed() / 255.0F, (float)var8.getGreen() / 255.0F, (float)var8.getBlue() / 255.0F, (float)var8.getAlpha() / 255.0F * var4.getCombinedAlphaMult());
            MagicRender.singleframe(var7, new Vector2f(var3.getLocation().getX(), var3.getLocation().getY()), new Vector2f(var7.getWidth(), var7.getHeight()), var4.getFacing() - 90.0F, var8, false, CombatEngineLayers.BELOW_SHIPS_LAYER);
         }
      }
   }
}
