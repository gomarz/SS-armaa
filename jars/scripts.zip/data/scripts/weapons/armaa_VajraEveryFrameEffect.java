package data.scripts.weapons;

import com.fs.starfarer.api.combat.BaseCombatLayeredRenderingPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.weapons.armaa_vajraProjectileScript;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_VajraEveryFrameEffect extends BaseCombatLayeredRenderingPlugin implements OnFireEffectPlugin, OnHitEffectPlugin, EveryFrameWeaponEffectPlugin {

   private int lastAmmo = 0;
   private boolean soundPlayed = false;
   private boolean windingUp = true;
   private IntervalUtil cockSound = new IntervalUtil(0.33F, 0.38F);
   private IntervalUtil reloadTime = new IntervalUtil(2.8F, 2.85F);
   private DamagingProjectileAPI dummy;
   private List alreadyRegisteredProjectiles = new ArrayList();
   private static final Color MUZZLE_FLASH_COLOR = new Color(250, 146, 0, 255);
   private static final Color MUZZLE_FLASH_COLOR_ALT = new Color(255, 255, 255, 100);
   private static final Color MUZZLE_FLASH_COLOR_GLOW = new Color(255, 0, 0, 50);
   private static final float MUZZLE_FLASH_DURATION = 0.2F;
   private static final float MUZZLE_FLASH_SIZE = 50.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {}

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {}

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      ShipAPI var4 = var2.getShip();
      ShipAPI var5 = null;
      if(MagicRender.screenCheck(0.2F, var1.getLocation())) {
         var3.addSmoothParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 75.0F, 2.0F, 0.1F, Color.white);
         var3.addSmoothParticle(var1.getLocation(), new Vector2f(), 100.0F, 0.5F, 0.1F, MUZZLE_FLASH_COLOR_GLOW);
         var3.addHitParticle(var1.getLocation(), new Vector2f(), 75.0F, 0.5F, 0.25F, MUZZLE_FLASH_COLOR);

         for(int var6 = 0; var6 < 5; ++var6) {
            var3.addHitParticle(var1.getLocation(), MathUtils.getPointOnCircumference((Vector2f)null, MathUtils.getRandomNumberInRange(100.0F, 150.0F), (float)Math.random() * 360.0F), 5.0F, 1.0F, MathUtils.getRandomNumberInRange(0.6F, 1.0F), MUZZLE_FLASH_COLOR);
         }
      }

      if(Math.random() > 0.75D) {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 5.0F, 0.2F);
      } else {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 50.0F, 0.2F);
      }

      var3.addSmoothParticle(var1.getLocation(), var1.getVelocity(), 150.0F, 1.0F, 0.4F, MUZZLE_FLASH_COLOR_GLOW);
      if(var4.getWeaponGroupFor(var2) != null) {
         if(var4.getWeaponGroupFor(var2).isAutofiring() && var4.getSelectedGroupAPI() != var4.getWeaponGroupFor(var2)) {
            var5 = var4.getWeaponGroupFor(var2).getAutofirePlugin(var2).getTargetShip();
         } else {
            var5 = var4.getShipTarget();
         }
      }

      if(var1.getWeapon() == var2 && !this.alreadyRegisteredProjectiles.contains(var1) && var3.isEntityInPlay(var1) && !var1.didDamage()) {
         var3.addPlugin(new armaa_vajraProjectileScript(var1, var5));
         this.alreadyRegisteredProjectiles.add(var1);
      }

      ArrayList var9 = new ArrayList(this.alreadyRegisteredProjectiles);
      Iterator var7 = var9.iterator();

      while(var7.hasNext()) {
         DamagingProjectileAPI var8 = (DamagingProjectileAPI)var7.next();
         if(!var3.isEntityInPlay(var8) || var8.didDamage()) {
            this.alreadyRegisteredProjectiles.remove(var8);
         }
      }

   }

}
