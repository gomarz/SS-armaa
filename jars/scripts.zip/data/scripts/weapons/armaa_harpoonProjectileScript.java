package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.util.MagicFakeBeam;
import data.scripts.util.MagicRender;
import java.awt.Color;
import java.util.List;
import org.jetbrains.annotations.NotNull;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_harpoonProjectileScript extends BaseEveryFrameCombatPlugin {

   private MissileAPI proj;
   private CombatEntityAPI target;
   private CombatEntityAPI source;
   private float id;
   private IntervalUtil fireInterval = new IntervalUtil(0.05F, 0.1F);
   private static final float AT_MAX_RANGE = 0.5F;
   private static final float PUSH_CONSTANT = 2000.0F;
   private static final float MISSILE_SCALAR = 0.2F;


   public armaa_harpoonProjectileScript(@NotNull DamagingProjectileAPI var1, CombatEntityAPI var2, CombatEntityAPI var3) {
      this.proj = (MissileAPI)var1;
      this.target = var3;
      this.source = var2;
   }

   public void advance(float var1, List var2) {
      if(Global.getCombatEngine() != null) {
         if(!Global.getCombatEngine().isPaused()) {
            if(this.proj != null && !this.proj.didDamage() && !this.proj.isFizzling() && Global.getCombatEngine().isEntityInPlay(this.proj)) {
               float var3 = ((ShipAPI)this.source).getMassWithModules();
               float var4 = ((Vector2f)this.proj.getWeapon().getSpec().getTurretFireOffsets().get(0)).x;
               float var5 = ((Vector2f)this.proj.getWeapon().getSpec().getTurretFireOffsets().get(0)).y;
               Vector2f var6 = new Vector2f(this.proj.getWeapon().getLocation());
               Vector2f var7 = new Vector2f(var4, var5);
               VectorUtils.rotate(var7, this.proj.getWeapon().getCurrAngle(), var7);
               Vector2f.add(var7, var6, var6);
               if(MagicRender.screenCheck(0.2F, this.proj.getLocation())) {
                  MagicFakeBeam.spawnFakeBeam(Global.getCombatEngine(), var6, MathUtils.getDistance(this.proj, var6), VectorUtils.getAngle(var6, new Vector2f(this.proj.getLocation().getX(), this.proj.getLocation().getY())), 8.0F, var1, var1, 0.0F, new Color(100, 100, 100, 200), new Color(15, 15, 15, 255), 0.0F, DamageType.ENERGY, 0.0F, this.proj.getSource());
               }

               this.fireInterval.advance(0.05F);
               if(this.fireInterval.intervalElapsed()) {
                  float var8;
                  float var11;
                  if(this.target instanceof ShipAPI) {
                     if(((ShipAPI)this.target).getParentStation() != null && ((ShipAPI)this.target).isAlive()) {
                        this.target = ((ShipAPI)this.target).getParentStation();
                     }

                     var8 = ((ShipAPI)this.target).getMassWithModules();
                     if(Math.random() > 0.800000011920929D) {
                        Global.getCombatEngine().spawnEmpArcVisual(var6, this.source, this.proj.getLocation(), this.proj, 0.5F, new Color(255, 150, 255, 200), new Color(255, 175, 255, 255));
                        float var10 = this.proj.getWeapon().getDamage().getDamage() * 0.4F;
                        var11 = this.proj.getWeapon().getDamage().getFluxComponent() * 0.5F;
                        Global.getCombatEngine().spawnEmpArc((ShipAPI)this.source, this.proj.getLocation(), this.target, this.target, DamageType.ENERGY, var10, var10, 10000.0F, "system_emp_emitter_impact", 2.0F, new Color(255, 150, 255, 200), new Color(255, 175, 255, 255));
                     }
                  } else if(this.target instanceof MissileAPI) {
                     var8 = this.target.getMass() * 0.2F;
                  } else {
                     var8 = this.target.getMass();
                  }

                  if(var8 == 0.0F) {
                     var8 = 1.0F;
                  }

                  float var9 = 1.0F;
                  Vector2f var17 = Vector2f.sub(var6, this.proj.getLocation(), new Vector2f());
                  var11 = var17.length();
                  if(var11 > this.proj.getWeapon().getRange()) {
                     Global.getCombatEngine().removePlugin(this);
                     return;
                  }

                  if(var17.lengthSquared() > 0.0F) {
                     var17.normalise();
                  }

                  float var12 = var3 / (var3 + var8);
                  float var13 = 2000.0F / var3 * (1.0F - var12);
                  float var14 = 2000.0F / var8 * var12;
                  float var15 = 1.0F - var11 / 600.0F * 0.5F;
                  if(var11 > 150.0F) {
                     Vector2f var16 = new Vector2f(var17);
                     Vector2f.add((Vector2f)var17.scale(var13 * var9 * var15 * -1.0F), this.source.getVelocity(), this.source.getVelocity());
                     Vector2f.add((Vector2f)var16.scale(var14 * var9 * var15), this.target.getVelocity(), this.target.getVelocity());
                  }
               }

            } else {
               Global.getCombatEngine().removePlugin(this);
            }
         }
      }
   }
}
