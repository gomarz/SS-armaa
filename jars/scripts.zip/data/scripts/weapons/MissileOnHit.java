package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;

public class MissileOnHit implements OnHitEffectPlugin {

   private final Color EXPLOSION_COLOR = new Color(255, 120, 255, 255);


   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, CombatEngineAPI var5) {
      Vector2f var6 = new Vector2f(var2.getVelocity());
      var5.spawnExplosion(var3, var6, this.EXPLOSION_COLOR, 75.0F, 0.55F);
   }
}
