package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.ArmorGridAPI;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.impl.combat.DisintegratorEffect;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import org.lwjgl.util.vector.Vector2f;

public class armaa_BarrettaOnHitEffect implements OnHitEffectPlugin {

   public static float DAMAGE = 200.0F;


   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      if(!var4 && var2 instanceof ShipAPI) {
         dealArmorDamage(var1, (ShipAPI)var2, var3);
         var6.spawnExplosion(var1.getLocation(), var2.getVelocity(), new Color(255, 120, 190, 20), 120.0F, 0.2F);
      }

   }

   public static void dealArmorDamage(DamagingProjectileAPI var0, ShipAPI var1, Vector2f var2) {
      CombatEngineAPI var3 = Global.getCombatEngine();
      ArmorGridAPI var4 = var1.getArmorGrid();
      int[] var5 = var4.getCellAtLocation(var2);
      if(var5 != null) {
         int var6 = var4.getGrid().length;
         int var7 = var4.getGrid()[0].length;
         float var8 = DisintegratorEffect.getDamageTypeMult(var0.getSource(), var1);
         float var9 = 0.0F;

         for(int var10 = -2; var10 <= 2; ++var10) {
            for(int var11 = -2; var11 <= 2; ++var11) {
               if(var10 != 2 && var10 != -2 || var11 != 2 && var11 != -2) {
                  int var12 = var5[0] + var10;
                  int var13 = var5[1] + var11;
                  if(var12 >= 0 && var12 < var6 && var13 >= 0 && var13 < var7) {
                     float var14 = 0.033333335F;
                     if(var10 == 0 && var11 == 0) {
                        var14 = 0.06666667F;
                     } else if(var10 <= 1 && var10 >= -1 && var11 <= 1 && var11 >= -1) {
                        var14 = 0.06666667F;
                     } else {
                        var14 = 0.033333335F;
                     }

                     float var15 = var4.getArmorValue(var12, var13);
                     float var16 = DAMAGE * var14 * var8;
                     var16 = Math.min(var16, var15);
                     if(var16 > 0.0F) {
                        var1.getArmorGrid().setArmorValue(var12, var13, Math.max(0.0F, var15 - var16));
                        var9 += var16;
                     }
                  }
               }
            }
         }

         if(var9 > 0.0F) {
            if(Misc.shouldShowDamageFloaty(var0.getSource(), var1)) {
               var3.addFloatingDamageText(var2, var9, Misc.FLOATY_ARMOR_DAMAGE_COLOR, var1, var0.getSource());
            }

            var1.syncWithArmorGridState();
         }

      }
   }

}
