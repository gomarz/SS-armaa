package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_valkazardShotgunEveryFrameEffect implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin, OnHitEffectPlugin {

   public static final int SHOTS = 7;
   public static final float SPREAD = 8.0F;
   public static final float SPREAD_EXTRA_PROJS = 10.0F;
   public static final float PUSH_CONSTANT = 12800.0F;
   private int lastAmmo = 0;
   private boolean init = false;
   private boolean reloading = true;
   private IntervalUtil cockSound = new IntervalUtil(0.33F, 0.38F);
   private IntervalUtil reloadTime = new IntervalUtil(2.8F, 2.85F);
   private DamagingProjectileAPI dummy;
   private List registeredProjectiles = new ArrayList();
   private static final Color MUZZLE_FLASH_COLOR = new Color(255, 200, 100, 50);
   private static final Color MUZZLE_FLASH_COLOR_ALT = new Color(255, 255, 255, 100);
   private static final Color MUZZLE_FLASH_COLOR_GLOW = new Color(255, 75, 0, 50);
   private static final float MUZZLE_FLASH_DURATION = 0.1F;
   private static final float MUZZLE_FLASH_SIZE = 15.0F;
   private final Color PARTICLE_COLOR = new Color(255, 0, 255);
   private final float PARTICLE_SIZE = 3.0F;
   private final float PARTICLE_BRIGHTNESS = 150.0F;
   private final float PARTICLE_DURATION = 1.0F;
   private static final int PARTICLE_COUNT = 1;
   private final int max = 40;
   private final int min = 10;
   private final Color EMP_COLOR = new Color(250, 150, 250);
   private static final float VEL_MIN = 0.1F;
   private static final float VEL_MAX = 0.15F;
   private static final float CONE_ANGLE = 150.0F;
   private static final float A_2 = 75.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!this.init) {
         this.init = true;
         this.lastAmmo = var3.getAmmo();
      }

      if(var3.getAmmo() > 0) {
         this.reloading = true;
      } else {
         this.reloadTime.setElapsed(0.0F);
      }

      if(this.lastAmmo == 0 && var3.getAmmo() > 0) {
         var3.setRemainingCooldownTo(1.0F);
      }

      this.lastAmmo = var3.getAmmo();
      if(this.reloading) {
         this.cockSound.advance(var1);
         if(this.cockSound.intervalElapsed()) {
            this.reloading = false;
         }
      }

   }

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      if(Math.random() > 0.75D) {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 1.5F, 0.1F);
      } else {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 15.0F, 0.1F);
      }

      var3.addSmoothParticle(var1.getLocation(), var1.getVelocity(), 45.0F, 1.0F, 0.2F, MUZZLE_FLASH_COLOR_GLOW);

      for(int var4 = 0; var4 < 7; ++var4) {
         float var5 = (float)Math.random() * 8.0F - (float)Math.random() * 8.0F;
         float var6 = var2.getCurrAngle() + var5;
         String var7 = "armaa_valkazard_shotgun";
         Vector2f var8 = (Vector2f)var2.getSpec().getTurretFireOffsets().get(0);
         DamagingProjectileAPI var9 = (DamagingProjectileAPI)var3.spawnProjectile(var2.getShip(), var2, var7, var1.getLocation(), var6, var2.getShip().getVelocity());
         float var10 = (float)Math.random() * 0.4F + 0.8F;
         var9.getVelocity().scale(var10);
      }

      Global.getCombatEngine().removeEntity(var1);
   }

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      if(MagicRender.screenCheck(0.2F, var3)) {
         var6.addSmoothParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 60.0F, 2.0F, 0.1F, Color.white);
         var6.addHitParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 50.0F, 1.0F, 0.4F, MUZZLE_FLASH_COLOR_GLOW);
         var6.spawnExplosion(var1.getLocation(), new Vector2f(0.0F, 0.0F), Color.BLACK, 60.0F, 2.0F);
         float var7 = var1.getVelocity().length();
         float var8 = var1.getFacing();

         for(int var9 = 0; var9 <= 1; ++var9) {
            float var10 = MathUtils.getRandomNumberInRange(var8 - 75.0F, var8 + 75.0F);
            float var11 = MathUtils.getRandomNumberInRange(var7 * -0.1F, var7 * -0.15F);
            Vector2f var12 = MathUtils.getPointOnCircumference((Vector2f)null, var11, var10);
            var6.addHitParticle(var3, var12, 3.0F, 150.0F, 1.0F, MUZZLE_FLASH_COLOR);
         }
      }

   }

   private Vector2f calculateMuzzle(WeaponAPI var1) {
      Vector2f var3 = new Vector2f(var1.getLocation());
      Vector2f var4 = new Vector2f(5.0F, -15.0F);
      VectorUtils.rotate(var4, var1.getCurrAngle(), var4);
      Vector2f.add(var4, var3, var3);
      return var3;
   }

}
