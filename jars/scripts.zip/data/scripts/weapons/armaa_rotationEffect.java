package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;

public class armaa_rotationEffect implements EveryFrameWeaponEffectPlugin {

   public float angle = 0.0F;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!Global.getCombatEngine().isPaused()) {
         var3.setCurrAngle(this.angle);
         this.angle += 0.5F;
      }
   }
}
