package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.OnFireEffectPlugin;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponSize;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicInterference;
import org.magiclib.util.MagicLensFlare;
import org.magiclib.util.MagicRender;

public class armaa_curvyEffect implements EveryFrameWeaponEffectPlugin, OnFireEffectPlugin, OnHitEffectPlugin {

   private boolean runOnce = false;
   private boolean hasFired = false;
   public float TURRET_OFFSET = 45.0F;
   private final IntervalUtil particle = new IntervalUtil(0.025F, 0.05F);
   private final IntervalUtil particle2 = new IntervalUtil(0.1F, 0.2F);
   float charge = 0.0F;
   private static final int SMOKE_SIZE_MIN = 10;
   private static final int SMOKE_SIZE_MAX = 30;
   private static final Color MUZZLE_FLASH_COLOR = new Color(100, 200, 255, 50);
   private static final Color MUZZLE_FLASH_COLOR_ALT = new Color(255, 255, 255, 100);
   private static final Color MUZZLE_FLASH_COLOR_GLOW = new Color(0, 75, 255, 50);
   private static final float MUZZLE_FLASH_DURATION = 0.2F;
   private static final float MUZZLE_FLASH_SIZE = 30.0F;
   private static final Color PARTICLE_COLOR = new Color(50, 150, 255, 174);
   private static final Color BLAST_COLOR = new Color(255, 16, 16, 255);
   private static final Color CORE_COLOR = new Color(119, 194, 255);
   private static final Color FLASH_COLOR = new Color(152, 225, 255);
   private static final int NUM_PARTICLES = 30;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.TURRET_OFFSET = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(0)).x;
      float var4 = ((Vector2f)var3.getSpec().getTurretFireOffsets().get(0)).y;
      if(var3.getShip().getOriginalOwner() < 0 && !var3.getSlot().isBuiltIn()) {
         MagicInterference.ApplyInterference(var3.getShip().getVariant());
      }

      if(var3.getChargeLevel() > 0.0F && var3.getCooldownRemaining() > 0.0F) {
         this.particle2.advance(var1);
         if(this.particle2.intervalElapsed()) {
            Vector2f var5 = new Vector2f(var3.getLocation());
            Vector2f var6 = new Vector2f(this.TURRET_OFFSET, var4);
            VectorUtils.rotate(var6, var3.getCurrAngle(), var6);
            Vector2f.add(var6, var5, var5);
            float var7 = (float)MathUtils.getRandomNumberInRange(10, 30);
            float var8 = (float)MathUtils.getRandomNumberInRange(-20, 20);
            float var9 = (float)MathUtils.getRandomNumberInRange(-20, 20);
            Global.getCombatEngine().addSmokeParticle(var5, new Vector2f(var8, var9), var7 * var3.getChargeLevel(), 1.0F * var3.getChargeLevel(), 1.0F * var3.getChargeLevel(), Color.gray);
            var5 = new Vector2f(var3.getLocation());
            var6 = new Vector2f(this.TURRET_OFFSET, var4);
            VectorUtils.rotate(var6, var3.getCurrAngle(), var6);
            Vector2f.add(var6, var5, var5);
            var7 = (float)MathUtils.getRandomNumberInRange(10, 30);
            var8 = (float)MathUtils.getRandomNumberInRange(-50, 50);
            var9 = (float)MathUtils.getRandomNumberInRange(-50, 50);
            Global.getCombatEngine().addSmokeParticle(var3.getLocation(), new Vector2f(var8, var9), var7 * var3.getChargeLevel(), 1.0F * var3.getChargeLevel(), 1.0F * var3.getChargeLevel(), Color.gray);
         }
      }

      if(var3.isFiring() && this.charge != 1.0F) {
         float var14 = var3.getChargeLevel();
         float var15 = 1.0F;
         if(var3.getSize() == WeaponSize.LARGE) {
            var15 = 2.0F;
         }

         if(!this.hasFired) {
            Global.getSoundPlayer().playLoop("beamchargeM", var3, 1.0F, 1.0F, var3.getLocation(), var3.getShip().getVelocity());
            this.particle.advance(var1);
            if(this.particle.intervalElapsed()) {
               Vector2f var16 = new Vector2f(var3.getLocation());
               Vector2f var17 = new Vector2f(this.TURRET_OFFSET, var4);
               VectorUtils.rotate(var17, var3.getCurrAngle(), var17);
               Vector2f.add(var17, var16, var16);
               Vector2f var18 = MathUtils.getPoint(var3.getLocation(), 18.5F, var3.getCurrAngle());
               Vector2f var10 = var3.getShip().getVelocity();
               var2.addHitParticle(var16, var10, MathUtils.getRandomNumberInRange(20.0F * var15, var14 * var15 * 60.0F + 20.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var14), MathUtils.getRandomNumberInRange(0.1F, 0.1F + var14 / 10.0F), new Color(var14, var14, var14));
               var2.addSwirlyNebulaParticle(var16, new Vector2f(0.0F, 0.0F), MathUtils.getRandomNumberInRange(20.0F * var15, var14 * var15 * 60.0F + 20.0F), 1.2F, 0.15F, 0.0F, 0.35F * var14, new Color(0.0F, var14 / 4.0F, var14), false);
               Vector2f var11 = MathUtils.getRandomPointInCircle(new Vector2f(), 35.0F * var14);
               Vector2f var12 = new Vector2f();
               Vector2f.sub(var16, new Vector2f(var11), var12);
               Vector2f.add(var10, var11, var11);

               for(int var13 = 0; var13 < 5; ++var13) {
                  var2.addHitParticle(var12, var11, MathUtils.getRandomNumberInRange(2.0F, var14 * 2.0F + 2.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var14), MathUtils.getRandomNumberInRange(0.75F, 0.75F + var14 / 4.0F), new Color(var14 / 4.0F, var14 / 2.0F, var14));
               }
            }
         }

         if(var14 == 1.0F) {
            this.hasFired = true;
         }
      } else {
         this.hasFired = false;
      }

   }

   public void onFire(DamagingProjectileAPI var1, WeaponAPI var2, CombatEngineAPI var3) {
      if(Math.random() > 0.75D) {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 3.0F, 0.2F);
      } else {
         var3.spawnExplosion(var1.getLocation(), var1.getVelocity(), MUZZLE_FLASH_COLOR, 30.0F, 0.2F);
      }

      var3.addSmoothParticle(var1.getLocation(), var1.getVelocity(), 90.0F, 1.0F, 0.4F, MUZZLE_FLASH_COLOR_GLOW);
   }

   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      var6.spawnExplosion(var3, new Vector2f(), PARTICLE_COLOR, 150.0F, 1.0F);
      var6.spawnExplosion(var3, new Vector2f(), CORE_COLOR, 75.0F, 1.0F);
      MagicLensFlare.createSharpFlare(var6, var1.getSource(), var1.getLocation(), 8.0F, 400.0F, 0.0F, new Color(186, 240, 255), new Color(255, 255, 255));
      float var7 = var1.getDamageAmount() / 10.0F;
      DamagingExplosionSpec var8 = new DamagingExplosionSpec(0.1F, 75.0F, 25.0F, var7, var7 / 2.0F, CollisionClass.PROJECTILE_FF, CollisionClass.PROJECTILE_FIGHTER, 10.0F, 10.0F, 0.0F, 0, BLAST_COLOR, (Color)null);
      var8.setDamageType(DamageType.FRAGMENTATION);
      var8.setShowGraphic(false);
      var6.spawnDamagingExplosion(var8, var1.getSource(), var3, false);
      if(MagicRender.screenCheck(0.2F, var3)) {
         var6.addSmoothParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 200.0F, 2.0F, 0.1F, Color.white);
         var6.addSmoothParticle(var3, new Vector2f(), 400.0F, 0.5F, 0.1F, PARTICLE_COLOR);
         var6.addHitParticle(var3, new Vector2f(), 200.0F, 0.5F, 0.25F, FLASH_COLOR);

         for(int var9 = 0; var9 < 30; ++var9) {
            var6.addHitParticle(var3, MathUtils.getPointOnCircumference((Vector2f)null, MathUtils.getRandomNumberInRange(150.0F, 300.0F), (float)Math.random() * 360.0F), 5.0F, 1.0F, MathUtils.getRandomNumberInRange(0.6F, 1.0F), PARTICLE_COLOR);
         }
      }

   }

}
