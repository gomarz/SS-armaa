package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAIPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.Iterator;
import java.util.Map;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicAnim;

public class armaa_paEffect implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private ShipSystemAPI system;
   private ShipAPI ship;
   private SpriteAPI sprite;
   private AnimationAPI anim;
   private AnimationAPI aGlow;
   private AnimationAPI aGlow2;
   private WeaponAPI head;
   private WeaponAPI armL;
   private WeaponAPI armL2;
   private WeaponAPI armR;
   private WeaponAPI pauldronL;
   private WeaponAPI pauldronR;
   private WeaponAPI torso;
   private WeaponAPI vernier;
   private WeaponAPI gun;
   private WeaponAPI shoulderwep;
   private WeaponAPI headGlow;
   private final Vector2f ZERO = new Vector2f();
   private int limbInit = 0;
   private float swingLevel = 0.0F;
   private boolean swinging = false;
   private boolean cooldown = false;
   private boolean isBoarding = false;
   private float swingLevelR = 0.0F;
   private boolean swingingR = false;
   private boolean cooldownR = false;
   private Vector2f to;
   private IntervalUtil animInterval = new IntervalUtil(0.012F, 0.012F);
   private IntervalUtil boardingInterval = new IntervalUtil(3.0F, 3.0F);
   private IntervalUtil sabotageInterval = new IntervalUtil(5.0F, 10.0F);
   private IntervalUtil abscondInterval = new IntervalUtil(0.5F, 0.5F);
   private float overlap = 0.0F;
   private float heat = 0.0F;
   private float originalRArmPos = 0.0F;
   private float originalArmPos = 0.0F;
   private float originalArmPos2 = 0.0F;
   private float originalShoulderPos = 0.0F;
   private float originalVernierPos = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -60.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;
   private final float LPAULDRONOFFSET = -5.0F;


   public static Vector2f lerp(Vector2f var0, Vector2f var1, float var2) {
      if(var2 < 0.0F) {
         var2 = 0.0F;
      }

      if(var2 > 1.0F) {
         var2 = 1.0F;
      }

      float var3 = var0.x + var2 * (var1.x - var0.x);
      float var4 = var0.y + var2 * (var1.y - var0.y);
      return new Vector2f(var3, var4);
   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.ship = var3.getShip();
      this.sprite = this.ship.getSpriteAPI();
      this.system = this.ship.getSystem();
      if(!var2.isPaused()) {
         if(this.ship.isAlive()) {
            this.boardingInterval.advance(var1);
            ShipAPI var4;
            Map var11;
            int var13;
            if(this.boardingInterval.intervalElapsed() && !this.isBoarding) {
               var4 = null;
               Iterator var5 = CombatUtils.getShipsWithinRange(this.ship.getLocation(), 25.0F).iterator();

               while(var5.hasNext()) {
                  ShipAPI var6 = (ShipAPI)var5.next();
                  if(var6.isAlive() && var6 != this.ship && var6.getOwner() != this.ship.getOwner()) {
                     boolean var7 = false;
                     if(var6.getShield() == null) {
                        var7 = true;
                     } else if(var6.getShield().isOff()) {
                        var7 = true;
                     } else if(!var6.getShield().isWithinArc(this.ship.getLocation())) {
                        var7 = true;
                     }

                     if(var7) {
                        var4 = var6;
                        var2.getCustomData().put("armaa_boardingTarget_" + this.ship.getId(), var6);
                        break;
                     }
                  }
               }

               if(var4 != null) {
                  this.ship.setShipAI((ShipAIPlugin)null);
                  this.ship.beginLandingAnimation(var4);
                  this.ship.setCollisionClass(CollisionClass.NONE);
                  this.ship.getMutableStats().getHullDamageTakenMult().modifyMult("invincible", 0.0F);
                  this.ship.getMutableStats().getArmorDamageTakenMult().modifyMult("invincible", 0.0F);
                  this.ship.setControlsLocked(true);
                  var11 = var2.getCustomData();
                  var13 = var11.get("armaa_boardingTarget_" + var4.getId() + "_numBoarders") == null?0:((Integer)var11.get("armaa_boardingTarget_" + var4.getId() + "_numBoarders")).intValue();
                  var2.getCustomData().put("armaa_boardingTarget_" + var4.getId() + "_numBoarders", Integer.valueOf(10 + var13));
                  this.isBoarding = true;
               }
            }

            if(this.isBoarding) {
               var4 = (ShipAPI)var2.getCustomData().get("armaa_boardingTarget_" + this.ship.getId());
               var11 = var2.getCustomData();
               var13 = var11.get("armaa_boardingTarget_" + var4.getId() + "_numBoarders") == null?0:((Integer)var11.get("armaa_boardingTarget_" + var4.getId() + "_numBoarders")).intValue();
               this.abscondInterval.advance(var1);
               if(!var4.isAlive() && this.abscondInterval.intervalElapsed() || var4 == null) {
                  var11.put("armaa_boardingTarget_" + var4.getId() + "_numBoarders", Integer.valueOf(-10));
                  this.ship.setControlsLocked(false);
                  this.ship.getMutableStats().getHullDamageTakenMult().unmodify("invincible");
                  this.ship.getMutableStats().getArmorDamageTakenMult().unmodify("invincible");
                  this.ship.setCollisionClass(CollisionClass.FIGHTER);
                  this.ship.setAnimatedLaunch();
                  Global.getSoundPlayer().playSound("fighter_takeoff", 1.0F, 0.5F, this.ship.getLocation(), new Vector2f());
                  this.ship.resetDefaultAI();
                  this.isBoarding = false;
               }

               this.sabotageInterval.advance(var1);
               Vector2f var15 = new Vector2f(CollisionUtils.getNearestPointOnBounds(this.ship.getLocation(), var4));
               float var8 = (float)((double)MathUtils.getDistanceSquared(var15, this.ship.getLocation()) / Math.pow((double)var4.getCollisionRadius(), 2.0D));
               if(!this.ship.isFinishedLanding()) {
                  float var9 = 1.0F - Math.min(1.0F, var8);
                  this.ship.getLocation().x = (var15.x * var9 * 0.1F + this.ship.getLocation().x * (2.0F - var9 * 0.1F)) / 2.0F;
                  this.ship.getLocation().y = (var15.y * var9 * 0.1F + this.ship.getLocation().y * (2.0F - var9 * 0.1F)) / 2.0F;
               } else {
                  this.ship.getLocation().set(var4.getLocation());
               }

               if(this.sabotageInterval.intervalElapsed()) {
                  if(!var2.hasAttachedFloaty(var4)) {
                     var2.addFloatingText(var4.getLocation(), "Boarded! Defender Strength: " + var4.getFleetMember().getMinCrew() + " vs " + var13, 15.0F, Color.white, var4, 1.0F, 5.0F);
                  }

                  var2.applyDamage(var4, this.ship.getLocation(), 150.0F, DamageType.ENERGY, 150.0F, true, false, this.ship);
               }
            }

            float var10 = 0.0F;
            float var12 = 0.0F;
            float var14 = 0.0F;
            float var16 = 0.0F;
            if(var3 != null) {
               if(var3.getChargeLevel() < 1.0F) {
                  var14 = MagicAnim.smoothNormalizeRange(var3.getChargeLevel(), 0.3F, 0.9F);
                  var16 = MagicAnim.smoothNormalizeRange(var3.getChargeLevel(), 0.3F, 1.0F);
               } else {
                  var14 = 1.0F;
                  var16 = 1.0F;
               }

               if(var3.getCooldownRemaining() <= 0.0F && !var3.isFiring()) {
                  this.cooldownR = false;
               }

               if(!this.swingingR && !this.cooldownR && var3.getChargeLevel() > 0.0F) {
                  var3.setCurrAngle(var3.getCurrAngle() + var14 * 45.0F * 0.3F * var3.getChargeLevel());
               }

               if(var3.getChargeLevel() >= 1.0F) {
                  this.swingingR = true;
               }

               if(this.swingingR && var3.getCurrAngle() != var3.getShip().getFacing() - 90.0F) {
                  this.animInterval.advance(var1);
                  var3.setCurrAngle(Math.max(var3.getCurrAngle() - this.swingLevelR, var3.getCurrAngle() - var3.getArc() / 2.0F));
               }

               if(this.swingingR && var3.getChargeLevel() <= 0.0F) {
                  this.swingingR = false;
                  this.swingLevelR = 0.0F;
                  this.cooldownR = true;
               }

               if(this.animInterval.intervalElapsed()) {
                  this.swingLevelR = (float)((double)this.swingLevelR + 0.5D);
               }

               if(this.swingLevelR > 9.0F) {
                  this.swingLevelR = 9.0F;
               }

               if(!this.swingingR) {
                  this.swingLevelR = 0.0F;
               }
            }

         }
      }
   }
}
