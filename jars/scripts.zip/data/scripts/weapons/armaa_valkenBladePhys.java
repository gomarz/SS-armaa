package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_valkenBladePhys implements BeamEffectPlugin {

   private IntervalUtil fireInterval = new IntervalUtil(0.05F, 0.05F);
   private final Vector2f ZERO = new Vector2f();
   private final float BLADE_KNOCKBACK_MAX = 200.0F;
   private static final Color PARTICLE_COLOR = new Color(250, 236, 111, 255);
   private static final float PARTICLE_SIZE = 4.0F;
   private static final float PARTICLE_BRIGHTNESS = 150.0F;
   private static final float PARTICLE_DURATION = 0.8F;
   private static final int PARTICLE_COUNT = 4;
   private static final float CONE_ANGLE = 150.0F;
   private static final float VEL_MIN = 0.1F;
   private static final float VEL_MAX = 0.3F;
   private static final float A_2 = 75.0F;
   private float arc = 20.0F;
   private float level = 0.0F;
   private boolean firstStrike = false;
   private boolean firstTrail = false;
   private float id;
   private float id2;
   private boolean runOnce = false;
   private WeaponAPI weapon;
   private List targets = new ArrayList();
   private List hitTargets = new ArrayList();


   public void advance(float var1, CombatEngineAPI var2, BeamAPI var3) {
      this.weapon = var3.getWeapon();
      var3.getDamage().setDamage(0.0F);
      CombatEntityAPI var4 = var3.getDamageTarget();
      if(!this.targets.contains(var4)) {
         this.targets.add(var4);
      }

      Vector2f var5 = MathUtils.getRandomPointOnLine(var3.getFrom(), var3.getTo());
      float var8;
      float var20;
      if(this.weapon.isFiring() && var3.getBrightness() >= 0.7F) {
         Iterator var6 = this.targets.iterator();

         while(var6.hasNext()) {
            CombatEntityAPI var7 = (CombatEntityAPI)var6.next();
            if(var7 == var3.getDamageTarget() && !this.hitTargets.contains(var3.getDamageTarget())) {
               var8 = Math.max(this.weapon.getDamage().getDamage(), this.weapon.getDamage().getDamage() * this.weapon.getSpec().getBurstDuration() * (this.weapon.getShip().getMutableStats().getBallisticWeaponDamageMult().computeMultMod() + this.weapon.getShip().getMutableStats().getBallisticWeaponDamageMult().getPercentMod() / 100.0F) * (this.weapon.getShip().getMutableStats().getEnergyWeaponDamageMult().computeMultMod() + this.weapon.getShip().getMutableStats().getBeamWeaponDamageMult().getPercentMod() / 100.0F));
               float var9 = this.weapon.getShip().getFluxBasedEnergyWeaponDamageMultiplier() - 1.0F;
               if(var9 > 0.0F) {
                  var8 *= 1.0F + var9;
               }

               var2.applyDamage(var7, var3.getTo(), var8, this.weapon.getDamageType(), var8, false, false, this.weapon.getShip());
               this.hitTargets.add(var7);
            }
         }

         this.fireInterval.advance(var1);
         if(this.fireInterval.intervalElapsed() && var3.getBrightness() == 1.0F) {
            var20 = this.weapon.getCurrAngle() + 90.0F;
         }
      }

      if(var4 instanceof CombatEntityAPI) {
         var20 = var3.getDamage().getDpsDuration();
         if(!this.firstStrike && var3.getBrightness() > 0.9F) {
            Vector2f var21 = var3.getTo();
            var8 = MathUtils.getRandomNumberInRange(-0.3F, 0.3F);
            Global.getSoundPlayer().playSound("armaa_sword_strike", 1.0F + var8, 1.0F + var8, var21, this.ZERO);
            this.firstStrike = true;
            CombatUtils.applyForce(this.weapon.getShip(), this.weapon.getShip().getFacing() - 180.0F, Math.min(var4.getMass(), 200.0F));
            Vector2f var22 = Vector2f.sub(var3.getTo(), var3.getFrom(), new Vector2f());
            if(var22.lengthSquared() > 0.0F) {
               var22.normalise();
            }

            var22.scale(50.0F);
            var21 = Vector2f.sub(var3.getTo(), var22, new Vector2f());
            if(MagicRender.screenCheck(0.2F, var21) && (this.weapon.isFiring() && this.weapon.getChargeLevel() > 0.0F && this.weapon.getChargeLevel() < 1.0F || this.weapon.getChargeLevel() == 1.0F)) {
               SpriteAPI var10 = Global.getSettings().getSprite("misc", "armaa_sfxpulse");
               if(var10 != null) {
                  MagicRender.battlespace(var10, var3.getTo(), new Vector2f(), new Vector2f(5.0F, 5.0F), new Vector2f(200.0F, 200.0F), 15.0F, 15.0F, new Color(150, 155, 155, 155), true, 0.3F, 0.0F, 0.3F);
               }

               float var11 = 10.0F + this.weapon.getChargeLevel() * this.weapon.getChargeLevel() * MathUtils.getRandomNumberInRange(25.0F, 75.0F);
               Color var12 = var3.getFringeColor();
               Color var13 = var3.getCoreColor();
               float var14 = 500.0F;
               float var15 = var3.getWeapon().getCurrAngle();

               for(int var16 = 0; var16 <= 4; ++var16) {
                  float var17 = MathUtils.getRandomNumberInRange(var15 - 75.0F, var15 + 75.0F);
                  float var18 = MathUtils.getRandomNumberInRange(var14 * -0.1F, var14 * -0.3F);
                  Vector2f var19 = MathUtils.getPointOnCircumference((Vector2f)null, var18, var17);
                  var2.addHitParticle(var3.getTo(), var19, 4.0F, 150.0F, 0.8F, PARTICLE_COLOR);
               }
            }
         }
      }

   }

}
