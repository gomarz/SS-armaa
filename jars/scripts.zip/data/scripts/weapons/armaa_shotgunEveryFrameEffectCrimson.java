package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.ArrayList;
import java.util.Iterator;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_shotgunEveryFrameEffectCrimson implements EveryFrameWeaponEffectPlugin {

   public static final int SHOTS = 20;
   public static final float SPREAD = 20.0F;
   public static final float PUSH_CONSTANT = 12800.0F;
   private int lastAmmo = 0;
   private boolean init = false;
   private boolean reloading = true;
   private IntervalUtil cockSound = new IntervalUtil(0.33F, 0.38F);
   private IntervalUtil reloadTime = new IntervalUtil(2.8F, 2.85F);
   private DamagingProjectileAPI dummy;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!this.init) {
         this.init = true;
         this.lastAmmo = var3.getAmmo();
      }

      ShipwideAIFlags var4 = var3.getShip().getAIFlags();
      if(var3.getShip().getFluxTracker().getFluxLevel() >= 0.6F) {
         var4.setFlag(AIFlags.BACK_OFF, var1);
         var4.setFlag(AIFlags.RUN_QUICKLY, var1);
         var4.setFlag(AIFlags.BACKING_OFF, var1);
      }

      ArrayList var5 = new ArrayList(Global.getCombatEngine().getProjectiles().size() / 4);
      var5.addAll(CombatUtils.getProjectilesWithinRange(var3.getShip().getLocation(), 100.0F));
      var5.addAll(CombatUtils.getMissilesWithinRange(var3.getShip().getLocation(), 100.0F));
      Iterator var6 = var5.iterator();

      while(var6.hasNext()) {
         CombatEntityAPI var7 = (CombatEntityAPI)var6.next();
         DamagingProjectileAPI var8 = (DamagingProjectileAPI)var7;
         if(var8.getWeapon() == var3) {
            this.dummy = var8;
            var2.removeEntity(var8);
         }
      }

      if(this.dummy != null) {
         for(int var13 = 0; var13 < 20; ++var13) {
            float var14 = (float)Math.random() * 20.0F - 10.0F;
            float var15 = var3.getCurrAngle() + var14;
            String var9 = "armaa_altagrave_shotgun_pellet";
            this.calculateMuzzle(var3);
            DamagingProjectileAPI var11 = (DamagingProjectileAPI)var2.spawnProjectile(var3.getShip(), var3, var9, this.dummy.getLocation(), var15, var3.getShip().getVelocity());
            float var12 = (float)Math.random() * 0.4F + 0.8F;
            var11.getVelocity().scale(var12);
         }

         this.dummy = null;
      }

      if(var3.getAmmo() > 0) {
         this.reloading = true;
      } else {
         this.reloadTime.setElapsed(0.0F);
      }

      if(this.lastAmmo == 0 && var3.getAmmo() > 0) {
         Global.getSoundPlayer().playSound("armaa_shotgun_cock", 0.5F, 2.8F, var3.getLocation(), var3.getShip().getVelocity());
         var3.setRemainingCooldownTo(1.0F);
      }

      this.lastAmmo = var3.getAmmo();
      if(this.reloading) {
         this.cockSound.advance(var1);
         if(this.cockSound.intervalElapsed()) {
            this.reloading = false;
         }
      }

   }

   private Vector2f calculateMuzzle(WeaponAPI var1) {
      float var2;
      if(var1.getSlot().isHardpoint()) {
         var2 = ((Vector2f)var1.getSpec().getHardpointFireOffsets().get(0)).getX();
      } else {
         var2 = ((Vector2f)var1.getSpec().getTurretFireOffsets().get(0)).getX();
      }

      double var3 = Math.toRadians((double)var1.getCurrAngle());
      Vector2f var5 = new Vector2f((float)Math.cos(var3), (float)Math.sin(var3));
      if(var5.lengthSquared() > 0.0F) {
         var5.normalise();
      }

      var5.scale(var2);
      Vector2f var6 = new Vector2f(var1.getLocation().getX(), var1.getLocation().getY() - 20.0F);
      return Vector2f.add(var6, var5, new Vector2f());
   }
}
