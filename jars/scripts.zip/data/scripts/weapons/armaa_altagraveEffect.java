package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.magiclib.util.MagicAnim;

public class armaa_altagraveEffect implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private WeaponAPI reference;
   private ShipAPI ship;
   private ShipwideAIFlags flags;
   private WeaponAPI armL;
   private WeaponAPI armR;
   private WeaponAPI shoulderR;
   private WeaponAPI head;
   private WeaponAPI headGlow;
   private WeaponAPI module1;
   private WeaponAPI module2;
   private float overlap = 0.0F;
   private float overlap2 = 0.0F;
   private float overlap3 = 0.0F;
   private float currentRotateL = 0.0F;
   private float currentRotateR = 0.0F;
   private float sway = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -75.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 7.0F;
   private final float maxlegRotate = 22.5F;
   private float swingLevel = 0.0F;
   private boolean windingUp = false;
   private boolean swinging = false;
   private boolean cooldown = false;
   private IntervalUtil animInterval = new IntervalUtil(0.012F, 0.012F);
   private boolean lostmodules = false;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!this.runOnce) {
         this.runOnce = true;
         this.ship = var3.getShip();
         this.flags = this.ship.getAIFlags();
         Iterator var4 = this.ship.getAllWeapons().iterator();

         while(var4.hasNext()) {
            WeaponAPI var5 = (WeaponAPI)var4.next();
            String var6 = var5.getSlot().getId();
            byte var7 = -1;
            switch(var6.hashCode()) {
            case -1726101279:
               if(var6.equals("WS0005")) {
                  var7 = 5;
               }
               break;
            case -1726101277:
               if(var6.equals("WS0007")) {
                  var7 = 6;
               }
               break;
            case 1630742648:
               if(var6.equals("E_RSHOULDER")) {
                  var7 = 2;
               }
               break;
            case 1672492306:
               if(var6.equals("E_HEAD_GLOW")) {
                  var7 = 3;
               }
               break;
            case 2065359258:
               if(var6.equals("E_HEAD")) {
                  var7 = 4;
               }
               break;
            case 2065475114:
               if(var6.equals("E_LARM")) {
                  var7 = 0;
               }
               break;
            case 2065653860:
               if(var6.equals("E_RARM")) {
                  var7 = 1;
               }
            }

            switch(var7) {
            case 0:
               if(this.armL == null) {
                  this.armL = var5;
               }
               break;
            case 1:
               if(this.armR == null) {
                  this.armR = var5;
               }
               break;
            case 2:
               this.shoulderR = var5;
               break;
            case 3:
               if(this.headGlow == null) {
                  this.headGlow = var5;
               }
               break;
            case 4:
               if(this.head == null) {
                  this.head = var5;
               }
               break;
            case 5:
               if(this.module1 == null) {
                  this.module1 = var5;
               }
               break;
            case 6:
               if(this.module2 == null) {
                  this.module2 = var5;
               }
            }
         }
      }

      if(this.armL != null) {
         if(this.ship.getEngineController().isAccelerating()) {
            if(this.overlap > 6.9F) {
               this.overlap = 7.0F;
            } else {
               this.overlap = Math.min(7.0F, this.overlap + (7.0F - this.overlap) * var1 * 5.0F);
            }
         } else if(!this.ship.getEngineController().isDecelerating() && !this.ship.getEngineController().isAcceleratingBackwards()) {
            if(Math.abs(this.overlap) < 0.1F) {
               this.overlap = 0.0F;
            } else {
               this.overlap -= this.overlap / 2.0F * var1 * 3.0F;
            }
         } else if(this.overlap < -6.9F) {
            this.overlap = -7.0F;
         } else {
            this.overlap = Math.max(-7.0F, this.overlap + (-7.0F + this.overlap) * var1 * 5.0F);
         }

         if(!this.ship.getEngineController().isStrafingLeft() && !this.ship.getEngineController().isTurningLeft()) {
            if(Math.abs(this.overlap2) < 0.1F) {
               this.overlap2 = 0.0F;
            } else {
               this.overlap2 -= this.overlap2 / 2.0F * var1 * 3.0F;
            }
         } else if(this.overlap2 > 6.9F) {
            this.overlap2 = 7.0F;
         } else {
            this.overlap2 = Math.min(7.0F, this.overlap2 + (7.0F - this.overlap2) * var1 * 5.0F);
         }

         if(!this.ship.getEngineController().isStrafingRight() && !this.ship.getEngineController().isTurningRight()) {
            if(Math.abs(this.overlap3) < 0.1F) {
               this.overlap3 = 0.0F;
            } else {
               this.overlap3 -= this.overlap3 / 2.0F * var1 * 3.0F;
            }
         } else if(this.overlap3 > 6.9F) {
            this.overlap3 = 7.0F;
         } else {
            this.overlap3 = Math.min(7.0F, this.overlap3 + (7.0F - this.overlap3) * var1 * 5.0F);
         }

         float var16 = 0.0F;
         float var17 = 0.0F;
         float var18 = 0.0F;
         float var19 = 0.0F;
         float var8 = 0.0F;
         if(this.armL.getChargeLevel() < 1.0F) {
            var8 = MagicAnim.smoothNormalizeRange(this.armL.getChargeLevel(), 0.3F, 0.9F);
         } else {
            var8 = 1.0F;
         }

         float var9;
         float var10;
         if(!var2.isPaused()) {
            if(this.armL != null && this.armL.getId().equals("armaa_altagrave_blade")) {
               if(this.armL.getCooldownRemaining() <= 0.0F && !this.armL.isFiring()) {
                  this.cooldown = false;
               }

               if(!this.swinging && !this.cooldown && this.armL.getChargeLevel() > 0.0F) {
                  this.armL.setCurrAngle(this.armL.getCurrAngle() + var8 * -45.0F * 0.3F * this.armL.getChargeLevel());
               }

               if(this.armL.getChargeLevel() >= 1.0F) {
                  this.swinging = true;
               }

               if(this.swinging && this.armL.getCurrAngle() != this.armL.getShip().getFacing() + 45.0F) {
                  this.animInterval.advance(var1);
                  this.armL.setCurrAngle(Math.min(this.armL.getCurrAngle() + this.swingLevel, this.armL.getCurrAngle() + this.armL.getArc() / 2.0F));
               }

               if(this.swinging && this.armL.getChargeLevel() <= 0.0F) {
                  this.swinging = false;
                  this.swingLevel = 0.0F;
                  this.cooldown = true;
               }

               if(this.animInterval.intervalElapsed()) {
                  this.swingLevel = (float)((double)this.swingLevel + 0.5D);
               }

               if(this.swingLevel > 9.0F) {
                  this.swingLevel = 9.0F;
               }

               if(!this.swinging) {
                  this.swingLevel = 0.0F;
               }
            }

            if(this.ship.getEngineController().isAccelerating()) {
               var16 += 11.25F;
               var17 -= 11.25F;
               if(this.sway > -1.0F) {
                  this.sway = (float)((double)this.sway - 0.08D);
               }
            } else if(this.ship.getEngineController().isDecelerating() || this.ship.getEngineController().isAcceleratingBackwards()) {
               var16 -= 11.25F;
               var17 += 11.25F;
               if(this.sway < 1.0F) {
                  this.sway = (float)((double)this.sway + 0.08D);
               }
            }

            if(this.ship.getEngineController().isStrafingLeft()) {
               var16 += 7.5F;
               var17 += 15.0F;
            } else if(this.ship.getEngineController().isStrafingRight()) {
               var16 -= 15.0F;
               var17 -= 7.5F;
            }

            if(this.ship.getEngineController().isTurningLeft()) {
               var16 -= 11.25F;
               var17 -= 11.25F;
            } else if(this.ship.getEngineController().isTurningRight()) {
               var16 += 11.25F;
               var17 += 11.25F;
            }

            var9 = MathUtils.getShortestRotation(this.currentRotateL, var16);
            if(Math.abs(var9) < 0.5F) {
               this.currentRotateL = var16;
            } else if(var9 > 0.0F) {
               this.currentRotateL += 0.4F;
            } else {
               this.currentRotateL -= 0.4F;
            }

            var10 = MathUtils.getShortestRotation(this.currentRotateR, var17);
            if(Math.abs(var10) < 0.5F) {
               this.currentRotateR = var17;
            } else if(var10 > 0.0F) {
               this.currentRotateR += 0.4F;
            } else {
               this.currentRotateR -= 0.4F;
            }

            if(this.sway > 0.0F) {
               this.sway = (float)((double)this.sway - 0.05D);
            } else {
               this.sway = (float)((double)this.sway + 0.05D);
            }
         }

         var9 = this.ship.getFacing();
         var10 = MathUtils.getShortestRotation(var9, var3.getCurrAngle());
         if(!this.ship.getVariant().getHullSpec().getHullId().equals("armaa_altagrave_ex") && !this.armL.getId().equals("armaa_altagrave_blade")) {
            this.armL.setCurrAngle(var9 + (var10 + -75.0F) * var19 + (this.overlap + this.overlap3 - this.overlap2 + var10 * 0.25F) * (1.0F - var19));
         }

         List var11 = this.ship.getChildModulesCopy();
         if(var11 != null && !this.lostmodules) {
            Iterator var12 = var11.iterator();

            while(var12.hasNext()) {
               ShipAPI var13 = (ShipAPI)var12.next();
               var13.ensureClonedStationSlotSpec();
               if(var13.getStationSlot() != null) {
                  boolean var14 = Global.getCombatEngine().getPlayerShip() == this.ship;
                  float var15 = var14?0.5F:0.7F;
                  if(this.ship.getHullLevel() <= var15) {
                     var13.getFluxTracker().showOverloadFloatyIfNeeded("Emergency Purge!", Color.yellow, 4.0F, true);
                     var13.setStationSlot((WeaponSlotAPI)null);
                     continue;
                  }

                  if(var13.getStationSlot().getId().equals("WS0001")) {
                     var13.setFacing(this.ship.getFacing() + this.currentRotateR);
                     var13.getSpriteAPI().setCenter(67.0F, 79.0F - 5.0F * this.sway);
                  } else if(var13.getStationSlot().getId().equals("WS0002")) {
                     var13.setFacing(this.ship.getFacing() + this.currentRotateL);
                     var13.getSpriteAPI().setCenter(41.0F, 79.0F - 5.0F * this.sway);
                  }
               }

               if(var13.getHullSpec().getHullName().equals("Backpack Module") && var13.getStationSlot() == null) {
                  if(this.module1 != null) {
                     this.module1.disable(true);
                     this.module1.getSprite().setColor(new Color(0, 0, 0, 0));
                     this.ship.removeWeaponFromGroups(this.module1);
                  }

                  if(this.module2 != null) {
                     this.module2.disable(true);
                     this.module2.getSprite().setColor(new Color(0, 0, 0, 0));
                     this.ship.removeWeaponFromGroups(this.module2);
                  }

                  this.lostmodules = true;
               }
            }
         }

         var3.setCurrAngle(this.ship.getFacing() + MathUtils.getShortestRotation(this.ship.getFacing(), this.armL.getCurrAngle()) * 0.7F);
         this.shoulderR.setCurrAngle(this.ship.getFacing() + MathUtils.getShortestRotation(this.ship.getFacing(), this.armR.getCurrAngle()) * 0.7F);
         this.shoulderR.getSprite().setCenterY(this.armR.getBarrelSpriteAPI().getCenterY());
         this.headGlow.setCurrAngle(this.head.getCurrAngle());
         this.ship.syncWeaponDecalsWithArmorDamage();
         if(!this.ship.isHulk()) {
            this.headGlow.getSprite().setAlphaMult(1.3F);
            if(this.ship.getVariant().getHullSpec().getHullId().equals("armaa_altagrave")) {
               this.headGlow.getSprite().setColor(new Color(255, 255, 150, 255));
               this.headGlow.getSprite().setAlphaMult(1.3F);
            } else if(this.ship.getVariant().getHullSpec().getHullId().equals("armaa_altagrave_c")) {
               this.headGlow.getSprite().setColor(new Color(0, 50, 150, 200));
               this.headGlow.getSprite().setAlphaMult(1.0F);
            } else {
               this.headGlow.getSprite().setColor(new Color(155, 0, 0, 200));
               this.headGlow.getSprite().setAlphaMult(1.0F);
            }
         } else {
            this.headGlow.getSprite().setColor(new Color(0, 0, 0, 255));
         }

      }
   }
}
