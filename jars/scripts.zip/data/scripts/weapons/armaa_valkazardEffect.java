package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicAnim;
import org.magiclib.util.MagicRender;

public class armaa_valkazardEffect implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private ShipSystemAPI system;
   private ShipAPI ship;
   private SpriteAPI sprite;
   private AnimationAPI anim;
   private AnimationAPI aGlow;
   private AnimationAPI aGlow2;
   private WeaponAPI head;
   private WeaponAPI armL;
   private WeaponAPI armR;
   private WeaponAPI pauldronL;
   private WeaponAPI torso;
   private WeaponAPI headGlow;
   private WeaponAPI gun;
   private WeaponAPI rwep;
   private float delay = 0.1F;
   private int numFrames = 8;
   private float minDelay = 0.033333335F;
   public int frame = 7;
   private float SPINUP = 0.02F;
   private float SPINDOWN = 10.0F;
   private boolean charging = false;
   private boolean cooling = false;
   private boolean firing = false;
   private final IntervalUtil interval = new IntervalUtil(0.06F, 0.06F);
   private float level = 0.0F;
   private float glowLevel = 1.0F;
   private int glowEffect = 0;
   float eyeG = 0.0F;
   private final Vector2f ZERO = new Vector2f();
   public float TURRET_OFFSET = 30.0F;
   private int limbInit = 0;
   private float timer = 0.0F;
   private int anime = 0;
   private boolean windingUp = false;
   private boolean swinging = false;
   private boolean cooldown = false;
   private float swingLevel = 0.0F;
   private IntervalUtil animInterval = new IntervalUtil(0.012F, 0.012F);
   private float overlap = 0.0F;
   private float heat = 0.0F;
   private float originalRArmPos = 0.0F;
   private float originalArmPos = 0.0F;
   private float originalShoulderPos = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -60.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;
   private final float LPAULDRONOFFSET = -5.0F;


   public void init() {
      this.runOnce = true;
      Iterator var1 = this.ship.getAllWeapons().iterator();

      while(var1.hasNext()) {
         WeaponAPI var2 = (WeaponAPI)var1.next();
         String var3 = var2.getSlot().getId();
         byte var4 = -1;
         switch(var3.hashCode()) {
         case -2143743196:
            if(var3.equals("H_GLOW")) {
               var4 = 6;
            }
            break;
         case -6931076:
            if(var3.equals("D_PAULDRONL")) {
               var4 = 3;
            }
            break;
         case 62929954:
            if(var3.equals("A_GUN")) {
               var4 = 4;
            }
            break;
         case 1245480854:
            if(var3.equals("B_TORSO")) {
               var4 = 0;
            }
            break;
         case 2007905292:
            if(var3.equals("C_ARML")) {
               var4 = 1;
            }
            break;
         case 2007905298:
            if(var3.equals("C_ARMR")) {
               var4 = 2;
            }
            break;
         case 2065359258:
            if(var3.equals("E_HEAD")) {
               var4 = 5;
            }
            break;
         case 2094107774:
            if(var3.equals("F_LEGS")) {
               var4 = 7;
            }
         }

         switch(var4) {
         case 0:
            if(this.torso == null) {
               this.torso = var2;
               ++this.limbInit;
            }
            break;
         case 1:
            if(this.armL == null) {
               this.armL = var2;
               this.originalArmPos = this.armL.getSprite().getCenterY();
               ++this.limbInit;
            }
            break;
         case 2:
            if(this.armR == null) {
               this.armR = var2;
               ++this.limbInit;
            }
            break;
         case 3:
            if(this.pauldronL == null) {
               this.pauldronL = var2;
               this.originalShoulderPos = this.pauldronL.getSprite().getCenterY();
               ++this.limbInit;
            }
            break;
         case 4:
            if(this.gun == null) {
               this.gun = var2;
               this.originalRArmPos = var2.getBarrelSpriteAPI().getCenterY();
               ++this.limbInit;
            }
            break;
         case 5:
            if(this.head == null) {
               this.head = var2;
               ++this.limbInit;
            }
            break;
         case 6:
            this.headGlow = var2;
            break;
         case 7:
            this.rwep = var2;
            this.rwep.ensureClonedSpec();
            this.sprite = this.rwep.getSprite();
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.ship = var3.getShip();
      this.system = this.ship.getSystem();
      this.anim = var3.getAnimation();
      this.init();
      if(this.ship.getEngineController().isAccelerating()) {
         if(this.overlap > 9.9F) {
            this.overlap = 10.0F;
         } else {
            this.overlap = Math.min(10.0F, this.overlap + (10.0F - this.overlap) * var1 * 5.0F);
         }
      } else if(!this.ship.getEngineController().isDecelerating() && !this.ship.getEngineController().isAcceleratingBackwards()) {
         if(Math.abs(this.overlap) < 0.1F) {
            this.overlap = 0.0F;
         } else {
            this.overlap -= this.overlap / 2.0F * var1 * 3.0F;
         }
      } else if(this.overlap < -9.9F) {
         this.overlap = -10.0F;
      } else {
         this.overlap = Math.max(-10.0F, this.overlap + (-10.0F + this.overlap) * var1 * 5.0F);
      }

      float var4 = 0.0F;
      float var5 = 0.0F;
      float var6 = 0.0F;
      boolean var7 = false;
      if(this.gun != null) {
         float var8 = this.ship.getFacing();
         float var9 = MathUtils.getShortestRotation(var8, this.gun.getCurrAngle());
         if(!this.ship.isLanding()) {
            Iterator var10 = this.ship.getAllWeapons().iterator();

            while(var10.hasNext()) {
               WeaponAPI var11 = (WeaponAPI)var10.next();
               String var12 = var11.getSlot().getId();
               byte var13 = -1;
               switch(var12.hashCode()) {
               case -1726101283:
                  if(var12.equals("WS0001")) {
                     var13 = 0;
                  }
                  break;
               case -1726101282:
                  if(var12.equals("WS0002")) {
                     var13 = 1;
                  }
               }

               switch(var13) {
               case 0:
               case 1:
                  if(var11.getAmmo() < 1 && var11.getAmmoPerSecond() == 0.0F) {
                     var11.getSprite().setColor(new Color(0, 0, 0, 0));
                  } else {
                     var11.getSprite().setColor(new Color(255, 255, 255, 255));
                  }
               }
            }
         }

         if(!var2.isPaused()) {
            if(this.armL != null) {
               if(this.armL.getSpec().getWeaponId().equals("armaa_valkazard_harpoon")) {
                  var7 = true;
               }

               if(var7 || this.armL.getId().equals("armaa_valkazard_blade")) {
                  if(this.armL.getChargeLevel() < 1.0F) {
                     var4 = MagicAnim.smoothNormalizeRange(this.armL.getChargeLevel(), 0.3F, 0.9F);
                     var5 = MagicAnim.smoothNormalizeRange(this.armL.getChargeLevel(), 0.3F, 1.0F);
                  } else {
                     var4 = 1.0F;
                     var5 = 1.0F;
                  }

                  this.armL.getSprite().setCenterY(this.originalArmPos - 16.0F * var5);
               }

               MathUtils.getShortestRotation(var8, this.armL.getCurrAngle());
            }

            if(this.armL != null && this.armL.getId().equals("armaa_valkazard_blade")) {
               this.armL.getSprite().setCenterY(this.originalArmPos - 16.0F * var5);
               if(this.torso != null) {
                  if(this.armL.getCooldownRemaining() <= 0.0F && !this.armL.isFiring()) {
                     this.cooldown = false;
                  }

                  if(!this.swinging && !this.cooldown && this.armL.getChargeLevel() > 0.0F) {
                     this.armL.setCurrAngle(this.armL.getCurrAngle() + var4 * -45.0F * 0.3F * this.armL.getChargeLevel());
                  }

                  if(this.armL.getChargeLevel() >= 1.0F) {
                     this.swinging = true;
                  }

                  if(this.swinging && this.armL.getCurrAngle() != this.armL.getShip().getFacing() + 45.0F) {
                     this.animInterval.advance(var1);
                     this.armL.setCurrAngle(Math.min(this.armL.getCurrAngle() + this.swingLevel, this.armL.getCurrAngle() + this.armL.getArc() / 2.0F));
                  }

                  if(this.swinging && this.armL.getChargeLevel() <= 0.0F) {
                     this.swinging = false;
                     this.swingLevel = 0.0F;
                     this.cooldown = true;
                  }

                  if(this.animInterval.intervalElapsed()) {
                     this.swingLevel = (float)((double)this.swingLevel + 0.5D);
                  }

                  if(this.swingLevel > 9.0F) {
                     this.swingLevel = 9.0F;
                  }

                  if(!this.swinging) {
                     this.swingLevel = 0.0F;
                  }
               }
            }

            if(this.torso != null && this.torso.getChargeLevel() == 0.0F && this.ship.getSelectedGroupAPI() != null && this.ship.getSelectedGroupAPI().getActiveWeapon() != this.torso) {
               if(var7) {
                  this.torso.setCurrAngle(var8 + (var4 * -45.0F + var6 * -45.0F + var9 * 0.3F) * this.armL.getChargeLevel());
               } else {
                  this.torso.setCurrAngle(var8 + var4 * (-45.0F - -45.0F * (this.swingLevel / 9.0F)) + var9 * 0.3F);
               }
            }

            if(this.head != null) {
               this.head.setCurrAngle(this.gun.getCurrAngle());
            }

            if(this.armR != null) {
               this.armR.setCurrAngle(this.gun.getCurrAngle() + -25.0F + var6 * -45.0F);
            }

            if(var3 != null) {
               var3.setCurrAngle(var8 + var4 * (-45.0F - -45.0F * (this.swingLevel / 9.0F)) * 0.5F + var6 * -45.0F + var9 * 0.75F + -12.5F);
               var3.getSprite().setCenterY(this.gun.getBarrelSpriteAPI().getCenterY() - 23.0F);
            }

            if(this.pauldronL != null) {
               this.pauldronL.setCurrAngle(this.torso.getCurrAngle() + -5.0F * var4 + var6 * -22.5F + MathUtils.getShortestRotation(this.torso.getCurrAngle(), this.armL.getCurrAngle()) * 0.7F);
               this.pauldronL.getSprite().setCenterY(this.originalShoulderPos - 8.0F * var5);
            }

            if(this.headGlow != null) {
               this.headGlow.setCurrAngle(this.head.getCurrAngle());
               this.headGlow.getSprite().setColor(new Color(55, 5, 10, 255));
            }

            this.interval.advance(var1);
            if(this.ship.getEngineController().isAcceleratingBackwards()) {
               if(this.interval.intervalElapsed() && this.frame != 1) {
                  --this.frame;
               }

               if(this.frame < 1) {
                  this.frame = 1;
               }
            } else if(this.ship.getEngineController().isAccelerating()) {
               if(this.interval.intervalElapsed() && this.frame != 16) {
                  ++this.frame;
               }

               if(this.frame > 16) {
                  this.frame = 16;
               }
            } else if(this.interval.intervalElapsed()) {
               if(this.frame > 7) {
                  --this.frame;
               } else if(this.frame != 7) {
                  ++this.frame;
               }
            }

            SpriteAPI var14 = Global.getSettings().getSprite("graphics/armaa/ships/valkazard/armaa_valkazard_legs0" + this.frame + ".png");
            if(this.frame >= 10) {
               var14 = Global.getSettings().getSprite("graphics/armaa/ships/valkazard/armaa_valkazard_legs" + this.frame + ".png");
            }

            this.rwep.getAnimation().setFrame(this.frame);
            MagicRender.singleframe(var14, new Vector2f(this.rwep.getLocation().getX(), this.rwep.getLocation().getY()), new Vector2f(var14.getWidth(), var14.getHeight()), this.ship.getFacing() - 90.0F, this.pauldronL.getSprite().getColor(), false, CombatEngineLayers.BELOW_SHIPS_LAYER);
            this.rwep.getSprite().setColor(new Color(0.0F, 0.0F, 0.0F, 0.0F));
         }

      }
   }
}
