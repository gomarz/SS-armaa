package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.combat.DeployedFleetMemberAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ViewportAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.util.MagicRender;
import java.awt.Color;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_AWACSCeylon implements EveryFrameWeaponEffectPlugin {

   private static final float[] COLOR_NORMAL = new float[]{1.0F, 0.39215687F, 0.078431375F};
   private static final float MAX_JITTER_DISTANCE = 0.2F;
   private static final float MAX_OPACITY = 1.0F;
   public static final float RANGE_BOOST = 100.0F;
   public static final float SPEED_BOOST = 15.0F;
   private static final float DAMAGE_MALUS = 0.8F;
   private static float EFFECT_RANGE = 2000.0F;
   public static final float ROTATION_SPEED = 5.0F;
   public static final Color COLOR = new Color(15, 215, 55, 200);
   private static final String AWACS_ID = "AWACS_ID";
   private float rotation = 0.0F;
   private float sfxOpacity = 0.0F;
   private int MAX_DRONES = 3;
   private SpriteAPI sprite = Global.getSettings().getSprite("misc", "armaa_ceylonrad");
   private List targetList = new ArrayList();
   private List enemyList = new ArrayList();
   private List deployedShips = new ArrayList();
   private static final EnumSet WEAPON_TYPES = EnumSet.of(WeaponType.MISSILE, WeaponType.BALLISTIC, WeaponType.ENERGY);
   private IntervalUtil interval = new IntervalUtil(5.0F, 5.0F);
   private boolean init = false;
   private boolean activated = false;
   public static float effectLevel = 0.25F;


   public static float getEffectLevel() {
      return effectLevel;
   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(var2 != null && !var2.isPaused()) {
         ShipAPI var4 = var3.getShip();
         if(var4 != null) {
            int var5 = var4.getOwner() == 0?1:0;
            this.interval.advance(var1);
            if(var5 == 0) {
               if(!this.init) {
                  this.deployedShips.addAll(Global.getCombatEngine().getFleetManager(var5).getAllEverDeployedCopy());
                  this.init = true;
               } else if(this.deployedShips.size() != Global.getCombatEngine().getFleetManager(var5).getAllEverDeployedCopy().size() && this.interval.intervalElapsed()) {
                  this.deployedShips.clear();
                  this.deployedShips.addAll(Global.getCombatEngine().getFleetManager(var5).getAllEverDeployedCopy());
                  ShipAPI var6 = ((DeployedFleetMemberAPI)Global.getCombatEngine().getFleetManager(var5).getAllEverDeployedCopy().get(Global.getCombatEngine().getFleetManager(var5).getAllEverDeployedCopy().size() - 1)).getShip();
                  String var7 = var6.getName();
                  if(!var6.isFighter()) {
                     String var8 = "\"" + var6.getHullSpec().getHullNameWithDashClass() + " approaching the AO from " + VectorUtils.getAngle(var4.getLocation(), var6.getLocation()) + " degrees.\"";
                     if(!MagicRender.screenCheck(0.2F, var4.getParentStation().getLocation())) {
                        Global.getCombatEngine().getCombatUI().addMessage(1, new Object[]{var4, Misc.getBasePlayerColor(), var4.getParentStation().getName(), Color.white, ":", Color.white, var8});
                     } else {
                        Global.getCombatEngine().addFloatingTextAlways(var4.getParentStation().getLocation(), var8, 30.0F, Color.white, var4, 0.0F, 0.0F, 1.0F, 3.0F, 2.0F, 0.0F);
                     }
                  }
               }
            }

            if(!var4.isHulk() && var4.isAlive()) {
               if(var4.getParentStation() != null) {
                  float var16 = 0.0F;
                  var16 = (float)var4.getDeployedDrones().size() / (float)this.MAX_DRONES;
                  effectLevel = Math.max(0.25F, var16);
                  boolean var17 = var4 == var2.getPlayerShip();
                  if(!var4.getSystem().isActive() && var17 && !var4.isHulk() && !var4.isPiece() && var4.isAlive() && var4.getSystem().isOutOfAmmo()) {
                     ;
                  }

                  ViewportAPI var18 = Global.getCombatEngine().getViewport();
                  float var9 = Global.getSettings().getScreenScaleMult();
                  float var10 = var4.getParentStation().getMutableStats().getSystemRangeBonus().computeEffective(EFFECT_RANGE);
                  if(var4.getParentStation().isFrigate() || var4.isDestroyer()) {
                     var10 = (float)((double)var10 * 0.75D);
                  }

                  Vector2f var11 = var4.getParentStation().getLocation();
                  float var12 = var10 * effectLevel * 2.0F;
                  if(var18.isNearViewport(var11, var10 * effectLevel)) {
                     MagicRender.singleframe(this.sprite, new Vector2f(var11.getX(), var11.getY()), new Vector2f(var12, var12), this.rotation, var4.getOwner() == 0?COLOR:new Color(215, 21, 16, 186), false, CombatEngineLayers.BELOW_SHIPS_LAYER);
                  }

                  this.rotation += 5.0F * var1;
                  if(this.rotation > 360.0F) {
                     this.rotation -= 360.0F;
                  }

                  Iterator var13 = CombatUtils.getShipsWithinRange(var4.getLocation(), var10 * effectLevel).iterator();

                  while(var13.hasNext()) {
                     ShipAPI var14 = (ShipAPI)var13.next();
                     if(var14.getOwner() == var4.getOwner() && !this.targetList.contains(var14)) {
                        this.targetList.add(var14);
                     } else if(var14.getOwner() != var4.getOwner() && !var14.isHulk() && !this.enemyList.contains(var14)) {
                        this.enemyList.add(var14);
                     }
                  }

                  ArrayList var19 = new ArrayList();
                  Iterator var20 = this.targetList.iterator();

                  ShipAPI var15;
                  while(var20.hasNext()) {
                     var15 = (ShipAPI)var20.next();
                     if(MathUtils.getDistance(var15.getLocation(), var4.getLocation()) <= var10 * effectLevel) {
                        if(!var4.getParentStation().getVariant().hasHullMod("fourteenth")) {
                           var15.getMutableStats().getEnergyWeaponRangeBonus().modifyFlat("AWACS_ID", 100.0F);
                           var15.getMutableStats().getBallisticWeaponRangeBonus().modifyFlat("AWACS_ID", 100.0F);
                        } else {
                           var15.getMutableStats().getMaxSpeed().modifyPercent("AWACS_ID", 15.0F);
                        }

                        if(var4.getSystem() != null && var4.getSystem().isActive()) {
                           ;
                        }
                     } else {
                        var15.getMutableStats().getEnergyWeaponRangeBonus().unmodify("AWACS_ID");
                        var15.getMutableStats().getBallisticWeaponRangeBonus().unmodify("AWACS_ID");
                        var15.getMutableStats().getAutofireAimAccuracy().unmodify("AWACS_ID");
                        var15.getMutableStats().getProjectileSpeedMult().unmodify("AWACS_ID");
                        var15.getMutableStats().getMaxSpeed().unmodify("AWACS_ID");
                        var19.add(var15);
                     }
                  }

                  if(var4.getParentStation().getSystem() != null && var4.getParentStation().getSystem().isActive()) {
                     if(var4.getParentStation().getVariant().hasHullMod("fourteenth") && !this.activated) {
                        var20 = CombatUtils.getMissilesWithinRange(var4.getLocation(), var10 * effectLevel).iterator();

                        while(var20.hasNext()) {
                           MissileAPI var21 = (MissileAPI)var20.next();
                           if(var21.getOwner() != var4.getOwner()) {
                              var21.getVelocity().setX(var21.getVelocity().x / 2.0F);
                              var21.getVelocity().setY(var21.getVelocity().y / 2.0F);
                           }
                        }
                     }

                     var20 = this.enemyList.iterator();

                     while(var20.hasNext()) {
                        var15 = (ShipAPI)var20.next();
                        if(var15.isAlive() && MathUtils.getDistance(var15.getLocation(), var4.getLocation()) <= var10 * effectLevel) {
                           if(!var4.getParentStation().getVariant().hasHullMod("fourteenth")) {
                              if(!this.activated && !Global.getCombatEngine().hasAttachedFloaty(var15)) {
                                 Global.getCombatEngine().addFloatingTextAlways(var15.getLocation(), "Damage Reduced!", 30.0F, Color.orange, var15, 0.0F, 0.0F, 1.0F, 3.0F, 2.0F, 0.0F);
                              }

                              var15.getMutableStats().getEnergyWeaponDamageMult().modifyMult("AWACS_ID", 0.8F);
                              var15.getMutableStats().getBallisticWeaponDamageMult().modifyMult("AWACS_ID", 0.8F);
                              var15.getMutableStats().getMissileWeaponDamageMult().modifyMult("AWACS_ID", 0.8F);
                           }
                        } else {
                           var15.getMutableStats().getEnergyWeaponDamageMult().unmodify("AWACS_ID");
                           var15.getMutableStats().getBallisticWeaponDamageMult().unmodify("AWACS_ID");
                           var15.getMutableStats().getMissileWeaponDamageMult().unmodify("AWACS_ID");
                           var19.add(var15);
                        }
                     }

                     this.activated = true;
                  }

                  if(!var4.getParentStation().getSystem().isActive()) {
                     this.activated = false;
                  }

                  var20 = var19.iterator();

                  while(var20.hasNext()) {
                     var15 = (ShipAPI)var20.next();
                     this.targetList.remove(var15);
                  }

               }
            }
         }
      }
   }

}
