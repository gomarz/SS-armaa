package data.scripts.weapons;

import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.BeamEffectPlugin;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;

public class armaa_targetPainter_BeamEffect implements BeamEffectPlugin {

   private static final float EXPLOSION_MULTIPLIER = 2.0F;
   private static final float FOCUS_TIME = 1.0F;
   private float timer = 0.0F;
   private boolean wasZero = true;
   private static final int TEXTURE_LENGTH = 128;


   public void advance(float var1, CombatEngineAPI var2, BeamAPI var3) {
      CombatEntityAPI var4 = var3.getDamageTarget();
      float var5 = var3.getDamage().getDpsDuration();
      if(var4 != null) {
         if(!this.wasZero) {
            var5 = 0.0F;
         }

         this.wasZero = var3.getDamage().getDpsDuration() <= 0.0F;
         if(var3.getSource() != null) {
            var5 *= var3.getSource().getMutableStats().getEnergyRoFMult().getModifiedValue();
         }

         this.timer += var5;
         if(this.timer > 1.0F) {
            float var6 = Misc.random.nextFloat() * 0.1F + 0.95F;
            this.timer -= 1.0F * var6;
            this.spawnExplosion(var2, var3, var4);
         }
      }

      this.setInterruptedBeamLength(var3, var4, 156.0F);
   }

   private void setInterruptedBeamLength(BeamAPI var1, CombatEntityAPI var2, float var3) {
      if(var1 != null) {
         float var4 = MathUtils.getDistance(var1.getTo(), var1.getFrom()) + 4.0F;
         if(var2 == null) {
            var4 += var1.getLength() * 0.5F;
         }

         var1.setPixelsPerTexel(var4 / var3);
      }
   }

   private void spawnExplosion(CombatEngineAPI var1, BeamAPI var2, CombatEntityAPI var3) {
      float var4 = var2.getDamage().getDamage() * 2.0F;
      Color var5 = var2.getFringeColor();
      var1.spawnExplosion(var2.getTo(), var3.getVelocity(), var5, var4 * 0.5F, 0.75F);
      if((float)Math.random() <= 0.5F) {
         var1.addNebulaParticle(var2.getTo(), var3.getVelocity(), var4 * 0.5F * (0.75F + (float)Math.random() * 0.5F), MathUtils.getRandomNumberInRange(1.0F, 3.0F), 0.0F, 0.0F, 1.0F, new Color(var2.getFringeColor().getRed(), var2.getFringeColor().getGreen(), var2.getFringeColor().getBlue(), 100), true);
      }

      var1.spawnDamagingExplosion(this.getExplosion(var4, var2.getFringeColor(), var2.getCoreColor()), var2.getSource(), var2.getTo(), true);
   }

   private DamagingExplosionSpec getExplosion(float var1, Color var2, Color var3) {
      float var4 = var1 * 0.5F;
      DamagingExplosionSpec var5 = new DamagingExplosionSpec(0.1875F, var4, var4 * 0.5F, var1, var1 * 0.5F, CollisionClass.PROJECTILE_FF, CollisionClass.PROJECTILE_FIGHTER, 3.0F, 5.0F, 1.5F, Math.round(var1 * 0.2F), var3, var2);
      var5.setDamageType(DamageType.FRAGMENTATION);
      var5.setShowGraphic(false);
      return var5;
   }
}
