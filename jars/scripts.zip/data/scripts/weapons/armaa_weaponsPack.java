package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;

public class armaa_weaponsPack implements EveryFrameWeaponEffectPlugin {

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      ShipAPI var4 = var3.getShip();
      if(var4.getParentStation() != null) {
         ShipAPI var5 = var4.getParentStation();
         if(!var4.isAlive()) {
            var5.getMutableStats().getMaxSpeed().unmodify(var4.getId() + "_weaponsPack");
            var5.getMutableStats().getMaxTurnRate().unmodify(var4.getId() + "_weaponsPack");
            var5.getMutableStats().getTurnAcceleration().unmodify(var4.getId() + "_weaponsPack");
         } else {
            var5.getPhaseCloak().setCooldownRemaining(1.0F);
            var5.getSystem().setCooldownRemaining(1.0F);
            var5.getMutableStats().getMaxSpeed().modifyMult(var4.getId() + "_weaponsPack", 0.6F);
            var5.getMutableStats().getMaxTurnRate().modifyMult(var4.getId() + "_weaponsPack", 0.6F);
            var5.getMutableStats().getTurnAcceleration().modifyMult(var4.getId() + "_weaponsPack", 0.6F);
         }
      }
   }
}
