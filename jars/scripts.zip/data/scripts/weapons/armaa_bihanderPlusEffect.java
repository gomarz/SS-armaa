package data.scripts.weapons;

import com.fs.starfarer.api.AnimationAPI;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_bihanderPlusEffect implements EveryFrameWeaponEffectPlugin {

   private boolean runOnce = false;
   private boolean lockNloaded = false;
   private ShipSystemAPI system;
   private ShipAPI ship;
   private SpriteAPI sprite;
   private AnimationAPI anim;
   private AnimationAPI aGlow;
   private AnimationAPI aGlow2;
   private WeaponAPI head;
   private WeaponAPI armL;
   private WeaponAPI armR;
   private WeaponAPI pauldronL;
   private WeaponAPI pauldronR;
   private WeaponAPI torso;
   private WeaponAPI wGlow;
   private WeaponAPI cannon;
   public float TURRET_OFFSET = 30.0F;
   private float delay = 0.1F;
   private float timer = 0.0F;
   private float SPINUP = 0.02F;
   private float SPINDOWN = 10.0F;
   private final IntervalUtil interval = new IntervalUtil(0.015F, 0.015F);
   private float level = 0.0F;
   private int limbInit = 0;
   private float overlap = 0.0F;
   private float heat = 0.0F;
   private final float TORSO_OFFSET = -45.0F;
   private final float LEFT_ARM_OFFSET = -75.0F;
   private final float RIGHT_ARM_OFFSET = -25.0F;
   private final float MAX_OVERLAP = 10.0F;


   public void init() {
      this.runOnce = true;
      this.ship.setCollisionClass(CollisionClass.FIGHTER);
      Iterator var1 = this.ship.getAllWeapons().iterator();

      while(var1.hasNext()) {
         WeaponAPI var2 = (WeaponAPI)var1.next();
         String var3 = var2.getSlot().getId();
         byte var4 = -1;
         switch(var3.hashCode()) {
         case -1726101283:
            if(var3.equals("WS0001")) {
               var4 = 7;
            }
            break;
         case -6931076:
            if(var3.equals("D_PAULDRONL")) {
               var4 = 3;
            }
            break;
         case -6931070:
            if(var3.equals("D_PAULDRONR")) {
               var4 = 4;
            }
            break;
         case 1245480854:
            if(var3.equals("B_TORSO")) {
               var4 = 0;
            }
            break;
         case 2007905292:
            if(var3.equals("C_ARML")) {
               var4 = 1;
            }
            break;
         case 2007905298:
            if(var3.equals("C_ARMR")) {
               var4 = 2;
            }
            break;
         case 2065359258:
            if(var3.equals("E_HEAD")) {
               var4 = 6;
            }
            break;
         case 2093965798:
            if(var3.equals("F_GLOW")) {
               var4 = 5;
            }
         }

         switch(var4) {
         case 0:
            if(this.torso == null) {
               this.torso = var2;
               ++this.limbInit;
            }
            break;
         case 1:
            if(this.armL == null) {
               this.armL = var2;
               ++this.limbInit;
            }
            break;
         case 2:
            if(this.armR == null) {
               this.armR = var2;
               ++this.limbInit;
            }
            break;
         case 3:
            if(this.pauldronL == null) {
               this.pauldronL = var2;
               ++this.limbInit;
            }
            break;
         case 4:
            if(this.pauldronR == null) {
               this.pauldronR = var2;
               ++this.limbInit;
            }
            break;
         case 5:
            if(this.wGlow == null) {
               this.wGlow = var2;
               this.aGlow = var2.getAnimation();
               ++this.limbInit;
            }
            break;
         case 6:
            if(this.head == null) {
               this.head = var2;
               ++this.limbInit;
            }
            break;
         case 7:
            if(this.cannon == null) {
               this.cannon = var2;
               ++this.limbInit;
            }
         }
      }

   }

   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      this.ship = var3.getShip();
      this.sprite = this.ship.getSpriteAPI();
      this.system = this.ship.getSystem();
      this.anim = var3.getAnimation();
      this.init();
      if(this.runOnce && this.limbInit == 8) {
         if(this.ship.getEngineController().isAccelerating()) {
            if(this.overlap > 9.9F) {
               this.overlap = 10.0F;
            } else {
               this.overlap = Math.min(10.0F, this.overlap + (10.0F - this.overlap) * var1 * 5.0F);
            }
         } else if(!this.ship.getEngineController().isDecelerating() && !this.ship.getEngineController().isAcceleratingBackwards()) {
            if(Math.abs(this.overlap) < 0.1F) {
               this.overlap = 0.0F;
            } else {
               this.overlap -= this.overlap / 2.0F * var1 * 3.0F;
            }
         } else if(this.overlap < -9.9F) {
            this.overlap = -10.0F;
         } else {
            this.overlap = Math.max(-10.0F, this.overlap + (-10.0F + this.overlap) * var1 * 5.0F);
         }

         float var4 = 0.0F;
         float var5 = 0.0F;
         float var6 = this.ship.getFacing();
         float var7 = MathUtils.getShortestRotation(var6, var3.getCurrAngle());
         this.torso.setCurrAngle(var6 + var4 * -45.0F + var7 * 0.3F);
         this.armR.setCurrAngle(var3.getCurrAngle() + -25.0F);
         this.pauldronR.setCurrAngle(var6 + var4 * -45.0F * 0.5F + var7 * 0.75F + -12.5F);
         if((double)(this.ship.getHitpoints() / this.ship.getMaxHitpoints()) <= 0.5D) {
            this.ship.syncWeaponDecalsWithArmorDamage();
         }

         Vector2f var8 = new Vector2f(var3.getLocation());
         Vector2f var9 = new Vector2f(this.TURRET_OFFSET, -15.0F);
         VectorUtils.rotate(var9, var3.getCurrAngle(), var9);
         Vector2f.add(var9, var8, var8);
         float var10 = var3.getCurrAngle();
         Vector2f var11 = this.ship.getVelocity();
         if(this.armL != null) {
            this.armL.setCurrAngle(var6 + (var7 + -75.0F) * var5 + (this.overlap + var7 * 0.25F) * (1.0F - var5));
         }

         if(this.pauldronL != null) {
            this.pauldronL.setCurrAngle(this.torso.getCurrAngle() + MathUtils.getShortestRotation(this.torso.getCurrAngle(), this.armL.getCurrAngle()) * 0.6F);
         }

         if(this.wGlow != null) {
            this.wGlow.setCurrAngle(var3.getCurrAngle());
         }

      }
   }
}
