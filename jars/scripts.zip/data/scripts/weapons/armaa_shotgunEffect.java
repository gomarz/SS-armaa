package data.scripts.weapons;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.OnHitEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.listeners.ApplyDamageResultAPI;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_shotgunEffect implements OnHitEffectPlugin {

   private final Color PARTICLE_COLOR = new Color(255, 0, 0);
   private final float PARTICLE_SIZE = 4.0F;
   private final float PARTICLE_BRIGHTNESS = 150.0F;
   private final float PARTICLE_DURATION = 1.0F;
   private static final int PARTICLE_COUNT = 1;
   private final int max = 40;
   private final int min = 10;
   private final Color EMP_COLOR = new Color(250, 236, 40);
   private static final float VEL_MIN = 0.1F;
   private static final float VEL_MAX = 0.15F;
   private static final float CONE_ANGLE = 150.0F;
   private static final float A_2 = 75.0F;
   private static final float PUSH_CONSTANT = 300.0F;
   private final Color FLASH_COLOR = new Color(255, 10, 20);


   public void onHit(DamagingProjectileAPI var1, CombatEntityAPI var2, Vector2f var3, boolean var4, ApplyDamageResultAPI var5, CombatEngineAPI var6) {
      float var7;
      if(var2 instanceof ShipAPI) {
         var7 = ((ShipAPI)var2).getMassWithModules();
      } else {
         var7 = var2.getMass();
      }

      if(var7 == 0.0F) {
         var7 = 1.0F;
      }

      Vector2f var8 = Vector2f.sub(var2.getLocation(), var1.getLocation(), new Vector2f());
      if(var8.lengthSquared() > 0.0F) {
         var8.normalise();
      }

      float var9 = 300.0F / var7;
      Vector2f.add((Vector2f)var8.scale(var9), var2.getVelocity(), var2.getVelocity());
      float var10 = var1.getEmpAmount();
      float var11 = var1.getDamageAmount();
      if(MagicRender.screenCheck(0.2F, var3)) {
         if((float)Math.random() >= 0.9F) {
            var6.addSmoothParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 200.0F, 2.0F, 0.15F, Color.white);
            var6.addHitParticle(var1.getLocation(), new Vector2f(0.0F, 0.0F), 100.0F, 1.0F, 0.4F, new Color(200, 100, 25));
            var6.spawnExplosion(var1.getLocation(), new Vector2f(0.0F, 0.0F), Color.DARK_GRAY, 125.0F, 1.0F);
            var6.spawnExplosion(var1.getLocation(), new Vector2f(0.0F, 0.0F), Color.BLACK, 300.0F, 2.0F);
         }

         float var12 = var1.getVelocity().length();
         float var13 = var1.getFacing();

         for(int var14 = 0; var14 <= 1; ++var14) {
            float var15 = MathUtils.getRandomNumberInRange(var13 - 75.0F, var13 + 75.0F);
            float var16 = MathUtils.getRandomNumberInRange(var12 * -0.1F, var12 * -0.15F);
            Vector2f var17 = MathUtils.getPointOnCircumference((Vector2f)null, var16, var15);
            var6.addHitParticle(var3, var17, 4.0F, 150.0F, 1.0F, this.EMP_COLOR);
         }
      }

   }
}
