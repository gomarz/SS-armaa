package data.scripts.weapons;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CombatAssignmentType;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DeployedFleetMemberAPI;
import com.fs.starfarer.api.combat.EveryFrameWeaponEffectPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.CombatFleetManagerAPI.AssignmentInfo;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import java.awt.Color;
import java.util.ArrayList;
import java.util.List;
import org.lwjgl.util.vector.Vector2f;

public class armaa_beamConvergeEffect implements EveryFrameWeaponEffectPlugin {

   private static final Color CHARGEUP_PARTICLE_COLOR = new Color(130, 190, 160, 100);
   private static final float CHARGEUP_PARTICLE_DISTANCE_MIN = 4.0F;
   private static final float CHARGEUP_PARTICLE_DISTANCE_MAX = 60.0F;
   private static final float CHARGEUP_PARTICLE_SIZE_MIN = 1.0F;
   private static final float CHARGEUP_PARTICLE_SIZE_MAX = 4.0F;
   private static final float CHARGEUP_PARTICLE_ANGLE_SPREAD = 180.0F;
   private static final float CHARGEUP_PARTICLE_DURATION = 0.2F;
   private static final float CHARGEUP_PARTICLE_COUNT_FACTOR = 5.0F;
   private static final float CHARGEUP_PARTICLE_BRIGHTNESS = 0.7F;
   private static final Vector2f ZERO = new Vector2f();
   public static final float MAX_OFFSET = 5.0F;
   public static final float SWEEP_INTERVAL = 1.5F;
   private List ANGLES = new ArrayList();
   protected float timer = 0.0F;
   protected int dir = 1;
   private float last_charge_level = 0.0F;
   private boolean charging = false;
   private boolean firing = false;
   private boolean restart = true;
   private boolean runOnce = false;
   ShipAPI wingman;


   public void advance(float var1, CombatEngineAPI var2, WeaponAPI var3) {
      if(!var2.isPaused()) {
         ShipAPI var4 = var3.getShip();
         if(var3.isFiring() && this.wingman == null) {
            this.wingman = Global.getCombatEngine().getFleetManager(var3.getShip().getOwner()).spawnShipOrWing("armaa_valkenmp_wing", var3.getLocation(), var3.getCurrAngle());
         }

         if(this.wingman != null && var4.getShipTarget() != null && var4.getShipTarget() != this.wingman.getShipTarget()) {
            DeployedFleetMemberAPI var5 = Global.getCombatEngine().getFleetManager(var4.getShipTarget().getOwner()).getDeployedFleetMember(var4.getShipTarget());

            for(int var7 = 0; var7 < 3; ++var7) {
               ShipAPI var8 = (ShipAPI)this.wingman.getWing().getWingMembers().get(var7);
               DeployedFleetMemberAPI var9 = Global.getCombatEngine().getFleetManager(var4.getOwner()).getDeployedFleetMember(var8);
               ((ShipAPI)this.wingman.getWing().getWingMembers().get(var7)).getAIFlags().setFlag(AIFlags.CARRIER_FIGHTER_TARGET, 1.0F, Integer.valueOf(var4.getShipTarget().getOwner()));
               ((ShipAPI)this.wingman.getWing().getWingMembers().get(var7)).getAIFlags().setFlag(AIFlags.CARRIER_FIGHTER_TARGET, 1.0F, Integer.valueOf(var4.getShipTarget().getOwner()));
               AssignmentInfo var6 = Global.getCombatEngine().getFleetManager(var3.getShip().getOwner()).getTaskManager(true).createAssignment(CombatAssignmentType.LIGHT_ESCORT, var5, false);
               Global.getCombatEngine().getFleetManager(var4.getOwner()).getTaskManager(true).giveAssignment(var9, var6, false);
            }
         }

      }
   }

}
