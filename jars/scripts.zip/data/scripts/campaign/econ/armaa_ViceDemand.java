package data.scripts.campaign.econ;

import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class armaa_ViceDemand extends BaseMarketConditionPlugin {

   public void apply(String var1) {
      this.market.getDemand("drugs").getDemand().modifyFlat(var1, Math.max(10.0F, (float)this.market.getSize() * 5.0F));
   }

   public void unapply(String var1) {
      this.market.getDemand("drugs").getDemand().unmodify(var1);
   }

   protected void createTooltipAfterDescription(TooltipMakerAPI var1, boolean var2) {
      super.createTooltipAfterDescription(var1, var2);
      var1.addPara("%s demand", 10.0F, Misc.getHighlightColor(), new String[]{"-" + (int)this.market.getDemand("drugs").getDemand().getBaseValue()});
   }
}
