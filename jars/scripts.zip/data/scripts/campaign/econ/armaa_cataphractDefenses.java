package data.scripts.campaign.econ;

import com.fs.starfarer.api.impl.campaign.econ.BaseMarketConditionPlugin;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;

public class armaa_cataphractDefenses extends BaseMarketConditionPlugin {

   public static final float DEFENSE_BONUS = 20.0F;


   public void apply(String var1) {
      super.apply(var1);
      this.market.getStats().getDynamic().getMod("ground_defenses_mod").modifyMult(var1, 1.2F, "Cataphract Defense Force");
   }

   public void unapply(String var1) {
      super.unapply(var1);
      this.market.getStats().getDynamic().getMod("ground_defenses_mod").unmodify(var1);
   }

   protected void createTooltipAfterDescription(TooltipMakerAPI var1, boolean var2) {
      super.createTooltipAfterDescription(var1, var2);
      if(this.market != null) {
         var1.addPara("%s ground defenses.", 10.0F, Misc.getHighlightColor(), new String[]{"+20"});
      }
   }
}
