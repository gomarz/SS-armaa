package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.econ.Industry;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.campaign.listeners.ColonyPlayerHostileActListener;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.MarketCMD.TempData;
import com.fs.starfarer.api.util.Misc;
import data.hullmods.cataphract;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;

public class armaa_raid implements ColonyPlayerHostileActListener {

   private static float BASE_DAMAGE_CHANCE = 0.35F;


   public void reportRaidForValuablesFinishedBeforeCargoShown(InteractionDialogAPI var1, MarketAPI var2, TempData var3, CargoAPI var4) {
      handleRaid(var1, var2, "Deployment", var3);
   }

   public void reportRaidToDisruptFinished(InteractionDialogAPI var1, MarketAPI var2, TempData var3, Industry var4) {
      handleRaid(var1, var2, "Deployment", var3);
   }

   public void reportTacticalBombardmentFinished(InteractionDialogAPI var1, MarketAPI var2, TempData var3) {}

   public void reportSaturationBombardmentFinished(InteractionDialogAPI var1, MarketAPI var2, TempData var3) {}

   public static String getMagnitude(float var0, float var1) {
      float var2 = var1 / var0;
      return var2 <= 1.25F && var2 >= 0.5F?"moderate":(var2 > 1.25F && var2 < 2.0F?"heavy":(var2 > 2.0F?"fierce":"minor"));
   }

   private static void handleRaid(InteractionDialogAPI var0, MarketAPI var1, String var2, TempData var3) {
      CampaignFleetAPI var4 = Global.getSector().getPlayerFleet();
      if(var4 != null) {
         float var5 = var3.attackerStr;
         float var6 = var3.defenderStr;
         List var7 = var4.getFleetData().getMembersListCopy();
         Collections.shuffle(var7);
         Iterator var8 = var7.iterator();

         while(var8.hasNext()) {
            FleetMemberAPI var9 = (FleetMemberAPI)var8.next();
            if(!var9.isMothballed() && (var9.getHullSpec().getBuiltInMods().contains("cataphract") || var9.getHullSpec().getBuiltInMods().contains("cataphract2")) && var9.getRepairTracker().getCR() >= cataphract.getCRPenalty(var9.getVariant())) {
               if(var0 != null && var0.getTextPanel() != null) {
                  String var10 = "" + Math.round(-cataphract.getCRPenalty(var9.getVariant()) * 100.0F) + "%";
                  if(var9.getCaptain().isPlayer()) {
                     var0.getTextPanel().addPara("You assisted on this op using the " + var9.getShipName() + ", an " + var9.getHullSpec().getHullNameWithDashClass() + " " + var9.getHullSpec().getDesignation() + " you personally pilot.", Misc.getHighlightColor(), new String[]{var9.getShipName(), var9.getHullSpec().getHullNameWithDashClass(), var9.getHullSpec().getDesignation()});
                     var0.getTextPanel().addPara(var9.getShipName() + ": " + var10 + "% CR", Misc.getNegativeHighlightColor(), new String[]{var10});
                  } else {
                     var0.getTextPanel().addPara(var9.getShipName() + " was deployed: " + var10 + "% CR", Misc.getNegativeHighlightColor(), new String[]{var10});
                  }

                  if(Math.random() <= (double)(BASE_DAMAGE_CHANCE * (var6 / var5))) {
                     String var11 = getMagnitude(var5, var6);
                     float var12 = var9.getCaptain().isDefault()?1.0F:(float)var9.getCaptain().getStats().getLevel();
                     float var13 = Math.min(MathUtils.getRandomNumberInRange(0.01F, 0.7F * (var6 / var5)) / var12, 0.99F);
                     String var14 = "" + Math.round(var13 * 100.0F) + "%";
                     var0.getTextPanel().addPara(var9.getShipName() + " encountered " + var11 + " resistance! Took " + var14 + "% damage.", Misc.getNegativeHighlightColor(), Misc.getHighlightColor(), new String[]{var11, var14});
                     var9.getStatus().applyHullFractionDamage(var13);
                  }
               }

               var9.getRepairTracker().applyCREvent(-cataphract.getCRPenalty(var9.getVariant()), "armaa_raid", var2 + " in support of military op at " + var1.getName());
               break;
            }
         }

      }
   }

}
