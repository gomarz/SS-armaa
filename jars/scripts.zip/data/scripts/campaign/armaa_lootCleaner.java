package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.campaign.listeners.ShowLootListener;
import data.hullmods.armaa_leynosWeaponSwap;
import data.hullmods.armaa_weaponSwap;
import java.util.Iterator;

public class armaa_lootCleaner implements ShowLootListener {

   public void reportAboutToShowLootToPlayer(CargoAPI var1, InteractionDialogAPI var2) {
      armaa_weaponSwap var3 = new armaa_weaponSwap();
      armaa_leynosWeaponSwap var4 = new armaa_leynosWeaponSwap();
      Iterator var5 = var1.getStacksCopy().iterator();

      while(var5.hasNext()) {
         CargoStackAPI var6 = (CargoStackAPI)var5.next();
         if(var6.isWeaponStack() && (var3.LEFT_SELECTOR.containsValue(var6.getWeaponSpecIfWeapon().getWeaponId()) || var3.RIGHT_SELECTOR.containsValue(var6.getWeaponSpecIfWeapon().getWeaponId()))) {
            var1.removeStack(var6);
         }

         if(var6.isWeaponStack() && (var4.LEFT_SELECTOR.containsValue(var6.getWeaponSpecIfWeapon().getWeaponId()) || var4.RIGHT_SELECTOR.containsValue(var6.getWeaponSpecIfWeapon().getWeaponId()))) {
            var1.removeStack(var6);
         }
      }

      CargoAPI var8 = Global.getSector().getPlayerFleet().getCargo();
      Iterator var9 = Global.getSector().getPlayerFleet().getCargo().getStacksCopy().iterator();

      while(var9.hasNext()) {
         CargoStackAPI var7 = (CargoStackAPI)var9.next();
         if(var7.isWeaponStack() && (var3.LEFT_SELECTOR.containsValue(var7.getWeaponSpecIfWeapon().getWeaponId()) || var3.RIGHT_SELECTOR.containsValue(var7.getWeaponSpecIfWeapon().getWeaponId()))) {
            var8.removeStack(var7);
         }

         if(var7.isWeaponStack() && (var4.LEFT_SELECTOR.containsValue(var7.getWeaponSpecIfWeapon().getWeaponId()) || var4.RIGHT_SELECTOR.containsValue(var7.getWeaponSpecIfWeapon().getWeaponId()))) {
            var8.removeStack(var7);
         }
      }

   }
}
