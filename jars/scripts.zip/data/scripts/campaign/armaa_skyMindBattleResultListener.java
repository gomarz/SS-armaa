package data.scripts.campaign;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.EngagementResultForFleetAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.FleetEncounterContextPlugin.DataForEncounterSide;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class armaa_skyMindBattleResultListener extends BaseCampaignEventListener implements EveryFrameScript {

   static long previousXP = Long.MAX_VALUE;
   private Float repRewardPerson = null;
   private Float repPenaltyPerson = null;
   private Float repRewardFaction = null;
   transient int numEngagements = 0;
   Float repPenaltyFaction = null;
   RepLevel rewardLimitPerson = null;
   RepLevel rewardLimitFaction = null;
   RepLevel penaltyLimitPerson = null;
   RepLevel penaltyLimitFaction = null;
   transient int memberToPromote;
   transient boolean isWin = false;
   transient boolean canPromote = false;
   transient Map promoteablePilots = new HashMap();
   transient EngagementResultAPI batResult;


   public armaa_skyMindBattleResultListener() {
      super(true);
   }

   public void advance(float var1) {}

   public boolean runWhilePaused() {
      return false;
   }

   public boolean isDone() {
      return false;
   }

   public DataForEncounterSide getDataFor(CampaignFleetAPI var1, BattleAPI var2, List var3) {
      CampaignFleetAPI var4 = var2.getCombinedFor(var1);
      if(var4 == null) {
         return new DataForEncounterSide(var1);
      } else {
         Iterator var5 = var3.iterator();

         DataForEncounterSide var6;
         do {
            if(!var5.hasNext()) {
               DataForEncounterSide var7 = new DataForEncounterSide(var4);
               var3.add(var7);
               return var7;
            }

            var6 = (DataForEncounterSide)var5.next();
         } while(var6.getFleet() != var4);

         return var6;
      }
   }

   protected void clearNoSourceMembers(EngagementResultForFleetAPI var1, BattleAPI var2) {
      Iterator var3 = var1.getDeployed().iterator();

      FleetMemberAPI var4;
      while(var3.hasNext()) {
         var4 = (FleetMemberAPI)var3.next();
         if(var2.getSourceFleet(var4) == null) {
            var3.remove();
         }
      }

      var3 = var1.getReserves().iterator();

      while(var3.hasNext()) {
         var4 = (FleetMemberAPI)var3.next();
         if(var2.getSourceFleet(var4) == null) {
            var3.remove();
         }
      }

      var3 = var1.getDestroyed().iterator();

      while(var3.hasNext()) {
         var4 = (FleetMemberAPI)var3.next();
         if(var2.getSourceFleet(var4) == null) {
            var3.remove();
         }
      }

      var3 = var1.getDisabled().iterator();

      while(var3.hasNext()) {
         var4 = (FleetMemberAPI)var3.next();
         if(var2.getSourceFleet(var4) == null) {
            var3.remove();
         }
      }

      var3 = var1.getRetreated().iterator();

      while(var3.hasNext()) {
         var4 = (FleetMemberAPI)var3.next();
         if(var2.getSourceFleet(var4) == null) {
            var3.remove();
         }
      }

   }

   public void reportPlayerEngagement(EngagementResultAPI var1) {
      this.batResult = var1;
      ++this.numEngagements;
   }

   public void reportBattleOccurred(CampaignFleetAPI var1, BattleAPI var2) {
      if(var2.isPlayerInvolved() && this.batResult != null) {
         ArrayList var3 = new ArrayList();
         EngagementResultForFleetAPI var4 = this.batResult.getWinnerResult();
         EngagementResultForFleetAPI var5 = this.batResult.getLoserResult();
         this.clearNoSourceMembers(var4, var2);
         this.clearNoSourceMembers(var5, var2);
         this.getDataFor(var4.getFleet(), var2, var3);
         this.getDataFor(var5.getFleet(), var2, var3);
         EngagementResultForFleetAPI var8 = var5.isPlayer()?var4:var5;
         EngagementResultForFleetAPI var9 = var5.isPlayer()?var5:var4;
         ArrayList var10 = new ArrayList();
         var10.addAll(var9.getDestroyed());
         var10.addAll(var9.getDisabled());
         Iterator var11 = var10.iterator();

         while(var11.hasNext()) {
            FleetMemberAPI var12 = (FleetMemberAPI)var11.next();
            if(var12.getVariant().getHullMods().contains("armaa_skyMindAlpha")) {
               var12.getVariant().removeMod("armaa_skyMindAlpha");
            } else if(var12.getVariant().getHullMods().contains("armaa_skyMindBeta")) {
               var12.getVariant().removeMod("armaa_skyMindBeta");
            } else if(var12.getVariant().getHullMods().contains("armaa_skyMindGamma")) {
               var12.getVariant().removeMod("armaa_skyMindGamma");
            }
         }

         this.batResult = null;
         var10.clear();
         this.numEngagements = 0;
      }
   }

}
