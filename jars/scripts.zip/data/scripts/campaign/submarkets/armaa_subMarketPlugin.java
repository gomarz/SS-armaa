package data.scripts.campaign.submarkets;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.campaign.CoreUIAPI;
import com.fs.starfarer.api.campaign.FactionDoctrineAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.FactionAPI.ShipPickMode;
import com.fs.starfarer.api.campaign.SubmarketPlugin.TransferAction;
import com.fs.starfarer.api.campaign.econ.SubmarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.submarkets.BaseSubmarketPlugin;
import com.fs.starfarer.api.util.Misc;

public class armaa_subMarketPlugin extends BaseSubmarketPlugin {

   private final RepLevel MIN_STANDING;


   public armaa_subMarketPlugin() {
      this.MIN_STANDING = RepLevel.FAVORABLE;
   }

   public void init(SubmarketAPI var1) {
      super.init(var1);
      this.getCargo().addHullmods("armaa_wingCommander", 1);
   }

   public float getTariff() {
      return Misc.getCommissionFactionId() == "tritachyon"?0.35F:0.3F;
   }

   public String getTooltipAppendix(CoreUIAPI var1) {
      RepLevel var2 = this.market.getFaction().getRelationshipLevel(Global.getSector().getFaction("player"));
      return super.getTooltipAppendix(var1);
   }

   public boolean isEnabled(CoreUIAPI var1) {
      return true;
   }

   public void updateCargoPrePlayerInteraction() {
      this.sinceLastCargoUpdate = 0.0F;
      if(this.okToUpdateShipsAndWeapons()) {
         this.sinceSWUpdate = 0.0F;
         this.getCargo().getMothballedShips().clear();
         float var1 = 0.1F;
         FactionDoctrineAPI var2 = this.submarket.getFaction().getDoctrine().clone();
         this.addShips(this.submarket.getFaction().getId(), 125.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, (Float)null, 0.0F, ShipPickMode.PRIORITY_THEN_ALL, var2);
         this.pruneWeapons(0.0F);
         this.addWeapons(3, 10, 5, this.submarket.getFaction().getId());
         this.addFighters(3, 10, 5, this.submarket.getFaction().getId());
         this.pruneShips(0.5F);
      }

      this.getCargo().sort();
   }

   public boolean isIllegalOnSubmarket(CargoStackAPI var1, TransferAction var2) {
      return var2 == TransferAction.PLAYER_SELL;
   }

   public boolean isIllegalOnSubmarket(String var1, TransferAction var2) {
      return var2 == TransferAction.PLAYER_SELL;
   }

   public boolean isIllegalOnSubmarket(FleetMemberAPI var1, TransferAction var2) {
      return var2 == TransferAction.PLAYER_SELL;
   }

   public String getIllegalTransferText(FleetMemberAPI var1, TransferAction var2) {
      return "Sales only!";
   }

   public String getIllegalTransferText(CargoStackAPI var1, TransferAction var2) {
      return "Sales only!";
   }

   public boolean isParticipatesInEconomy() {
      return false;
   }
}
