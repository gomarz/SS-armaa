package data.scripts.campaign;

import com.fs.starfarer.api.EveryFrameScript;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListener;
import com.fs.starfarer.api.campaign.BattleAPI;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.EngagementResultForFleetAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.TextPanelAPI;
import com.fs.starfarer.api.campaign.CombatDamageData.DamageToFleetMember;
import com.fs.starfarer.api.campaign.FleetEncounterContextPlugin.DataForEncounterSide;
import com.fs.starfarer.api.campaign.ReputationActionResponsePlugin.ReputationAdjustmentResult;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI.SkillLevelAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.MissionCompletionRep;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActionEnvelope;
import com.fs.starfarer.api.impl.campaign.CoreReputationPlugin.RepActions;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent;
import com.fs.starfarer.api.impl.campaign.events.OfficerManagerEvent.SkillPickPreference;
import com.fs.starfarer.api.util.Misc;
import data.scripts.campaign.intel.armaa_promoteWingman;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Map.Entry;
import org.lazywizard.lazylib.MathUtils;

public class armaa_wingmanPromotion extends BaseCampaignEventListener implements EveryFrameScript {

   static long previousXP = Long.MAX_VALUE;
   private Float repRewardPerson = null;
   private Float repPenaltyPerson = null;
   private Float repRewardFaction = null;
   private int numEngagements = 0;
   Float repPenaltyFaction = null;
   RepLevel rewardLimitPerson = null;
   RepLevel rewardLimitFaction = null;
   RepLevel penaltyLimitPerson = null;
   RepLevel penaltyLimitFaction = null;
   transient int memberToPromote;
   transient boolean isWin = false;
   transient boolean canPromote = false;
   transient Map promoteablePilots = new HashMap();
   transient EngagementResultAPI batResult;
   public TextPanelAPI textPanelForXPGain = null;
   private Random salvageRandom = null;


   public armaa_wingmanPromotion() {
      super(true);
   }

   public static long getReAdjustedXp() {
      long var0 = Global.getSector().getPlayerStats().getXP() + Global.getSector().getPlayerStats().getBonusXp() - previousXP;
      return var0;
   }

   public TextPanelAPI getTextPanelForXPGain() {
      return this.textPanelForXPGain;
   }

   public void setTextPanelForXPGain(TextPanelAPI var1) {
      this.textPanelForXPGain = var1;
   }

   public Random getSalvageRandom() {
      return this.salvageRandom;
   }

   public void setSalvageRandom(Random var1) {
      this.salvageRandom = var1;
   }

   public boolean runWhilePaused() {
      return false;
   }

   public boolean isDone() {
      return false;
   }

   public void advance(float var1) {
      long var2 = Global.getSector().getPlayerStats().getXP();
      if(previousXP == Long.MAX_VALUE) {
         previousXP = var2;
      } else if(previousXP < var2) {
         long var4 = Math.min(10000L, Global.getSector().getPlayerStats().getXP() - previousXP);
         previousXP = var2;
      }

   }

   public DataForEncounterSide getDataFor(CampaignFleetAPI var1, BattleAPI var2, List var3) {
      CampaignFleetAPI var4 = var2.getCombinedFor(var1);
      if(var4 == null) {
         return new DataForEncounterSide(var1);
      } else {
         Iterator var5 = var3.iterator();

         DataForEncounterSide var6;
         do {
            if(!var5.hasNext()) {
               DataForEncounterSide var7 = new DataForEncounterSide(var4);
               var3.add(var7);
               return var7;
            }

            var6 = (DataForEncounterSide)var5.next();
         } while(var6.getFleet() != var4);

         return var6;
      }
   }

   protected void clearNoSourceMembers(EngagementResultForFleetAPI var1, BattleAPI var2) {
      Iterator var3 = var1.getDeployed().iterator();

      FleetMemberAPI var4;
      while(var3.hasNext()) {
         var4 = (FleetMemberAPI)var3.next();
         if(var2.getSourceFleet(var4) == null) {
            var3.remove();
         }
      }

      var3 = var1.getReserves().iterator();

      while(var3.hasNext()) {
         var4 = (FleetMemberAPI)var3.next();
         if(var2.getSourceFleet(var4) == null) {
            var3.remove();
         }
      }

      var3 = var1.getDestroyed().iterator();

      while(var3.hasNext()) {
         var4 = (FleetMemberAPI)var3.next();
         if(var2.getSourceFleet(var4) == null) {
            var3.remove();
         }
      }

      var3 = var1.getDisabled().iterator();

      while(var3.hasNext()) {
         var4 = (FleetMemberAPI)var3.next();
         if(var2.getSourceFleet(var4) == null) {
            var3.remove();
         }
      }

      var3 = var1.getRetreated().iterator();

      while(var3.hasNext()) {
         var4 = (FleetMemberAPI)var3.next();
         if(var2.getSourceFleet(var4) == null) {
            var3.remove();
         }
      }

   }

   public void reportPlayerEngagement(EngagementResultAPI var1) {
      this.batResult = var1;
      ++this.numEngagements;
   }

   public void reportBattleOccurred(CampaignFleetAPI var1, BattleAPI var2) {
      if(var2.isPlayerInvolved() && this.batResult != null) {
         this.isWin = (var2 != null && var1 != null && var2.getPlayerSide() != null?Boolean.valueOf(var2.getPlayerSide().contains(var1)):null).booleanValue();
         ArrayList var3 = new ArrayList();
         long var4 = getReAdjustedXp();
         Object var6 = null;
         if(var4 > 0L) {
            EngagementResultForFleetAPI var7 = this.batResult.getWinnerResult();
            EngagementResultForFleetAPI var8 = this.batResult.getLoserResult();
            this.clearNoSourceMembers(var7, var2);
            this.clearNoSourceMembers(var8, var2);
            DataForEncounterSide var9 = this.getDataFor(var7.getFleet(), var2, var3);
            DataForEncounterSide var10 = this.getDataFor(var8.getFleet(), var2, var3);
            if(var2.isPlayerSide(var2.getSideFor(var10.getFleet()))) {
               ;
            }

            EngagementResultForFleetAPI var15 = var8.isPlayer()?var7:var8;
            EngagementResultForFleetAPI var16 = var8.isPlayer()?var8:var7;
            ArrayList var17 = new ArrayList();
            ArrayList var18 = new ArrayList();
            var17.addAll(var15.getDestroyed());
            var17.addAll(var15.getDisabled());
            var18.addAll(var16.getDestroyed());
            var18.addAll(var16.getDisabled());
            var18.addAll(var16.getRetreated());
            float var19 = 0.0F;

            Iterator var20;
            FleetMemberAPI var21;
            float var22;
            for(var20 = var17.iterator(); var20.hasNext(); var19 += var22) {
               var21 = (FleetMemberAPI)var20.next();
               var22 = (float)var21.getFleetPointCost();
               var22 *= 1.0F + (float)var21.getCaptain().getStats().getLevel() / 5.0F;
            }

            var19 *= 1.0F;
            var20 = var18.iterator();

            while(var20.hasNext()) {
               var21 = (FleetMemberAPI)var20.next();
               if(!var21.isAlly()) {
                  var22 = (float)var21.getFleetPointCost();
                  var22 *= 1.0F + (float)var21.getCaptain().getStats().getLevel() / 5.0F;
                  var19 += var22;
               }
            }

            float var33 = 0.0F;

            float var23;
            Iterator var25;
            for(Iterator var34 = Global.getSector().getPlayerFleet().getFleetData().getMembersListCopy().iterator(); var34.hasNext(); var33 += var23) {
               FleetMemberAPI var36 = (FleetMemberAPI)var34.next();
               var23 = (float)var36.getFleetPointCost();
               var23 *= 1.0F + (float)var36.getCaptain().getStats().getLevel() / 5.0F;
               if(Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_0_" + var36.getCaptain().getId()) instanceof PersonAPI && var36.getVariant().hasHullMod("armaa_wingCommander") && (var16.getDeployed().contains(var36) || var18.contains(var36))) {
                  float var24 = 0.0F;
                  if(this.batResult.getLastCombatDamageData() != null && this.batResult.getLastCombatDamageData().getDealtBy(var36).getDamage() != null) {
                     DamageToFleetMember var26;
                     for(var25 = this.batResult.getLastCombatDamageData().getDealtBy(var36).getDamage().values().iterator(); var25.hasNext(); var24 += var26.hullDamage) {
                        var26 = (DamageToFleetMember)var25.next();
                     }

                     var24 = var24 / var36.getMemberStrength() / 5.0F;
                  }

                  this.adjustRelations(var36, var18, var24);
               }
            }

            float var35 = Global.getSettings().getFloat("maxOfficerPromoteProb");
            int var37 = Misc.getMaxOfficers(Global.getSector().getPlayerFleet());
            int var38 = Misc.getNumNonMercOfficers(Global.getSector().getPlayerFleet());
            ArrayList var39 = new ArrayList();
            if(var38 < var37) {
               if(Global.getSector().getIntelManager().getIntel(armaa_promoteWingman.class) != null) {
                  int var40 = Global.getSector().getIntelManager().getIntel(armaa_promoteWingman.class).size();

                  for(int var41 = 0; var41 < var40; ++var41) {
                     armaa_promoteWingman var27 = (armaa_promoteWingman)Global.getSector().getIntelManager().getIntel(armaa_promoteWingman.class).get(var41);
                     var39.add(var27.getCandidate().getId());
                  }
               }

               var25 = this.promoteablePilots.entrySet().iterator();

               while(var25.hasNext()) {
                  Entry var42 = (Entry)var25.next();
                  FleetMemberAPI var43 = (FleetMemberAPI)var42.getKey();
                  if(var43 != null) {
                     Iterator var28 = ((List)var42.getValue()).iterator();

                     while(var28.hasNext()) {
                        Integer var29 = (Integer)var28.next();
                        boolean var30 = false;
                        PersonAPI var31 = null;
                        if(Global.getSector().getIntelManager().getIntel(armaa_promoteWingman.class) != null) {
                           if(Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_" + var29 + "_" + var43.getCaptain().getId()) instanceof PersonAPI) {
                              var31 = (PersonAPI)Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_" + var29 + "_" + var43.getCaptain().getId());
                           }

                           if(var39.contains(var31.getId())) {
                              var30 = true;
                           }
                        }

                        if((var31 == null || !var31.hasTag("armaa_doNotAutoConsiderAgain")) && !var30) {
                           armaa_promoteWingman var32 = new armaa_promoteWingman(this.textPanelForXPGain, var43, var29.intValue());
                           Global.getSector().getIntelManager().addIntel(var32, false, this.textPanelForXPGain);
                        }
                     }
                  }
               }
            }

            this.promoteablePilots.clear();
            this.batResult = null;
            previousXP = Global.getSector().getPlayerStats().getXP();
            var17.clear();
            var18.clear();
            this.numEngagements = 0;
         }
      }
   }

   private void adjustRelations(FleetMemberAPI var1, List var2, float var3) {
      ArrayList var4 = new ArrayList();
      var4.add(RepActions.COMBAT_HELP_MINOR);
      var4.add(RepActions.COMBAT_HELP_MAJOR);
      var4.add(RepActions.MISSION_SUCCESS);
      Random var5 = new Random();
      if(var2 != null && var2.contains(var1)) {
         var4.clear();
         var4.add(RepActions.COMBAT_NORMAL_TOFF);
         var4.add(RepActions.COMBAT_AGGRESSIVE_TOFF);
         var4.add(RepActions.MISSION_FAILURE);
         if(this.isWin) {
            var4.add(RepActions.MISSION_SUCCESS);
         }
      }

      int var6 = 0;
      if(Global.getSector().getPersistentData().get("armaa_wingCommander_squadSize_" + var1.getCaptain().getId()) instanceof Integer) {
         var6 = ((Integer)Global.getSector().getPersistentData().get("armaa_wingCommander_squadSize_" + var1.getCaptain().getId())).intValue();
      }

      ArrayList var7 = new ArrayList();

      for(int var8 = 0; var8 < var6; ++var8) {
         this.repRewardPerson = null;
         this.repPenaltyPerson = null;
         this.repRewardFaction = null;
         this.repPenaltyFaction = null;
         this.rewardLimitPerson = null;
         this.rewardLimitFaction = null;
         this.penaltyLimitPerson = null;
         this.penaltyLimitFaction = null;
         if(Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_" + var8 + "_" + var1.getCaptain().getId()) instanceof PersonAPI) {
            Object var9 = null;
            boolean var10 = var8 == 0;
            PersonAPI var11 = (PersonAPI)Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_" + var8 + "_" + var1.getCaptain().getId());
            String var12 = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_" + var8 + "_" + "callsign_" + var1.getCaptain().getId());
            MissionCompletionRep var13 = new MissionCompletionRep(this.getRepRewardSuccessPerson(), this.getRewardLimitPerson(), -this.getRepPenaltyFailurePerson(), this.getPenaltyLimitPerson());
            ReputationAdjustmentResult var14 = Global.getSector().adjustPlayerReputation(new RepActionEnvelope((RepActions)var4.get(var5.nextInt(var4.size())), var13, (TextPanelAPI)var9, true, false), var11);
            this.levelUpIfApplicable(var11, var8, var12, var1);
            if(var11.getRelToPlayer().getRel() >= 0.7F) {
               this.canPromote = true;
               this.memberToPromote = var8;
               var7.add(Integer.valueOf(var8));
            }
         }
      }

      this.promoteablePilots.put(var1, var7);
   }

   public float getRepRewardSuccessPerson() {
      return this.repRewardPerson != null?this.repRewardPerson.floatValue():MathUtils.getRandomNumberInRange(0.02F, 0.07F) * (float)this.numEngagements;
   }

   public float getRepPenaltyFailurePerson() {
      return this.repPenaltyPerson != null?this.repPenaltyPerson.floatValue():MathUtils.getRandomNumberInRange(0.02F, 0.07F);
   }

   public RepLevel getRewardLimitPerson() {
      return this.rewardLimitPerson != null?this.rewardLimitPerson:RepLevel.COOPERATIVE;
   }

   public RepLevel getPenaltyLimitPerson() {
      return this.penaltyLimitPerson != null?this.penaltyLimitPerson:RepLevel.VENGEFUL;
   }

   public void levelUpIfApplicable(PersonAPI var1, int var2, String var3, FleetMemberAPI var4) {
      MutableCharacterStatsAPI var5 = Global.getSector().getPlayerFleet().getFleetData().getCommander().getStats();
      int var6 = (int)var5.getDynamic().getMod("officer_max_level_mod").computeEffective(0.0F) + (int)Misc.MAX_OFFICER_LEVEL;
      int var7 = Global.getSettings().getInt("officerMaxEliteSkills") + (int)var5.getDynamic().getMod("officer_max_elite_skills_mod").computeEffective(0.0F);
      float var8 = var1.getStats().getLevel() != var6?(float)(var6 - var1.getStats().getLevel()) * 0.1F:0.4F;
      var8 *= (float)this.numEngagements;
      float var9 = var1.hasTag("armaa_latentTalent")?0.05F:0.01F;
      if(Math.random() <= (double)var8 && var1.getRelToPlayer().getRel() >= 0.25F) {
         ArrayList var10 = new ArrayList();
         var10.add("combat_endurance");
         var10.add("helmsmanship");
         var10.add("energy_weapon_mastery");
         var10.add("ballistic_mastery");
         var10.add("field_modulation");
         var10.add("target_analysis");
         var10.add("impact_mitigation");
         var10.add("damage_control");
         var10.add("polarized_armor");
         var10.add("point_defense");
         var10.add("missile_specialization");
         var10.add("systems_expertise");
         byte var11 = 7;
         String var12 = OfficerManagerEvent.pickSkill(var1, var10, SkillPickPreference.YES_ENERGY_YES_BALLISTIC_YES_MISSILE_YES_DEFENSE, 0, new Random());
         MutableCharacterStatsAPI var13 = var1.getStats();
         String var14 = Global.getSettings().getSkillSpec(var12).getName();
         new ArrayList(var13.getSkillsCopy());
         boolean var16 = false;
         if(Misc.getNumEliteSkills(var1) < var7) {
            Iterator var17 = var13.getSkillsCopy().iterator();

            while(var17.hasNext()) {
               SkillLevelAPI var18 = (SkillLevelAPI)var17.next();
               if((var18.getSkill().getName().equals(var14) || var1.getStats().getLevel() >= var6) && var10.contains(var18.getSkill().getId())) {
                  int var19 = (int)var13.getSkillLevel(var18.getSkill().getId());
                  if(var19 <= 1) {
                     Global.getSector().getCampaignUI().addMessage("Pilot, callsign \"" + var3 + "\" \'s aptitude in " + var18.getSkill().getName() + " increased to Elite!", Misc.getHighlightColor());
                     var13.increaseSkill(var18.getSkill().getId());
                     var16 = true;
                     break;
                  }
               }
            }
         }

         if(!var16 && var1.getStats().getLevel() < var6 && !var13.hasSkill(var12) || !var16 && var1.getStats().getLevel() < var11 && var1.getStats().getLevel() >= var6 && !var13.hasSkill(var12) && (double)((float)var11 - (float)var1.getStats().getLevel() * var9) > Math.random()) {
            Global.getSector().getCampaignUI().addMessage("Pilot, callsign \"" + var3 + "\" learned " + var14 + "!", Misc.getHighlightColor());
            var13.increaseSkill(var12);
            var13.setLevel(var13.getLevel() + 1);
         }

         Global.getSector().getPersistentData().put("armaa_wingCommander_wingman_" + var2 + "_" + var4.getCaptain().getId(), var1);
      }

   }

}
