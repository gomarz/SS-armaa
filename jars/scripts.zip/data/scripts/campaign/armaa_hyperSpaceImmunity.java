package data.scripts.campaign;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.BaseCampaignEventListenerAndScript;
import com.fs.starfarer.api.campaign.FleetDataAPI;
import com.fs.starfarer.api.campaign.InteractionDialogAPI;
import com.fs.starfarer.api.combat.EngagementResultAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.Iterator;

public class armaa_hyperSpaceImmunity extends BaseCampaignEventListenerAndScript {

   private IntervalUtil interval = new IntervalUtil(1.0F, 1.0F);


   public boolean runWhilePaused() {
      return false;
   }

   public void advance(float var1) {
      if(Global.getSector().getPlayerFleet() != null) {
         if(Global.getSector().getPersistentData().containsKey("armaa_hyperSpaceBuff")) {
            if(Global.getSector().getPlayerFleet().isInHyperspace()) {
               this.interval.advance(var1);
               if(this.interval.intervalElapsed() && Global.getSector().getPlayerFleet() != null && Global.getSector().getPlayerFleet().getFleetData() != null) {
                  FleetDataAPI var2 = Global.getSector().getPlayerFleet().getFleetData();
                  Iterator var3 = var2.getMembersInPriorityOrder().iterator();

                  while(var3.hasNext()) {
                     FleetMemberAPI var4 = (FleetMemberAPI)var3.next();
                     if(var4.getVariant().hasHullMod("strikeCraft")) {
                        var4.getStats().getDynamic().getStat("corona_resistance").modifyMult("armaa_carrierStorageHyper", 1.0E-5F);
                     }
                  }

                  Global.getSector().getPersistentData().put("armaa_hyperSpaceBuff", "-");
               }

            }
         }
      }
   }

   public void reportPlayerEngagement(EngagementResultAPI var1) {
      Global.getSector().getPersistentData().remove("armaa_hyperSpaceBuff");
   }

   public void reportShownInteractionDialog(InteractionDialogAPI var1) {
      if(Global.getSector().getPlayerFleet() != null && Global.getSector().getPlayerFleet().getFleetData() != null) {
         FleetDataAPI var2 = Global.getSector().getPlayerFleet().getFleetData();
         Iterator var3 = var2.getMembersInPriorityOrder().iterator();

         while(var3.hasNext()) {
            FleetMemberAPI var4 = (FleetMemberAPI)var3.next();
            if(var4.getVariant().hasHullMod("strikeCraft")) {
               var4.getStats().getDynamic().getStat("corona_resistance").unmodify("armaa_carrierStorageHyper");
            }
         }

         Global.getSector().getPersistentData().put("armaa_hyperSpaceBuff", "-");
      }

   }
}
