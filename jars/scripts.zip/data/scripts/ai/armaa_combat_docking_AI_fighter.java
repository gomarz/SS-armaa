package data.scripts.ai;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.SoundAPI;
import com.fs.starfarer.api.combat.ArmorGridAPI;
import com.fs.starfarer.api.combat.CombatFleetManagerAPI;
import com.fs.starfarer.api.combat.FighterLaunchBayAPI;
import com.fs.starfarer.api.combat.FighterWingAPI;
import com.fs.starfarer.api.combat.ShipAIConfig;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.mission.FleetSide;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.ai.BaseShipAI;
import data.scripts.util.armaa_utils;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.Point;
import org.lwjgl.util.vector.Vector2f;

public class armaa_combat_docking_AI_fighter extends BaseShipAI {

   private final ShipwideAIFlags flags = new ShipwideAIFlags();
   private final ShipAIConfig config = new ShipAIConfig();
   public ShipAPI carrier;
   private ShipAPI fighterbay;
   private CombatFleetManagerAPI combatfleet;
   private CombatFleetManagerAPI fleetManager;
   private ShipAPI fightercopy;
   private List carrierdata;
   private boolean carrierworking;
   private ShipAPI target;
   private Vector2f targetOffset;
   private Point cellToFix = new Point();
   private Random rng = new Random();
   private ArmorGridAPI armorGrid;
   private SoundAPI repairSound;
   private float max;
   private float cellSize;
   private int gridWidth;
   private int gridHeight;
   private int cellCount;
   private boolean returning = false;
   private boolean spark = false;
   private float targetFacingOffset = Float.MIN_VALUE;
   private float range = 4000.0F;
   private boolean needrepair = false;
   private float HPPercent = 0.5F;
   private float CRmarker = 0.4F;
   private float CRrestored = 0.2F;
   private float CRmax = 1.0F;
   private boolean hasLanded = false;
   private boolean intervalCheck = false;
   private float pptMax = 180.0F;
   private String timer = "0";
   private float nearest = 10000.0F;
   private final IntervalUtil interval = new IntervalUtil(0.25F, 0.33F);
   private final IntervalUtil countdown = new IntervalUtil(4.0F, 4.0F);
   private final IntervalUtil landingTimer = new IntervalUtil(20.0F, 20.0F);
   public final IntervalUtil BASE_REFIT = new IntervalUtil(20.0F, 20.0F);
   private final IntervalUtil BASE_REFIT_CR = new IntervalUtil(20.0F, 20.0F);


   Vector2f getDestination() {
      return new Vector2f();
   }

   public armaa_combat_docking_AI_fighter(ShipAPI var1) {
      super(var1);
   }

   public void advance(float var1) {
      ShipAPI var2 = Global.getCombatEngine().getPlayerShip();
      if(this.carrier == null || this.carrier == this.ship || this.carrier.isHulk() || !this.carrier.isAlive()) {
         this.ship.setControlsLocked(false);
         this.init();
      }

      if(this.ship.isLanding() && this.ship.isFighter() && this.ship.getWing() != null) {
         this.countdown.advance(var1);
         if(this.countdown.intervalElapsed()) {
            this.ship.getWing().getSource().land(this.ship);
            return;
         }
      }

      if(this.ship.isLanding()) {
         this.ship.setShipSystemDisabled(true);
         this.ship.setControlsLocked(true);
         this.countdown.advance(var1);
         if(this.countdown.intervalElapsed()) {
            this.ship.setControlsLocked(true);
            if(this.fighterbay != null) {
               armaa_utils.setLocation(this.ship, this.fighterbay.getWing().getSource().getLandingLocation(this.fighterbay));
            }

            if(this.carrier == null || !this.carrier.isAlive()) {
               this.ship.abortLanding();
               this.ship.setShipSystemDisabled(false);
               this.ship.setControlsLocked(false);
               this.ship.setHullSize(HullSize.FRIGATE);
               this.ship.resetDefaultAI();
               this.ship.setHullSize(HullSize.FIGHTER);
               return;
            }
         }
      }

      if(this.ship.isFinishedLanding()) {
         this.fleetManager = Global.getCombatEngine().getFleetManager(FleetSide.PLAYER);
         if(this.carrier == null) {
            this.ship.abortLanding();
            this.ship.setShipSystemDisabled(false);
            this.ship.setControlsLocked(false);
            this.init();
            return;
         }

         Iterator var3 = this.ship.getChildModulesCopy().iterator();

         while(var3.hasNext()) {
            ShipAPI var4 = (ShipAPI)var3.next();
            if(var4 != null) {
               var4.isFinishedLanding();
            }
         }

         if(!this.carrier.isAlive()) {
            armaa_utils.destroy(this.ship);
            return;
         }
      }

      if(!this.hasLanded) {
         this.hasLanded = true;
      }

      this.goToDestination();
      this.beginlandingAI();
   }

   public float getCarrierRefitRate() {
      return this.carrier == null?1.0F:this.carrier.getSharedFighterReplacementRate();
   }

   public ShipAPI getCarrier() {
      return this.carrier;
   }

   public void beginlandingAI() {
      if(this.carrier != null) {
         if(this.returning && !this.ship.isLanding() && MathUtils.getDistance(this.ship, this.carrier) < this.carrier.getCollisionRadius() / 3.0F) {
            this.ship.beginLandingAnimation(this.carrier);
            Iterator var1 = this.ship.getAllWings().iterator();

            while(var1.hasNext()) {
               FighterWingAPI var2 = (FighterWingAPI)var1.next();
               Iterator var3 = var2.getWingMembers().iterator();

               while(var3.hasNext()) {
                  ShipAPI var4 = (ShipAPI)var3.next();
                  var2.orderReturn(var4);
               }
            }

            var1 = this.ship.getChildModulesCopy().iterator();

            while(var1.hasNext()) {
               ShipAPI var5 = (ShipAPI)var1.next();
               if(var5 != null) {
                  var5.beginLandingAnimation(this.carrier);
               }
            }
         }

      }
   }

   public boolean needsRefit() {
      return true;
   }

   public void cancelCurrentManeuver() {}

   public void evaluateCircumstances() {
      if(!this.needsRefit()) {
         this.ship.setHullSize(HullSize.FRIGATE);
         this.ship.resetDefaultAI();
      }

      if(this.carrier != null && (this.carrier.isHulk() || !this.carrier.isAlive())) {
         this.ship.setControlsLocked(false);
         this.init();
      }

      if(this.carrier != this.ship && this.carrier != null) {
         this.setTarget(this.chooseTarget());
      } else {
         this.init();
      }

      if(this.returning && this.fighterbay != null && this.targetOffset == null) {
         this.targetOffset = armaa_utils.toRelative(this.target, this.fighterbay.getWing().getSource().getLandingLocation(this.fighterbay));
      } else if(this.fighterbay == null) {
         ;
      }

   }

   ShipAPI chooseTarget() {
      if(this.carrier == null) {
         return this.ship;
      } else if(this.needsRefit() && (this.carrier != null || this.carrier != this.ship)) {
         this.returning = true;
         return this.carrier;
      } else {
         this.returning = false;
         return this.ship;
      }
   }

   void setTarget(ShipAPI var1) {
      if(this.target != var1) {
         this.target = var1;
         this.ship.setShipTarget(var1);
      }
   }

   void goToDestination() {
      if(this.target != null && this.carrier != null) {
         Vector2f var1 = armaa_utils.toAbsolute(this.target, this.targetOffset);
         MathUtils.getDistance(this.ship, var1);
         float var3 = (float)((double)MathUtils.getDistanceSquared(this.carrier.getLocation(), this.ship.getLocation()) / Math.pow((double)this.target.getCollisionRadius(), 2.0D));
         float var4;
         if((this.target != this.carrier || var3 >= 1.0F) && !this.ship.isLanding()) {
            this.targetFacingOffset = Float.MIN_VALUE;
            var4 = MathUtils.getShortestRotation(this.ship.getFacing(), VectorUtils.getAngle(this.ship.getLocation(), var1));
            if(Math.abs(var4) < 30.0F) {
               this.accelerate();
            } else {
               this.turnToward(var1);
            }

            this.strafeToward(var1);
         } else {
            var4 = 1.0F - Math.min(1.0F, var3);
            if(!this.returning) {
               var4 *= 0.1F;
            }

            this.turnToward(this.target.getFacing());
            this.ship.getLocation().x = (var1.x * var4 * 0.1F + this.ship.getLocation().x * (2.0F - var4 * 0.1F)) / 2.0F;
            this.ship.getLocation().y = (var1.y * var4 * 0.1F + this.ship.getLocation().y * (2.0F - var4 * 0.1F)) / 2.0F;
            this.ship.getVelocity().x = (this.target.getVelocity().x * var4 + this.ship.getVelocity().x * (2.0F - var4)) / 2.0F;
            this.ship.getVelocity().y = (this.target.getVelocity().y * var4 + this.ship.getVelocity().y * (2.0F - var4)) / 2.0F;
            if(!this.ship.isLanding() && !this.ship.isFinishedLanding()) {
               this.ship.beginLandingAnimation(this.target);
            }
         }

      }
   }

   public ShipwideAIFlags getAIFlags() {
      return this.flags;
   }

   public void setDoNotFireDelay(float var1) {}

   public ShipAIConfig getConfig() {
      return this.config;
   }

   public void init() {
      if(this.ship.isAlive()) {
         ShipAPI var1 = Global.getCombatEngine().getPlayerShip();
         boolean var2 = false;
         if(this.ship.getShipTarget() != null) {
            ShipAPI var3 = this.ship.getShipTarget();
            if(var3.getOwner() == this.ship.getOwner() && !var3.isFighter() && (!var3.isFrigate() || var3.isStationModule()) && var3 != this.ship && var3.getCurrentCR() > 0.0F && var3.hasLaunchBays()) {
               Random var4 = new Random();
               var4.nextInt(var3.getLaunchBaysCopy().size());
               ShipAPI var6 = ((FighterLaunchBayAPI)var3.getLaunchBaysCopy().get(0)).getWing().getLeader();
               if(var6 != null) {
                  this.fighterbay = var6;
                  this.carrier = var3;
                  this.target = this.carrier;
                  this.targetOffset = armaa_utils.toRelative(this.carrier, var6.getWing().getSource().getLandingLocation(var6));
                  var2 = true;
               }
            }
         }

         if(!var2) {
            Iterator var7 = CombatUtils.getShipsWithinRange(this.ship.getLocation(), 10000.0F).iterator();

            while(var7.hasNext()) {
               ShipAPI var8 = (ShipAPI)var7.next();
               if(var8.getOwner() == this.ship.getOwner() && var8.isFighter() && var8.getWing() != null && var8.getWing().getSourceShip() != null) {
                  ShipAPI var5 = var8.getWing().getSourceShip();
                  if(!var5.isFighter() && (!var5.isFrigate() || var5.isStationModule()) && var5 != this.ship && var5.getCurrentCR() > 0.0F && Global.getCombatEngine().isEntityInPlay(var5) && MathUtils.getDistance(this.ship, var5) <= this.nearest && var8 != null && var5 != null) {
                     if(MathUtils.getDistance(this.ship, var5) < this.nearest) {
                        this.nearest = MathUtils.getDistance(this.ship, var5);
                     }

                     this.fighterbay = var8;
                     this.carrier = var5;
                     this.target = this.carrier;
                     this.targetOffset = armaa_utils.toRelative(this.carrier, var8.getWing().getSource().getLandingLocation(var8));
                  }
               }
            }
         }

      }
   }
}
