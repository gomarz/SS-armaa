package data.scripts.util;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.MechaModPlugin;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.apache.log4j.Logger;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_pilotTrackerNP extends BaseEveryFrameCombatPlugin {

   private ShipAPI fighter;
   private String name;
   private ShipAPI ship;
   private PersonAPI captain;
   private int pilotNo;
   private IntervalUtil interval = new IntervalUtil(10.0F, 10.0F);
   private IntervalUtil openingDialogue = new IntervalUtil(1.0F, 10.0F);
   private IntervalUtil combatDialogue = new IntervalUtil(20.0F, 50.0F);
   private boolean runOnce = false;
   private boolean hasChattered = false;
   private List introChatter = new ArrayList();
   private List combatChatter = new ArrayList();
   private List squadChatter_s = new ArrayList();
   private List squadChatter_r = new ArrayList();
   private Logger logger;


   public armaa_pilotTrackerNP(ShipAPI var1, String var2, int var3) {
      this.fighter = var1;
      this.name = var2;
      this.pilotNo = var3;
      this.ship = var1.getWing().getSourceShip();
      this.captain = var1.getWing().getSourceShip().getCaptain();
      this.introChatter.addAll(MechaModPlugin.introChatter);
      this.combatChatter.addAll(MechaModPlugin.combatChatter);
      this.squadChatter_s.addAll(MechaModPlugin.intersquadChatter_statement);
      this.squadChatter_r.addAll(MechaModPlugin.intersquadChatter_response);
      if(var1.getOwner() == 1) {
         Iterator var4 = MechaModPlugin.introChatter_special.keySet().iterator();

         while(var4.hasNext()) {
            String var5 = (String)var4.next();
            if(Global.getSector().getMemory().get(var5) != null) {
               this.introChatter.addAll((Collection)MechaModPlugin.introChatter_special.get(var5));
            }
         }

         Collections.shuffle(this.introChatter);
      }

   }

   public void advance(float var1, List var2) {
      if(!Global.getCombatEngine().isPaused()) {
         if(!this.introChatter.isEmpty() && MechaModPlugin.chatterEnabled) {
            if(Global.getCombatEngine().getCustomData().get("armaa_wingCommander_squadron_hasChattered_" + this.captain.getId()) instanceof Boolean) {
               this.hasChattered = ((Boolean)Global.getCombatEngine().getCustomData().get("armaa_wingCommander_squadron_hasChattered_" + this.captain.getId())).booleanValue();
            }

            if(!Global.getCombatEngine().isPaused()) {
               this.interval.advance(var1);
               if(!this.runOnce && !this.hasChattered && this.fighter.getWing().getLeader() == this.fighter) {
                  this.openingDialogue.advance(var1);
                  if(this.openingDialogue.intervalElapsed()) {
                     if(Math.random() <= 0.5D) {
                        String var3 = this.ship.getName() + " Squadron";
                        Random var4 = new Random();
                        int var5 = var4.nextInt(this.introChatter.size());
                        String var6 = (String)this.introChatter.get(var5);
                        Color var7 = this.fighter.isAlly()?Misc.getHighlightColor():Misc.getNegativeHighlightColor();
                        Color var8 = Global.getSettings().getColor("standardTextColor");
                        if(var6.contains("$")) {
                           String var9 = this.processSpecialStrings(this.fighter, this.ship, var6);
                           Global.getCombatEngine().getCombatUI().addMessage(1, new Object[]{this.fighter, var7, var3, Color.white, ":", var8, var9});
                        } else {
                           Global.getCombatEngine().getCombatUI().addMessage(1, new Object[]{this.fighter, var7, var3, Color.white, ":", var8, var6});
                        }
                     }

                     this.runOnce = true;
                     Global.getCombatEngine().getCustomData().put("armaa_wingCommander_squadron_hasChattered_" + this.captain.getId(), Boolean.valueOf(true));
                  }
               }
            }
         }

         if(Global.getCombatEngine() == null || this.fighter == null || this.fighter.getHitpoints() <= 0.0F || !Global.getCombatEngine().isEntityInPlay(this.fighter) || Global.getCombatEngine().isCombatOver()) {
            Global.getCombatEngine().getCustomData().put("armaa_wingCommander_wingman_" + this.pilotNo + "_wasAssigned_" + this.captain.getId(), Boolean.valueOf(false));
            Global.getCombatEngine().removePlugin(this);
         }

         if(MagicRender.screenCheck(0.2F, this.fighter.getLocation()) && !this.fighter.isLiftingOff() && this.fighter.isAlive()) {
            Color var10 = this.fighter.getOwner() == 1?Misc.getHighlightColor():Misc.getPositiveHighlightColor();
            Vector2f var11 = new Vector2f(this.fighter.getLocation());
            var11.setY(var11.getY() + 35.0F);
            if(!Global.getCombatEngine().hasAttachedFloaty(this.fighter)) {
               Global.getCombatEngine().addFloatingTextAlways(var11, this.name, 10.0F, var10, this.fighter, 0.0F, 0.0F, 5.0F, var1, var1, 0.0F);
            }
         }

      }
   }

   private String processSpecialStrings(ShipAPI var1, ShipAPI var2, String var3) {
      int var4 = var1.getOwner() == 0?1:0;
      if(Global.getCombatEngine().getFleetManager(var4) == null) {
         return "*static*";
      } else if(Global.getCombatEngine().getFleetManager(var4).getFleetCommander() == null) {
         return "*fzzt*";
      } else if(Global.getCombatEngine().getFleetManager(var4).getFleetCommander().getFaction() == null) {
         return "*bzzt*";
      } else if(var2 != null && var1 != null) {
         String var5 = var3;
         PersonAPI var6 = Global.getCombatEngine().getFleetManager(var4).getFleetCommander();
         String var7;
         if(var3.contains("$factionnamearticle")) {
            var7 = "the enemy";
            if(var6.getFaction().isPlayerFaction()) {
               if(Misc.getFactionMarkets(Global.getSector().getPlayerFaction()).isEmpty()) {
                  var7 = "the Savior of Galatia";
               } else {
                  var7 = Global.getCombatEngine().getFleetManager(var4).getFleetCommander().getFaction().getDisplayNameWithArticle();
               }
            } else {
               var7 = Global.getCombatEngine().getFleetManager(var4).getFleetCommander().getFaction().getDisplayNameWithArticle();
            }

            var5 = var3.replace("$factionnamearticle", var7);
            var3 = var5;
         }

         if(var5.contains("$factionname")) {
            var7 = "hostiles";
            if(var6.getFaction().isPlayerFaction()) {
               if(Misc.getFactionMarkets(Global.getSector().getPlayerFaction()).isEmpty()) {
                  var7 = "the Savior of Galatia";
               } else {
                  var7 = Global.getCombatEngine().getFleetManager(var4).getFleetCommander().getFaction().getDisplayNameWithArticle();
               }
            } else {
               var7 = Global.getCombatEngine().getFleetManager(var4).getFleetCommander().getFaction().getDisplayName();
            }

            var5 = var3.replace("$factionname", var7);
            var3 = var5;
         }

         if(var5.contains("$squadronname")) {
            var7 = " " + var2.getName() + " Squadron";
            var5 = var3.replace("$squadronname", var7);
            var3 = var5;
         }

         if(var5.contains("$squadleader")) {
            var7 = "the Command Ship";
            if(var2 != null && var2.getName() != null) {
               var7 = var2.getName();
            }

            var5 = var3.replace("$squadleader", var7);
         }

         return var5;
      } else {
         return "*crackle*";
      }
   }
}
