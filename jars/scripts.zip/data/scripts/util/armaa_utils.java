package data.scripts.util;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.MutableCharacterStatsAPI;
import com.fs.starfarer.api.combat.ArmorGridAPI;
import com.fs.starfarer.api.combat.BeamAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.DeployedFleetMemberAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipEngineControllerAPI.ShipEngineAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_utils {

   static Map shieldUpkeeps;
   static Map SystemIDs;
   static final float SAFE_DISTANCE = 600.0F;
   static final float DEFAULT_DAMAGE_WINDOW = 3.0F;
   static IntervalUtil particle = new IntervalUtil(0.015F, 0.015F);
   static final Map baseOverloadTimes = new HashMap();


   public static float getEngineFractionDisabled(ShipAPI var0) {
      float var1 = 0.0F;
      float var2 = 0.0F;
      Iterator var3 = var0.getEngineController().getShipEngines().iterator();

      while(var3.hasNext()) {
         ShipEngineAPI var4 = (ShipEngineAPI)var3.next();
         if(!var4.isSystemActivated()) {
            if(!var4.isDisabled()) {
               var2 += var4.getContribution();
            }

            var1 += var4.getContribution();
         }
      }

      return var2 / var1;
   }

   public static void showHealText(ShipAPI var0, Vector2f var1, float var2) {}

   public static List getCollideablesInRange(Vector2f var0, float var1) {
      LinkedList var2 = new LinkedList();
      var2.addAll(CombatUtils.getAsteroidsWithinRange(var0, var1));
      Iterator var3 = CombatUtils.getShipsWithinRange(var0, var1).iterator();

      while(var3.hasNext()) {
         ShipAPI var4 = (ShipAPI)var3.next();
         if(!var4.isFighter()) {
            var2.add(var4);
         }
      }

      return var2;
   }

   public static List getProjectilesDamagedBy(ShipAPI var0) {
      LinkedList var1 = new LinkedList();
      Iterator var2 = CombatUtils.getProjectilesWithinRange(var0.getLocation(), var0.getCollisionRadius()).iterator();

      while(var2.hasNext()) {
         DamagingProjectileAPI var3 = (DamagingProjectileAPI)var2.next();
         if(var3.didDamage() && var3.getDamageTarget() == var0) {
            var1.add(var3);
         }
      }

      return var1;
   }

   public static float estimateOptimalRange(ShipAPI var0) {
      float var1 = 0.0F;
      float var2 = 0.0F;

      WeaponAPI var4;
      float var5;
      for(Iterator var3 = var0.getAllWeapons().iterator(); var3.hasNext(); var1 += var5 * var4.getRange()) {
         var4 = (WeaponAPI)var3.next();
         var5 = var4.getSpec().getOrdnancePointCost((MutableCharacterStatsAPI)null);
         if(var4.getDamageType() == DamageType.FRAGMENTATION) {
            var5 *= 0.2F;
         }

         var2 += var5;
      }

      return var1 / var2;
   }

   public static Vector2f getDirectionalVector(float var0) {
      double var1 = Math.toRadians((double)var0);
      return new Vector2f((float)Math.cos(var1), (float)Math.sin(var1));
   }

   public static Vector2f getMidpoint(Vector2f var0, Vector2f var1, float var2) {
      var2 *= 2.0F;
      return new Vector2f((var0.x * (2.0F - var2) + var1.x * var2) / 2.0F, (var0.y * (2.0F - var2) + var1.y * var2) / 2.0F);
   }

   public static Vector2f getMidpoint(Vector2f var0, Vector2f var1) {
      return getMidpoint(var0, var1, 0.5F);
   }

   public static Vector2f toRelative(CombatEntityAPI var0, Vector2f var1) {
      Vector2f var2 = new Vector2f(var1);
      Vector2f.sub(var2, var0.getLocation(), var2);
      VectorUtils.rotate(var2, -var0.getFacing(), var2);
      return var2;
   }

   public static Vector2f toAbsolute(CombatEntityAPI var0, Vector2f var1) {
      Vector2f var2 = new Vector2f(var1);
      VectorUtils.rotate(var2, var0.getFacing(), var2);
      Vector2f.add(var2, var0.getLocation(), var2);
      return var2;
   }

   public static void blink(Vector2f var0) {
      Global.getCombatEngine().addHitParticle(var0, new Vector2f(), 30.0F, 1.0F, 0.1F, Color.RED);
   }

   public static List getShipsOnSegment(Vector2f var0, Vector2f var1) {
      float var2 = MathUtils.getDistance(var0, var1);
      Vector2f var3 = new Vector2f();
      var3.x = (var0.x + var1.x) / 2.0F;
      var3.y = (var0.y + var1.y) / 2.0F;
      ArrayList var4 = new ArrayList();
      Iterator var5 = CombatUtils.getShipsWithinRange(var3, var2 / 2.0F).iterator();

      while(var5.hasNext()) {
         ShipAPI var6 = (ShipAPI)var5.next();
         if(CollisionUtils.getCollisionPoint(var0, var1, var6) != null) {
            var4.add(var6);
         }
      }

      return var4;
   }

   public static ShipAPI getFirstShipOnSegment(Vector2f var0, Vector2f var1, CombatEntityAPI var2) {
      ShipAPI var3 = null;
      float var4 = Float.MAX_VALUE;
      Iterator var5 = getShipsOnSegment(var0, var1).iterator();

      while(var5.hasNext()) {
         ShipAPI var6 = (ShipAPI)var5.next();
         if(var6 != var2) {
            float var7 = MathUtils.getDistanceSquared(var6, var0);
            if(var7 < var4) {
               var4 = var7;
               var3 = var6;
            }
         }
      }

      return var3;
   }

   public static ShipAPI getFirstNonFighterOnSegment(Vector2f var0, Vector2f var1, CombatEntityAPI var2) {
      ShipAPI var3 = null;
      float var4 = Float.MAX_VALUE;
      Iterator var5 = getShipsOnSegment(var0, var1).iterator();

      while(var5.hasNext()) {
         ShipAPI var6 = (ShipAPI)var5.next();
         if(var6 != var2 && !var6.isFighter()) {
            float var7 = MathUtils.getDistanceSquared(var6, var0);
            if(var7 < var4) {
               var4 = var7;
               var3 = var6;
            }
         }
      }

      return var3;
   }

   public static ShipAPI getFirstShipOnSegment(Vector2f var0, Vector2f var1) {
      return getFirstShipOnSegment(var0, var1, (CombatEntityAPI)null);
   }

   public static ShipAPI getShipInLineOfFire(WeaponAPI var0) {
      Vector2f var1 = var0.getLocation();
      var1.x = (float)((double)var1.x + Math.cos(Math.toRadians((double)var0.getCurrAngle())) * (double)var0.getRange());
      var1.y = (float)((double)var1.y + Math.sin(Math.toRadians((double)var0.getCurrAngle())) * (double)var0.getRange());
      return getFirstShipOnSegment(var0.getLocation(), var1, var0.getShip());
   }

   public static float getArmorPercent(ShipAPI var0) {
      float var1 = 0.0F;
      int var2 = var0.getArmorGrid().getGrid().length;
      int var3 = var0.getArmorGrid().getGrid()[0].length;

      for(int var4 = 0; var4 < var2; ++var4) {
         for(int var5 = 0; var5 < var3; ++var5) {
            var1 += var0.getArmorGrid().getArmorFraction(var4, var5);
         }
      }

      return var1 / (float)(var2 * var3);
   }

   public static void setArmorPercentage(ShipAPI var0, float var1) {
      ArmorGridAPI var2 = var0.getArmorGrid();
      var1 = Math.min(1.0F, Math.max(0.0F, var1));

      for(int var3 = 0; var3 < var2.getGrid().length; ++var3) {
         for(int var4 = 0; var4 < var2.getGrid()[0].length; ++var4) {
            var2.setArmorValue(var3, var4, var2.getMaxArmorInCell() * var1);
         }
      }

   }

   public static List getCellLocations(ShipAPI var0) {
      int var1 = var0.getArmorGrid().getGrid().length;
      int var2 = var0.getArmorGrid().getGrid()[0].length;
      ArrayList var3 = new ArrayList();

      for(int var4 = 0; var4 < var1; ++var4) {
         for(int var5 = 0; var5 < var2; ++var5) {
            var3.add(getCellLocation(var0, (float)var4, (float)var5));
         }
      }

      return var3;
   }

   public static void setLocation(CombatEntityAPI var0, Vector2f var1) {
      Vector2f var2 = new Vector2f(var1);
      Vector2f.sub(var1, var0.getLocation(), var2);
      Vector2f.add(var0.getLocation(), var2, var0.getLocation());
   }

   public static Vector2f getCellLocation(ShipAPI var0, float var1, float var2) {
      var1 -= (float)var0.getArmorGrid().getGrid().length / 2.0F;
      var2 -= (float)var0.getArmorGrid().getGrid()[0].length / 2.0F;
      float var3 = var0.getArmorGrid().getCellSize();
      Vector2f var4 = new Vector2f();
      float var5 = (float)((double)((var0.getFacing() - 90.0F) / 360.0F) * 6.283185307179586D);
      var4.x = (float)((double)var1 * Math.cos((double)var5) - (double)var2 * Math.sin((double)var5)) * var3 + var0.getLocation().x;
      var4.y = (float)((double)var1 * Math.sin((double)var5) + (double)var2 * Math.cos((double)var5)) * var3 + var0.getLocation().y;
      return var4;
   }

   public static void print(String var0) {
      print(Global.getCombatEngine().getPlayerShip(), var0);
   }

   public static void print(ShipAPI var0, String var1) {
      if(var0 != null) {
         Global.getCombatEngine().addFloatingText(var0.getLocation(), var1, 40.0F, Color.green, var0, 1.0F, 5.0F);
      }
   }

   public static void print(Vector2f var0, String var1) {
      if(var0 != null) {
         Global.getCombatEngine().addFloatingText(var0, var1, 40.0F, Color.green, (CombatEntityAPI)null, 1.0F, 5.0F);
      }
   }

   public static void destroy(CombatEntityAPI var0) {
      Global.getCombatEngine().applyDamage(var0, var0.getLocation(), var0.getMaxHitpoints() * 10.0F, DamageType.HIGH_EXPLOSIVE, 0.0F, true, true, var0);
   }

   public static float estimateIncomingDamage(ShipAPI var0) {
      return estimateIncomingDamage(var0, 3.0F);
   }

   public static float estimateIncomingDamage(ShipAPI var0, float var1) {
      float var2 = 0.0F;
      var2 += estimateIncomingBeamDamage(var0, var1);
      Iterator var3 = Global.getCombatEngine().getProjectiles().iterator();

      while(var3.hasNext()) {
         DamagingProjectileAPI var4 = (DamagingProjectileAPI)var3.next();
         if(var4.getOwner() != var0.getOwner()) {
            Vector2f var5 = new Vector2f(var4.getVelocity());
            var5.scale(var1);
            Vector2f.add(var5, var4.getLocation(), var5);
            if((var0.getShield() == null || !var0.getShield().isOn() || !var0.getShield().isWithinArc(var4.getLocation())) && CollisionUtils.getCollides(var4.getLocation(), var5, new Vector2f(var0.getLocation()), var0.getCollisionRadius())) {
               var2 += var4.getDamageAmount();
            }
         }
      }

      return var2;
   }

   public static float estimateAllIncomingDamage(ShipAPI var0) {
      float var1 = 0.0F;
      var1 += estimateIncomingBeamDamage(var0, 3.0F);
      Iterator var2 = Global.getCombatEngine().getProjectiles().iterator();

      while(var2.hasNext()) {
         DamagingProjectileAPI var3 = (DamagingProjectileAPI)var2.next();
         Vector2f var4 = new Vector2f(var3.getVelocity());
         var4.scale(3.0F);
         Vector2f.add(var4, var3.getLocation(), var4);
         if((var0.getShield() == null || !var0.getShield().isWithinArc(var3.getLocation())) && CollisionUtils.getCollides(var3.getLocation(), var4, new Vector2f(var0.getLocation()), var0.getCollisionRadius())) {
            var1 += var3.getDamageAmount() + var3.getEmpAmount();
         }
      }

      return var1;
   }

   public static float estimateIncomingBeamDamage(ShipAPI var0, float var1) {
      float var2 = 0.0F;
      Iterator var3 = Global.getCombatEngine().getBeams().iterator();

      while(var3.hasNext()) {
         BeamAPI var4 = (BeamAPI)var3.next();
         if(var4.getDamageTarget() == var0) {
            float var5 = var4.getWeapon().getDerivedStats().getDamageOver30Sec() / 30.0F;
            float var6 = var4.getWeapon().getDerivedStats().getEmpPerSecond();
            var2 += (var5 + var6) * var1;
         }
      }

      return var2;
   }

   public static float estimateIncomingMissileDamage(ShipAPI var0) {
      float var1 = 0.0F;
      Iterator var3 = Global.getCombatEngine().getMissiles().iterator();

      while(var3.hasNext()) {
         DamagingProjectileAPI var2 = (DamagingProjectileAPI)var3.next();
         if(var2.getOwner() != var0.getOwner()) {
            float var4 = 600.0F + var0.getCollisionRadius();
            float var5 = var2.getDamageAmount() + var2.getEmpAmount();
            if(var0.getShield() == null || !var0.getShield().isWithinArc(var2.getLocation())) {
               var1 = (float)((double)var1 + (double)var5 * Math.max(0.0D, Math.min(1.0D, Math.pow((double)(1.0F - MathUtils.getDistance(var2, var0) / var4), 2.0D))));
            }
         }
      }

      return var1;
   }

   public static float getHitChance(DamagingProjectileAPI var0, CombatEntityAPI var1) {
      if(var0.getOwner() == var1.getOwner()) {
         return 0.0F;
      } else {
         float var2 = MathUtils.getDistance(var1, var0.getLocation()) / Math.max(1.0F, var0.getMoveSpeed());
         Vector2f var3 = new Vector2f(var1.getVelocity().x * var2, var1.getVelocity().y * var2);
         float var4 = var1.getAngularVelocity() * var2;
         Vector2f var5 = new Vector2f(var0.getVelocity());
         var1.setFacing(var1.getFacing() + var4);
         Vector2f.add(var1.getLocation(), var3, var1.getLocation());
         var5.scale(var2 * 3.0F);
         Vector2f.add(var5, var0.getLocation(), var5);
         Vector2f var6 = CollisionUtils.getCollisionPoint(var0.getLocation(), var5, var1);
         var1.setFacing(var1.getFacing() - var4);
         Vector2f.add(var1.getLocation(), (Vector2f)var3.scale(-1.0F), var1.getLocation());
         return var6 == null?0.0F:1.0F;
      }
   }

   public static float getHitChance(WeaponAPI var0, CombatEntityAPI var1) {
      float var2 = MathUtils.getDistance(var1, var0.getLocation()) / Math.max(1.0F, var0.getProjectileSpeed());
      Vector2f var3 = new Vector2f(var1.getVelocity().x * var2, var1.getVelocity().y * var2);
      float var4 = var1.getAngularVelocity() * var2;
      double var5 = (double)var0.getCurrAngle() * 0.017453292519943295D;
      Vector2f var7 = new Vector2f((float)Math.cos(var5) * var0.getProjectileSpeed() + var0.getShip().getVelocity().x, (float)Math.sin(var5) * var0.getProjectileSpeed() + var0.getShip().getVelocity().y);
      var1.setFacing(var1.getFacing() + var4);
      Vector2f.add(var1.getLocation(), var3, var1.getLocation());
      var7.scale(var2 * 3.0F);
      Vector2f.add(var7, var0.getLocation(), var7);
      Vector2f var8 = CollisionUtils.getCollisionPoint(var0.getLocation(), var7, var1);
      var1.setFacing(var1.getFacing() - var4);
      Vector2f.add(var1.getLocation(), (Vector2f)var3.scale(-1.0F), var1.getLocation());
      return var8 == null?0.0F:1.0F;
   }

   public static void createChargeParticle(float var0, Vector2f var1, CombatEntityAPI var2) {
      float var3 = var0;
      float var4 = 1.0F;
      ShipAPI var5 = (ShipAPI)var2;
      IntervalUtil var6 = new IntervalUtil(0.025F, 0.05F);
      if(var0 != 1.0F) {
         Global.getSoundPlayer().playLoop("beamchargeM", var5, 1.0F, 1.0F, var5.getLocation(), var5.getVelocity());
         var6.advance(Global.getCombatEngine().getElapsedInLastFrame());
         if(var6.intervalElapsed()) {
            Vector2f var7 = new Vector2f(var1);
            MathUtils.getPoint(var1, 18.5F, var5.getFacing());
            Vector2f var9 = var5.getVelocity();
            Global.getCombatEngine().addHitParticle(var7, var9, MathUtils.getRandomNumberInRange(20.0F * var4, var0 * var4 * 60.0F + 20.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var0), MathUtils.getRandomNumberInRange(0.1F, 0.1F + var0 / 10.0F), new Color(var0 / 2.0F, var0 / 1.5F, var0));
            Global.getCombatEngine().addSwirlyNebulaParticle(var7, new Vector2f(0.0F, 0.0F), MathUtils.getRandomNumberInRange(20.0F * var4, var0 * var4 * 60.0F + 20.0F), 1.2F, 0.15F, 0.0F, 0.35F * var0, new Color(var0 / 2.0F, var0 / 4.0F, var0), false);
            Vector2f var10 = MathUtils.getRandomPointInCircle(new Vector2f(), 35.0F * var0);
            Vector2f var11 = new Vector2f();
            Vector2f.sub(var7, new Vector2f(var10), var11);
            Vector2f.add(var9, var10, var10);

            for(int var12 = 0; var12 < 5; ++var12) {
               Global.getCombatEngine().addHitParticle(var11, var10, MathUtils.getRandomNumberInRange(2.0F, var3 * 2.0F + 2.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var3), MathUtils.getRandomNumberInRange(0.75F, 0.75F + var3 / 4.0F), new Color(var3 / 4.0F, var3 / 2.0F, var3));
            }
         }
      }

   }

   public static void createChargeParticle(float var0, Vector2f var1, CombatEntityAPI var2, Color var3, float var4) {
      float var5 = var0;
      ShipAPI var7 = (ShipAPI)var2;
      float var9 = (float)var3.getRed() / 255.0F;
      float var10 = (float)var3.getGreen() / 255.0F;
      float var11 = (float)var3.getBlue() / 255.0F;
      if(var0 != 1.0F) {
         Global.getSoundPlayer().playLoop("beamchargeM", var7, 1.0F, 1.0F, var7.getLocation(), var7.getVelocity());
         particle.advance(Global.getCombatEngine().getElapsedInLastFrame());
         if(particle.intervalElapsed()) {
            Vector2f var12 = new Vector2f(var1);
            Vector2f var13 = new Vector2f(-5.0F, -0.0F);
            VectorUtils.rotate(var13, var2.getFacing(), var13);
            Vector2f.add(var13, var12, var12);
            Vector2f var14 = var7.getVelocity();
            Global.getCombatEngine().addHitParticle(var12, var14, MathUtils.getRandomNumberInRange(10.0F * var4, var0 * var4 * 20.0F + 20.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var0), MathUtils.getRandomNumberInRange(0.1F, 0.1F + var0 / 10.0F), new Color(var9 * var0, var10 * var0, var11 * var0, var0));
            Vector2f var15 = MathUtils.getRandomPointInCircle(new Vector2f(), 35.0F * var0);
            Vector2f var16 = new Vector2f();
            Vector2f.sub(var12, new Vector2f(var15), var16);
            Vector2f.add(var14, var15, var15);

            for(int var17 = 0; var17 < 5 + (int)(var0 * 5.0F); ++var17) {
               Global.getCombatEngine().addHitParticle(var16, var15, MathUtils.getRandomNumberInRange(2.0F, var5 * 2.0F + 2.0F), MathUtils.getRandomNumberInRange(0.25F, 0.25F + var5), MathUtils.getRandomNumberInRange(0.75F, 0.75F + var5 / 4.0F), new Color(var9 * var5, var10 * var5, var11 * var5, var5));
            }
         }
      }

   }

   public static void createChargeParticle(float var0, ShipEngineAPI var1, CombatEntityAPI var2) {
      float var3 = var0;
      float var4 = 1.0F;
      ShipAPI var5 = (ShipAPI)var2;
      Color var6 = ((ShipEngineAPI)var5.getEngineController().getShipEngines().get(0)).getEngineColor();
      float var7 = (float)var6.getRed() / 255.0F;
      float var8 = (float)var6.getGreen() / 255.0F;
      float var9 = (float)var6.getBlue() / 255.0F;
      if(var0 != 1.0F) {
         Global.getSoundPlayer().playLoop("beamchargeM", var5, 1.0F, 1.0F, var5.getLocation(), var5.getVelocity());
         particle.advance(Global.getCombatEngine().getElapsedInLastFrame());
         if(particle.intervalElapsed()) {
            Vector2f var10 = new Vector2f(var1.getLocation());
            Vector2f var11 = new Vector2f(-5.0F, -0.0F);
            VectorUtils.rotate(var11, var2.getFacing(), var11);
            Vector2f.add(var11, var10, var10);
            Vector2f var12 = var5.getVelocity();
            Global.getCombatEngine().addHitParticle(var10, var12, MathUtils.getRandomNumberInRange(10.0F * var4, var0 * var4 * 40.0F + 20.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var0), MathUtils.getRandomNumberInRange(0.1F, 0.1F + var0 / 10.0F), new Color(var7 * var0, var8 * var0, var9 * var0));
            Vector2f var13 = MathUtils.getRandomPointInCircle(new Vector2f(), 35.0F * var0);
            Vector2f var14 = new Vector2f();
            Vector2f.sub(var10, new Vector2f(var13), var14);
            Vector2f.add(var12, var13, var13);

            for(int var15 = 0; var15 < 5; ++var15) {
               Global.getCombatEngine().addHitParticle(var14, var13, MathUtils.getRandomNumberInRange(2.0F, var3 * 2.0F + 2.0F), MathUtils.getRandomNumberInRange(0.5F, 0.5F + var3), MathUtils.getRandomNumberInRange(0.75F, 0.75F + var3 / 4.0F), new Color(var7 * var3, var8 * var3, var9 * var3));
            }
         }
      }

   }

   public static float getFPWorthOfSupport(ShipAPI var0, float var1) {
      float var2 = 0.0F;
      Iterator var3 = AIUtils.getNearbyAllies(var0, var1).iterator();

      while(var3.hasNext()) {
         ShipAPI var4 = (ShipAPI)var3.next();
         if(var4 != var0) {
            float var5 = var0.getCollisionRadius() + var4.getCollisionRadius();
            float var6 = Math.max(0.0F, MathUtils.getDistance(var0, var4) - var5);
            float var7 = Math.max(1.0F, var1 - var5);
            var2 += getFPStrength(var4) * (1.0F - var6 / var7);
         }
      }

      return var2;
   }

   public static float getFPWorthOfHostility(ShipAPI var0, float var1) {
      float var2 = 0.0F;

      ShipAPI var4;
      float var6;
      float var7;
      for(Iterator var3 = AIUtils.getNearbyEnemies(var0, var1).iterator(); var3.hasNext(); var2 += getFPStrength(var4) * (1.0F - var6 / var7)) {
         var4 = (ShipAPI)var3.next();
         float var5 = var0.getCollisionRadius() + var4.getCollisionRadius();
         var6 = Math.max(0.0F, MathUtils.getDistance(var0, var4) - var5);
         var7 = Math.max(1.0F, var1 - var5);
      }

      return var2;
   }

   public static float getStrengthInArea(Vector2f var0, float var1) {
      float var2 = 0.0F;

      ShipAPI var4;
      for(Iterator var3 = CombatUtils.getShipsWithinRange(var0, var1).iterator(); var3.hasNext(); var2 += getFPStrength(var4)) {
         var4 = (ShipAPI)var3.next();
      }

      return var2;
   }

   public static float getStrengthInArea(Vector2f var0, float var1, int var2) {
      float var3 = 0.0F;
      Iterator var4 = CombatUtils.getShipsWithinRange(var0, var1).iterator();

      while(var4.hasNext()) {
         ShipAPI var5 = (ShipAPI)var4.next();
         if(var5.getOwner() == var2) {
            var3 += getFPStrength(var5);
         }
      }

      return var3;
   }

   public static float getFPStrength(ShipAPI var0) {
      DeployedFleetMemberAPI var1 = Global.getCombatEngine().getFleetManager(var0.getOwner()).getDeployedFleetMember(var0);
      return var1 != null && var1.getMember() != null?var1.getMember().getMemberStrength():0.0F;
   }

   public static float getFP(ShipAPI var0) {
      DeployedFleetMemberAPI var1 = Global.getCombatEngine().getFleetManager(var0.getOwner()).getDeployedFleetMember(var0);
      return var1 != null && var1.getMember() != null?(float)var1.getMember().getFleetPointCost():0.0F;
   }

   public static float getBaseOverloadDuration(ShipAPI var0) {
      return ((Float)baseOverloadTimes.get(var0.getHullSize())).floatValue();
   }

   public static float estimateOverloadDurationOnHit(ShipAPI var0, float var1, DamageType var2) {
      if(var0.getShield() == null) {
         return 0.0F;
      } else {
         float var3 = var1 * var2.getShieldMult() * var0.getMutableStats().getShieldAbsorptionMult().getModifiedValue();
         var3 += var0.getFluxTracker().getCurrFlux() - var0.getFluxTracker().getMaxFlux();
         return var3 <= 0.0F?0.0F:Math.min(15.0F, getBaseOverloadDuration(var0) + var3 / 25.0F);
      }
   }

   public static float getLifeExpectancy(ShipAPI var0) {
      float var1 = estimateIncomingDamage(var0);
      return var1 <= 0.0F?3600.0F:var0.getHitpoints() / var1;
   }

   public static float lerp(float var0, float var1, float var2) {
      return (1.0F - var2) * var0 + var2 * var1;
   }

   public static int clamp255(int var0) {
      return Math.max(0, Math.min(255, var0));
   }

   public static float effectiveRadius(ShipAPI var0) {
      if(var0.getSpriteAPI() != null && !var0.isPiece()) {
         float var1 = 1.5F;
         return (var0.getSpriteAPI().getWidth() / 2.0F + var0.getSpriteAPI().getHeight() / 2.0F) * 0.5F * var1;
      } else {
         return var0.getCollisionRadius();
      }
   }

   public static String getMoreAggressivePersonality(FleetMemberAPI var0, ShipAPI var1) {
      if(var1 == null) {
         return "aggressive";
      } else {
         boolean var2 = false;
         if(var0 != null && var0.getFleetData() != null && var0.getFleetData().getFleet() != null && var0.getFleetData().getFleet().isPlayerFleet()) {
            var2 = true;
         }

         String var3 = null;
         if(var0 != null) {
            if(var0.getCaptain() != null) {
               if(var2 && (!var0.getCaptain().isDefault() || var0.getCaptain().isPlayer())) {
                  return null;
               }

               var3 = var0.getCaptain().getPersonalityAPI().getId();
            }
         } else if(var1.getCaptain() != null) {
            var3 = var1.getCaptain().getPersonalityAPI().getId();
         }

         if(var1.getShipAI() != null && var1.getShipAI().getConfig() != null && var1.getShipAI().getConfig().personalityOverride != null) {
            var3 = var1.getShipAI().getConfig().personalityOverride;
         }

         String var4;
         if(var3 == null) {
            var4 = "aggressive";
         } else {
            byte var6 = -1;
            switch(var3.hashCode()) {
            case -892381166:
               if(var3.equals("steady")) {
                  var6 = 3;
               }
               break;
            case -803105292:
               if(var3.equals("reckless")) {
                  var6 = 5;
               }
               break;
            case 93052737:
               if(var3.equals("cautious")) {
                  var6 = 1;
               }
               break;
            case 110364595:
               if(var3.equals("timid")) {
                  var6 = 0;
               }
               break;
            case 1147132932:
               if(var3.equals("aggressive")) {
                  var6 = 4;
               }
            }

            switch(var6) {
            case 0:
               var4 = "cautious";
               break;
            case 1:
               var4 = "steady";
               break;
            case 2:
            case 3:
            default:
               var4 = "aggressive";
               break;
            case 4:
            case 5:
               var4 = "reckless";
            }
         }

         return var4;
      }
   }

   public static String getLessAggressivePersonality(FleetMemberAPI var0, ShipAPI var1) {
      if(var1 == null) {
         return "cautious";
      } else {
         boolean var2 = false;
         if(var0 != null && var0.getFleetData() != null && var0.getFleetData().getFleet() != null && var0.getFleetData().getFleet().isPlayerFleet()) {
            var2 = true;
         }

         String var3 = null;
         if(var0 != null) {
            if(var0.getCaptain() != null) {
               if(var2 && (!var0.getCaptain().isDefault() || var0.getCaptain().isPlayer())) {
                  return null;
               }

               var3 = var0.getCaptain().getPersonalityAPI().getId();
            }
         } else if(var1.getCaptain() != null) {
            var3 = var1.getCaptain().getPersonalityAPI().getId();
         }

         if(var1.getShipAI() != null && var1.getShipAI().getConfig() != null && var1.getShipAI().getConfig().personalityOverride != null) {
            var3 = var1.getShipAI().getConfig().personalityOverride;
         }

         String var4;
         if(var3 == null) {
            var4 = "cautious";
         } else {
            byte var6 = -1;
            switch(var3.hashCode()) {
            case -892381166:
               if(var3.equals("steady")) {
                  var6 = 3;
               }
               break;
            case -803105292:
               if(var3.equals("reckless")) {
                  var6 = 5;
               }
               break;
            case 93052737:
               if(var3.equals("cautious")) {
                  var6 = 1;
               }
               break;
            case 110364595:
               if(var3.equals("timid")) {
                  var6 = 0;
               }
               break;
            case 1147132932:
               if(var3.equals("aggressive")) {
                  var6 = 4;
               }
            }

            switch(var6) {
            case 0:
            case 1:
               var4 = "timid";
               break;
            case 2:
            case 3:
            default:
               var4 = "cautious";
               break;
            case 4:
               var4 = "steady";
               break;
            case 5:
               var4 = "aggressive";
            }
         }

         return var4;
      }
   }

   static {
      baseOverloadTimes.put(HullSize.FIGHTER, Float.valueOf(10.0F));
      baseOverloadTimes.put(HullSize.FRIGATE, Float.valueOf(4.0F));
      baseOverloadTimes.put(HullSize.DESTROYER, Float.valueOf(6.0F));
      baseOverloadTimes.put(HullSize.CRUISER, Float.valueOf(8.0F));
      baseOverloadTimes.put(HullSize.CAPITAL_SHIP, Float.valueOf(10.0F));
      baseOverloadTimes.put(HullSize.DEFAULT, Float.valueOf(6.0F));
   }
}
