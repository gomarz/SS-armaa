package data.scripts.util;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_reloadEveryFrame extends BaseEveryFrameCombatPlugin {

   private ShipAPI ship;
   private static float DAMAGE_BONUS = 2.0F;
   private float count = 0.4F;
   private boolean recoiling = false;
   private IntervalUtil buffTimer = new IntervalUtil(3.0F, 3.0F);


   public armaa_reloadEveryFrame(ShipAPI var1) {
      this.ship = var1;
   }

   public void advance(float var1, List var2) {
      if(!Global.getCombatEngine().isPaused()) {
         boolean var3 = this.ship == Global.getCombatEngine().getPlayerShip();
         MutableShipStatsAPI var4 = this.ship.getMutableStats();
         var4.getBallisticRoFMult().modifyMult(this.ship.getId(), DAMAGE_BONUS);
         var4.getBallisticWeaponFluxCostMod().modifyMult(this.ship.getId(), DAMAGE_BONUS);
         var4.getBallisticWeaponDamageMult().modifyMult(this.ship.getId(), DAMAGE_BONUS);
         this.ship.setWeaponGlow(this.buffTimer.getIntervalDuration() - this.buffTimer.getElapsed(), Color.red, EnumSet.of(WeaponType.BALLISTIC));
         this.buffTimer.advance(var1);
         Iterator var5 = this.ship.getAllWeapons().iterator();

         while(var5.hasNext()) {
            WeaponAPI var6 = (WeaponAPI)var5.next();
            if(var6.getId().equals("armaa_barretta")) {
               if(var6.getChargeLevel() == 1.0F) {
                  Global.getSoundPlayer().playSound("armaa_rcl_fire", 0.8F, 1.0F, this.ship.getLocation(), new Vector2f());
                  float var7 = 180.0F + var6.getCurrAngle();
                  Vector2f var8 = MathUtils.getPoint(var6.getFirePoint(0), 45.0F, var7);

                  int var9;
                  Vector2f var10;
                  for(var9 = 0; var9 < 20; ++var9) {
                     var10 = MathUtils.getRandomPointInCone(new Vector2f(), 100.0F, var7 - 20.0F, var7 + 20.0F);
                     var10.scale((float)Math.random());
                     Vector2f.add(var10, var6.getShip().getVelocity(), var10);
                     float var11 = MathUtils.getRandomNumberInRange(0.5F, 0.75F);
                     Global.getCombatEngine().addSmokeParticle(MathUtils.getRandomPointInCircle(var6.getFirePoint(0), 5.0F), var10, (float)MathUtils.getRandomNumberInRange(5, 20), MathUtils.getRandomNumberInRange(0.25F, 0.75F), MathUtils.getRandomNumberInRange(0.25F, 1.0F), new Color(var11, var11, var11, MathUtils.getRandomNumberInRange(0.25F, 0.75F)));
                  }

                  for(var9 = 0; var9 < 10; ++var9) {
                     var10 = MathUtils.getRandomPointInCone(new Vector2f(), 250.0F, var7 - 20.0F, var7 + 20.0F);
                     Vector2f.add(var10, var6.getShip().getVelocity(), var10);
                     Global.getCombatEngine().addHitParticle(var8, var10, (float)MathUtils.getRandomNumberInRange(2, 4), 1.0F, MathUtils.getRandomNumberInRange(0.05F, 0.25F), new Color(255, 125, 50));
                  }

                  Vector2f var12 = MathUtils.getRandomPointInCone(new Vector2f(), 100.0F, var7 - 20.0F, var7 + 20.0F);
                  var12.scale((float)Math.random());
                  Vector2f.add(var12, var6.getShip().getVelocity(), var12);
                  Global.getCombatEngine().addHitParticle(var8, var12, 100.0F, 0.5F, 0.5F, new Color(255, 20, 10));
                  Global.getCombatEngine().addHitParticle(var8, var12, 80.0F, 0.75F, 0.15F, new Color(255, 200, 50));
                  Global.getCombatEngine().addHitParticle(var8, var12, 50.0F, 1.0F, 0.05F, new Color(255, 200, 150));
                  var8 = MathUtils.getPoint(var6.getFirePoint(0), 0.0F, var7);
                  Global.getCombatEngine().addHitParticle(var8, this.ship.getVelocity(), 100.0F, 0.5F, 0.5F, new Color(255, 20, 10));
                  Global.getCombatEngine().addHitParticle(var8, this.ship.getVelocity(), 80.0F, 0.75F, 0.15F, new Color(255, 200, 50));
                  Global.getCombatEngine().addHitParticle(var8, this.ship.getVelocity(), 50.0F, 1.0F, 0.05F, new Color(255, 200, 150));
                  if(!this.recoiling) {
                     this.recoiling = true;
                  }
               }

               if(this.recoiling && this.count > 0.0F) {
                  this.count -= var1;
                  this.ship.setFacing(this.ship.getFacing() - this.count);
               }

               if(this.count <= 0.0F) {
                  this.count = 0.4F;
                  this.recoiling = false;
               }
            }
         }

         Global.getCombatEngine().maintainStatusForPlayerShip("eis_wingClipper", "graphics/ui/icons/icon_repair_refit.png", "Air Superiority", "Time Dilation: +", false);
         if(this.buffTimer.intervalElapsed() || !this.ship.isAlive()) {
            var4.getBallisticWeaponFluxCostMod().unmodify(this.ship.getId());
            var4.getBallisticWeaponDamageMult().unmodify(this.ship.getId());
            var4.getBallisticRoFMult().unmodify(this.ship.getId());
            this.ship.setWeaponGlow(0.0F, new Color(255, 125, 50, 220), EnumSet.of(WeaponType.BALLISTIC, WeaponType.MISSILE, WeaponType.ENERGY));
            Global.getCombatEngine().removePlugin(this);
         }

      }
   }

}
