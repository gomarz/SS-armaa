package data.scripts.util;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.util.armaa_utils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.FastTrig;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;
import org.magiclib.util.MagicUI;

public class armaa_sykoEveryFrame extends BaseEveryFrameCombatPlugin {

   private ShipAPI ship;
   private float MIN_PROJECTILE_DMG = 40.0F;
   private float GRAZE_DAMAGE_BONUS = 10.0F;
   private float GRAZE_TIME_BONUS = 1.6F;
   private float GRAZE_TIME_BONUS_MIN = 1.1F;
   private float MAX_TIME_MULT = 1.0F;
   private float MIN_TIME_MULT = 0.1F;
   private float AFTERIMAGE_THRESHOLD = 0.1F;
   private IntervalUtil buffTimer = new IntervalUtil(3.0F, 3.0F);
   private IntervalUtil coolDownTimer = new IntervalUtil(9.0F, 9.0F);
   private boolean dodgeBonus = false;
   private boolean cooldown = false;
   private float multBonus = 1.0F;


   public armaa_sykoEveryFrame(ShipAPI var1, float var2, float var3, float var4, float var5, float var6, float var7) {
      this.ship = var1;
      this.MIN_PROJECTILE_DMG = var2;
      this.GRAZE_DAMAGE_BONUS = var3;
      this.GRAZE_TIME_BONUS = var4;
      this.GRAZE_TIME_BONUS_MIN = var5;
      this.buffTimer = new IntervalUtil(var6, var6);
      this.coolDownTimer = new IntervalUtil(var7, var7);
   }

   public armaa_sykoEveryFrame(ShipAPI var1) {
      this.ship = var1;
   }

   public void advance(float var1, List var2) {
      if(!Global.getCombatEngine().isPaused()) {
         float var3 = this.coolDownTimer.getElapsed();
         float var4 = this.coolDownTimer.getMaxInterval();
         float var5 = var3 / var4;
         MagicUI.drawInterfaceStatusBar(this.ship, var5, Color.RED, Color.RED, var5, "Graze", (int)((1.0F - var5) * 100.0F));
         boolean var6 = this.ship == Global.getCombatEngine().getPlayerShip();
         boolean var7 = false;
         boolean var8 = Global.getCombatEngine().isInCampaign();
         if(!(Global.getCombatEngine().getCustomData().get("armaa_hasCopium_" + this.ship.getId()) instanceof Boolean)) {
            var7 = this.ship.getOwner() == 0?!var8 || Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity("drugs") > 0.0F:false;
         }

         if(this.ship.isAlive() && !this.ship.isPiece()) {
            float var12;
            if(!this.dodgeBonus && !this.cooldown && var7 && !CombatUtils.getEntitiesWithinRange(this.ship.getLocation(), 1000.0F).isEmpty() && !this.ship.isFinishedLanding()) {
               ArrayList var9 = new ArrayList(100);
               var9.addAll(CombatUtils.getMissilesWithinRange(this.ship.getLocation(), this.ship.getCollisionRadius()));
               var9.addAll(CombatUtils.getProjectilesWithinRange(this.ship.getLocation(), this.ship.getCollisionRadius()));
               Iterator var10 = var9.iterator();

               while(var10.hasNext()) {
                  DamagingProjectileAPI var11 = (DamagingProjectileAPI)var10.next();
                  var12 = 0.0F;
                  if(var11.getOwner() != this.ship.getOwner() && !var11.isFading() && var11.getCollisionClass() != CollisionClass.NONE) {
                     if(var11 instanceof MissileAPI) {
                        MissileAPI var13 = (MissileAPI)var11;
                        if(var13.isFlare()) {
                           continue;
                        }
                     }

                     if(Global.getCombatEngine().isEntityInPlay(var11) && !var11.didDamage() && var11.getBaseDamageAmount() > 0.0F) {
                        if(var11.getDamageType() == DamageType.FRAGMENTATION) {
                           var12 = var11.getDamageAmount() * 0.5F + var11.getEmpAmount() * 0.5F;
                        } else {
                           var12 = var11.getDamageAmount() + var11.getEmpAmount() * 0.25F;
                        }

                        if(CollisionUtils.isPointWithinCollisionCircle(var11.getLocation(), this.ship) && (this.ship.getShield() == null || this.ship.getShield().isOff()) && !CollisionUtils.getCollides(var11.getLocation(), var11.getVelocity(), this.ship.getLocation(), 25.0F) && var12 >= 40.0F && !var11.didDamage()) {
                           SpriteAPI var28 = Global.getSettings().getSprite("misc", "armaa_sfxpulse");
                           if(var28 != null) {
                              MagicRender.battlespace(var28, this.ship.getLocation(), new Vector2f(), new Vector2f(5.0F, 5.0F), new Vector2f(200.0F, 200.0F), 15.0F, 15.0F, new Color(255, 255, 255, 155), true, 0.3F, 0.0F, 0.3F);
                           }

                           Global.getCombatEngine().addFloatingText(this.ship.getLocation(), "Grazed!", 15.0F, Color.white, var11, 0.0F, 0.0F);
                           Global.getSoundPlayer().playSound("ui_neural_transfer_begin", 0.7F, 1.0F, this.ship.getLocation(), new Vector2f());
                           armaa_utils.blink(var11.getLocation());
                           CombatUtils.applyForce(var11, -var11.getFacing(), 25.0F);
                           this.dodgeBonus = true;
                        }
                     }
                  }
               }
            }

            boolean var25 = false;
            float var26 = 99999.0F;
            float var27 = 1.0F;
            float var14;
            String var15;
            float var29;
            if(this.dodgeBonus) {
               this.buffTimer.advance(var1);
               var12 = this.buffTimer.getElapsed();
               var29 = this.buffTimer.getMaxInterval();
               var27 = var12 / var29;
               this.multBonus = this.GRAZE_TIME_BONUS * (1.0F - var27);
               var14 = (float)Math.round(var12 / var29 * 100.0F);
               var15 = String.valueOf(var14);
               if(var6) {
                  Global.getCombatEngine().maintainStatusForPlayerShip("adrenal", "graphics/ui/icons/icon_search_and_destroy.png", "Grazed", "DMG +" + (int)(this.GRAZE_DAMAGE_BONUS * (1.0F - var27)) + "%", false);
               }

               this.ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerNullerID", -1.0F);
               this.ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerID", this.ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() + var1);
               if(this.ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() > this.AFTERIMAGE_THRESHOLD) {
                  SpriteAPI var16 = this.ship.getSpriteAPI();
                  float var17 = var16.getWidth() / 2.0F - var16.getCenterX();
                  float var18 = var16.getHeight() / 2.0F - var16.getCenterY();
                  float var19 = (float)FastTrig.cos(Math.toRadians((double)(this.ship.getFacing() - 90.0F))) * var17 - (float)FastTrig.sin(Math.toRadians((double)(this.ship.getFacing() - 90.0F))) * var18;
                  float var20 = (float)FastTrig.sin(Math.toRadians((double)(this.ship.getFacing() - 90.0F))) * var17 + (float)FastTrig.cos(Math.toRadians((double)(this.ship.getFacing() - 90.0F))) * var18;
                  if(!this.ship.isHulk()) {
                     Iterator var21 = this.ship.getAllWeapons().iterator();

                     while(var21.hasNext()) {
                        WeaponAPI var22 = (WeaponAPI)var21.next();
                        if((var22.getSlot().isBuiltIn() || var22.getSlot().isDecorative()) && (var22.getSpec().getType() != WeaponType.MISSILE || var22.getAmmo() >= 0) && var22.getSprite() != null) {
                           if(!var22.getSlot().getId().equals("F_LEGS")) {
                              MagicRender.battlespace(Global.getSettings().getSprite(var22.getSpec().getTurretSpriteName()), new Vector2f(var22.getLocation().getX() + var19, var22.getLocation().getY() + var20), new Vector2f(0.0F, 0.0F), new Vector2f(var22.getSprite().getWidth(), var22.getSprite().getHeight()), new Vector2f(0.0F, 0.0F), this.ship.getFacing() - 90.0F, 0.0F, new Color(100, 255, 150, 185), true, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1F, 0.1F, 0.3F, CombatEngineLayers.BELOW_SHIPS_LAYER);
                           } else {
                              int var23 = var22.getAnimation().getFrame();
                              SpriteAPI var24 = Global.getSettings().getSprite("graphics/armaa/ships/valkazard/armaa_valkazard_legs0" + var23 + ".png");
                              if(var23 >= 10) {
                                 var24 = Global.getSettings().getSprite("graphics/armaa/ships/valkazard/armaa_valkazard_legs" + var23 + ".png");
                              }

                              MagicRender.battlespace(var24, new Vector2f(var22.getLocation().getX() + var19, var22.getLocation().getY() + var20), new Vector2f(0.0F, 0.0F), new Vector2f(var22.getSprite().getWidth(), var22.getSprite().getHeight()), new Vector2f(0.0F, 0.0F), this.ship.getFacing() - 90.0F, 0.0F, new Color(100, 255, 150, 185), true, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1F, 0.1F, 0.3F, CombatEngineLayers.BELOW_SHIPS_LAYER);
                           }

                           if(var22.getBarrelSpriteAPI() != null && (var22.getSlot().getId().equals("C_ARML") || var22.getSlot().getId().equals("A_GUN"))) {
                              SpriteAPI var30 = Global.getSettings().getSprite(var22.getSpec().getHardpointSpriteName());
                              MagicRender.battlespace(var30, new Vector2f(var22.getLocation().getX() + var19, var22.getLocation().getY() + var20), new Vector2f(0.0F, 0.0F), new Vector2f(var22.getBarrelSpriteAPI().getWidth(), var22.getBarrelSpriteAPI().getHeight()), new Vector2f(0.0F, 0.0F), var22.getCurrAngle() - 90.0F, 0.0F, new Color(100, 200, 150, 185), true, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1F, 0.1F, 0.3F, CombatEngineLayers.BELOW_SHIPS_LAYER);
                           }
                        }
                     }
                  }

                  this.ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerID", this.ship.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() - this.AFTERIMAGE_THRESHOLD);
               }
            }

            if(this.buffTimer.intervalElapsed() && this.dodgeBonus) {
               this.dodgeBonus = false;
               this.cooldown = true;
            }

            if(this.cooldown) {
               this.coolDownTimer.advance(var1);
               var27 = 0.0F;
               var12 = this.coolDownTimer.getElapsed();
               var29 = this.coolDownTimer.getMaxInterval();
               var14 = (float)Math.round(var12 / var29 * 100.0F);
               var15 = String.valueOf(var14);
               if(var6) {
                  Global.getCombatEngine().maintainStatusForPlayerShip("adrenal", "graphics/ui/icons/icon_repair_refit.png", "Crash", var15 + "%", true);
               }
            }

            if(this.coolDownTimer.intervalElapsed() && this.cooldown) {
               this.cooldown = false;
               var27 = 0.0F;
            }

            this.ship.getMutableStats().getTimeMult().modifyMult(this.ship.getId() + "_graze", this.MAX_TIME_MULT + this.multBonus);
            if(!this.cooldown && !this.dodgeBonus) {
               this.multBonus = 0.0F;
               this.ship.getMutableStats().getEnergyWeaponDamageMult().unmodify(this.ship.getId() + "_graze");
               this.ship.getMutableStats().getBallisticWeaponDamageMult().unmodify(this.ship.getId() + "_graze");
            } else {
               this.ship.getMutableStats().getEnergyWeaponDamageMult().modifyPercent(this.ship.getId() + "_graze", this.GRAZE_DAMAGE_BONUS * (1.0F - var27));
               this.ship.getMutableStats().getBallisticWeaponDamageMult().modifyPercent(this.ship.getId() + "_graze", this.GRAZE_DAMAGE_BONUS * (1.0F - var27));
            }

            if(var6 && this.ship.isAlive()) {
               if(!this.ship.isLanding() && !this.ship.isFinishedLanding()) {
                  var12 = 1.0F / (this.MAX_TIME_MULT + this.multBonus);
                  Global.getCombatEngine().getTimeMult().modifyMult(this.ship.getId() + "_graze", var12);
               }
            } else {
               Global.getCombatEngine().getTimeMult().unmodify(this.ship.getId() + "_graze");
            }

         } else {
            Global.getCombatEngine().getTimeMult().unmodify(this.ship.getId() + "_graze");
         }
      }
   }
}
