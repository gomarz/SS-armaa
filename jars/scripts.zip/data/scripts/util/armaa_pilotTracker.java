package data.scripts.util;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.BaseEveryFrameCombatPlugin;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.MechaModPlugin;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Random;
import org.apache.log4j.Logger;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_pilotTracker extends BaseEveryFrameCombatPlugin {

   private ShipAPI fighter;
   private String name;
   private ShipAPI ship;
   private PersonAPI captain;
   private int pilotNo;
   private IntervalUtil interval = new IntervalUtil(10.0F, 10.0F);
   private IntervalUtil openingDialogue = new IntervalUtil(3.0F, 15.0F);
   private IntervalUtil combatDialogue = new IntervalUtil(5.0F, 40.0F);
   private boolean runOnce = false;
   private boolean hasChattered = false;
   private boolean hasSquadChattered = false;
   private List introChatter = new ArrayList();
   private HashSet alreadyUsed = new HashSet();
   private List combatChatter = new ArrayList();
   private List squadChatter_s = new ArrayList();
   private List squadChatter_r = new ArrayList();
   private Logger logger;


   public armaa_pilotTracker(ShipAPI var1, String var2, int var3) {
      this.fighter = var1;
      this.name = var2;
      this.pilotNo = var3;
      this.ship = var1.getWing().getSourceShip();
      this.captain = var1.getWing().getSourceShip().getCaptain();
      int var4 = this.ship.getOwner() == 0?1:0;
      this.introChatter.addAll(MechaModPlugin.introChatter);
      if(Global.getCombatEngine().getFleetManager(var4).getFleetCommander() != null) {
         String var5 = Global.getCombatEngine().getFleetManager(var4).getFleetCommander().getFaction().getId();
         if(MechaModPlugin.introChatter_special.containsKey(var5)) {
            this.introChatter.addAll((Collection)MechaModPlugin.introChatter_special.get(var5));
         }
      }

      Iterator var7 = Global.getCombatEngine().getFleetManager(var4).getDeployedCopy().iterator();

      while(var7.hasNext()) {
         FleetMemberAPI var6 = (FleetMemberAPI)var7.next();
         if(MechaModPlugin.introChatter_special.containsKey(var6.getHullId())) {
            this.introChatter.addAll((Collection)MechaModPlugin.introChatter_special.get(var6.getHullId()));
         }

         if(MechaModPlugin.introChatter_special.containsKey(var6.getCaptain().getId())) {
            this.introChatter.addAll((Collection)MechaModPlugin.introChatter_special.get(var6.getCaptain().getId()));
         }
      }

      this.combatChatter.addAll(MechaModPlugin.combatChatter);
      this.squadChatter_s.addAll(MechaModPlugin.intersquadChatter_statement);
      this.squadChatter_r.addAll(MechaModPlugin.intersquadChatter_response);
   }

   public void advance(float var1, List var2) {
      if(!Global.getCombatEngine().isPaused()) {
         if(!this.introChatter.isEmpty() && MechaModPlugin.chatterEnabled) {
            if(Global.getCombatEngine().getCustomData().get("armaa_wingCommander_squadron_hasChattered_" + this.captain.getId()) instanceof Boolean) {
               this.hasChattered = ((Boolean)Global.getCombatEngine().getCustomData().get("armaa_wingCommander_squadron_hasChattered_" + this.captain.getId())).booleanValue();
            }

            if(!Global.getCombatEngine().isPaused()) {
               this.interval.advance(var1);
               if(!this.runOnce && !this.hasChattered && this.fighter.getWing().getLeader() == this.fighter) {
                  this.openingDialogue.advance(var1);
                  if(this.openingDialogue.intervalElapsed()) {
                     if(Math.random() >= 0.699999988079071D) {
                        if(Global.getCombatEngine().getCustomData().containsKey("armaa_alreadyUsedLines")) {
                           this.alreadyUsed = (HashSet)Global.getCombatEngine().getCustomData().get("armaa_alreadyUsedLines");
                        }

                        String var3 = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_" + this.captain.getId());
                        Random var4 = new Random();
                        int var5 = var4.nextInt(this.introChatter.size());
                        String var6 = (String)this.introChatter.get(var5);
                        if(!this.alreadyUsed.contains(var6)) {
                           this.alreadyUsed.add(var6);
                           Global.getCombatEngine().getCustomData().put("armaa_alreadyUsedLines", this.alreadyUsed);
                           Color var7 = this.fighter.isAlly()?Misc.getHighlightColor():Misc.getBasePlayerColor();
                           Color var8 = Global.getSettings().getColor("standardTextColor");
                           if(var6.contains("$")) {
                              String var9 = this.processSpecialStrings(this.fighter, this.ship, var6);
                              Global.getCombatEngine().getCombatUI().addMessage(1, new Object[]{this.fighter, var7, var3, Color.white, ":", var8, var9});
                           } else {
                              Global.getCombatEngine().getCombatUI().addMessage(1, new Object[]{this.fighter, var7, var3, Color.white, ":", var8, var6});
                           }
                        }
                     }

                     this.runOnce = true;
                     Global.getCombatEngine().getCustomData().put("armaa_wingCommander_squadron_hasChattered_" + this.captain.getId(), Boolean.valueOf(true));
                  }
               }
            }
         }

         this.combatDialogue.advance(var1);
         float var20 = (float)this.fighter.getWing().getWingMembers().size();
         if(Global.getCombatEngine().getCustomData().get("armaa_wingCommander_squadron_hasSquadChattered_" + this.captain.getId()) instanceof Boolean) {
            this.hasSquadChattered = ((Boolean)Global.getCombatEngine().getCustomData().get("armaa_wingCommander_squadron_hasSquadChattered_" + this.captain.getId())).booleanValue();
         }

         Color var21;
         if(this.combatDialogue.intervalElapsed() && MechaModPlugin.chatterEnabled) {
            var21 = this.fighter.isAlly()?Misc.getHighlightColor():Misc.getBasePlayerColor();
            Color var22 = Global.getSettings().getColor("standardTextColor");
            if(this.fighter.getOwner() == 1) {
               var21 = Misc.getNegativeHighlightColor();
            }

            boolean var24 = false;
            float var25 = 0.2F;
            if(MagicRender.screenCheck(0.2F, this.fighter.getLocation())) {
               var25 *= 3.0F;
            }

            Iterator var26 = this.fighter.getAllWeapons().iterator();

            while(var26.hasNext()) {
               WeaponAPI var29 = (WeaponAPI)var26.next();
               if(var29.isFiring()) {
                  var24 = true;
                  break;
               }
            }

            int var30;
            if(!var24 && this.fighter.getShipTarget() == null) {
               if(Math.random() <= (double)(0.15F / var20) && !this.hasSquadChattered) {
                  int var28 = ((Integer)Global.getSector().getPersistentData().get("armaa_wingCommander_squadSize_" + this.captain.getId())).intValue();

                  for(var30 = 0; var30 < var28; ++var30) {
                     boolean var31 = false;
                     Object var32 = Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_" + var30 + "_" + this.captain.getId());
                     if(var32 instanceof PersonAPI && this.fighter.getWing().getSpec().getVariant().getHullSpec().getMinCrew() > 0.0F) {
                        Object var33 = Global.getCombatEngine().getCustomData().get("armaa_wingCommander_wingman_" + var30 + "_wasAssigned_" + this.captain.getId());
                        if(var33 instanceof Boolean) {
                           var31 = ((Boolean)Global.getCombatEngine().getCustomData().get("armaa_wingCommander_wingman_" + var30 + "_wasAssigned_" + this.captain.getId())).booleanValue();
                        }

                        PersonAPI var13 = (PersonAPI)Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_" + var30 + "_" + this.captain.getId());
                        if(var31 && var13 != this.fighter.getCaptain()) {
                           String var14 = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_" + var30 + "_" + "callsign_" + this.captain.getId());
                           String var15 = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_" + this.captain.getId());
                           Random var16 = new Random();
                           int var17 = var16.nextInt(this.squadChatter_s.size());
                           String var18 = (String)this.squadChatter_s.get(var17);
                           String var19;
                           if(var18.contains("$")) {
                              if(var18.contains("$squadmember")) {
                                 var19 = var18.replace("$squadmember", var14);
                                 var18 = var19;
                              }

                              var19 = this.processSpecialStrings(this.fighter, this.ship, var18);
                              var18 = var19;
                           }

                           Global.getCombatEngine().getCombatUI().addMessage(1, new Object[]{this.fighter, var21, this.name + ", " + var15, Color.white, ":", var22, var18});
                           var17 = var16.nextInt(this.squadChatter_r.size());
                           var18 = (String)this.squadChatter_r.get(var17);
                           if(var18.contains("$")) {
                              if(var18.contains("$squadmember")) {
                                 var19 = var18.replace("$squadmember", this.name);
                                 var18 = var19;
                              }

                              var19 = this.processSpecialStrings(this.fighter, this.ship, var18);
                              var18 = var19;
                           }

                           Global.getCombatEngine().getCombatUI().addMessage(1, new Object[]{this.fighter, var21, var14 + ", " + var15, Color.white, ":", var22, var18});
                           Global.getCombatEngine().getCustomData().put("armaa_wingCommander_squadron_hasSquadChattered_" + this.captain.getId(), Boolean.valueOf(true));
                           break;
                        }
                     }
                  }
               }
            } else if(Math.random() <= (double)(var25 / var20)) {
               Random var27 = new Random();
               var30 = var27.nextInt(this.combatChatter.size());
               String var10 = (String)this.combatChatter.get(var30);
               String var11 = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_" + this.captain.getId());
               if(var10.contains("$")) {
                  String var12 = this.processSpecialStrings(this.fighter, this.ship, var10);
                  var10 = var12;
               }

               if(!MagicRender.screenCheck(0.2F, this.fighter.getLocation())) {
                  Global.getCombatEngine().getCombatUI().addMessage(1, new Object[]{this.fighter, var21, this.name + ", " + var11, Color.white, ":", var22, var10});
               } else {
                  Global.getCombatEngine().addFloatingTextAlways(this.fighter.getLocation(), var10, 30.0F, Color.white, this.fighter, 0.0F, 0.0F, 1.0F, 3.0F, 2.0F, 0.0F);
               }
            }
         }

         if(Global.getCombatEngine() == null || this.fighter == null || this.fighter.getHitpoints() <= 0.0F || !Global.getCombatEngine().isEntityInPlay(this.fighter) || Global.getCombatEngine().isCombatOver()) {
            Global.getCombatEngine().getCustomData().put("armaa_wingCommander_wingman_" + this.pilotNo + "_wasAssigned_" + this.captain.getId(), Boolean.valueOf(false));
            Global.getCombatEngine().removePlugin(this);
         }

         if(MagicRender.screenCheck(0.2F, this.fighter.getLocation()) && !this.fighter.isLiftingOff() && this.fighter.isAlive()) {
            var21 = this.fighter.getOwner() == 1?Misc.getHighlightColor():Misc.getBasePlayerColor();
            Vector2f var23 = new Vector2f(this.fighter.getLocation());
            var23.setY(var23.getY() + 35.0F);
            if(!Global.getCombatEngine().hasAttachedFloaty(this.fighter)) {
               Global.getCombatEngine().addFloatingTextAlways(var23, this.name, 15.0F, var21, this.fighter, 0.0F, 0.0F, 5.0F, var1, var1, 0.0F);
            }
         }

      }
   }

   private String processSpecialStrings(ShipAPI var1, ShipAPI var2, String var3) {
      int var4 = var1.getOwner() == 0?1:0;
      if(Global.getCombatEngine().getFleetManager(var4) == null) {
         return "*static*";
      } else if(Global.getCombatEngine().getFleetManager(var4).getFleetCommander() == null) {
         return "*fzzt*";
      } else if(Global.getCombatEngine().getFleetManager(var4).getFleetCommander().getFaction() == null) {
         return "*bzzt*";
      } else if(var2 != null && var1 != null) {
         String var5 = var3;
         PersonAPI var6 = Global.getCombatEngine().getFleetManager(var4).getFleetCommander();
         String var7;
         if(var3.contains("$factionnamearticle")) {
            var7 = "the enemy";
            if(var6.getFaction().isPlayerFaction()) {
               if(Misc.getFactionMarkets(Global.getSector().getPlayerFaction()).isEmpty()) {
                  var7 = "the Savior of Galatia";
               }
            } else {
               var7 = Global.getCombatEngine().getFleetManager(var4).getFleetCommander().getFaction().getDisplayNameWithArticle();
            }

            var5 = var3.replace("$factionnamearticle", var7);
            var3 = var5;
         }

         if(var5.contains("$factionname")) {
            var7 = "hostiles";
            if(var6.getFaction().isPlayerFaction()) {
               if(Misc.getFactionMarkets(Global.getSector().getPlayerFaction()).isEmpty()) {
                  var7 = "unaffiliated";
               }
            } else {
               var7 = Global.getCombatEngine().getFleetManager(var4).getFleetCommander().getFaction().getDisplayName();
            }

            var5 = var3.replace("$factionname", var7);
            var3 = var5;
         }

         if(var5.contains("$squadronname")) {
            var7 = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_" + this.captain.getId());
            var5 = var3.replace("$squadronname", var7);
            var3 = var5;
         }

         if(var5.contains("$squadleader")) {
            var7 = "the Command Ship";
            if(var2 != null && var2.getName() != null) {
               var7 = var2.getName();
            }

            var5 = var3.replace("$squadleader", var7);
         }

         return var5;
      } else {
         return "*crackle*";
      }
   }
}
