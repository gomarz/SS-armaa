package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.GuidedMissileAI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import data.hullmods.armaa_KarmaMod;
import data.scripts.MechaModPlugin;
import java.awt.Color;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.combat.entities.SimpleEntity;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicLensFlare;
import org.magiclib.util.MagicRender;

public class armaa_karma extends BaseShipSystemScript {

   private ShipAPI ship;
   private final Color PARTICLE_COLOR = new Color(100, 166, 255);
   private final float PARTICLE_SIZE = 10.0F;
   private final float PARTICLE_BRIGHTNESS = 150.0F;
   private final float PARTICLE_DURATION = 1.0F;
   private final float EXPLOSION_SIZE_OUTER = 350.0F;
   private final float EXPLOSION_SIZE_INNER = 150.0F;
   private final float EXPLOSION_DAMAGE_MAX = 500.0F;
   private final float EXPLOSION_DAMAGE_MIN = 1.0F;
   private final float EXPLOSION_DURATION = 0.05F;
   private final float PARTICLE_DURATION2 = 0.2F;
   private final Color VFX_COLOR = new Color(149, 206, 240, 200);
   private final int PARTICLE_COUNT = 50;
   private final int PARTICLE_SIZE_MIN = 8;
   private final int PARTICLE_SIZE_RANGE = 3;
   private final Vector2f ZERO = new Vector2f();
   private float MIN_SPEED = 5.0F;
   private float MAX_SPEED = 10.0F;
   private float BASE_INCREMENT = 36.0F;
   private final Color GLOW_COLOUR = new Color(254, 205, 255, 255);
   private final Color MUZZLE_GLOW_COLOUR_EXTRA = new Color(182, 22, 235, 255);
   private final float MUZZLE_GLOW_SIZE = 95.0F;
   public boolean activated = true;


   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      if(var1.getEntity() instanceof ShipAPI) {
         this.ship = (ShipAPI)var1.getEntity();
         CombatEngineAPI var5 = Global.getCombatEngine();
         if(var3 == State.IN) {
            this.activated = false;
         }

         WeaponAPI var6 = null;
         Iterator var7 = this.ship.getAllWeapons().iterator();

         while(var7.hasNext()) {
            WeaponAPI var8 = (WeaponAPI)var7.next();
            if(var8.getSlot().getId().equals("E_RARM")) {
               var6 = var8;
            }
         }

         float var9;
         float var16;
         if(var5.getCustomData().get("armaa_karmaTotal" + this.ship.getId()) instanceof Float) {
            var16 = ((Float)var5.getCustomData().get("armaa_karmaTotal" + this.ship.getId())).floatValue();
            if(var16 >= 1.0F) {
               if(!this.ship.getVariant().getHullSpec().getHullId().equals("armaa_altagrave_c")) {
                  MissileAPI var18 = (MissileAPI)var5.spawnProjectile(this.ship, var6, "armaa_karmicburst", var6.getLocation(), 0.0F, this.ship.getVelocity());
                  var9 = 1.25F;
                  var5.spawnExplosion(var18.getLocation(), var18.getVelocity(), new Color(149, 200, 255, 255), 200.0F, 0.1F);
                  DamagingExplosionSpec var19 = new DamagingExplosionSpec(0.05F, 350.0F, 150.0F, 500.0F, 1.0F, CollisionClass.PROJECTILE_NO_FF, CollisionClass.PROJECTILE_FIGHTER, 8.0F, 3.0F, 0.2F, 50, this.VFX_COLOR, this.VFX_COLOR);
                  var19.setDamageType(DamageType.ENERGY);
                  var19.setShowGraphic(true);
                  var19.setSoundSetId("explosion_ship");
                  var5.spawnDamagingExplosion(var19, this.ship, var18.getLocation(), false);
                  float var21 = this.ship.getVelocity().length();

                  for(int var12 = 0; var12 <= 50; ++var12) {
                     float var13 = (float)MathUtils.getRandomNumberInRange(0, 360);
                     float var14 = MathUtils.getRandomNumberInRange(var21 * this.MIN_SPEED, var21 * this.MAX_SPEED);
                     Vector2f var15 = MathUtils.getPointOnCircumference((Vector2f)null, var14, var13);
                     var5.addHitParticle(this.ship.getLocation(), var15, 10.0F, 150.0F, 1.05F, this.PARTICLE_COLOR);
                  }

                  float var22 = 1.0F / var16;
                  int var23 = (int)(this.BASE_INCREMENT * var22);
                  if(var23 < 30) {
                     var23 = 30;
                  }

                  for(int var24 = 0; var24 < 360; var24 += var23) {
                     DamagingProjectileAPI var25 = (DamagingProjectileAPI)var5.spawnProjectile(this.ship, var6, "armaa_karma", var6.getLocation(), (float)var24, this.ship.getVelocity());
                     var25.setFacing((float)var24);
                  }

                  var5.getCustomData().put("armaa_karmaTotal" + this.ship.getId(), Float.valueOf(0.99F));
                  this.activated = true;
                  Global.getSoundPlayer().playSound("system_interdictor", 1.1F, 1.0F, this.ship.getLocation(), this.ZERO);
                  Global.getSoundPlayer().playSound("explosion_from_damage", 1.0F, 1.0F, this.ship.getLocation(), this.ZERO);
                  return;
               }

               var5.getCustomData().put("armaa_karmaTotal" + this.ship.getId(), Float.valueOf(1.0F));
            }
         }

         if(var3 == State.OUT && !this.activated) {
            var16 = 0.0F;
            float var17 = 0.0F;
            var9 = 600.0F;
            var9 = this.ship.getMutableStats().getSystemRangeBonus().computeEffective(var9);
            Iterator var10 = CombatUtils.getProjectilesWithinRange(this.ship.getLocation(), var9).iterator();

            while(var10.hasNext()) {
               DamagingProjectileAPI var11 = (DamagingProjectileAPI)var10.next();
               if(var11.getSource().getOwner() != this.ship.getOwner() && var11.getBaseDamageAmount() > 0.0F && var5.isEntityInPlay(var11)) {
                  if(var11.getDamageType() == DamageType.FRAGMENTATION) {
                     var17 = var11.getDamageAmount() * 0.25F + var11.getEmpAmount() * 0.25F;
                  } else {
                     var17 = var11.getDamageAmount() + var11.getEmpAmount() * 0.25F;
                  }

                  if(var17 > 0.0F) {
                     var16 += var17;
                     if(var5.isEntityInPlay(var11)) {
                        var5.spawnEmpArc(this.ship, new Vector2f(var11.getLocation()), new SimpleEntity(var11.getLocation()), this.ship, DamageType.OTHER, 0.0F, 0.0F, 500.0F, "tachyon_lance_emp_impact", 10.0F, new Color(100, 206, 240), new Color(100, 206, 255));
                        if(MagicRender.screenCheck(0.2F, var11.getLocation())) {
                           MagicLensFlare.createSharpFlare(var5, this.ship, var11.getLocation(), 10.0F, 100.0F, (float)Math.random() * 360.0F, new Color(100, 206, 240), new Color(100, 206, 255));
                           var5.addSmoothParticle(var11.getLocation(), new Vector2f(), 150.0F, 0.5F, 0.3F, Color.blue);
                           var5.addHitParticle(var11.getLocation(), new Vector2f(), 150.0F, 1.0F, 0.15F, Color.white);
                           var5.addSwirlyNebulaParticle(var11.getLocation(), new Vector2f(0.0F, 0.0F), 100.0F, 1.2F, 0.15F, 0.0F, 0.35F, Color.blue, false);
                        }
                     }
                  }

                  var5.removeEntity(var11);
               }
            }

            Global.getSoundPlayer().playSound("system_phase_skimmer", 1.0F, 0.25F + (float)Math.sqrt((double)var17) / 30.0F, this.ship.getLocation(), this.ZERO);
            var10 = CombatUtils.getMissilesWithinRange(this.ship.getLocation(), var9).iterator();

            while(var10.hasNext()) {
               MissileAPI var20 = (MissileAPI)var10.next();
               if(var20.getSource().getOwner() != this.ship.getOwner() && var20.getSource().getOwner() != this.ship.getOwner()) {
                  if(var20.isGuided()) {
                     if(!MechaModPlugin.KARMA_IMMUNE.contains(var20.getProjectileSpecId())) {
                        if(var20 instanceof MissileAPI) {
                           if(var20.getMissileAI() instanceof GuidedMissileAI) {
                              ((GuidedMissileAI)var20.getMissileAI()).setTarget((CombatEntityAPI)null);
                           }

                           var5.addFloatingText(var20.getLocation(), "REDIRECTED!", 20.0F, Color.yellow, var20, 2.0F, 0.2F);
                           var20.setFacing(-var20.getFacing());
                           var20.setOwner(this.ship.getOwner());
                           var20.setSource(this.ship);
                           var5.addSmoothParticle(var20.getLocation(), new Vector2f(), 150.0F, 0.5F, 0.3F, Color.red);
                           var5.addHitParticle(var20.getLocation(), new Vector2f(), 150.0F, 1.0F, 0.15F, Color.white);
                        }
                     } else {
                        var5.addFloatingText(var20.getLocation(), "NO EFFECT!", 20.0F, Color.red, var20, 2.0F, 0.2F);
                     }
                  } else {
                     if(var20.getDamageType() == DamageType.FRAGMENTATION) {
                        var17 = var20.getDamageAmount() * 0.25F + var20.getEmpAmount() * 0.25F;
                     } else {
                        var17 = var20.getDamageAmount() + var20.getEmpAmount() * 0.25F;
                     }

                     if(var17 > 0.0F) {
                        var16 += var17;
                        var5.getCustomData().put("armaa_hasGainedKarma" + this.ship.getId(), Boolean.valueOf(true));
                        var5.getCustomData().put("armaa_gainedKarmaAount" + this.ship.getId(), Float.valueOf(var17 / armaa_KarmaMod.getKarmaThreshold()));
                        if(var5.isEntityInPlay(var20)) {
                           var5.spawnEmpArc(this.ship, new Vector2f(var20.getLocation()), new SimpleEntity(var20.getLocation()), this.ship, DamageType.OTHER, 0.0F, 0.0F, 500.0F, "tachyon_lance_emp_impact", 10.0F, new Color(100, 206, 240), new Color(100, 206, 255));
                           if(MagicRender.screenCheck(0.2F, var20.getLocation())) {
                              MagicLensFlare.createSharpFlare(var5, this.ship, var20.getLocation(), 10.0F, 100.0F, (float)Math.random() * 360.0F, new Color(100, 206, 240), new Color(100, 206, 255));
                           }
                        }
                     }

                     Global.getSoundPlayer().playSound("system_interdictor", 1.5F, 0.8F, var20.getLocation(), this.ZERO);
                     var5.removeEntity(var20);
                  }
               }
            }

            var5.getCustomData().put("armaa_hasGainedKarma" + this.ship.getId(), Boolean.valueOf(true));
            var5.getCustomData().put("armaa_gainedKarmaAount" + this.ship.getId(), Float.valueOf(var16 / armaa_KarmaMod.getKarmaThreshold()));
            this.activated = true;
         }

      }
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      this.activated = false;
   }
}
