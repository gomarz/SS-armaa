package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import java.util.HashMap;
import java.util.Map;

public class armaa_damperFieldStats extends BaseShipSystemScript {

   private static Map mag = new HashMap();
   protected Object STATUSKEY1 = new Object();
   public static final float INCOMING_DAMAGE_CAPITAL = 0.5F;


   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      var4 = 1.0F;
      float var5 = ((Float)mag.get(HullSize.CRUISER)).floatValue();
      if(var1.getVariant() != null) {
         var5 = ((Float)mag.get(var1.getVariant().getHullSize())).floatValue();
      }

      var1.getHullDamageTakenMult().modifyMult(var2, 1.0F - (1.0F - var5) * var4);
      var1.getArmorDamageTakenMult().modifyMult(var2, 1.0F - (1.0F - var5) * var4);
      var1.getEmpDamageTakenMult().modifyMult(var2, 1.0F - (1.0F - var5) * var4);
      ShipAPI var6 = null;
      boolean var7 = false;
      if(var1.getEntity() instanceof ShipAPI) {
         var6 = (ShipAPI)var1.getEntity();
         var7 = var6 == Global.getCombatEngine().getPlayerShip();
      }

      if(var7) {
         ShipSystemAPI var8 = var6.getPhaseCloak();
         if(var8 != null) {
            float var9 = (1.0F - var5) * var4 * 100.0F;
            Global.getCombatEngine().maintainStatusForPlayerShip(this.STATUSKEY1, var8.getSpecAPI().getIconSpriteName(), var8.getDisplayName(), Math.round(var9) + "% less damage taken", false);
         }
      }

   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      var1.getHullDamageTakenMult().unmodify(var2);
      var1.getArmorDamageTakenMult().unmodify(var2);
      var1.getEmpDamageTakenMult().unmodify(var2);
   }

   static {
      mag.put(HullSize.FIGHTER, Float.valueOf(0.2F));
      mag.put(HullSize.FRIGATE, Float.valueOf(0.2F));
      mag.put(HullSize.DESTROYER, Float.valueOf(0.5F));
      mag.put(HullSize.CRUISER, Float.valueOf(0.5F));
      mag.put(HullSize.CAPITAL_SHIP, Float.valueOf(0.5F));
   }
}
