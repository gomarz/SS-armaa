package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.StatusData;
import com.fs.starfarer.api.util.IntervalUtil;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.combat.CombatUtils;

public class armaa_siegeModeStats extends BaseShipSystemScript {

   public static final float SENSOR_RANGE_PERCENT = 25.0F;
   public static final float WEAPON_RANGE_PERCENT = 50.0F;
   private IntervalUtil interval = new IntervalUtil(0.05F, 0.05F);


   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      ShipAPI var5 = (ShipAPI)var1.getEntity();
      this.interval.advance(Global.getCombatEngine().getElapsedInLastFrame());
      if(this.interval.intervalElapsed()) {
         Object var6;
         if(Global.getCombatEngine().getCustomData().get("armaa_guardianProtocolShips" + var5.getId()) instanceof List) {
            var6 = (List)Global.getCombatEngine().getCustomData().get("armaa_guardianProtocolShips" + var5.getId());
         } else {
            var6 = new ArrayList();
         }

         Iterator var7 = CombatUtils.getShipsWithinRange(var5.getLocation(), 1000.0F).iterator();

         ShipAPI var8;
         while(var7.hasNext()) {
            var8 = (ShipAPI)var7.next();
            if(var8 != var5 && var5.getOwner() == var8.getOwner() && !((List)var6).contains(var8)) {
               ((List)var6).add(var8);
            }
         }

         var7 = ((List)var6).iterator();

         while(var7.hasNext()) {
            var8 = (ShipAPI)var7.next();
            var8.getMutableStats().getShieldDamageTakenMult().modifyMult("armaa_guardianProtocol", 0.9F * var4);
            if(Global.getCombatEngine().getPlayerShip() == var8) {
               Global.getCombatEngine().maintainStatusForPlayerShip(var8.getId(), "graphics/icons/hullsys/fortress_shield.png", "GRDIAN PRTCL", "Shield damage reduced by " + (int)(10.000002F * var4), false);
            }

            var8.setJitterUnder(var5, Color.white, 0.5F * var4, 3, 15.0F * var4);
            var8.setJitterShields(true);
         }

         Global.getCombatEngine().getCustomData().put("armaa_guardianProtocolShips" + var5.getId(), var6);
      }

      float var9 = 25.0F * var4;
      float var10 = 50.0F * var4;
      var1.getSightRadiusMod().modifyPercent(var2, var9);
      var1.getMaxSpeed().modifyMult(var2, 0.0F);
      var1.getMaxTurnRate().modifyMult(var2, 0.8F);
      var1.getMaxRecoilMult().modifyMult(var2, 1.5F);
      var1.getBallisticWeaponRangeBonus().modifyPercent(var2, var5.getMutableStats().getSystemRangeBonus().computeEffective(var10));
      var1.getEnergyWeaponRangeBonus().modifyPercent(var2, var10);
      var1.getEnergyProjectileSpeedMult().modifyPercent(var2, var10);
      var1.getBallisticProjectileSpeedMult().modifyPercent(var2, var10);
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      ShipAPI var3 = (ShipAPI)var1.getEntity();
      var1.getSightRadiusMod().unmodify(var2);
      var1.getBallisticWeaponRangeBonus().unmodify(var2);
      var1.getEnergyWeaponRangeBonus().unmodify(var2);
      var1.getBallisticRoFMult().unmodify(var2);
      var1.getEnergyRoFMult().unmodify(var2);
      var1.getBallisticProjectileSpeedMult().unmodify(var2);
      var1.getEnergyProjectileSpeedMult().unmodify(var2);
      var1.getMaxRecoilMult().unmodify(var2);
      var1.getMaxSpeed().unmodify(var2);
      var1.getMaxTurnRate().unmodify(var2);
      if(Global.getCombatEngine().getCustomData().get("armaa_guardianProtocolShips" + var3.getId()) instanceof List) {
         List var4 = (List)Global.getCombatEngine().getCustomData().get("armaa_guardianProtocolShips" + var3.getId());
         Iterator var5 = var4.iterator();

         while(var5.hasNext()) {
            ShipAPI var6 = (ShipAPI)var5.next();
            var6.getMutableStats().getShieldDamageTakenMult().unmodify("armaa_guardianProtocol");
            var6.setJitterShields(false);
         }

         Global.getCombatEngine().getCustomData().put("armaa_guardianProtocolShips" + var3.getId(), (Object)null);
      }

   }

   public StatusData getStatusData(int var1, State var2, float var3) {
      float var4 = 25.0F * var3;
      float var5 = 50.0F * var3;
      return var1 == 0?new StatusData("WPN PROJ SPEED +" + (int)var5 + "%", false):(var1 == 1?null:(var1 == 2?new StatusData("WPN/SNSR RNG, RECOIL +" + (int)var5 + "%", false):null));
   }
}
