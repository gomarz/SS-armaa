package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;

public class MPhaseDamperStats extends BaseShipSystemScript {

   public static final float MAX_TIME_MULT = 1.3F;
   public static final float MIN_TIME_MULT = 0.1F;
   public static final float DEF_MULT = 0.8F;
   public static final float DEF_BEAM_MULT = 0.6F;
   public static final float DAM_MULT = 0.1F;
   protected Object STATUSKEY1 = new Object();


   public static float getMaxTimeMult(MutableShipStatsAPI var0) {
      return 1.0F + 0.29999995F * var0.getDynamic().getValue("phase_time_mult");
   }

   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      ShipAPI var5 = null;
      boolean var6 = false;
      if(var1.getEntity() instanceof ShipAPI) {
         var5 = (ShipAPI)var1.getEntity();
         var6 = var5 == Global.getCombatEngine().getPlayerShip();
         var2 = var2 + "_" + var5.getId();
         float var8 = 0.0F;
         float var9 = 10.0F;
         var4 *= var4;
         float var10 = 1.0F + (getMaxTimeMult(var1) - 1.0F) * var4;
         var1.getTimeMult().modifyMult(var2, var10);
         var1.getHullDamageTakenMult().modifyMult(var2, 1.0F - 0.19999999F * var4);
         var1.getArmorDamageTakenMult().modifyMult(var2, 1.0F - 0.19999999F * var4);
         var1.getEmpDamageTakenMult().modifyMult(var2, 1.0F - 0.19999999F * var4);
         var1.getBeamDamageTakenMult().modifyMult(var2, 1.0F - 0.39999998F * var4);
         if(var6) {
            Global.getCombatEngine().getTimeMult().modifyMult(var2, 1.0F / var10);
         } else {
            Global.getCombatEngine().getTimeMult().unmodify(var2);
         }

         if(var6) {
            ShipSystemAPI var11 = var5.getPhaseCloak();
            if(var11 != null) {
               float var12 = 0.19999999F * var4 * 100.0F;
               float var13 = (1.0F - var10) * var4 * 100.0F * -1.0F;
               Global.getCombatEngine().maintainStatusForPlayerShip(this.STATUSKEY1, var11.getSpecAPI().getIconSpriteName(), var11.getDisplayName(), Math.round(var12) + "% DMG REDUCTION / " + Math.round(var13) + "% TIME-FLOW ALTERATION", false);
            }
         }

      }
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      ShipAPI var3 = null;
      boolean var4 = false;
      if(var1.getEntity() instanceof ShipAPI) {
         var3 = (ShipAPI)var1.getEntity();
         var4 = var3 == Global.getCombatEngine().getPlayerShip();
         var2 = var2 + "_" + var3.getId();
         Global.getCombatEngine().getTimeMult().unmodify(var2);
         var1.getTimeMult().unmodify(var2);
         var1.getHullDamageTakenMult().unmodify(var2);
         var1.getArmorDamageTakenMult().unmodify(var2);
         var1.getEmpDamageTakenMult().unmodify(var2);
         var1.getBeamDamageTakenMult().unmodify(var2);
      }
   }
}
