package data.scripts.shipsystems.ai;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAIScript;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.shipsystems.armaa_RecallDeviceStats;
import org.lwjgl.util.vector.Vector2f;

public class armaa_recallAI implements ShipSystemAIScript {

   private ShipAPI ship;
   private CombatEngineAPI engine;
   private ShipwideAIFlags flags;
   private ShipSystemAPI system;
   private IntervalUtil tracker = new IntervalUtil(0.5F, 1.0F);


   public void init(ShipAPI var1, ShipSystemAPI var2, ShipwideAIFlags var3, CombatEngineAPI var4) {
      this.ship = var1;
      this.flags = var3;
      this.engine = var4;
      this.system = var1.getSystem();
   }

   public void advance(float var1, Vector2f var2, Vector2f var3, ShipAPI var4) {
      this.tracker.advance(var1);
      float var5 = 0.0F;
      if(this.engine != null) {
         if(!this.engine.isPaused()) {
            if(this.tracker.intervalElapsed()) {
               FluxTrackerAPI var6 = this.ship.getFluxTracker();
               if(var6.getFluxLevel() <= 0.5F && armaa_RecallDeviceStats.getFighters(this.ship).size() > 0) {
                  var5 += 9999.0F;
               }

               if(var5 >= 2.0F && !this.system.isActive()) {
                  this.ship.useSystem();
               }
            }

         }
      }
   }
}
