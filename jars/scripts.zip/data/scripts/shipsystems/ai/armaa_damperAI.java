package data.scripts.shipsystems.ai;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.FluxTrackerAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipCommand;
import com.fs.starfarer.api.combat.ShipSystemAIScript;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.util.IntervalUtil;
import org.lwjgl.util.vector.Vector2f;

public class armaa_damperAI implements ShipSystemAIScript {

   private ShipAPI ship;
   private CombatEngineAPI engine;
   private ShipwideAIFlags flags;
   private ShipSystemAPI system;
   private IntervalUtil tracker = new IntervalUtil(0.5F, 1.0F);


   public void init(ShipAPI var1, ShipSystemAPI var2, ShipwideAIFlags var3, CombatEngineAPI var4) {
      this.ship = var1;
      this.flags = var3;
      this.engine = var4;
      this.system = var1.getPhaseCloak();
   }

   public void advance(float var1, Vector2f var2, Vector2f var3, ShipAPI var4) {
      this.tracker.advance(var1);
      if(this.engine != null) {
         if(!this.engine.isPaused()) {
            if(this.tracker.intervalElapsed()) {
               float var5 = 0.0F;
               if(this.flags.hasFlag(AIFlags.PURSUING)) {
                  var5 -= 0.25F;
               }

               if(this.flags.hasFlag(AIFlags.BACKING_OFF)) {
                  var5 += 0.35F;
               }

               if(this.flags.hasFlag(AIFlags.RUN_QUICKLY)) {
                  var5 += 0.1F;
               }

               if(this.flags.hasFlag(AIFlags.NEEDS_HELP)) {
                  var5 += 2.0F;
               }

               if(this.flags.hasFlag(AIFlags.HAS_INCOMING_DAMAGE)) {
                  var5 += 1.0F - 1.0F * this.ship.getHullLevel();
               }

               if(this.flags.hasFlag(AIFlags.IN_CRITICAL_DPS_DANGER)) {
                  var5 += 2.0F;
               }

               if(this.flags.hasFlag(AIFlags.SAFE_FROM_DANGER_TIME)) {
                  var5 -= 0.5F;
               }

               FluxTrackerAPI var6 = this.ship.getFluxTracker();
               if(var5 >= 0.5F) {
                  this.flags.setFlag(AIFlags.BACK_OFF, 15.0F);
                  this.ship.giveCommand(ShipCommand.TOGGLE_SHIELD_OR_PHASE_CLOAK, new Vector2f(), 0);
               } else if(this.system.isActive()) {
                  ;
               }
            }

         }
      }
   }
}
