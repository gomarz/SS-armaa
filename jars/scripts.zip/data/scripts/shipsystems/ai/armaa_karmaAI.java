package data.scripts.shipsystems.ai;

import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAIScript;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.ArrayList;
import java.util.Iterator;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_karmaAI implements ShipSystemAIScript {

   private CombatEngineAPI engine = null;
   private ShipwideAIFlags flags;
   private ShipAPI ship;
   private final IntervalUtil tracker = new IntervalUtil(0.25F, 1.0F);
   private final float BASE_RANGE = 600.0F;


   public void advance(float var1, Vector2f var2, Vector2f var3, ShipAPI var4) {
      if(this.engine != null) {
         if(!this.engine.isPaused()) {
            this.tracker.advance(var1);
            if(this.ship.getFluxTracker().getFluxLevel() >= 0.6F) {
               this.flags.setFlag(AIFlags.BACK_OFF, 1.0F);
               this.flags.setFlag(AIFlags.DO_NOT_USE_FLUX, 1.0F);
            }

            if(this.tracker.intervalElapsed()) {
               if(!AIUtils.canUseSystemThisFrame(this.ship)) {
                  return;
               }

               float var5 = 600.0F;
               boolean var6 = this.ship.getCaptain().getStats().getSkillLevel("systems_expertise") > 0.0F;
               if(var6) {
                  var5 *= 1.5F;
               }

               ArrayList var7 = new ArrayList(100);
               var7.addAll(CombatUtils.getMissilesWithinRange(this.ship.getLocation(), var5));
               var7.addAll(CombatUtils.getProjectilesWithinRange(this.ship.getLocation(), var5));
               float var8 = 0.0F;
               Iterator var9 = var7.iterator();

               while(var9.hasNext()) {
                  DamagingProjectileAPI var10 = (DamagingProjectileAPI)var9.next();
                  if(var10.getOwner() != this.ship.getOwner() && !var10.isFading() && var10.getCollisionClass() != CollisionClass.NONE) {
                     if(var10.getDamageType() == DamageType.FRAGMENTATION) {
                        var8 += (float)Math.sqrt((double)(0.25F * var10.getDamageAmount() + var10.getEmpAmount() * 0.25F));
                     } else {
                        var8 += (float)Math.sqrt((double)(var10.getDamageAmount() + var10.getEmpAmount() * 0.25F));
                     }
                  }
               }

               if(var8 > 50.0F) {
                  this.ship.useSystem();
               }
            }

         }
      }
   }

   public void init(ShipAPI var1, ShipSystemAPI var2, ShipwideAIFlags var3, CombatEngineAPI var4) {
      this.ship = var1;
      this.flags = var3;
      this.engine = var4;
   }
}
