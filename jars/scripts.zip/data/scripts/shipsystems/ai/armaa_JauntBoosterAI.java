package data.scripts.shipsystems.ai;

import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatAssignmentType;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipCommand;
import com.fs.starfarer.api.combat.ShipSystemAIScript;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.CombatFleetManagerAPI.AssignmentInfo;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.shipsystems.armaa_JauntBoosterStats;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.CollectionUtils.SortEntitiesByDistance;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_JauntBoosterAI implements ShipSystemAIScript {

   private CombatEngineAPI engine;
   private ShipwideAIFlags flags;
   private ShipAPI ship;
   private boolean phase = false;
   private ShipSystemAPI system;
   private final IntervalUtil tracker = new IntervalUtil(0.05F, 0.1F);
   private static final float FIGHTER_CRITICAL_RANGE = 500.0F;
   private static final float FIGHTER_STRIKE_RANGE = 1200.0F;
   private static final boolean DEBUG = false;
   private final Object STATUSKEY1 = new Object();
   private final Object STATUSKEY2 = new Object();
   private float desireShow = 0.0F;
   private float targetDesireShow = 0.0F;
   private float angleToTargetShow = 0.0F;


   public void advance(float var1, Vector2f var2, Vector2f var3, ShipAPI var4) {
      if(this.engine != null) {
         if(!this.engine.isPaused()) {
            this.tracker.advance(var1);
            if(this.tracker.intervalElapsed()) {
               if(this.ship.getFluxTracker().isOverloadedOrVenting() || this.system.getAmmo() == 0 || !AIUtils.canUseSystemThisFrame(this.ship) || this.ship.isLanding()) {
                  return;
               }

               float var5 = 0.0F;
               if(this.ship.getEngineController().isFlamedOut()) {
                  return;
               }

               boolean var6 = false;
               if(this.ship.getWing() != null && this.ship.getWing().isReturning(this.ship)) {
                  var6 = true;
               }

               float var7;
               if(this.ship.getWing() != null) {
                  if(var6) {
                     var7 = 500.0F;
                  } else {
                     var7 = this.ship.getWing().getSpec().getAttackRunRange();
                  }
               } else {
                  var7 = 1000.0F;
                  Iterator var8 = this.ship.getUsableWeapons().iterator();

                  while(var8.hasNext()) {
                     WeaponAPI var9 = (WeaponAPI)var8.next();
                     if(var9.getType() != WeaponType.MISSILE && var9.getRange() > var7) {
                        var7 = var9.getRange();
                     }
                  }
               }

               Object var25 = null;
               ShipAPI var26 = null;
               if(this.ship.getWing() != null && this.ship.getWing().getSourceShip() != null) {
                  var26 = this.ship.getWing().getSourceShip();
                  if(var6) {
                     var25 = var26;
                  } else if(var26.getAIFlags() != null && var26.getAIFlags().getCustom(AIFlags.CARRIER_FIGHTER_TARGET) instanceof CombatEntityAPI) {
                     var25 = (CombatEntityAPI)var26.getAIFlags().getCustom(AIFlags.CARRIER_FIGHTER_TARGET);
                  } else if(var26.getAIFlags() != null && var26.getAIFlags().getCustom(AIFlags.MANEUVER_TARGET) instanceof CombatEntityAPI) {
                     var25 = (CombatEntityAPI)var26.getAIFlags().getCustom(AIFlags.MANEUVER_TARGET);
                  } else {
                     var25 = var26.getShipTarget();
                  }
               }

               if(var25 == null && this.ship.isFighter() && this.flags.getCustom(AIFlags.CARRIER_FIGHTER_TARGET) instanceof CombatEntityAPI) {
                  var25 = (CombatEntityAPI)this.flags.getCustom(AIFlags.CARRIER_FIGHTER_TARGET);
               }

               if(var25 == null && this.flags.getCustom(AIFlags.MANEUVER_TARGET) instanceof CombatEntityAPI) {
                  var25 = (CombatEntityAPI)this.flags.getCustom(AIFlags.MANEUVER_TARGET);
               }

               if(var25 == null) {
                  var25 = this.ship.getShipTarget();
               }

               AssignmentInfo var10 = this.engine.getFleetManager(this.ship.getOwner()).getTaskManager(this.ship.isAlly()).getAssignmentFor(this.ship);
               Vector2f var11;
               if(this.ship.isFighter()) {
                  var10 = null;
                  var11 = null;
               } else if(var10 != null && var10.getTarget() != null && var10.getType() != CombatAssignmentType.AVOID) {
                  var11 = var10.getTarget().getLocation();
               } else {
                  var11 = null;
               }

               Vector2f var12 = new Vector2f();
               float var13 = ((Float)armaa_JauntBoosterStats.BASELINE_MULT.get(this.ship.getHullSize())).floatValue();
               if(this.ship.getEngineController().isAccelerating()) {
                  var12.y += ((Float)armaa_JauntBoosterStats.BASELINE_MULT.get(this.ship.getHullSize())).floatValue() - ((Float)armaa_JauntBoosterStats.FORWARD_PENALTY.get(this.ship.getHullSize())).floatValue();
                  var13 -= ((Float)armaa_JauntBoosterStats.FORWARD_PENALTY.get(this.ship.getHullSize())).floatValue();
               } else if(this.ship.getEngineController().isAcceleratingBackwards() || this.ship.getEngineController().isDecelerating()) {
                  var12.y -= ((Float)armaa_JauntBoosterStats.BASELINE_MULT.get(this.ship.getHullSize())).floatValue() - ((Float)armaa_JauntBoosterStats.REVERSE_PENALTY.get(this.ship.getHullSize())).floatValue();
                  var13 -= ((Float)armaa_JauntBoosterStats.REVERSE_PENALTY.get(this.ship.getHullSize())).floatValue();
               }

               if(this.ship.getEngineController().isStrafingLeft()) {
                  --var12.x;
                  var13 += 1.0F - ((Float)armaa_JauntBoosterStats.BASELINE_MULT.get(this.ship.getHullSize())).floatValue();
               } else if(this.ship.getEngineController().isStrafingRight()) {
                  ++var12.x;
                  var13 += 1.0F - ((Float)armaa_JauntBoosterStats.BASELINE_MULT.get(this.ship.getHullSize())).floatValue();
               }

               if(var12.length() <= 0.0F) {
                  var12.y = ((Float)armaa_JauntBoosterStats.BASELINE_MULT.get(this.ship.getHullSize())).floatValue() - ((Float)armaa_JauntBoosterStats.FORWARD_PENALTY.get(this.ship.getHullSize())).floatValue();
                  var13 -= ((Float)armaa_JauntBoosterStats.FORWARD_PENALTY.get(this.ship.getHullSize())).floatValue();
               }

               Misc.normalise(var12);
               VectorUtils.rotate(var12, this.ship.getFacing() - 90.0F, var12);
               float var14 = 0.0F;
               float var15;
               if(var11 != null) {
                  var15 = VectorUtils.getAngleStrict(this.ship.getLocation(), var11);
                  var14 = MathUtils.getShortestRotation(VectorUtils.getFacing(var12), var15);
               }

               var15 = 0.0F;
               float var16;
               if(var25 != null) {
                  var16 = VectorUtils.getAngleStrict(this.ship.getLocation(), ((CombatEntityAPI)var25).getLocation());
                  var15 = MathUtils.getShortestRotation(VectorUtils.getFacing(var12), var16);
               }

               this.angleToTargetShow = var15;
               if(this.ship.isFighter()) {
                  var16 = 45.0F;
               } else {
                  var16 = 60.0F;
               }

               if(!this.ship.isFighter()) {
                  if(this.flags.hasFlag(AIFlags.RUN_QUICKLY)) {
                     if(var25 != null) {
                        if(Math.abs(var15) >= 90.0F) {
                           ++var5;
                        }
                     } else {
                        var5 += 0.75F;
                     }
                  }

                  if(this.flags.hasFlag(AIFlags.PURSUING)) {
                     if(var25 != null) {
                        if(Math.abs(var15) <= var16) {
                           var5 += 0.75F;
                        }
                     } else if(var11 != null) {
                        if(Math.abs(var14) <= var16) {
                           var5 += 0.5F;
                        }
                     } else {
                        var5 += 0.25F;
                     }
                  }

                  if(this.flags.hasFlag(AIFlags.HARASS_MOVE_IN)) {
                     if(var25 != null) {
                        if(Math.abs(var15) <= var16) {
                           ++var5;
                        }
                     } else if(var11 != null) {
                        if(Math.abs(var14) <= var16) {
                           var5 += 0.75F;
                        }
                     } else {
                        var5 += 0.5F;
                     }
                  }
               } else if(!var6 && this.flags.hasFlag(AIFlags.IN_ATTACK_RUN)) {
                  if(var25 != null) {
                     if(Math.abs(var15) <= var16) {
                        if(MathUtils.getDistance((CombatEntityAPI)var25, this.ship) < 500.0F - this.ship.getCollisionRadius()) {
                           --var5;
                        } else if(MathUtils.getDistance((CombatEntityAPI)var25, this.ship) >= 1200.0F - this.ship.getCollisionRadius()) {
                           ++var5;
                        }
                     } else if(Math.abs(var15) >= 180.0F - var16) {
                        if(MathUtils.getDistance((CombatEntityAPI)var25, this.ship) < 500.0F - this.ship.getCollisionRadius()) {
                           ++var5;
                        } else if(MathUtils.getDistance((CombatEntityAPI)var25, this.ship) < 1200.0F - this.ship.getCollisionRadius()) {
                           if(this.flags.hasFlag(AIFlags.POST_ATTACK_RUN)) {
                              ++var5;
                           }
                        } else {
                           --var5;
                        }
                     } else if(MathUtils.getDistance((CombatEntityAPI)var25, this.ship) < 500.0F - this.ship.getCollisionRadius()) {
                        ++var5;
                     } else if(MathUtils.getDistance((CombatEntityAPI)var25, this.ship) < 1200.0F - this.ship.getCollisionRadius()) {
                        if(this.flags.hasFlag(AIFlags.POST_ATTACK_RUN)) {
                           ++var5;
                        } else {
                           var5 += 0.75F;
                        }
                     }
                  } else if(var11 != null) {
                     if(Math.abs(var14) <= var16) {
                        ++var5;
                     }
                  } else {
                     var5 += 0.5F;
                  }
               }

               boolean var17 = false;
               if(var25 != null && MathUtils.getDistance((CombatEntityAPI)var25, this.ship) < var7 - this.ship.getCollisionRadius()) {
                  var17 = true;
               }

               if(var25 != null && !var17 && (var26 == null || !var26.isPullBackFighters() || var25 == var26) && Math.abs(var15) <= var16) {
                  var5 += 0.5F;
               }

               float var18;
               if(!this.ship.isFighter()) {
                  var18 = 500.0F;
                  if(var10 != null && (var10.getType() == CombatAssignmentType.ENGAGE || var10.getType() == CombatAssignmentType.HARASS || var10.getType() == CombatAssignmentType.INTERCEPT || var10.getType() == CombatAssignmentType.LIGHT_ESCORT || var10.getType() == CombatAssignmentType.MEDIUM_ESCORT || var10.getType() == CombatAssignmentType.HEAVY_ESCORT || var10.getType() == CombatAssignmentType.STRIKE)) {
                     var18 = var7;
                  }

                  if(var11 != null && MathUtils.getDistance(var11, this.ship.getLocation()) >= var18 && !var17) {
                     if(var25 != null && MathUtils.getDistance((CombatEntityAPI)var25, var11) <= var7) {
                        if(Math.abs(var14) <= var16) {
                           var5 += 0.5F;
                        }
                     } else if(var25 != null) {
                        if(Math.abs(var14) <= var16) {
                           var5 += 0.25F;
                        }
                     } else if(Math.abs(var14) <= var16) {
                        var5 += 0.75F;
                     }
                  }
               } else if(var6 && !var17) {
                  if(var25 != null) {
                     if(Math.abs(var15) <= var16) {
                        var5 += 2.0F;
                     }
                  } else if(var11 != null) {
                     if(Math.abs(var14) <= var16) {
                        var5 += 2.0F;
                     }
                  } else {
                     ++var5;
                  }
               }

               if(!this.ship.isFighter()) {
                  if(this.flags.hasFlag(AIFlags.TURN_QUICKLY)) {
                     var5 += 0.35F;
                  }

                  if(this.flags.hasFlag(AIFlags.BACKING_OFF)) {
                     if(var25 != null) {
                        if(Math.abs(var15) >= 90.0F) {
                           var5 += 0.75F;
                        }
                     } else {
                        var5 += 0.5F;
                     }
                  }

                  if(this.flags.hasFlag(AIFlags.DO_NOT_PURSUE)) {
                     if(var25 != null) {
                        if(Math.abs(var15) <= var16) {
                           --var5;
                        }
                     } else {
                        var5 -= 0.5F;
                     }
                  }

                  if(this.flags.hasFlag(AIFlags.DO_NOT_USE_FLUX)) {
                     var5 += 0.35F;
                  }

                  if(this.flags.hasFlag(AIFlags.NEEDS_HELP) || this.flags.hasFlag(AIFlags.IN_CRITICAL_DPS_DANGER)) {
                     if(var25 != null) {
                        if(Math.abs(var15) <= var16) {
                           --var5;
                        } else if(Math.abs(var15) >= 180.0F - var16) {
                           ++var5;
                        } else {
                           ++var5;
                        }
                     } else {
                        ++var5;
                     }
                  }

                  if(this.flags.hasFlag(AIFlags.HAS_INCOMING_DAMAGE)) {
                     if(var25 != null) {
                        if(Math.abs(var15) <= var16) {
                           var5 -= 0.5F;
                        } else if(Math.abs(var15) >= 180.0F - var16) {
                           var5 += 0.5F;
                        } else {
                           var5 += 0.75F;
                        }
                     } else {
                        var5 += 0.75F;
                     }
                  }

                  if(var10 != null && var10.getType() == CombatAssignmentType.RETREAT) {
                     var18 = this.ship.getOwner() == 0?270.0F:90.0F;
                     if(Math.abs(MathUtils.getShortestRotation(VectorUtils.getFacing(var12), var18)) <= var16) {
                        ++var5;
                     } else if(Math.abs(MathUtils.getShortestRotation(VectorUtils.getFacing(var12), var18)) >= 90.0F) {
                        --var5;
                     }
                  }
               } else if(this.flags.hasFlag(AIFlags.WANTED_TO_SLOW_DOWN)) {
                  var5 -= 0.5F;
               }

               var18 = 500.0F * var13;
               List var19 = CombatUtils.getShipsWithinRange(this.ship.getLocation(), var18);
               if(!var19.isEmpty() && !this.ship.isFighter()) {
                  Vector2f var20 = new Vector2f(var12);
                  var20.scale(var18);
                  Vector2f.add(var20, this.ship.getLocation(), var20);
                  Collections.sort(var19, new SortEntitiesByDistance(this.ship.getLocation()));
                  ListIterator var21 = var19.listIterator();

                  while(var21.hasNext()) {
                     ShipAPI var22 = (ShipAPI)var21.next();
                     if(var22 != this.ship && this.ship.getCollisionClass() != CollisionClass.NONE && !var22.isFighter() && !var22.isDrone()) {
                        Vector2f var23 = var22.getLocation();
                        float var24 = 1.0F;
                        if(var22.getOwner() == this.ship.getOwner()) {
                           var24 *= 1.5F;
                        }

                        if(CollisionUtils.getCollides(this.ship.getLocation(), var20, var23, var22.getCollisionRadius() * 0.5F + this.ship.getCollisionRadius() * 0.75F * var24)) {
                           if(this.ship.isFrigate()) {
                              if(var22.isFrigate()) {
                                 --var5;
                              } else if(var22.isDestroyer()) {
                                 var5 -= 2.0F;
                              } else if(var22.isCruiser()) {
                                 var5 -= 4.0F;
                              } else {
                                 var5 -= 8.0F;
                              }
                           } else if(this.ship.isDestroyer()) {
                              if(var22.isFrigate() && !var22.isHulk()) {
                                 var5 -= 2.0F;
                              } else if(var22.isDestroyer()) {
                                 --var5;
                              } else if(var22.isCruiser()) {
                                 var5 -= 2.0F;
                              } else {
                                 var5 -= 4.0F;
                              }
                           } else if(this.ship.isCruiser()) {
                              if(var22.isFrigate() && !var22.isHulk()) {
                                 var5 -= 4.0F;
                              } else if(var22.isDestroyer() && !var22.isHulk()) {
                                 var5 -= 2.0F;
                              } else if(var22.isCruiser()) {
                                 --var5;
                              } else {
                                 var5 -= 2.0F;
                              }
                           } else if(var22.isFrigate() && !var22.isHulk()) {
                              var5 -= 8.0F;
                           } else if(var22.isDestroyer() && !var22.isHulk()) {
                              var5 -= 4.0F;
                           } else if(var22.isCruiser() && !var22.isHulk()) {
                              var5 -= 2.0F;
                           } else {
                              --var5;
                           }
                        }
                     }
                  }
               }

               float var27;
               if(this.system.getMaxAmmo() <= 2) {
                  if(this.system.getAmmo() <= 1) {
                     var27 = 1.0F;
                  } else {
                     var27 = 0.5F;
                  }
               } else if(this.system.getMaxAmmo() == 3) {
                  if(this.system.getAmmo() <= 1) {
                     var27 = 1.1F;
                  } else if(this.system.getAmmo() == 2) {
                     var27 = 0.667F;
                  } else {
                     var27 = 0.45F;
                  }
               } else if(this.system.getMaxAmmo() == 4) {
                  if(this.system.getAmmo() <= 1) {
                     var27 = 1.2F;
                  } else if(this.system.getAmmo() == 2) {
                     var27 = 0.8F;
                  } else if(this.system.getAmmo() == 3) {
                     var27 = 0.533F;
                  } else {
                     var27 = 0.4F;
                  }
               } else if(this.system.getAmmo() <= 1) {
                  var27 = 1.4F;
               } else if(this.system.getAmmo() == 2) {
                  var27 = 1.033F;
               } else if(this.system.getAmmo() == 3) {
                  var27 = 0.74F;
               } else if(this.system.getAmmo() == 4) {
                  var27 = 0.52F;
               } else if(this.system.getAmmo() == 5) {
                  var27 = 0.373F;
               } else {
                  var27 = 0.3F;
               }

               this.desireShow = var5;
               this.targetDesireShow = var27;
               if(var5 >= var27) {
                  if(!this.phase) {
                     this.ship.useSystem();
                  } else {
                     this.ship.giveCommand(ShipCommand.TOGGLE_SHIELD_OR_PHASE_CLOAK, (Object)null, 0);
                  }
               }
            }

         }
      }
   }

   public void init(ShipAPI var1, ShipSystemAPI var2, ShipwideAIFlags var3, CombatEngineAPI var4) {
      this.ship = var1;
      this.flags = var3;
      this.system = var2;
      this.engine = var4;
      if(var2 != null) {
         if(var1.getPhaseCloak() != null && var1.getPhaseCloak().getId().equals("armaa_jauntbooster")) {
            this.system = var1.getPhaseCloak();
            this.phase = true;
         }
      } else {
         this.phase = true;
         this.system = var1.getPhaseCloak();
      }

   }
}
