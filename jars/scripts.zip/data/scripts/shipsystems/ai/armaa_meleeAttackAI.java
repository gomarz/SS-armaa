package data.scripts.shipsystems.ai;

import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipCommand;
import com.fs.starfarer.api.combat.ShipSystemAIScript;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.WeaponGroupAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.util.IntervalUtil;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_meleeAttackAI implements ShipSystemAIScript {

   private ShipAPI ship;
   private CombatEngineAPI engine;
   private ShipwideAIFlags flags;
   private ShipSystemAPI system;
   private IntervalUtil tracker = new IntervalUtil(0.5F, 1.0F);


   public void init(ShipAPI var1, ShipSystemAPI var2, ShipwideAIFlags var3, CombatEngineAPI var4) {
      this.ship = var1;
      this.flags = var3;
      this.engine = var4;
      this.system = var2;
   }

   public void advance(float var1, Vector2f var2, Vector2f var3, ShipAPI var4) {
      if(!this.engine.isPaused() && !this.system.isActive()) {
         this.tracker.advance(var1);
         if(this.tracker.intervalElapsed()) {
            if(var4 == null) {
               return;
            }

            if(this.ship.getShipTarget() == null) {
               this.ship.setShipTarget(var4);
               return;
            }

            if(!var4.isAlive()) {
               return;
            }

            if(var4.isFighter() && !this.ship.isFighter() || var4.isDrone()) {
               return;
            }

            if(!MathUtils.isWithinRange(this.ship, var4, 1000.0F) && !AIUtils.canUseSystemThisFrame(this.ship)) {
               return;
            }

            if(this.ship.getFluxTracker().getFluxLevel() >= 0.5F) {
               return;
            }

            if(this.flags.hasFlag(AIFlags.MANEUVER_TARGET) || this.flags.hasFlag(AIFlags.PURSUING) || this.flags.hasFlag(AIFlags.HARASS_MOVE_IN)) {
               this.ship.useSystem();
            }
         }
      }

      WeaponAPI var5 = null;
      Iterator var6 = this.ship.getAllWeapons().iterator();

      while(var6.hasNext()) {
         WeaponAPI var7 = (WeaponAPI)var6.next();
         if(var7.getId().contentEquals("armaa_aleste_blade_LeftArm")) {
            var5 = var7;
         }
      }

      if(var5 != null && this.system.isActive()) {
         WeaponGroupAPI var11 = null;
         if(!var5.isDisabled() && !var5.isPermanentlyDisabled() && !var5.isFiring()) {
            var11 = this.ship.getWeaponGroupFor(var5);
         }

         if(var11 != null) {
            int var12 = 0;
            boolean var8 = false;

            for(Iterator var9 = this.ship.getWeaponGroupsCopy().iterator(); var9.hasNext(); ++var12) {
               WeaponGroupAPI var10 = (WeaponGroupAPI)var9.next();
               if(var10 == var11) {
                  var8 = true;
                  break;
               }
            }

            if(var8 && !var11.isAutofiring()) {
               this.ship.giveCommand(ShipCommand.TOGGLE_AUTOFIRE, (Object)null, var12);
            }
         }
      }

   }
}
