package data.scripts.shipsystems.ai;

import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAIScript;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.util.armaa_utils;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_ironrampage implements ShipSystemAIScript {

   private ShipAPI ship;
   private CombatEngineAPI engine;
   private ShipwideAIFlags flags;
   private ShipSystemAPI system;
   private IntervalUtil tracker = new IntervalUtil(0.5F, 1.0F);


   public void advance(float var1, Vector2f var2, Vector2f var3, ShipAPI var4) {
      if(!this.engine.isPaused()) {
         this.tracker.advance(var1);
         if(AIUtils.canUseSystemThisFrame(this.ship) && this.tracker.intervalElapsed()) {
            if(this.ship.isDirectRetreat()) {
               this.ship.useSystem();
               return;
            }

            if(var4 == null) {
               return;
            }

            if(this.ship.getShipTarget() == null) {
               this.ship.setShipTarget(var4);
               return;
            }

            if(!var4.isAlive() || var4.isAlly()) {
               return;
            }

            List var5 = AIUtils.getNearbyAllies(this.ship, 450.0F);
            if(!var5.isEmpty()) {
               Iterator var6 = var5.iterator();

               while(var6.hasNext()) {
                  ShipAPI var7 = (ShipAPI)var6.next();
                  if(var7.getCollisionClass() != CollisionClass.NONE && var7.getCollisionClass() != CollisionClass.FIGHTER && Math.abs(MathUtils.getShortestRotation(VectorUtils.getAngle(this.ship.getLocation(), var7.getLocation()), this.ship.getFacing())) <= MathUtils.getRandomNumberInRange(25.0F, 65.0F)) {
                     return;
                  }
               }
            }

            if(var4.isFighter() || var4.isDrone() || var4.isStation() || var4.isStationModule() || var4.getEngineController().isFlamedOut() || this.ship.isRetreating()) {
               return;
            }

            if(armaa_utils.getFPWorthOfHostility(this.ship, 1000.0F) >= armaa_utils.getFPWorthOfSupport(this.ship, 1000.0F) * 1.75F) {
               return;
            }

            if(MathUtils.isWithinRange(this.ship, var4, 625.0F * (float)this.ship.getSystem().getAmmo()) || this.flags.hasFlag(AIFlags.MANEUVER_RANGE_FROM_TARGET) && ((Float)this.flags.getCustom(AIFlags.MANEUVER_RANGE_FROM_TARGET)).floatValue() <= 475.0F * (float)this.ship.getSystem().getAmmo()) {
               this.ship.useSystem();
               this.flags.setFlag(AIFlags.DO_NOT_BACK_OFF, 3.5F);
               return;
            }

            if(MathUtils.isWithinRange(this.ship, var4, 2200.0F) && this.ship.getSystem().getAmmo() < MathUtils.getRandomNumberInRange(1, 2)) {
               return;
            }

            if(this.flags.hasFlag(AIFlags.BACKING_OFF) && this.ship.getHardFluxLevel() >= (float)this.ship.getSystem().getAmmo() * MathUtils.getRandomNumberInRange(0.8F, 1.0F)) {
               if(this.flags.hasFlag(AIFlags.HAS_INCOMING_DAMAGE)) {
                  this.ship.useSystem();
                  this.flags.setFlag(AIFlags.DO_NOT_BACK_OFF, 3.5F);
               }

               return;
            }

            if(this.flags.hasFlag(AIFlags.PURSUING) || this.flags.hasFlag(AIFlags.HARASS_MOVE_IN)) {
               this.ship.useSystem();
               this.flags.setFlag(AIFlags.DO_NOT_BACK_OFF, 3.5F);
            }
         }
      }

   }

   public void init(ShipAPI var1, ShipSystemAPI var2, ShipwideAIFlags var3, CombatEngineAPI var4) {
      this.ship = var1;
      this.flags = var3;
      this.engine = var4;
      this.system = var2;
   }
}
