package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.StatusData;

public class armaa_fullerAutoStats extends BaseShipSystemScript {

   public static final float ROF_BONUS = 0.33F;
   public static final float FLUX_REDUCTION = 33.0F;
   public static final float MAX_TIME_MULT = 1.2F;
   public static final float MIN_TIME_MULT = 0.1F;


   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      ShipAPI var5 = null;
      boolean var6 = false;
      if(var1.getEntity() instanceof ShipAPI) {
         var5 = (ShipAPI)var1.getEntity();
         var6 = var5 == Global.getCombatEngine().getPlayerShip();
         var2 = var2 + "_" + var5.getId();
         float var7 = 1.0F + 0.33F * var4;
         float var8 = 1.0F + 0.20000005F * var4;
         var1.getBallisticRoFMult().modifyMult(var2, var7);
         var1.getEnergyRoFMult().modifyMult(var2, var7);
         var1.getEnergyWeaponFluxCostMod().modifyPercent(var2, -33.0F);
         var1.getBallisticWeaponFluxCostMod().modifyPercent(var2, -33.0F);
         var1.getTimeMult().modifyMult(var2, var8);
         if(var6) {
            Global.getCombatEngine().getTimeMult().modifyMult(var2, 1.0F / var8);
         } else {
            Global.getCombatEngine().getTimeMult().unmodify(var2);
         }

      }
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      ShipAPI var3 = null;
      boolean var4 = false;
      if(var1.getEntity() instanceof ShipAPI) {
         var3 = (ShipAPI)var1.getEntity();
         var4 = var3 == Global.getCombatEngine().getPlayerShip();
         var2 = var2 + "_" + var3.getId();
         var1.getBallisticRoFMult().unmodify(var2);
         var1.getBallisticWeaponFluxCostMod().unmodify(var2);
         var1.getEnergyRoFMult().unmodify(var2);
         var1.getEnergyWeaponFluxCostMod().unmodify(var2);
         Global.getCombatEngine().getTimeMult().unmodify(var2);
         var1.getTimeMult().unmodify(var2);
      }
   }

   public StatusData getStatusData(int var1, State var2, float var3) {
      float var4 = 1.0F + 0.33F * var3;
      float var5 = (float)((int)((var4 - 1.0F) * 100.0F));
      float var6 = 20.000004F * var3;
      return var1 == 0?new StatusData("WPN ROF +" + (int)var5 + "% / WPN FLUX USE -" + 33 + "%", false):(var1 == 1?new StatusData("Reaction time +" + (int)var6 + "%", false):null);
   }
}
