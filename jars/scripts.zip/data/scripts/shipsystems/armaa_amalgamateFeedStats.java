package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.StatusData;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.ArrayList;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;

public class armaa_amalgamateFeedStats extends BaseShipSystemScript {

   public static final Object KEY_JITTER = new Object();
   private float numFighters = 0.0F;
   private float liveFighters = 0.0F;
   private boolean broken = false;
   public static final float ROF_BONUS = 0.33F;
   public static final float FLUX_REDUCTION = 33.0F;
   private static final float SPEED_MANEUVERABILITY_INCREASE = 10.0F;
   private static final float SPEED_SPEED_INCREASE = 10.0F;
   public static final float MAX_TIME_MULT = 0.15F;
   public static final Color JITTER_UNDER_COLOR = new Color(50, 70, 255, 50);
   public static final Color JITTER_COLOR = new Color(50, 70, 255, 75);


   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      ShipAPI var5 = null;
      if(var1.getEntity() instanceof ShipAPI) {
         var5 = (ShipAPI)var1.getEntity();
         float var6 = this.liveFighters / Math.max(1.0F, this.numFighters);
         var6 = Math.min(1.0F, var6);
         Global.getCombatEngine().getCustomData().put("armaa_amalgamateFeedStats_squadStrength_" + var5.getId(), Float.valueOf(var6));
         float var7 = 1.0F + 0.33F * var4 * var6;
         var1.getBallisticRoFMult().modifyMult(var2, var7);
         var1.getEnergyRoFMult().modifyMult(var2, var7);
         var1.getBallisticWeaponFluxCostMod().modifyMult(var2, 1.0F - 0.32999998F * var4 * var6);
         var1.getEnergyWeaponFluxCostMod().modifyMult(var2, 1.0F - 0.32999998F * var4 * var6);
         var1.getMaxTurnRate().modifyPercent(var2, 10.0F * var4 * var6);
         var1.getAcceleration().modifyPercent(var2, 10.0F * var4 * var6);
         var1.getDeceleration().modifyPercent(var2, 10.0F * var4 * var6);
         var1.getTurnAcceleration().modifyPercent(var2, 10.0F * var4 * var6);
         var1.getMaxSpeed().modifyPercent(var2, 10.0F * var4 * var6);
         if(var4 > 0.0F) {
            float var8 = var4 * var6;
            float var9 = 5.0F;
            float var10 = var8 * var9 * var6;
            var5.setWeaponGlow(var4 * var6, Misc.setAlpha(JITTER_UNDER_COLOR, 50), EnumSet.allOf(WeaponType.class));
            var5.setJitterUnder(KEY_JITTER, JITTER_COLOR, var8, 5, 0.0F, var10);
            var5.setJitter(KEY_JITTER, JITTER_UNDER_COLOR, var8, 2, 0.0F, 0.0F + var10 * 1.0F);
            Global.getSoundPlayer().playLoop("system_targeting_feed_loop", var5, 1.0F, 1.0F, var5.getLocation(), var5.getVelocity());
            Iterator var11 = this.getFighters(var5).iterator();

            while(var11.hasNext()) {
               ShipAPI var12 = (ShipAPI)var11.next();
               MutableShipStatsAPI var13 = var12.getMutableStats();
               var13.getBallisticRoFMult().modifyMult(var2, var7);
               var13.getEnergyRoFMult().modifyMult(var2, var7);
               var13.getBallisticWeaponFluxCostMod().modifyMult(var2, 1.0F - 0.32999998F * var4 * var6);
               var13.getEnergyWeaponFluxCostMod().modifyMult(var2, 1.0F - 0.32999998F * var4 * var6);
               var13.getMaxTurnRate().modifyPercent(var2, 10.0F * var4 * var6);
               var13.getAcceleration().modifyPercent(var2, 10.0F * var4 * var6);
               var13.getDeceleration().modifyPercent(var2, 10.0F * var4 * var6);
               var13.getTurnAcceleration().modifyPercent(var2, 10.0F * var4 * var6);
               var13.getMaxSpeed().modifyPercent(var2, 10.0F * var4 * var6);
               if(var8 > 0.0F) {
                  var12.setWeaponGlow(var4 * var6, Misc.setAlpha(JITTER_UNDER_COLOR, 200), EnumSet.allOf(WeaponType.class));
                  var12.setJitterUnder(KEY_JITTER, JITTER_COLOR, var8, 5, 0.0F, var10);
                  var12.setJitter(KEY_JITTER, JITTER_UNDER_COLOR, var8, 2, 0.0F, 0.0F + var10 * 1.0F);
                  Global.getSoundPlayer().playLoop("system_targeting_feed_loop", var5, 1.0F, 1.0F, var12.getLocation(), var12.getVelocity());
               }
            }
         }

      }
   }

   private List getFighters(ShipAPI var1) {
      ArrayList var2 = new ArrayList(30);
      boolean var3 = false;
      Iterator var4 = Global.getCombatEngine().getShips().iterator();

      while(var4.hasNext()) {
         ShipAPI var5 = (ShipAPI)var4.next();
         if(var5.isFighter() && var5.getWing() != null && !var5.isHulk() && var5.getWing().getSourceShip() != null && var5.getWing().getSourceShip() == var1 && !var5.getWing().isReturning(var5)) {
            var2.add(var5);
            this.numFighters = (float)var5.getWing().getSpec().getNumFighters();
            int var6 = var5.getWing().getWingMembers().size();
         }
      }

      this.liveFighters = (float)var2.size();
      return var2;
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      var1.getBallisticWeaponFluxCostMod().unmodify(var2);
      var1.getEnergyWeaponFluxCostMod().unmodify(var2);
      var1.getMissileWeaponFluxCostMod().unmodify(var2);
      var1.getBallisticRoFMult().unmodify(var2);
      var1.getEnergyRoFMult().unmodify(var2);
      var1.getMaxTurnRate().unmodify(var2);
      var1.getAcceleration().unmodify(var2);
      var1.getDeceleration().unmodify(var2);
      var1.getTurnAcceleration().unmodify(var2);
      var1.getMaxSpeed().unmodify(var2);
      ShipAPI var3 = null;
      if(var1.getEntity() instanceof ShipAPI) {
         var3 = (ShipAPI)var1.getEntity();
         Iterator var4 = this.getFighters(var3).iterator();

         while(var4.hasNext()) {
            ShipAPI var5 = (ShipAPI)var4.next();
            if(!var5.isHulk()) {
               MutableShipStatsAPI var6 = var5.getMutableStats();
               var6.getBallisticRoFMult().unmodify(var2);
               var6.getEnergyRoFMult().unmodify(var2);
               var6.getBallisticWeaponFluxCostMod().unmodify(var2);
               var6.getEnergyWeaponFluxCostMod().unmodify(var2);
               var6.getMissileWeaponFluxCostMod().unmodify(var2);
               var6.getMaxTurnRate().unmodify(var2);
               var6.getAcceleration().unmodify(var2);
               var6.getDeceleration().unmodify(var2);
               var6.getTurnAcceleration().unmodify(var2);
               var6.getMaxSpeed().unmodify(var2);
            }
         }

      }
   }

   public static float getGauge(ShipAPI var0) {
      if(var0 != null && var0.getSystem() != null) {
         Object var1 = Global.getCombatEngine().getCustomData().get("armaa_amalgamateFeedStats_squadStrength_" + var0.getId());
         if(var1 instanceof Float) {
            float var2 = ((Float)var1).floatValue();
            return var2;
         } else {
            return 100.0F;
         }
      } else {
         return 0.0F;
      }
   }

   public boolean isUsable(ShipSystemAPI var1, ShipAPI var2) {
      this.getFighters(var2);
      float var3 = this.liveFighters / Math.max(1.0F, this.numFighters);
      Global.getCombatEngine().getCustomData().put("armaa_amalgamateFeedStats_squadStrength_" + var2.getId(), Float.valueOf(var3));
      if(this.liveFighters == 0.0F) {
         this.broken = true;
      } else {
         this.broken = false;
      }

      float var4 = this.liveFighters / Math.max(1.0F, this.numFighters);
      return var4 < 0.0F?false:isUsable(var2, var1);
   }

   public static boolean isUsable(ShipAPI var0, ShipSystemAPI var1) {
      if(var0 != null && var1 != null) {
         float var2 = 0.5F;
         float var3 = getGauge(var0);
         return var3 > 0.0F || var1.isActive();
      } else {
         return false;
      }
   }

   public String getInfoText(ShipSystemAPI var1, ShipAPI var2) {
      float var3 = 0.5F;
      float var4 = getGauge(var2);
      int var5 = Math.round(100.0F * Math.max(0.0F, var4));
      if(this.broken) {
         return "SQUAD BROKEN";
      } else if(var1.isActive()) {
         return "" + var5 + "% - ENGAGED";
      } else {
         long var6;
         if(var4 / 1.0F > 0.5F && var4 / 1.0F < 1.0F) {
            var6 = (long)Math.floor((double)(Global.getCombatEngine().getTotalElapsedTime(true) / 0.3F));
            return var6 % 3L == 0L?"" + var5 + "% - CASUALTIES SUFFERED":"" + var5 + "% - ";
         } else if(var4 < var3) {
            var6 = (long)Math.floor((double)(Global.getCombatEngine().getTotalElapsedTime(true) / 0.3F));
            return var6 % 3L == 0L?"" + var5 + "% - HEAVY LOSSES":"" + var5 + "% - ";
         } else {
            return "" + var5 + "%";
         }
      }
   }

   public StatusData getStatusData(int var1, State var2, float var3) {
      float var4 = this.liveFighters / Math.max(1.0F, this.numFighters);
      float var5 = 0.15F * var3 * var4;
      return var1 == 0?new StatusData("+" + Math.round(10.0F * var3 * var4) + "% squadron maneuverability", false):(var1 == 1?new StatusData("+" + Math.round(10.0F * var3 * var4) + "% squadron speed", false):(var1 == 2?new StatusData("WEP FLX COST -" + Math.round(33.0F * var3 * var4) + "%", false):(var1 == 3?new StatusData("WEP ROF +" + Math.round(33.0F * var3 * var4) + "%", false):null)));
   }

}
