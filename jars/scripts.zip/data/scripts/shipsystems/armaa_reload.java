package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.StatusData;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.util.armaa_reloadEveryFrame;
import java.awt.Color;
import java.util.Iterator;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;

public class armaa_reload extends BaseShipSystemScript {

   public static final float ROF_BONUS = 1.0F;
   public static final float FLUX_REDUCTION = 50.0F;
   public static final float TIME_MULT = 1.5F;
   public static final Object KEY_JITTER = new Object();
   private IntervalUtil interval = new IntervalUtil(1.5F, 1.5F);
   private Color startColor;
   private Color endColor;
   private final float baseAccuracy;
   private final float maxAccuracy;
   float rotation;
   public static final float DAMAGE_INCREASE_PERCENT = 50.0F;
   public static final Color JITTER_UNDER_COLOR = new Color(255, 50, 0, 125);
   public static final Color JITTER_COLOR = new Color(255, 50, 0, 75);


   public armaa_reload() {
      this.startColor = Color.RED;
      this.endColor = Color.YELLOW;
      this.baseAccuracy = 0.7F;
      this.maxAccuracy = 1.0F;
      this.rotation = 0.0F;
   }

   public static float lerp(float var0, float var1, float var2) {
      return Math.max(0.0F, (1.0F - var2) * var0 + var2 * var1);
   }

   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      float var5 = Global.getCombatEngine().getElapsedInLastFrame();
      ShipAPI var6 = (ShipAPI)var1.getEntity();
      ShipAPI var7 = var6.getShipTarget();
      ShipAPI var8 = var7 == null?var6:var7;
      this.interval.advance(var5);
      SpriteAPI var9 = Global.getSettings().getSprite("ceylon", "armaa_ceylontarget");
      SpriteAPI var10 = Global.getSettings().getSprite("misc", "armaa_monitorrad");
      SpriteAPI var11 = Global.getSettings().getSprite("ceylon", "armaa_ceylonrad");
      float var12 = this.interval.getElapsed() / this.interval.getIntervalDuration();
      Color var14 = new Color(Math.round(lerp((float)this.startColor.getRed(), (float)this.endColor.getRed(), var12)), Math.min(255, Math.round(lerp((float)this.startColor.getGreen(), (float)this.endColor.getGreen(), var12))), Math.round(lerp((float)this.startColor.getBlue(), (float)this.endColor.getBlue(), var12)), Math.round(lerp((float)this.startColor.getAlpha() * var4, (float)this.endColor.getAlpha() * var4, var12)));
      ++this.rotation;
      float var15 = var6.getCollisionRadius() * 2.0F;
      float var16 = var15 * 2.0F - var15 * var12;
      if(Math.abs(var15 - var16) <= 15.0F) {
         var14 = Color.GREEN;
      }

      boolean var17 = Keyboard.isKeyDown(33);
      boolean var18 = var6 == Global.getCombatEngine().getPlayerShip() && Global.getCombatEngine().isUIAutopilotOn();
      if(var9 != null && var18) {
         MagicRender.objectspace(var9, var8, new Vector2f(), new Vector2f(), new Vector2f(var16, var16), new Vector2f(0.0F, 0.0F), this.rotation, 25.0F, true, var14, true, 0.0F, var5, 0.0F, true);
         MagicRender.objectspace(var10, var8, new Vector2f(), new Vector2f(), new Vector2f(var15, var15), new Vector2f(0.0F, 0.0F), 0.0F, 25.0F, true, Color.white, true, 0.0F, var5, 0.0F, true);
         MagicRender.objectspace(var11, var8, new Vector2f(), new Vector2f(), new Vector2f(var15 + 15.0F, var15 + 15.0F), new Vector2f(0.0F, 0.0F), this.rotation * -1.0F, 25.0F, true, Color.blue, true, 0.0F, var5, 0.0F, true);
      }

      float var19 = -1.0F;
      if(var19 <= 0.0F) {
         var19 = Math.max(0.7F, 0.7F + 0.3F * (float)(var6.getCaptain().getStats().getLevel() - 1) / 4.0F);
      }

      float var20 = (float)Math.random();
      var20 *= 0.7F;
      if(var18 || var19 < var20 || Math.abs(var15 - var16) < 15.0F) {
         boolean var21 = false;
         if((var18 && var17 || !var18) && var3 == State.ACTIVE) {
            String var22 = "Failure!" + var19 + " vs " + var20;
            if((var18 || !var18 && var19 >= var20) && Math.abs(var15 - var16) < 15.0F) {
               WeaponAPI var23 = null;
               var21 = true;
               Iterator var24 = var6.getAllWeapons().iterator();

               while(var24.hasNext()) {
                  WeaponAPI var25 = (WeaponAPI)var24.next();
                  if(var25.getId().equals("armaa_barretta")) {
                     var23 = var25;
                     break;
                  }
               }

               var22 = "perfect!";
               Global.getSoundPlayer().playSound("ui_char_spent_story_point_combat", 1.3F, 1.0F, var6.getLocation(), new Vector2f());
               Global.getCombatEngine().addFloatingText(var6.getLocation(), var22, 24.0F, Color.WHITE, var6, 0.0F, 0.0F);
               float var29 = 180.0F + var23.getCurrAngle();
               Vector2f var30 = MathUtils.getPoint(var23.getFirePoint(0), 45.0F, var29);

               int var26;
               Vector2f var27;
               for(var26 = 0; var26 < 20; ++var26) {
                  var27 = MathUtils.getRandomPointInCone(new Vector2f(), 100.0F, var29 - 20.0F, var29 + 20.0F);
                  var27.scale((float)Math.random());
                  Vector2f.add(var27, var23.getShip().getVelocity(), var27);
                  float var28 = MathUtils.getRandomNumberInRange(0.5F, 0.75F);
                  Global.getCombatEngine().addSmokeParticle(MathUtils.getRandomPointInCircle(var23.getFirePoint(0), 5.0F), var27, (float)MathUtils.getRandomNumberInRange(5, 20), MathUtils.getRandomNumberInRange(0.25F, 0.75F), MathUtils.getRandomNumberInRange(0.25F, 1.0F), new Color(var28, var28, var28, MathUtils.getRandomNumberInRange(0.25F, 0.75F)));
               }

               for(var26 = 0; var26 < 10; ++var26) {
                  var27 = MathUtils.getRandomPointInCone(new Vector2f(), 250.0F, var29 - 20.0F, var29 + 20.0F);
                  Vector2f.add(var27, var23.getShip().getVelocity(), var27);
                  Global.getCombatEngine().addHitParticle(var30, var27, (float)MathUtils.getRandomNumberInRange(2, 4), 1.0F, MathUtils.getRandomNumberInRange(0.05F, 0.25F), new Color(255, 125, 50));
               }

               Vector2f var31 = MathUtils.getRandomPointInCone(new Vector2f(), 100.0F, var29 - 20.0F, var29 + 20.0F);
               var31.scale((float)Math.random());
               Vector2f.add(var31, var23.getShip().getVelocity(), var31);
               Global.getCombatEngine().addHitParticle(var30, var31, 100.0F, 0.5F, 0.5F, new Color(255, 20, 10));
               Global.getCombatEngine().addHitParticle(var30, var31, 80.0F, 0.75F, 0.15F, new Color(255, 200, 50));
               Global.getCombatEngine().addHitParticle(var30, var31, 50.0F, 1.0F, 0.05F, new Color(255, 200, 150));
               var30 = MathUtils.getPoint(var23.getFirePoint(0), 0.0F, var29);
               Global.getCombatEngine().addHitParticle(var30, var6.getVelocity(), 100.0F, 0.5F, 0.5F, new Color(255, 20, 10));
               Global.getCombatEngine().addHitParticle(var30, var6.getVelocity(), 80.0F, 0.75F, 0.15F, new Color(255, 200, 50));
               Global.getCombatEngine().addHitParticle(var30, var6.getVelocity(), 50.0F, 1.0F, 0.05F, new Color(255, 200, 150));
               Global.getCombatEngine().addPlugin(new armaa_reloadEveryFrame(var6));
            } else {
               Global.getCombatEngine().addFloatingText(var6.getLocation(), var22, 24.0F, Color.WHITE, var6, 0.0F, 0.0F);
            }

            if(var18) {
               MagicRender.objectspace(var9, var8, new Vector2f(), new Vector2f(), new Vector2f(var16, var16), new Vector2f(100.0F, 100.0F), this.rotation, 25.0F, true, var14, true, 0.0F, 0.5F, 0.5F, true);
               MagicRender.objectspace(var10, var8, new Vector2f(), new Vector2f(), new Vector2f(var15, var15), new Vector2f(0.0F, 0.0F), 0.0F, 25.0F, true, Color.white, true, 0.0F, 0.5F, 0.5F, true);
            }

            if(!var21) {
               Global.getSoundPlayer().playSound("cr_playership_malfunction", 1.3F, 1.0F, var6.getLocation(), new Vector2f());
            }

            var6.getSystem().deactivate();
         }

      }
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      this.interval = new IntervalUtil(1.5F, 1.5F);
   }

   public StatusData getStatusData(int var1, State var2, float var3) {
      float var4 = 1.0F + 1.0F * var3;
      float var5 = (float)((int)((var4 - 1.0F) * 100.0F));
      return var1 == 0?new StatusData("ballistic rate of fire +" + (int)var5 + "%", false):(var1 == 1?new StatusData("ballistic flux use -50%", false):null);
   }

}
