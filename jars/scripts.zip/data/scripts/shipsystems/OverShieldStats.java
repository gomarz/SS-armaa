package data.scripts.shipsystems;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.StatusData;

public class OverShieldStats extends BaseShipSystemScript {

   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      var1.getShieldDamageTakenMult().modifyMult(var2, 1.0F - 0.5F * var4);
      var1.getShieldUpkeepMult().modifyMult(var2, 0.0F);
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      var1.getShieldAbsorptionMult().unmodify(var2);
      var1.getShieldArcBonus().unmodify(var2);
      var1.getShieldDamageTakenMult().unmodify(var2);
      var1.getShieldTurnRateMult().unmodify(var2);
      var1.getShieldUnfoldRateMult().unmodify(var2);
      var1.getShieldUpkeepMult().unmodify(var2);
   }

   public StatusData getStatusData(int var1, State var2, float var3) {
      return var1 == 0?new StatusData("shield absorbs 10x damage", false):null;
   }
}
