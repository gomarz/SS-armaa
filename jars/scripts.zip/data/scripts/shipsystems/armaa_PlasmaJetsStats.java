package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipEngineControllerAPI.ShipEngineAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.StatusData;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lwjgl.util.vector.Vector2f;

public class armaa_PlasmaJetsStats extends BaseShipSystemScript {

   private static final float VEL_MIN = 0.2F;
   private static final float VEL_MAX = 0.4F;
   private static final float CONE_ANGLE = 200.0F;
   private static final float A_2 = 100.0F;
   public static final float MAX_TIME_MULT = 3.0F;
   public static final float MIN_TIME_MULT = 0.1F;


   public static float getMaxTimeMult(MutableShipStatsAPI var0) {
      return 3.0F;
   }

   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      ShipAPI var5 = (ShipAPI)var1.getEntity();
      if(var3 == State.IN) {
         float var6 = 1.0F + (getMaxTimeMult(var1) - 1.0F) * (1.0F - var4);
         var1.getTimeMult().modifyMult(var2, var6);
         boolean var7 = false;
         var7 = var5 == Global.getCombatEngine().getPlayerShip();
         var1.getMaxSpeed().modifyFlat(var2, 300.0F * var4);
         var1.getAcceleration().modifyFlat(var2, 300.0F * var4);
         var1.getDeceleration().modifyFlat(var2, 300.0F * var4);
         if(var7) {
            Global.getCombatEngine().getTimeMult().modifyMult(var2, 1.0F / var6);
         } else {
            Global.getCombatEngine().getTimeMult().unmodify(var2);
         }
      } else if(var3 == State.OUT) {
         var1.getMaxSpeed().unmodify(var2);
         Global.getCombatEngine().getTimeMult().unmodify(var2);
      } else {
         var1.getMaxSpeed().modifyFlat(var2, 300.0F * var4);
         var1.getAcceleration().modifyFlat(var2, 300.0F * var4);
         var1.getDeceleration().modifyFlat(var2, 300.0F * var4);
         if(var5 != null) {
            if(var5 instanceof ShipAPI) {
               ;
            }

            Color var16 = Color.white;
            if(!var5.getSystem().getId().equals("armaa_plasmaJets")) {
               var16 = var5.getPhaseCloak().getSpecAPI().getEngineGlowColor();
            } else {
               var16 = var5.getSystem().getSpecAPI().getEngineGlowColor();
            }

            Color var17 = new Color((float)var16.getRed() / 255.0F, (float)var16.getGreen() / 255.0F, (float)var16.getBlue() / 255.0F, 1.0F * var4);
            if((float)Math.random() <= 0.5F) {
               for(int var8 = 0; var8 < var5.getEngineController().getShipEngines().size(); ++var8) {
                  float var9 = 500.0F;
                  float var10 = var5.getFacing();
                  float var11 = MathUtils.getRandomNumberInRange(var10 - 100.0F, var10 + 100.0F);
                  float var12 = MathUtils.getRandomNumberInRange(var9 * -0.2F, var9 * -0.4F);
                  Vector2f var13 = MathUtils.getPointOnCircumference((Vector2f)null, var12, var11);
                  Vector2f var14 = new Vector2f(((ShipEngineAPI)var5.getEngineController().getShipEngines().get(var8)).getLocation());
                  Vector2f var15 = new Vector2f(-5.0F, -0.0F);
                  VectorUtils.rotate(var15, var5.getFacing(), var15);
                  Vector2f.add(var15, var14, var14);
                  Global.getCombatEngine().addHitParticle(var14, var13, (float)MathUtils.getRandomNumberInRange(2, 5), 1.0F * var4, MathUtils.getRandomNumberInRange(0.4F, 0.8F), var17);
               }
            }
         }
      }

   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      var1.getMaxSpeed().unmodify(var2);
      var1.getAcceleration().unmodify(var2);
      Global.getCombatEngine().getTimeMult().unmodify(var2);
      var1.getTimeMult().unmodify(var2);
   }

   public StatusData getStatusData(int var1, State var2, float var3) {
      return var1 == 0?new StatusData("increased engine power", false):null;
   }

   public float getActiveOverride(ShipAPI var1) {
      return -1.0F;
   }

   public float getInOverride(ShipAPI var1) {
      return -1.0F;
   }

   public float getOutOverride(ShipAPI var1) {
      return -1.0F;
   }

   public float getRegenOverride(ShipAPI var1) {
      return -1.0F;
   }
}
