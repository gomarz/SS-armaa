package data.scripts.shipsystems;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.StatusData;

public class armaa_GU14FireboltFeeder extends BaseShipSystemScript {

   public static final float ROF_BONUS = 0.25F;
   public static final float FLUX_REDUCTION = 10.0F;
   public static final float DMG_BONUS = 25.0F;


   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      float var5 = 1.0F + 0.25F * var4;
      var1.getBallisticRoFMult().modifyMult(var2, var5);
      var1.getBallisticWeaponFluxCostMod().modifyPercent(var2, -10.0F);
      var1.getBallisticWeaponDamageMult().modifyPercent(var2, 25.0F * var4);
      var1.getEnergyRoFMult().modifyMult(var2, var5);
      var1.getEnergyWeaponFluxCostMod().modifyPercent(var2, -10.0F);
      var1.getEnergyWeaponDamageMult().modifyPercent(var2, 25.0F * var4);
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      var1.getBallisticRoFMult().unmodify(var2);
      var1.getBallisticWeaponFluxCostMod().unmodify(var2);
      var1.getBallisticWeaponDamageMult().unmodify(var2);
      var1.getEnergyRoFMult().unmodify(var2);
      var1.getEnergyWeaponFluxCostMod().unmodify(var2);
      var1.getEnergyWeaponDamageMult().unmodify(var2);
   }

   public StatusData getStatusData(int var1, State var2, float var3) {
      float var4 = 1.0F + 0.25F * var3;
      float var5 = (float)((int)((var4 - 1.0F) * 100.0F));
      return var1 == 0?new StatusData("ballistic rate of fire +" + (int)var5 + "%", false):(var1 == 1?new StatusData("ballistic flux use -10%", false):null);
   }
}
