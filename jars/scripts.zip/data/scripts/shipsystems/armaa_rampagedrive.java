package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipSystemAPI.SystemState;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import com.fs.starfarer.api.graphics.SpriteAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.StatusData;
import java.awt.Color;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.FastTrig;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicFakeBeam;
import org.magiclib.util.MagicRender;

public class armaa_rampagedrive extends BaseShipSystemScript {

   public static Map bugs = new HashMap();
   private static Map wide = new HashMap();
   private static Map damage = new HashMap();
   private static Map SPEED_BOOST = new HashMap();
   private float AFTERIMAGE_THRESHOLD = 0.09F;
   private static final Color color;
   public static final float MASS_MULT = 1.2F;
   public static final float DAMAGE_MULT = 0.15F;
   public static final float ROF_MULT = 0.5F;
   private boolean reset = true;
   private float activeTime = 0.0F;
   private float jitterLevel;
   private boolean DidRam = false;
   private float PARTICLE_ANGLE_SPREAD = 150.0F;
   private final float A_2;
   private float CHARGEUP_PARTICLE_BRIGHTNESS;
   private float CHARGEUP_PARTICLE_DISTANCE_MAX;
   private float CHARGEUP_PARTICLE_DISTANCE_MIN;
   private float CHARGEUP_PARTICLE_DURATION;
   private float CHARGEUP_PARTICLE_SIZE_MAX;
   private float CHARGEUP_PARTICLE_SIZE_MIN;
   private Float mass;


   public armaa_rampagedrive() {
      this.A_2 = this.PARTICLE_ANGLE_SPREAD / 2.0F;
      this.CHARGEUP_PARTICLE_BRIGHTNESS = 1.0F;
      this.CHARGEUP_PARTICLE_DISTANCE_MAX = 200.0F;
      this.CHARGEUP_PARTICLE_DISTANCE_MIN = 150.0F;
      this.CHARGEUP_PARTICLE_DURATION = 0.8F;
      this.CHARGEUP_PARTICLE_SIZE_MAX = 5.0F;
      this.CHARGEUP_PARTICLE_SIZE_MIN = 2.0F;
      this.mass = null;
   }

   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      CombatEngineAPI var5 = Global.getCombatEngine();
      ShipAPI var6 = (ShipAPI)var1.getEntity();
      if(!var5.isPaused() && var6 != null) {
         if(this.mass == null) {
            this.mass = Float.valueOf(var6.getMass());
         }

         if(this.reset) {
            this.reset = false;
            this.activeTime = 0.0F;
            this.jitterLevel = 0.0F;
            this.DidRam = false;
         }

         ShipAPI var7 = var6.getShipTarget();
         float var8 = var6.getMaxTurnRate() * 2.0F;
         if(var3 == State.OUT) {
            var1.getMaxSpeed().unmodify(var2);
            var6.setMass(this.mass.floatValue());
            this.DidRam = false;
         } else {
            if(var6.getMass() == this.mass.floatValue()) {
               var6.setMass(this.mass.floatValue() * 1.2F);
            }

            var1.getMaxSpeed().modifyFlat(var2, ((Float)SPEED_BOOST.get(var6.getVariant().getHullSize())).floatValue());
            var1.getAcceleration().modifyFlat(var2, ((Float)SPEED_BOOST.get(var6.getHullSize())).floatValue() * 3.0F);
            var1.getEmpDamageTakenMult().modifyMult(var2, 0.15F);
            var1.getArmorDamageTakenMult().modifyMult(var2, 0.15F);
            var1.getHullDamageTakenMult().modifyMult(var2, 0.15F);
            var1.getBallisticRoFMult().modifyMult(var2, 0.5F);
            var1.getEnergyRoFMult().modifyMult(var2, 0.5F);
            int var18;
            if(!this.DidRam) {
               Vector2f var9 = var6.getLocation();
               float var10 = var6.getFacing();
               Vector2f var11 = MathUtils.getPoint(var9, ((Float)bugs.get(var6.getHullSize())).floatValue(), var10);
               List var12 = CombatUtils.getEntitiesWithinRange(var6.getLocation(), ((Float)bugs.get(var6.getHullSize())).floatValue() + 25.0F);
               if(!var12.isEmpty()) {
                  Iterator var13 = var12.iterator();

                  while(var13.hasNext()) {
                     CombatEntityAPI var14 = (CombatEntityAPI)var13.next();
                     if(var14.getCollisionClass() != CollisionClass.NONE && var14.getOwner() != var6.getOwner()) {
                        Vector2f var15 = new Vector2f(1000000.0F, 1000000.0F);
                        if(var14 instanceof ShipAPI) {
                           if(var14 != var6 && ((ShipAPI)var14).getParentStation() != var14 && var14.getCollisionClass() != CollisionClass.NONE && var14.getCollisionClass() != CollisionClass.FIGHTER && CollisionUtils.getCollides(var6.getLocation(), var11, var14.getLocation(), var14.getCollisionRadius())) {
                              ShipAPI var16 = (ShipAPI)var14;
                              Vector2f var17 = MagicFakeBeam.getShipCollisionPoint(var9, var11, var16, var10);
                              if(var17 != null) {
                                 var15 = var17;
                              }
                           }

                           if(var15.x != 1000000.0F && MathUtils.getDistanceSquared(var9, var15) < MathUtils.getDistanceSquared(var9, var11)) {
                              this.DidRam = true;
                              MagicFakeBeam.spawnFakeBeam(var5, var6.getLocation(), ((Float)bugs.get(var6.getHullSize())).floatValue(), var6.getFacing(), ((Float)wide.get(var6.getHullSize())).floatValue(), 0.1F, 0.1F, 25.0F, color, color, ((Float)damage.get(var6.getHullSize())).floatValue(), DamageType.HIGH_EXPLOSIVE, 0.0F, var6);
                              Global.getSoundPlayer().playSound("collision_ships", 1.0F, 0.5F, var6.getLocation(), var6.getVelocity());
                              SpriteAPI var33 = Global.getSettings().getSprite("misc", "armaa_sfxpulse");
                              CombatUtils.applyForce(var6, var6.getFacing() - 180.0F, var6.getMaxSpeed() * 0.7F);
                              if(var33 != null) {
                                 MagicRender.battlespace(var33, var15, new Vector2f(), new Vector2f(20.0F, 20.0F), new Vector2f(350.0F, 350.0F), 15.0F, 15.0F, new Color(255, 255, 255, 200), true, 0.3F, 0.0F, 0.3F);
                              }

                              float var35 = var6.getFacing();
                              var18 = 1 + (int)(var4 * 20.0F);

                              for(int var19 = 0; var19 < var18; ++var19) {
                                 float var20 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_DISTANCE_MIN + 1.0F, this.CHARGEUP_PARTICLE_DISTANCE_MAX + 1.0F) * var4;
                                 float var21 = 0.75F * var20 / this.CHARGEUP_PARTICLE_DURATION * var4;
                                 float var22 = MathUtils.getRandomNumberInRange(var35 - this.A_2, var35 + this.A_2);
                                 float var23 = MathUtils.getRandomNumberInRange(var21 * -1.5F, var21 * -2.0F);
                                 Vector2f var24 = MathUtils.getPointOnCircumference((Vector2f)null, var23, var22);
                                 float var25 = MathUtils.getRandomNumberInRange(this.CHARGEUP_PARTICLE_SIZE_MIN + 1.0F, this.CHARGEUP_PARTICLE_SIZE_MAX + 1.0F) * var4;
                                 var5.addHitParticle(var15, var24, var25, this.CHARGEUP_PARTICLE_BRIGHTNESS * Math.min(var4 + 0.5F, 1.0F) * MathUtils.getRandomNumberInRange(0.75F, 1.25F), this.CHARGEUP_PARTICLE_DURATION, new Color(255, 255, 200, 255));
                              }
                           }
                        }
                     }
                  }
               }
            }

            float var26;
            if(var7 != null && var7.isAlive() && !var7.isAlly() && var6.getSystem().isActive()) {
               var26 = var6.getFacing();
               var26 = MathUtils.getShortestRotation(var26, VectorUtils.getAngle(var6.getLocation(), var7.getLocation()));
               if(!var7.isFighter() && !var7.isDrone()) {
                  var6.setAngularVelocity(Math.min(var8, Math.max(-var8, var26 * 5.0F)));
               } else {
                  var6.setAngularVelocity(Math.min(var8, Math.max(-var8, var26 * 2.0F)));
               }

               this.activeTime += var5.getElapsedInLastFrame();
               if(this.activeTime <= 3.0F) {
                  this.jitterLevel = Math.max(1.0F - this.activeTime / 1.0F, 1.0F);
                  var1.getEmpDamageTakenMult().modifyMult(var2, 0.15F);
                  var1.getArmorDamageTakenMult().modifyMult(var2, 0.15F);
                  var1.getHullDamageTakenMult().modifyMult(var2, 0.15F);
               }

               if(this.activeTime > 3.0F) {
                  this.jitterLevel = 0.0F;
                  var1.getEmpDamageTakenMult().unmodifyMult(var2);
                  var1.getArmorDamageTakenMult().unmodifyMult(var2);
                  var1.getHullDamageTakenMult().unmodifyMult(var2);
               }
            }

            var26 = Global.getCombatEngine().getElapsedInLastFrame();
            var6.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerNullerID", -1.0F);
            var6.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerID", var6.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() + var26);
            if(var6.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() > this.AFTERIMAGE_THRESHOLD) {
               SpriteAPI var27 = var6.getSpriteAPI();
               float var28 = var27.getWidth() / 2.0F - var27.getCenterX();
               float var29 = var27.getHeight() / 2.0F - var27.getCenterY();
               float var30 = (float)FastTrig.cos(Math.toRadians((double)(var6.getFacing() - 90.0F))) * var28 - (float)FastTrig.sin(Math.toRadians((double)(var6.getFacing() - 90.0F))) * var29;
               float var31 = (float)FastTrig.sin(Math.toRadians((double)(var6.getFacing() - 90.0F))) * var28 + (float)FastTrig.cos(Math.toRadians((double)(var6.getFacing() - 90.0F))) * var29;
               if(!var6.isHulk()) {
                  Iterator var32 = var6.getAllWeapons().iterator();

                  while(var32.hasNext()) {
                     WeaponAPI var34 = (WeaponAPI)var32.next();
                     if((var34.getSlot().isBuiltIn() || var34.getSlot().isDecorative()) && (var34.getSpec().getType() != WeaponType.MISSILE || var34.getAmmo() >= 0) && var34.getSprite() != null) {
                        Color var36 = var6.getSystem().getSpecAPI().getJitterEffectColor();
                        if(!var34.getSlot().getId().equals("F_LEGS")) {
                           MagicRender.battlespace(Global.getSettings().getSprite(var34.getSpec().getTurretSpriteName()), new Vector2f(var34.getLocation().getX() + var30, var34.getLocation().getY() + var31), new Vector2f(0.0F, 0.0F), new Vector2f(var34.getSprite().getWidth(), var34.getSprite().getHeight()), new Vector2f(0.0F, 0.0F), var6.getFacing() - 90.0F, 0.0F, var36, true, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1F, 0.1F, 0.3F, CombatEngineLayers.BELOW_SHIPS_LAYER);
                        } else {
                           var18 = var34.getAnimation().getFrame();
                           SpriteAPI var38 = Global.getSettings().getSprite("graphics/armaa/ships/valkazard/armaa_valkazard_legs0" + var18 + ".png");
                           if(var18 >= 10) {
                              var38 = Global.getSettings().getSprite("graphics/armaa/ships/valkazard/armaa_valkazard_legs" + var18 + ".png");
                           }

                           MagicRender.battlespace(var38, new Vector2f(var34.getLocation().getX() + var30, var34.getLocation().getY() + var31), new Vector2f(0.0F, 0.0F), new Vector2f(var34.getSprite().getWidth(), var34.getSprite().getHeight()), new Vector2f(0.0F, 0.0F), var6.getFacing() - 90.0F, 0.0F, var36, true, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1F, 0.1F, 0.3F, CombatEngineLayers.BELOW_SHIPS_LAYER);
                        }

                        if(var34.getBarrelSpriteAPI() != null && (var34.getSlot().getId().equals("C_ARML") || var34.getSlot().getId().equals("A_GUN"))) {
                           SpriteAPI var37 = Global.getSettings().getSprite(var34.getSpec().getHardpointSpriteName());
                           MagicRender.battlespace(var37, new Vector2f(var34.getLocation().getX() + var30, var34.getLocation().getY() + var31), new Vector2f(0.0F, 0.0F), new Vector2f(var34.getBarrelSpriteAPI().getWidth(), var34.getBarrelSpriteAPI().getHeight()), new Vector2f(0.0F, 0.0F), var34.getCurrAngle() - 90.0F, 0.0F, var36, true, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.1F, 0.1F, 0.3F, CombatEngineLayers.BELOW_SHIPS_LAYER);
                        }
                     }
                  }
               }

               var6.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerID", var6.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() - this.AFTERIMAGE_THRESHOLD);
            }
         }

      }
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      this.reset = true;
      ShipAPI var3 = (ShipAPI)var1.getEntity();
      if(var3 != null) {
         if(this.mass == null) {
            this.mass = Float.valueOf(var3.getMass());
         }

         if(var3.getMass() != this.mass.floatValue()) {
            var3.setMass(this.mass.floatValue());
         }

         var1.getMaxSpeed().unmodify(var2);
         var1.getAcceleration().unmodify(var2);
         var1.getEmpDamageTakenMult().unmodify(var2);
         var1.getHullDamageTakenMult().unmodify(var2);
         var1.getArmorDamageTakenMult().unmodify(var2);
         var1.getBallisticRoFMult().unmodify(var2);
         var1.getEnergyRoFMult().unmodify(var2);
      }
   }

   public StatusData getStatusData(int var1, State var2, float var3) {
      return var1 == 0?null:(var1 == 1?null:null);
   }

   public String getInfoText(ShipSystemAPI var1, ShipAPI var2) {
      return var1.isOutOfAmmo()?null:(var1.getState() != SystemState.IDLE?null:"READY");
   }

   static {
      bugs.put(HullSize.FIGHTER, Float.valueOf(50.0F));
      bugs.put(HullSize.FRIGATE, Float.valueOf(80.0F));
      bugs.put(HullSize.DESTROYER, Float.valueOf(100.0F));
      bugs.put(HullSize.CRUISER, Float.valueOf(160.0F));
      bugs.put(HullSize.CAPITAL_SHIP, Float.valueOf(1.0F));
      wide.put(HullSize.FIGHTER, Float.valueOf(50.0F));
      wide.put(HullSize.FRIGATE, Float.valueOf(126.0F));
      wide.put(HullSize.DESTROYER, Float.valueOf(136.0F));
      wide.put(HullSize.CRUISER, Float.valueOf(177.0F));
      wide.put(HullSize.CAPITAL_SHIP, Float.valueOf(1.0F));
      damage.put(HullSize.FIGHTER, Float.valueOf(50.0F));
      damage.put(HullSize.FRIGATE, Float.valueOf(1000.0F));
      damage.put(HullSize.DESTROYER, Float.valueOf(1500.0F));
      damage.put(HullSize.CRUISER, Float.valueOf(2250.0F));
      damage.put(HullSize.CAPITAL_SHIP, Float.valueOf(1.0F));
      SPEED_BOOST.put(HullSize.FIGHTER, Float.valueOf(150.0F));
      SPEED_BOOST.put(HullSize.FRIGATE, Float.valueOf(300.0F));
      SPEED_BOOST.put(HullSize.DESTROYER, Float.valueOf(275.0F));
      SPEED_BOOST.put(HullSize.CRUISER, Float.valueOf(250.0F));
      SPEED_BOOST.put(HullSize.CAPITAL_SHIP, Float.valueOf(1.0F));
      color = new Color(255, 255, 255, 200);
   }
}
