package data.scripts.shipsystems;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI.SystemState;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.StatusData;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;

public class armaa_meleeAttackStats extends BaseShipSystemScript {

   public static final float SPEED_BOOST = 250.0F;
   public static final float MASS_MULT = 2.0F;
   public static final float RANGE = 900.0F;
   private Float mass = null;


   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      ShipAPI var5 = (ShipAPI)var1.getEntity();
      if(var5 != null) {
         if(this.mass == null) {
            this.mass = Float.valueOf(var5.getMass());
         }

         ShipAPI var6 = var5.getShipTarget();
         float var7 = var5.getMaxTurnRate() * 2.0F;
         if(var3 == State.OUT) {
            var1.getMaxSpeed().unmodify(var2);
            var5.setMass(this.mass.floatValue());
         } else {
            if(var5.getMass() == this.mass.floatValue()) {
               var5.setMass(this.mass.floatValue() * 2.0F);
            }

            var1.getMaxSpeed().modifyFlat(var2, 250.0F);
            var1.getAcceleration().modifyFlat(var2, 750.0F);
            var1.getShieldDamageTakenMult().modifyMult(var2, 0.85F);
            if(var6 != null && var5.getSystem().isActive()) {
               float var8 = var5.getFacing();
               var8 = MathUtils.getShortestRotation(var8, VectorUtils.getAngle(var5.getLocation(), var6.getLocation()));
               var5.setAngularVelocity(Math.min(var7, Math.max(-var7, var8 * 5.0F)));
            }
         }

      }
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      ShipAPI var3 = (ShipAPI)var1.getEntity();
      if(var3 != null) {
         if(this.mass == null) {
            this.mass = Float.valueOf(var3.getMass());
         }

         if(var3.getMass() != this.mass.floatValue()) {
            var3.setMass(this.mass.floatValue());
         }

         var1.getMaxSpeed().unmodify(var2);
         var1.getAcceleration().unmodify(var2);
         var1.getShieldDamageTakenMult().unmodify(var2);
      }
   }

   public StatusData getStatusData(int var1, State var2, float var3) {
      return var1 == 0?new StatusData("Engines boosted", false):null;
   }

   public String getInfoText(ShipSystemAPI var1, ShipAPI var2) {
      if(var1.isOutOfAmmo()) {
         return null;
      } else if(var1.getState() != SystemState.IDLE) {
         return null;
      } else {
         ShipAPI var3 = this.findTarget(var2);
         return var3 != null && var3 != var2?"READY":((var3 == null || var3 == var2) && var2.getShipTarget() != null?"OUT OF RANGE":"NO TARGET");
      }
   }

   protected ShipAPI findTarget(ShipAPI var1) {
      ShipAPI var2 = var1.getShipTarget();
      return var2 != null && (!var2.isDrone() || !var2.isFighter()) && MathUtils.isWithinRange(var1, var2, 900.0F) && var2.getOwner() != var1.getOwner()?var2:null;
   }

   public boolean isUsable(ShipSystemAPI var1, ShipAPI var2) {
      ShipAPI var3 = this.findTarget(var2);
      return var3 != null && var3 != var2;
   }
}
