package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.StatusData;
import data.scripts.util.armaa_utils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicLensFlare;

public class armaa_RecallDeviceStats extends BaseShipSystemScript {

   public static final Object KEY_JITTER = new Object();
   public static final Color JITTER_COLOR = new Color(100, 165, 255, 155);
   private static final Color BASIC_FLASH_COLOR = new Color(184, 155, 218, 200);
   private static final Color BASIC_GLOW_COLOR = new Color(180, 161, 255, 200);


   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      ShipAPI var5 = null;
      if(var1.getEntity() instanceof ShipAPI) {
         var5 = (ShipAPI)var1.getEntity();
         ShipAPI var6 = null;
         if(var4 > 0.0F) {
            boolean var8 = false;
            String var9 = var5.getId() + "_recall_device_target";
            ShipAPI var10 = var5.getShipTarget();
            if(var10 != null && var10.getOwner() == var5.getOwner() && var10.getVariant().hasHullMod("strikeCraft")) {
               var6 = var10;
            } else {
               Object var11 = null;
               if(!Global.getCombatEngine().getCustomData().containsKey(var9)) {
                  var11 = getFighters(var5);
                  Global.getCombatEngine().getCustomData().put(var9, var11);
                  var8 = true;
               } else {
                  var11 = (List)Global.getCombatEngine().getCustomData().get(var9);
               }

               if(var11 == null) {
                  var11 = new ArrayList();
               }

               Iterator var12 = ((List)var11).iterator();

               while(var12.hasNext()) {
                  ShipAPI var13 = (ShipAPI)var12.next();
                  if(!var13.isHulk()) {
                     var6 = var13;
                  }
               }
            }

            if(var6 == null) {
               return;
            }

            float var15 = var6.getCollisionRadius() * 1.0F;
            float var14 = 5.0F + var4 * var15;
            if(var8) {
               Global.getSoundPlayer().playSound("system_phase_skimmer", 1.0F, 0.5F, var6.getLocation(), var6.getVelocity());
            }

            var6.setJitter(KEY_JITTER, JITTER_COLOR, var4, 10, 0.0F, var14);
            if(var6.isAlive()) {
               ;
            }

            if(var3 == State.IN) {
               float var16 = 1.0F - var4 * 0.5F;
               var6.setExtraAlphaMult(var16);
            }

            if(var4 == 1.0F && var5 != null) {
               armaa_utils.setLocation(var6, MathUtils.getRandomPointInCircle(var5.getLocation(), 200.0F));
               var6.setExtraAlphaMult(1.0F);
               MagicLensFlare.createSharpFlare(Global.getCombatEngine(), var6, var6.getLocation(), 5.0F, 100.0F, 0.0F, BASIC_FLASH_COLOR, Color.white);
               Global.getCombatEngine().addSmoothParticle(var6.getLocation(), new Vector2f(), 100.0F, 0.7F, 0.1F, BASIC_FLASH_COLOR);
               Global.getCombatEngine().addSmoothParticle(var6.getLocation(), new Vector2f(), 150.0F, 0.7F, 1.0F, BASIC_GLOW_COLOR);
               Global.getCombatEngine().addHitParticle(var6.getLocation(), new Vector2f(), 200.0F, 1.0F, 0.05F, Color.white);
            }
         }

      }
   }

   public static List getFighters(ShipAPI var0) {
      ArrayList var1 = new ArrayList();
      Iterator var2 = Global.getCombatEngine().getShips().iterator();

      while(var2.hasNext()) {
         ShipAPI var3 = (ShipAPI)var2.next();
         if(var3.getOwner() == var0.getOwner() && var3.getVariant().hasHullMod("strikeCraft") && (var3.getHullLevel() < 0.49F || var3.getCurrentCR() < 0.4F) && var3.isAlive() && MathUtils.getDistance(var3, var0) > 1000.0F && !var3.controlsLocked() && !var3.isRetreating()) {
            var1.add(var3);
            break;
         }
      }

      return var1;
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      ShipAPI var3 = null;
      if(var1.getEntity() instanceof ShipAPI) {
         var3 = (ShipAPI)var1.getEntity();
         String var4 = var3.getId() + "_recall_device_target";
         Global.getCombatEngine().getCustomData().remove(var4);
      }
   }

   public StatusData getStatusData(int var1, State var2, float var3) {
      return null;
   }

}
