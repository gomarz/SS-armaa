package data.scripts.shipsystems;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.StatusData;
import java.awt.Color;

public class EnergySurgeStats extends BaseShipSystemScript {

   public static final float DAMAGE_BONUS_PERCENT = 0.0F;
   public static float SPEED_BONUS = 50.0F;
   public static float TURN_BONUS = 100.0F;
   public float bonusPercent = 0.0F;
   private Color color = new Color(255, 0, 115, 255);


   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      ShipAPI var5 = (ShipAPI)var1.getEntity();
      this.bonusPercent = (0.0F + var5.getFluxLevel() * 25.0F) * var4;
      if(var3 == State.OUT) {
         var1.getMaxSpeed().unmodify(var2);
         var1.getMaxTurnRate().unmodify(var2);
      } else {
         var1.getMaxSpeed().modifyFlat(var2, SPEED_BONUS);
         var1.getAcceleration().modifyPercent(var2, SPEED_BONUS * 3.0F * var4);
         var1.getDeceleration().modifyPercent(var2, SPEED_BONUS * 3.0F * var4);
         var1.getTurnAcceleration().modifyFlat(var2, TURN_BONUS * var4);
         var1.getTurnAcceleration().modifyPercent(var2, TURN_BONUS * 5.0F * var4);
         var1.getMaxTurnRate().modifyFlat(var2, 15.0F);
         var1.getMaxTurnRate().modifyPercent(var2, 100.0F);
         var1.getEnergyRoFMult().modifyMult(var2, 0.5F);
         var1.getMaxRecoilMult().modifyMult(var2, 2.0F);
         var1.getRecoilPerShotMult().modifyMult(var2, 2.0F);
         var1.getEnergyWeaponDamageMult().modifyPercent(var2, this.bonusPercent);
      }

      if(var1.getEntity() instanceof ShipAPI) {
         var5.getEngineController().fadeToOtherColor(this, this.color, new Color(0, 0, 0, 0), var4, 0.67F);
         var5.getEngineController().extendFlame(this, 1.35F * var4, 1.35F * var4, 0.0F * var4);
      }

   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      var1.getMaxSpeed().unmodify(var2);
      var1.getMaxTurnRate().unmodify(var2);
      var1.getTurnAcceleration().unmodify(var2);
      var1.getAcceleration().unmodify(var2);
      var1.getDeceleration().unmodify(var2);
      var1.getMaxRecoilMult().unmodify(var2);
      var1.getRecoilPerShotMult().unmodify(var2);
      var1.getEnergyRoFMult().unmodify(var2);
      var1.getEnergyWeaponDamageMult().unmodify(var2);
   }

   public StatusData getStatusData(int var1, State var2, float var3) {
      return var1 == 0?new StatusData("Improved maneuverability, +" + (int)this.bonusPercent + "% DMG", false):null;
   }

}
