package data.scripts.shipsystems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipSystemAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript.State;

public class PhaseDamperStats extends BaseShipSystemScript {

   public static final float MAX_TIME_MULT = 1.85F;
   public static final float MIN_TIME_MULT = 0.1F;
   public static final float DEF_MULT = 0.85F;
   public static final float DEF_BEAM_MULT = 0.45F;
   public static final float DAM_MULT = 0.1F;
   protected Object STATUSKEY1 = new Object();
   protected Object STATUSKEY2 = new Object();


   public static float getMaxTimeMult(MutableShipStatsAPI var0) {
      return 1.0F + 0.85F * var0.getDynamic().getValue("phase_time_mult");
   }

   public void apply(MutableShipStatsAPI var1, String var2, State var3, float var4) {
      ShipAPI var5 = null;
      boolean var6 = false;
      if(var1.getEntity() instanceof ShipAPI) {
         var5 = (ShipAPI)var1.getEntity();
         var6 = var5 == Global.getCombatEngine().getPlayerShip();
         var2 = var2 + "_" + var5.getId();
         float var8 = 0.0F;
         float var9 = 10.0F;
         var4 *= var4;
         float var10 = 1.0F + (getMaxTimeMult(var1) - 1.0F) * var4;
         var1.getTimeMult().modifyMult(var2, var10);
         float var11 = var1.getDynamic().getMod("phase_cloak_speed").computeEffective(0.0F);
         var1.getMaxSpeed().modifyPercent(var2, var11 * var4);
         var1.getBallisticWeaponDamageMult().modifyMult(var2, 1.0F - 0.14999998F * var4);
         var1.getMissileWeaponDamageMult().modifyMult(var2, 1.0F - 0.14999998F * var4);
         var1.getEnergyWeaponDamageMult().modifyMult(var2, 1.0F - 0.14999998F * var4);
         var1.getHullDamageTakenMult().modifyMult(var2, 1.0F - 0.14999998F * var4);
         var1.getArmorDamageTakenMult().modifyMult(var2, 1.0F - 0.14999998F * var4);
         var1.getEmpDamageTakenMult().modifyMult(var2, 1.0F - 0.14999998F * var4);
         var1.getBeamDamageTakenMult().modifyMult(var2, 1.0F - 0.55F * var4);
         if(var6) {
            Global.getCombatEngine().getTimeMult().modifyMult(var2, 1.0F / var10);
         } else {
            Global.getCombatEngine().getTimeMult().unmodify(var2);
         }

         if(var6) {
            ShipSystemAPI var12 = var5.getPhaseCloak();
            if(var12 != null) {
               float var13 = 0.14999998F * var4 * 100.0F;
               float var14 = (1.0F - var10) * var4 * 100.0F * -1.0F;
               float var15 = (1.0F - var1.getBeamDamageTakenMult().getModifiedValue()) * var4 * 100.0F;
               Global.getCombatEngine().maintainStatusForPlayerShip(this.STATUSKEY1, var12.getSpecAPI().getIconSpriteName(), var12.getDisplayName(), Math.round(var13) + "% DMG RES / " + Math.round(var14) + "% TIME-FLOW ALTERATION", false);
               Global.getCombatEngine().maintainStatusForPlayerShip(this.STATUSKEY2, var12.getSpecAPI().getIconSpriteName(), var12.getDisplayName(), Math.round(var15) + "% BEAM DMG RES / -" + Math.round(var13) + "% LESS DMG DEALT", false);
            }
         }

      }
   }

   public void unapply(MutableShipStatsAPI var1, String var2) {
      ShipAPI var3 = null;
      boolean var4 = false;
      if(var1.getEntity() instanceof ShipAPI) {
         var3 = (ShipAPI)var1.getEntity();
         var4 = var3 == Global.getCombatEngine().getPlayerShip();
         var2 = var2 + "_" + var3.getId();
         Global.getCombatEngine().getTimeMult().unmodify(var2);
         var1.getTimeMult().unmodify(var2);
         var1.getHullDamageTakenMult().unmodify(var2);
         var1.getArmorDamageTakenMult().unmodify(var2);
         var1.getEmpDamageTakenMult().unmodify(var2);
         var1.getBeamDamageTakenMult().unmodify(var2);
         var1.getMaxSpeed().unmodifyPercent(var2);
         var1.getBallisticWeaponDamageMult().unmodify(var2);
         var1.getEnergyWeaponDamageMult().unmodify(var2);
         var1.getMissileWeaponDamageMult().unmodify(var2);
      }
   }
}
