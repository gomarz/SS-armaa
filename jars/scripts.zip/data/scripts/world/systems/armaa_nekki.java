package data.scripts.world.systems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CustomCampaignEntityAPI;
import com.fs.starfarer.api.campaign.FleetAssignment;
import com.fs.starfarer.api.campaign.JumpPointAPI;
import com.fs.starfarer.api.campaign.LocationAPI;
import com.fs.starfarer.api.campaign.OrbitAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.fleet.FleetMemberType;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin.DerelictShipData;
import com.fs.starfarer.api.impl.campaign.DerelictShipEntityPlugin.DerelictType;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.impl.campaign.procgen.DefenderDataOverride;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.BaseThemeGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner.ShipRecoverySpecialCreator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner.SpecialCreationContext;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial.PerShipData;
import com.fs.starfarer.api.impl.campaign.rulecmd.salvage.special.ShipRecoverySpecial.ShipCondition;
import com.fs.starfarer.api.impl.campaign.terrain.AsteroidFieldTerrainPlugin.AsteroidFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.WeightedRandomPicker;
import data.scripts.world.ARMAAWorldGen;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;
import org.jetbrains.annotations.Nullable;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.campaign.CampaignUtils;

public class armaa_nekki {

   public static String MECH_ID = "valkazard";


   public void generate(SectorAPI var1) {
      StarSystemAPI var2 = var1.createStarSystem("Nekki");
      LocationAPI var3 = Global.getSector().getHyperspace();
      var2.getLocation().set(-10200.0F, -16000.0F);
      if(var1.getEntityById("hybrasil") != null) {
         switch(MathUtils.getRandomNumberInRange(1, 4)) {
         case 1:
            var2.getLocation().set(var1.getEntityById("hybrasil").getLocation().getX() + 10000.0F, var1.getEntityById("hybrasil").getLocation().getY() + 4500.0F);
            break;
         case 2:
            var2.getLocation().set(var1.getEntityById("hybrasil").getLocation().getX() + 15200.0F, var1.getEntityById("hybrasil").getLocation().getY() + 8500.0F);
            break;
         case 3:
            var2.getLocation().set(var1.getEntityById("hybrasil").getLocation().getX() - 30000.0F, var1.getEntityById("hybrasil").getLocation().getY() + 8500.0F);
            break;
         case 4:
            var2.getLocation().set(var1.getEntityById("hybrasil").getLocation().getX() - 10000.0F, var1.getEntityById("hybrasil").getLocation().getY() + 12500.0F);
         }
      }

      var2.setBackgroundTextureFilename("graphics/backgrounds/background4.jpg");
      PlanetAPI var4 = var2.initStar("nekki", "star_red_giant", 1100.0F, 500.0F);
      var2.setLightColor(new Color(255, 200, 210));
      var2.addAsteroidBelt(var4, 50, 2200.0F, 100.0F, 30.0F, 40.0F, "asteroid_belt", (String)null);
      var2.addRingBand(var4, "misc", "rings_asteroids0", 256.0F, 3, Color.white, 256.0F, 2200.0F, 345.0F, (String)null, (String)null);
      PlanetAPI var5 = var2.addPlanet("nekki1", var4, "Jenius", "jungle", 200.0F, 230.0F, 10000.0F, 500.0F);
      PlanetAPI var6 = var2.addPlanet("nekki2", var4, "Meshan", "toxic", 50.0F, 225.0F, 4500.0F, 135.0F);
      var2.addAsteroidBelt(var6, 50, 400.0F, 50.0F, 39.0F, 49.0F, "asteroid_belt", (String)null);
      var2.addAsteroidBelt(var6, 100, 600.0F, 70.0F, 59.0F, 69.0F, "asteroid_belt", (String)null);
      var6.setCustomDescriptionId("armaa_meshan");
      var6.getSpec().setPlanetColor(new Color(126, 230, 155, 255));
      MarketAPI var7 = var6.getMarket();
      var7.addCondition("ruins_extensive");
      var7.addCondition("toxic_atmosphere");
      var7.addCondition("extreme_weather");
      var7.addCondition("irradiated");
      var7.addCondition("inimical_biosphere");
      var7.addSubmarket("storage");
      Misc.setAllPlanetsSurveyed(var2, true);
      var7.setHidden(Boolean.valueOf(true));
      CustomCampaignEntityAPI var8 = var2.addCustomEntity((String)null, (String)null, "stable_location", "neutral");
      var8.setCircularOrbitPointingDown(var4, 110.0F, 4500.0F, 135.0F);
      PlanetAPI var9 = var2.addPlanet("nekki3", var4, "Aznable", "barren-bombarded", 80.0F, 130.0F, 6800.0F, 225.0F);
      var9.getSpec().setPlanetColor(new Color(230, 240, 255, 255));
      var9.applySpecChanges();
      PlanetAPI var10 = var2.addPlanet("nekki3a", var9, "Union", "barren-bombarded", 80.0F, 60.0F, 400.0F, 25.0F);
      var10.getSpec().setTexture(Global.getSettings().getSpriteName("planets", "barren02"));
      var10.getSpec().setPlanetColor(new Color(220, 230, 255, 255));
      var10.applySpecChanges();
      JumpPointAPI var11 = Global.getFactory().createJumpPoint("nekki_jump", "Nekki\'s Inner Jump-point");
      var11.setCircularOrbit(var2.getEntityById("nekki"), 140.0F, 6800.0F, 225.0F);
      var11.setRelatedPlanet(var9);
      var11.setStandardWormholeToHyperspaceVisual();
      var2.addEntity(var11);
      SectorEntityToken var12 = var2.addTerrain("asteroid_field", new AsteroidFieldParams(400.0F, 600.0F, 16, 24, 4.0F, 16.0F, "Penelope L4 Asteroids"));
      SectorEntityToken var13 = var2.addTerrain("asteroid_field", new AsteroidFieldParams(400.0F, 600.0F, 16, 24, 4.0F, 16.0F, "Penelope L5 Asteroids"));
      var12.setCircularOrbit(var5, 290.0F, 9500.0F, 450.0F);
      var13.setCircularOrbit(var5, 170.0F, 9500.0F, 450.0F);
      CustomCampaignEntityAPI var14 = var2.addCustomEntity((String)null, (String)null, "stable_location", "neutral");
      var14.setCircularOrbitPointingDown(var4, 170.0F, 9500.0F, 450.0F);
      CustomCampaignEntityAPI var15 = var2.addCustomEntity((String)null, (String)null, "stable_location", "neutral");
      var15.setCircularOrbitPointingDown(var4, 50.0F, 9500.0F, 450.0F);
      PlanetAPI var16 = var2.addPlanet("penelope5", var4, "Raven", "gas_giant", 250.0F, 280.0F, 12050.0F, 650.0F);
      var16.getSpec().setPlanetColor(new Color(170, 190, 255, 255));
      var16.getSpec().setGlowTexture(Global.getSettings().getSpriteName("hab_glows", "banded"));
      var16.getSpec().setGlowColor(new Color(150, 225, 255, 32));
      var16.applySpecChanges();
      CustomCampaignEntityAPI var17 = var2.addCustomEntity("exsedol_station", "Fort Exsedol", "station_sporeship_derelict", "neutral");
      var17.setCircularOrbitPointingDown(var2.getEntityById("nekki2"), 90.0F, 420.0F, 25.0F);
      var17.setCustomDescriptionId("armaa_station_exsedol");
      var17.setInteractionImage("illustrations", "abandoned_station3");
      ARMAAWorldGen.addMarketplace("armaarmatura_pirates", var17, (ArrayList)null, var17.getName(), 4, new ArrayList(Arrays.asList(new String[]{"population_4", "armaa_mechbase"})), new ArrayList(Arrays.asList(new String[]{"open_market", "generic_military", "black_market", "storage"})), new ArrayList(Arrays.asList(new String[]{"population", "spaceport", "battlestation_mid", "militarybase", "heavybatteries"})), 0.3F, false, true);
      var17.setInteractionImage("illustrations", "armaa_exsedol_illus");
      var17.setCustomDescriptionId("armaa_station_exsedol");
      CustomCampaignEntityAPI var19 = var2.addCustomEntity("armaa_research_station", "Abandoned Research Station", "station_side07", "neutral");
      var19.setCircularOrbitPointingDown(var2.getEntityById("penelope5"), 90.0F, 420.0F, 25.0F);
      var19.setCustomDescriptionId("armaa_station_research");
      var19.setInteractionImage("illustrations", "abandoned_station");
      var19.addTag("armaa_tachie_ambush");
      Misc.setAbandonedStationMarket("armaa_research_station", var19);
      var19.getMarket().getSubmarket("storage").getCargo().addMothballedShip(FleetMemberType.SHIP, "armaa_aleste_swordsman", (String)null);
      var2.addRingBand(var6, "misc", "rings_special0", 256.0F, 1, new Color(200, 200, 200, 255), 256.0F, 600.0F, 30.0F, "ring", (String)null);
      SectorEntityToken var20 = addDerelict(var2, "armaa_valkazard_standard", var19.getOrbit(), ShipCondition.GOOD, true, (DefenderDataOverride)null);
      var20.getMemoryWithoutUpdate().set("$valkazard", Boolean.valueOf(true));
      DebrisFieldParams var21 = new DebrisFieldParams(300.0F, 2.0F, 1.0E7F, 0.0F);
      var21.source = DebrisFieldSource.MIXED;
      var21.baseSalvageXP = 500L;
      SectorEntityToken var22 = Misc.addDebrisField(var2, var21, StarSystemGenerator.random);
      SalvageSpecialAssigner.assignSpecialForDebrisField(var22);
      var22.setSensorProfile((Float)null);
      var22.setDiscoverable((Boolean)null);
      var22.setDiscoverable(Boolean.valueOf(true));
      var22.setDiscoveryXP(Float.valueOf(200.0F));
      var22.setSensorProfile(Float.valueOf(1.0F));
      var22.getDetectedRangeMod().modifyFlat("gen", 2000.0F);
      var22.setCircularOrbit(var20, 55.0F, 0.0F, 250.0F);
      JumpPointAPI var23 = Global.getFactory().createJumpPoint("nekki_jump", "Nekki\'s Outer Jump-point");
      var23.setCircularOrbit(var2.getEntityById("nekki"), 190.0F, 12050.0F, 650.0F);
      var23.setStandardWormholeToHyperspaceVisual();
      var2.addEntity(var23);
      var2.addAsteroidBelt(var4, 100, 13750.0F, 200.0F, 330.0F, 360.0F, "asteroid_belt", "Planetoid Debris");
      var2.addRingBand(var4, "misc", "rings_asteroids0", 256.0F, 0, Color.white, 256.0F, 13750.0F, 345.0F, (String)null, (String)null);
      var2.autogenerateHyperspaceJumpPoints(true, true);
      FleetParamsV3 var24 = new FleetParamsV3(Global.getSector().getEntityById("armaa_research_station").getLocationInHyperspace(), "tritachyon", (Float)null, "patrolMedium", 100.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 1.0F);
      CampaignFleetAPI var25 = FleetFactoryV3.createFleet(var24);
      SectorEntityToken var26 = Global.getSector().getEntityById("armaa_research_station");
      var26.getContainingLocation().spawnFleet(var26, 25.0F, 25.0F, var25);
      Global.getSector().addPing(var25, "danger");
      var25.setLocation(var26.getLocation().x, var26.getLocation().y);
      var25.setId("armaa_valkHunter");
      var25.getMemoryWithoutUpdate().set("$armaa_valkHunters", Boolean.valueOf(true));
      CampaignUtils.addShipToFleet("hyperion_Attack", FleetMemberType.SHIP, var25);
      CampaignUtils.addShipToFleet("armaa_aleste_swordsman", FleetMemberType.SHIP, var25);
      CampaignUtils.addShipToFleet("afflictor_Strike", FleetMemberType.SHIP, var25);
      CampaignUtils.addShipToFleet("armaa_hazard_standard", FleetMemberType.SHIP, var25);
      CampaignUtils.addShipToFleet("armaa_hazard_standard", FleetMemberType.SHIP, var25);
      CampaignUtils.addShipToFleet("armaa_hazard_standard", FleetMemberType.SHIP, var25);
      CampaignUtils.addShipToFleet("hyperion_Attack", FleetMemberType.SHIP, var25);
      var25.addAssignment(FleetAssignment.ORBIT_AGGRESSIVE, var26, 200.0F);
   }

   private static SectorEntityToken addDerelict(StarSystemAPI var0, String var1, OrbitAPI var2, ShipCondition var3, boolean var4, @Nullable DefenderDataOverride var5) {
      DerelictShipData var6 = new DerelictShipData(new PerShipData(var1, var3), false);
      SectorEntityToken var7 = BaseThemeGenerator.addSalvageEntity(var0, "wreck", "armaarmatura", var6);
      WeightedRandomPicker var8 = new WeightedRandomPicker();
      var8.add("tritachyon");
      var8.add("remnant");
      var8.add("hegemony");
      var7.setDiscoverable(Boolean.valueOf(true));
      var7.setId("valkazard");
      var7.setOrbit(var2);
      var7.setName("Derelict Cataphract");
      if(var4) {
         ShipRecoverySpecialCreator var9 = new ShipRecoverySpecialCreator((Random)null, 0, 0, false, (DerelictType)null, (WeightedRandomPicker)null);
         Misc.setSalvageSpecial(var7, var9.createSpecial(var7, (SpecialCreationContext)null));
      }

      if(var5 == null) {
         Misc.setDefenderOverride(var7, new DefenderDataOverride("remnant", 1.0F, 300.0F, 425.0F));
      }

      return var7;
   }

}
