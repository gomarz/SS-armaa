package data.scripts.world.systems;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CustomCampaignEntityAPI;
import com.fs.starfarer.api.campaign.PlanetAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.procgen.NebulaEditor;
import com.fs.starfarer.api.impl.campaign.procgen.StarSystemGenerator;
import com.fs.starfarer.api.impl.campaign.procgen.themes.SalvageSpecialAssigner;
import com.fs.starfarer.api.impl.campaign.terrain.HyperspaceTerrainPlugin;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldParams;
import com.fs.starfarer.api.impl.campaign.terrain.DebrisFieldTerrainPlugin.DebrisFieldSource;
import com.fs.starfarer.api.util.Misc;
import data.scripts.world.ARMAAWorldGen;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Arrays;

public class armaa_K {

   boolean hasIndEvo = false;


   public void generate(SectorAPI var1) {
      StarSystemAPI var2 = var1.createStarSystem("Gamlin");
      var2.getLocation().set(-16200.0F, -13000.0F);
      var2.setBackgroundTextureFilename("graphics/armaa/backgrounds/armaa_homesystem.jpg");
      if(Global.getSettings().getModManager().isModEnabled("deconomics")) {
         this.hasIndEvo = true;
      }

      PlanetAPI var3 = var2.initStar("Gamlin", "star_yellow", 600.0F, 350.0F);
      var2.setLightColor(new Color(255, 185, 50));
      var2.addAsteroidBelt(var3, 100, 2200.0F, 150.0F, 180.0F, 360.0F, "asteroid_belt", "");
      PlanetAPI var4 = var2.addPlanet("armaa_meshanii", var3, "New Meshan", "arid", 215.0F, 120.0F, 4500.0F, 365.0F);
      MarketAPI var5 = ARMAAWorldGen.addMarketplace("independent", var4, (ArrayList)null, var4.getName(), 5, new ArrayList(Arrays.asList(new String[]{"population_5", "habitable", "armaa_mechbase", "pollution", "hot", "industrial_polity", "farmland_adequate", "vice_demand"})), new ArrayList(Arrays.asList(new String[]{"open_market", "generic_military", "armaa_market", "black_market", "storage"})), new ArrayList(Arrays.asList(new String[]{"population", "megaport", "battlestation_high", "militarybase", "orbitalworks", "waystation", "heavybatteries", "commerce"})), 0.3F, false, true);
      var4.setInteractionImage("illustrations", "armaa_newmeshan_illus");
      var4.setCustomDescriptionId("armaa_homeworld");
      var5.getIndustry("battlestation_high").setAICoreId("alpha_core");
      DebrisFieldParams var6 = new DebrisFieldParams(150.0F, 1.0F, 1.0E7F, 0.0F);
      var6.source = DebrisFieldSource.MIXED;
      var6.baseSalvageXP = 500L;
      SectorEntityToken var7 = Misc.addDebrisField(var2, var6, StarSystemGenerator.random);
      SalvageSpecialAssigner.assignSpecialForDebrisField(var7);
      var7.setSensorProfile((Float)null);
      var7.setDiscoverable((Boolean)null);
      var7.setDiscoverable(Boolean.valueOf(true));
      var7.setDiscoveryXP(Float.valueOf(200.0F));
      var7.setSensorProfile(Float.valueOf(1.0F));
      var7.getDetectedRangeMod().modifyFlat("gen", 2000.0F);
      CustomCampaignEntityAPI var8 = var2.addCustomEntity("armaa_gate", "Gamlin Gate", "inactive_gate", "neutral");
      var8.setCircularOrbitPointingDown(var3, 185.0F, 8500.0F, 1000.0F);
      var2.autogenerateHyperspaceJumpPoints(true, true);
      var2.addAsteroidBelt(var2.getEntityById("armaa_meshanii"), 50, 2000.0F, 100.0F, 100.0F, 254.0F);
      CustomCampaignEntityAPI var9 = var2.addCustomEntity("armaa_relay", "Comm Relay", "comm_relay", "neutral");
      var9.setCircularOrbitPointingDown(var2.getEntityById("armaa_meshanii"), 185.0F, 2250.0F, 200.0F);
      var7.setCircularOrbit(var3, 55.0F, 1600.0F, 250.0F);
      this.cleanup(var2);
   }

   private void cleanup(StarSystemAPI var1) {
      HyperspaceTerrainPlugin var2 = (HyperspaceTerrainPlugin)Misc.getHyperspaceTerrain().getPlugin();
      NebulaEditor var3 = new NebulaEditor(var2);
      float var4 = var2.getTileSize() * 2.0F;
      float var5 = var1.getMaxRadiusInHyperspace();
      var3.clearArc(var1.getLocation().x, var1.getLocation().y, 0.0F, var5 + var4 * 0.5F, 0.0F, 360.0F);
      var3.clearArc(var1.getLocation().x, var1.getLocation().y, 0.0F, var5 + var4, 0.0F, 360.0F, 0.25F);
   }
}
