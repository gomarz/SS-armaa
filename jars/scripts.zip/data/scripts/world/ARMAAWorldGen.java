package data.scripts.world;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SectorGeneratorPlugin;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import data.scripts.world.systems.armaa_K;
import data.scripts.world.systems.armaa_nekki;
import java.util.ArrayList;
import java.util.Iterator;

public class ARMAAWorldGen implements SectorGeneratorPlugin {

   public static MarketAPI addMarketplace(String var0, SectorEntityToken var1, ArrayList var2, String var3, int var4, ArrayList var5, ArrayList var6, ArrayList var7, float var8, boolean var9, boolean var10) {
      EconomyAPI var11 = Global.getSector().getEconomy();
      String var12 = var1.getId();
      String var13 = var12 + "_market";
      MarketAPI var14 = Global.getFactory().createMarket(var13, var3, var4);
      var14.setFactionId(var0);
      var14.setPrimaryEntity(var1);
      var14.getTariff().modifyFlat("generator", var8);
      Iterator var15;
      String var16;
      if(null != var6) {
         var15 = var6.iterator();

         while(var15.hasNext()) {
            var16 = (String)var15.next();
            var14.addSubmarket(var16);
         }
      }

      var15 = var5.iterator();

      while(var15.hasNext()) {
         var16 = (String)var15.next();
         var14.addCondition(var16);
      }

      var15 = var7.iterator();

      while(var15.hasNext()) {
         var16 = (String)var15.next();
         var14.addIndustry(var16);
      }

      var14.setFreePort(var9);
      SectorEntityToken var17;
      if(null != var2) {
         var15 = var2.iterator();

         while(var15.hasNext()) {
            var17 = (SectorEntityToken)var15.next();
            var14.getConnectedEntities().add(var17);
         }
      }

      var11.addMarket(var14, var10);
      var1.setMarket(var14);
      var1.setFaction(var0);
      if(null != var2) {
         var15 = var2.iterator();

         while(var15.hasNext()) {
            var17 = (SectorEntityToken)var15.next();
            var17.setMarket(var14);
            var17.setFaction(var0);
         }
      }

      return var14;
   }

   public void generate(SectorAPI var1) {
      FactionAPI var2 = var1.getFaction("armaarmatura");
      (new armaa_K()).generate(var1);
      (new armaa_nekki()).generate(var1);
      var2.setRelationship("hegemony", 0.1F);
      var2.setRelationship("luddic_church", -0.1F);
      var2.setRelationship("luddic_path", -0.51F);
      var2.setRelationship("persean", 0.25F);
      var2.setRelationship("independent", 0.1F);
      var2.setRelationship("pirates", -0.5F);
      var2.setRelationship("tritachyon", -0.3F);
      var2.setRelationship("remnant", -1.0F);
      var2 = var1.getFaction("armaarmatura_pirates");
      Iterator var3 = var1.getAllFactions().iterator();

      while(var3.hasNext()) {
         FactionAPI var4 = (FactionAPI)var3.next();
         var2.setRelationship(var4.getId(), -0.35F);
      }

      var2.setRelationship("luddic_church", 0.0F);
      var2.setRelationship("luddic_path", 0.0F);
      var2.setRelationship("persean", 0.0F);
      var2.setRelationship("independent", -0.1F);
      var2.setRelationship("pirates", 0.1F);
      var2.setRelationship("tritachyon", -1.0F);
      var2.setRelationship("remnant", -1.0F);
      var2.setRelationship("sindrian_diktat", -1.0F);
      var2.setRelationship("hegemony", 0.0F);
      var2.setRelationship("tahlan_scalartech", 0.05F);
      var2.setRelationship("tahlan_legioinfernalis", 0.1F);
   }
}
