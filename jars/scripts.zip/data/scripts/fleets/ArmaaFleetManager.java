package data.scripts.fleets;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.RepLevel;
import com.fs.starfarer.api.campaign.StarSystemAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.fleets.DisposableFleetManager;
import com.fs.starfarer.api.impl.campaign.fleets.FleetFactoryV3;
import com.fs.starfarer.api.impl.campaign.fleets.FleetParamsV3;
import com.fs.starfarer.api.util.Misc;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class ArmaaFleetManager extends DisposableFleetManager {

   protected Object readResolve() {
      super.readResolve();
      return this;
   }

   protected String getSpawnId() {
      return "armaa_mercs";
   }

   protected int getDesiredNumFleetsForSpawnLocation() {
      MarketAPI var1 = this.getLargestMarket("armaarmatura_pirates");
      MarketAPI var2 = this.getLargestMarket("pirates");
      float var3 = 1.0F;
      if(var2 != null) {
         ++var3;
      }

      if(var1 != null) {
         var3 += (float)(var1.getSize() / 2);
      }

      return Math.round(var3);
   }

   protected MarketAPI getLargestMarket(String var1) {
      if(this.currSpawnLoc == null) {
         return null;
      } else {
         MarketAPI var2 = null;
         int var3 = 0;
         Iterator var4 = Global.getSector().getEconomy().getMarkets(this.currSpawnLoc).iterator();

         while(var4.hasNext()) {
            MarketAPI var5 = (MarketAPI)var4.next();
            if(!var5.isHidden() && !var5.getFaction().getRelationshipLevel("armaarmatura_pirates").isAtBest(RepLevel.INHOSPITABLE) && var5.getSize() > var3) {
               var3 = var5.getSize();
               var2 = var5;
            }
         }

         return var2;
      }
   }

   protected CampaignFleetAPI spawnFleetImpl() {
      StarSystemAPI var1 = this.currSpawnLoc;
      if(var1 == null) {
         return null;
      } else {
         CampaignFleetAPI var2 = Global.getSector().getPlayerFleet();
         if(var2 == null) {
            return null;
         } else {
            int var3 = Misc.getMarketsInLocation(var1).size();
            if(Misc.getMarketsInLocation(var1, "player").size() == var3 && var3 > 0) {
               return null;
            } else {
               String var4 = "mercPatrol";
               float var5 = 1.0F;

               for(int var6 = 0; var6 < 3; ++var6) {
                  if((float)Math.random() > 0.5F) {
                     ++var5;
                  }
               }

               float var13 = (float)this.getDesiredNumFleetsForSpawnLocation();
               if(var13 > 2.0F) {
                  var5 += (var13 - 2.0F) * (0.5F + (float)Math.random() * 0.5F);
               }

               var5 = (float)((double)var5 * Math.random());
               FleetParamsV3 var7 = new FleetParamsV3(Global.getSector().getEconomy().getMarket("armaa_meshanii_market"), var1.getLocation(), "armaarmatura_pirates", (Float)null, var4, var5, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F);
               var7.ignoreMarketFleetSizeMult = Boolean.valueOf(false);
               CampaignFleetAPI var8 = FleetFactoryV3.createFleet(var7);
               if(var8 != null && !var8.isEmpty()) {
                  ArrayList var9 = new ArrayList();
                  var9.add("$core_fleetNoMilitaryResponse");
                  var9.add("$core_fleetChasingGhost");
                  var9.add("$core_fleetChasingGhostRandom");
                  var9.add("$core_fleetMilitaryResponse");
                  Random var10 = new Random();
                  int var11 = var10.nextInt(var9.size());
                  var8.getMemoryWithoutUpdate().set((String)var9.get(var11), Boolean.valueOf(true));
                  float var12 = (float)this.getDesiredNumFleetsForSpawnLocation();
                  if(var12 == 1.0F) {
                     this.setLocationAndOrders(var8, 1.0F, 1.0F);
                  } else {
                     this.setLocationAndOrders(var8, 0.5F, 1.0F);
                  }

                  var8.getMemoryWithoutUpdate().set("$armaa_fleetObjective", var8.getCurrentAssignment().getActionText());
                  return var8;
               } else {
                  return null;
               }
            }
         }
      }
   }
}
