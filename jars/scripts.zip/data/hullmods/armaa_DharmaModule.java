package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.magiclib.util.MagicIncompatibleHullmods;

public class armaa_DharmaModule extends BaseHullMod {

   private static final Set BLOCKED_FRONT = new HashSet();
   private static final Set BLOCKED_OTHER = new HashSet();
   private static final Set BLOCKED_OTHER_PLAYER_ONLY = new HashSet();


   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      String var3 = var1.getHullSpec().getBaseHullId();
      byte var4 = -1;
      switch(var3.hashCode()) {
      case -2096371310:
         if(var3.equals("armaa_altagrave_leftleg")) {
            var4 = 0;
         }
         break;
      case 576765671:
         if(var3.equals("armaa_altagrave_rightleg")) {
            var4 = 1;
         }
      }

      Iterator var5;
      String var6;
      switch(var4) {
      case 0:
      case 1:
         var5 = BLOCKED_FRONT.iterator();

         while(var5.hasNext()) {
            var6 = (String)var5.next();
            if(var1.getVariant().getHullMods().contains(var6)) {
               MagicIncompatibleHullmods.removeHullmodWithWarning(var1.getVariant(), var6, "armaa_dharmamodule");
            }
         }
      default:
         var3 = var1.getHullSpec().getBaseHullId();
         var4 = -1;
         switch(var3.hashCode()) {
         case -2096371310:
            if(var3.equals("armaa_altagrave_leftleg")) {
               var4 = 0;
            }
            break;
         case 576765671:
            if(var3.equals("armaa_altagrave_rightleg")) {
               var4 = 1;
            }
         }

         switch(var4) {
         case 0:
         case 1:
            var5 = BLOCKED_OTHER.iterator();

            while(var5.hasNext()) {
               var6 = (String)var5.next();
               if(var1.getVariant().getHullMods().contains(var6)) {
                  MagicIncompatibleHullmods.removeHullmodWithWarning(var1.getVariant(), var6, "armaa_dharmamodule");
               }
            }
         default:
            var3 = var1.getHullSpec().getBaseHullId();
            var4 = -1;
            switch(var3.hashCode()) {
            case -2096371310:
               if(var3.equals("armaa_altagrave_leftleg")) {
                  var4 = 0;
               }
               break;
            case 576765671:
               if(var3.equals("armaa_altagrave_rightleg")) {
                  var4 = 1;
               }
            }

            switch(var4) {
            case 0:
            case 1:
               var5 = BLOCKED_OTHER_PLAYER_ONLY.iterator();

               while(var5.hasNext()) {
                  var6 = (String)var5.next();
                  if(var1.getVariant().getHullMods().contains(var6)) {
                     MagicIncompatibleHullmods.removeHullmodWithWarning(var1.getVariant(), var6, "armaa_dharmamodule");
                  }
               }
            default:
            }
         }
      }
   }

   static {
      BLOCKED_FRONT.add("frontemitter");
      BLOCKED_FRONT.add("frontshield");
      BLOCKED_FRONT.add("adaptiveshields");
      BLOCKED_OTHER.add("auxiliarythrusters");
      BLOCKED_OTHER.add("unstable_injector");
      BLOCKED_OTHER.add("ecm");
      BLOCKED_OTHER.add("nav_relay");
      BLOCKED_OTHER.add("operations_center");
      BLOCKED_OTHER.add("recovery_shuttles");
      BLOCKED_OTHER.add("additional_berthing");
      BLOCKED_OTHER.add("augmentedengines");
      BLOCKED_OTHER.add("auxiliary_fuel_tanks");
      BLOCKED_OTHER.add("efficiency_overhaul");
      BLOCKED_OTHER.add("expanded_cargo_holds");
      BLOCKED_OTHER.add("hiressensors");
      BLOCKED_OTHER.add("militarized_subsystems");
      BLOCKED_OTHER.add("surveying_equipment");
      BLOCKED_OTHER_PLAYER_ONLY.add("converted_hangar");
      BLOCKED_OTHER_PLAYER_ONLY.add("expanded_deck_crew");
      BLOCKED_OTHER_PLAYER_ONLY.add("TSC_converted_hangar");
   }
}
