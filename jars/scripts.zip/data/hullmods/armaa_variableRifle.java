package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.loading.WeaponSpecAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import data.scripts.MechaModPlugin;
import java.awt.Color;
import java.util.Iterator;

public class armaa_variableRifle extends BaseHullMod {

   private final Color E = Global.getSettings().getColor("textFriendlyColor");
   private final Color dark = Global.getSettings().getColor("textGrayColor");


   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      ShipVariantAPI var4 = var2.getVariant();
      boolean var5 = MechaModPlugin.varrifle_weapons.contains("ALL");
      if(!var5) {
         if(var4 != null && var4.getWeaponId("TRUE_GUN") != null && !MechaModPlugin.varrifle_weapons.contains(var4.getWeaponId("TRUE_GUN"))) {
            if(Global.getSector() != null) {
               Global.getSector().getPlayerFleet().getCargo().addWeapons(var4.getWeaponId("TRUE_GUN"), 1);
            }

            var4.clearSlot("TRUE_GUN");
            Global.getSoundPlayer().playUISound("cr_playership_warning", 0.8F, 1.0F);
         }

      }
   }

   public void addPostDescriptionSection(TooltipMakerAPI var1, HullSize var2, ShipAPI var3, float var4, boolean var5) {
      float var6 = 10.0F;
      float var7 = 2.0F;
      var1.addSectionHeading("Details", Alignment.MID, 10.0F);
      var1.addPara("%s This unit carries a rifle that can be configured to mimic the characteristics of various starship-grade weapons developed throughout the sector, however not all weapons are compatible.", var6, Misc.getHighlightColor(), new String[]{"-"});
      var1.addPara("%s These limitations can be adjusted via modSettings.", var7, Misc.getHighlightColor(), new String[]{"-"});
      var1.addSectionHeading("Compatible with:", Alignment.MID, 10.0F);
      String var8 = "";
      if(!MechaModPlugin.varrifle_weapons.contains("ALL")) {
         int var9 = MechaModPlugin.varrifle_weapons.size();
         int var10 = 0;
         Color[] var11 = new Color[]{Misc.getHighlightColor(), this.E};
         Iterator var12 = Global.getSettings().getAllWeaponSpecs().iterator();

         while(var12.hasNext()) {
            WeaponSpecAPI var13 = (WeaponSpecAPI)var12.next();
            Iterator var14 = MechaModPlugin.varrifle_weapons.iterator();

            while(var14.hasNext()) {
               String var15 = (String)var14.next();
               if(var13.getWeaponId().equals(var15)) {
                  ++var10;
                  var8 = var8 + var13.getWeaponName();
                  if(var10 != var9 - 1) {
                     var8 = var8 + ", ";
                  }
               }
            }
         }

         var8 = var8.substring(0, var8.length() - 2);
         var1.addPara("%s Compatible with %s.", var6, var11, new String[]{"-", "" + var8});
      }
   }
}
