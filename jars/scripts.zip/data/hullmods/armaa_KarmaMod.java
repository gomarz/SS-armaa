package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineLayers;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.FastTrig;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicRender;
import org.magiclib.util.ui.StatusBarData;

public class armaa_KarmaMod extends BaseHullMod {

   protected float karma = 0.0F;
   private static final float BONUS_AMT = 30.0F;
   protected static int karmaThreshold = 2000;
   private static final Color AFTERIMAGE_COLOR = new Color(149, 206, 240, 102);
   private static final float AFTERIMAGE_THRESHOLD = 0.4F;
   private static final List SAFE_MODS = new ArrayList();
   private static final List BAD_MODS = new ArrayList();


   public void advanceInCombat(ShipAPI var1, float var2) {
      float var5;
      if(Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var1.getId()) instanceof Float) {
         String var3 = "armaa_karma" + var1.getId();
         MutableShipStatsAPI var4 = var1.getMutableStats();
         var5 = ((Float)Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var1.getId())).floatValue();
         float var6 = var5 * 30.0F;
         if(var5 > 0.0F) {
            boolean var7 = var1 == Global.getCombatEngine().getPlayerShip();
            var5 -= 0.001F;
            Global.getCombatEngine().getCustomData().put("armaa_karmaTotal" + var1.getId(), Float.valueOf(var5));
            if(var7) {
               Global.getCombatEngine().maintainStatusForPlayerShip(var1.getId(), "graphics/icons/hullsys/entropy_amplifier.png", "Enlightened", "+" + (int)var6 + "% WEP ROF / " + "-" + (int)var6 * 2 + "% WEP FLUX COST", false);
            }

            var4.getBallisticRoFMult().modifyPercent(var3, var6);
            var4.getEnergyRoFMult().modifyPercent(var3, var6);
            var4.getBallisticWeaponFluxCostMod().modifyMult(var3, 1.0F - var6 * 2.0F * 0.01F);
            var4.getEnergyWeaponFluxCostMod().modifyMult(var3, 1.0F - var6 * 2.0F * 0.01F);
            var4.getMaxSpeed().modifyPercent(var3, var6);
            var4.getMaxTurnRate().modifyPercent(var3, var6);
            var1.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerNullerID", -1.0F);
            var1.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerID", var1.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() + var2);
            if(var1.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() > 0.4F) {
               SpriteAPI var8 = var1.getSpriteAPI();
               float var9 = var8.getWidth() / 2.0F - var8.getCenterX();
               float var10 = var8.getHeight() / 2.0F - var8.getCenterY();
               float var11 = (float)FastTrig.cos(Math.toRadians((double)(var1.getFacing() - 90.0F))) * var9 - (float)FastTrig.sin(Math.toRadians((double)(var1.getFacing() - 90.0F))) * var10;
               float var12 = (float)FastTrig.sin(Math.toRadians((double)(var1.getFacing() - 90.0F))) * var9 + (float)FastTrig.cos(Math.toRadians((double)(var1.getFacing() - 90.0F))) * var10;
               if(!var1.isHulk()) {
                  MagicRender.battlespace(Global.getSettings().getSprite(var1.getHullSpec().getSpriteName()), new Vector2f(var1.getLocation().getX() + var11, var1.getLocation().getY() + var12), new Vector2f(0.0F, 0.0F), new Vector2f(var1.getSpriteAPI().getWidth(), var1.getSpriteAPI().getHeight()), new Vector2f(0.0F, 0.0F), var1.getFacing() - 90.0F, 0.0F, AFTERIMAGE_COLOR, true, 0.1F, 0.1F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, CombatEngineLayers.BELOW_SHIPS_LAYER);
               }

               Iterator var13 = var1.getChildModulesCopy().iterator();

               while(var13.hasNext()) {
                  ShipAPI var14 = (ShipAPI)var13.next();
                  if(var14 != null && Global.getCombatEngine().isEntityInPlay(var14)) {
                     float var10000 = (float)FastTrig.cos(Math.toRadians((double)(var14.getFacing() - 90.0F))) * var9 - (float)FastTrig.sin(Math.toRadians((double)(var14.getFacing() - 90.0F))) * var10;
                     var10000 = (float)FastTrig.sin(Math.toRadians((double)(var14.getFacing() - 90.0F))) * var9 + (float)FastTrig.cos(Math.toRadians((double)(var14.getFacing() - 90.0F))) * var10;
                     MagicRender.battlespace(Global.getSettings().getSprite(var1.getHullSpec().getSpriteName()), new Vector2f(var1.getLocation().getX() + var11, var1.getLocation().getY() + var12), new Vector2f(0.0F, 0.0F), new Vector2f(var1.getSpriteAPI().getWidth(), var1.getSpriteAPI().getHeight()), new Vector2f(0.0F, 0.0F), var1.getFacing() - 90.0F, 0.0F, AFTERIMAGE_COLOR, true, 0.1F, 0.1F, 1.0F, 0.0F, 0.0F, 0.0F, 0.0F, 0.0F, CombatEngineLayers.BELOW_SHIPS_LAYER);
                  }
               }

               var1.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").modifyFlat("armaa_NNAfterimageTrackerID", var1.getMutableStats().getDynamic().getStat("armaa_NNAfterimageTracker").getModifiedValue() - 0.4F);
            }
         } else {
            var4.getBallisticRoFMult().unmodify(var3);
            var4.getEnergyRoFMult().unmodify(var3);
            var4.getBallisticWeaponFluxCostMod().unmodify(var3);
            var4.getEnergyWeaponFluxCostMod().unmodify(var3);
            var4.getMaxSpeed().unmodify(var3);
            var4.getMaxTurnRate().unmodify(var3);
         }

         StatusBarData var23 = new StatusBarData(var1, var5, Color.red, Color.green, 0.0F, "", (int)var5);
         var23.drawToScreen(new Vector2f());
      }

      if(Global.getCombatEngine().getCustomData().get("armaa_hasGainedKarma" + var1.getId()) instanceof Boolean && ((Boolean)Global.getCombatEngine().getCustomData().get("armaa_hasGainedKarma" + var1.getId())).booleanValue()) {
         float var17 = ((Float)Global.getCombatEngine().getCustomData().get("armaa_gainedKarmaAount" + var1.getId())).floatValue();
         if(Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var1.getId()) instanceof Float) {
            float var19 = ((Float)Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var1.getId())).floatValue();
            var5 = var19 + var17;
            Global.getCombatEngine().getCustomData().put("armaa_karmaTotal" + var1.getId(), Float.valueOf(var5));
         }

         Global.getCombatEngine().getCustomData().put("armaa_hasGainedKarma" + var1.getId(), Boolean.valueOf(false));
         Global.getCombatEngine().getCustomData().put("armaa_gainedKarmaAount" + var1.getId(), Float.valueOf(0.0F));
      }

      if(!(Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?" + var1.getId()) instanceof Boolean)) {
         Global.getCombatEngine().getCustomData().put("armaa_hullmodsDone?" + var1.getId(), Boolean.valueOf(false));
      }

      if(Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?" + var1.getId()) instanceof Boolean && !((Boolean)Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?" + var1.getId())).booleanValue()) {
         List var18 = var1.getChildModulesCopy();
         if(var18 != null && !var18.isEmpty()) {
            Iterator var20 = var18.iterator();

            while(var20.hasNext()) {
               ShipAPI var21 = (ShipAPI)var20.next();
               var21.ensureClonedStationSlotSpec();
               Collection var22 = var1.getVariant().getHullMods();
               ArrayList var24 = new ArrayList();
               var24.addAll(var22);
               var24.removeAll(BAD_MODS);
               Collection var25 = var21.getVariant().getHullMods();
               ArrayList var26 = new ArrayList();
               var26.addAll(var25);
               var26.removeAll(SAFE_MODS);
               if(!var22.isEmpty()) {
                  int var27;
                  for(var27 = 0; var27 < var24.size(); ++var27) {
                     if(!var21.getVariant().hasHullMod((String)var24.get(var27))) {
                        var21.getVariant().addMod((String)var24.get(var27));
                     }
                  }

                  if(!var26.isEmpty()) {
                     for(var27 = 0; var27 < var26.size(); ++var27) {
                        if(!var1.getVariant().hasHullMod((String)var26.get(var27))) {
                           var21.getVariant().removeMod((String)var26.get(var27));
                        }
                     }
                  }
               }
            }

            Global.getCombatEngine().getCustomData().put("armaa_hullmodsDone?" + var1.getId(), Boolean.valueOf(true));
            Global.getCombatEngine().getCustomData().put("armaa_hullmodsDoneCheck" + var1.getId(), Boolean.valueOf(true));
         }
      }

   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      if(Global.getCombatEngine() != null) {
         Global.getCombatEngine().getCustomData().put("armaa_hullmodsDone?" + var1.getId(), Boolean.valueOf(false));
         Global.getCombatEngine().getCustomData().put("armaa_karmaTotal" + var1.getId(), Float.valueOf(0.0F));
      }

   }

   public static void addKarma(float var0) {}

   public static float getKarma(String var0) {
      float var1 = 0.0F;
      if(Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var0) instanceof Float) {
         var1 = ((Float)Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var0)).floatValue();
      }

      return var1;
   }

   public static float getKarmaThreshold() {
      return (float)karmaThreshold;
   }

   static {
      SAFE_MODS.add("armaa_legmodule");
      SAFE_MODS.add("reduced_explosion");
      SAFE_MODS.add("always_detaches");
      SAFE_MODS.add("novent");
      SAFE_MODS.add("leg_engine");
      SAFE_MODS.add("neural_interface");
      SAFE_MODS.add("neural_integrator");
      BAD_MODS.add("neural_interface");
      BAD_MODS.add("neural_integrator");
   }
}
