package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.lazywizard.lazylib.MathUtils;

public class armaa_vxSkinSwap extends BaseHullMod {

   private final Map SWITCH = new HashMap();
   private final Map SWITCH_WEP;
   private final Map SWITCHWEP;
   private final String decoGunID;
   private String currentSkin;


   public armaa_vxSkinSwap() {
      this.SWITCH.put(Integer.valueOf(0), "armaa_vxSkin_AASV");
      this.SWITCH.put(Integer.valueOf(1), "armaa_vxSkin_rocketStars");
      this.SWITCH.put(Integer.valueOf(2), "armaa_vxSkin_midline");
      this.SWITCH_WEP = new HashMap();
      this.SWITCH_WEP.put(Integer.valueOf(2), "armaa_kouto_variablerifle");
      this.SWITCH_WEP.put(Integer.valueOf(1), "armaa_valkenx_frig_variablerifle");
      this.SWITCH_WEP.put(Integer.valueOf(0), "armaa_valkenx_frig_ml_variablerifle");
      this.SWITCHWEP = new HashMap();
      this.SWITCHWEP.put("armaa_kouto_variablerifle", Integer.valueOf(1));
      this.SWITCHWEP.put("armaa_valkenx_frig_variablerifle", Integer.valueOf(0));
      this.SWITCHWEP.put("armaa_valkenx_frig_ml_variablerifle", Integer.valueOf(2));
      this.decoGunID = "A_GUN";
      this.currentSkin = "armaa_vxSkin_AASV";
   }

   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      if(var2 != null) {
         boolean var4 = true;
         boolean var5 = false;

         for(int var6 = 0; var6 < this.SWITCH.size(); ++var6) {
            if(var2.getVariant().getHullMods().contains(this.SWITCH.get(Integer.valueOf(var6)))) {
               var4 = false;
               break;
            }
         }

         if(var4) {
            boolean var8 = false;
            int var7;
            if(var2.getVariant().getWeaponSpec("A_GUN") != null) {
               var7 = ((Integer)this.SWITCHWEP.get(var2.getVariant().getWeaponSpec("A_GUN").getWeaponId())).intValue();
            } else {
               var7 = MathUtils.getRandomNumberInRange(0, this.SWITCHWEP.size() - 1);
               var8 = true;
            }

            var2.getVariant().clearSlot("A_GUN");
            var2.getVariant().clearSlot("F_LEGS");
            var2.getVariant().addMod((String)this.SWITCH.get(Integer.valueOf(var7)));
            var2.getVariant().addWeapon("F_LEGS", "armaa_ht_legs");
            var2.getVariant().addWeapon("A_GUN", (String)this.SWITCH_WEP.get(Integer.valueOf(var7)));
            if(var8) {
               var2.getVariant().autoGenerateWeaponGroups();
            }
         }

      }
   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      if(var1.getOriginalOwner() < 0 && Global.getSector() != null && Global.getSector().getPlayerFleet() != null && Global.getSector().getPlayerFleet().getCargo() != null && Global.getSector().getPlayerFleet().getCargo().getStacksCopy() != null && !Global.getSector().getPlayerFleet().getCargo().getStacksCopy().isEmpty()) {
         Iterator var3 = Global.getSector().getPlayerFleet().getCargo().getStacksCopy().iterator();

         while(var3.hasNext()) {
            CargoStackAPI var4 = (CargoStackAPI)var3.next();
            if(var4.isWeaponStack() && (this.SWITCH_WEP.containsValue(var4.getWeaponSpecIfWeapon().getWeaponId()) || var4.getWeaponSpecIfWeapon().getWeaponId().equals("armaa_ht_legs") || var4.getWeaponSpecIfWeapon().getWeaponId().equals("armaa_valkazard_legs"))) {
               Global.getSector().getPlayerFleet().getCargo().removeStack(var4);
            }
         }
      }

   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"A":(var1 == 1?"B":(var1 == 2?"C":(var1 == 3?"D":null)));
   }

   public boolean isApplicableToShip(ShipAPI var1) {
      return var1.getHullSpec().getHullId().startsWith("armaa_");
   }
}
