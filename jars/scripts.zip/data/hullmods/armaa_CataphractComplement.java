package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.util.List;

public class armaa_CataphractComplement extends BaseHullMod {

   public final float GROUND_BONUS = 4.0F;
   public boolean runOnce = false;
   public float WING_BONUS = 1.0F;


   public float setBonus(ShipVariantAPI var1) {
      List var2 = var1.getWings();
      float var3 = 0.0F;

      for(int var4 = 0; var4 < var2.size(); ++var4) {
         String var5 = (String)var2.get(var4);
         byte var7 = -1;
         switch(var5.hashCode()) {
         case -1849547113:
            if(var5.equals("armaa_valkencannon_wing")) {
               var7 = 4;
            }
            break;
         case -1462050393:
            if(var5.equals("armaa_einhander_wing")) {
               var7 = 7;
            }
            break;
         case -877409471:
            if(var5.equals("armaa_kouto_wing")) {
               var7 = 0;
            }
            break;
         case 485442728:
            if(var5.equals("armaa_valkenx_wing")) {
               var7 = 1;
            }
            break;
         case 900355484:
            if(var5.equals("armaa_ilorin_wing")) {
               var7 = 5;
            }
            break;
         case 1456160433:
            if(var5.equals("armaa_valkenmp_wing")) {
               var7 = 3;
            }
            break;
         case 1648526493:
            if(var5.equals("armaa_aleste_wing")) {
               var7 = 6;
            }
            break;
         case 1675717366:
            if(var5.equals("armaa_record_wing")) {
               var7 = 2;
            }
         }

         switch(var7) {
         case 0:
         case 1:
            var3 += 2.0F;
            break;
         case 2:
         case 3:
            ++var3;
            break;
         case 4:
            var3 += 3.0F;
            break;
         case 5:
            var3 += 3.0F;
            break;
         case 6:
            var3 += 3.0F;
            break;
         case 7:
            var3 += 3.0F;
            break;
         default:
            ++var3;
         }
      }

      this.WING_BONUS = var3;
      return this.WING_BONUS;
   }

   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      var2.getDynamic().getMod("ground_support").modifyFlat(var3, 4.0F * this.setBonus(var2.getVariant()));
   }

   public void addPostDescriptionSection(TooltipMakerAPI var1, HullSize var2, ShipAPI var3, float var4, boolean var5) {
      float var6 = 10.0F;
      float var7 = 2.0F;
      float var8 = this.setBonus(var3.getVariant()) * 4.0F;
      var1.addPara("%s Ground support increased by %s.", var6, Misc.getHighlightColor(), new String[]{"-", (int)var8 + ""});
   }
}
