package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponSize;
import com.fs.starfarer.api.combat.WeaponAPI.WeaponType;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.magiclib.util.MagicIncompatibleHullmods;

public class armaa_SeraphTargetingSoftware extends BaseHullMod {

   public static final float DAMAGE_BONUS = 50.0F;
   private static final Set BLOCKED_HULLMODS = new HashSet();


   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      var2.getDynamic().getMod("pd_ignores_flares").modifyFlat(var3, 1.0F);
      var2.getDynamic().getMod("pd_best_target_leading").modifyFlat(var3, 1.0F);
      var2.getAutofireAimAccuracy().modifyMult(var3, 1.5F);
      var2.getDamageToMissiles().modifyPercent(var3, 50.0F);
      var2.getDamageToFighters().modifyPercent(var3, 50.0F);
   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      List var3 = var1.getAllWeapons();
      Iterator var4 = var3.iterator();

      while(var4.hasNext()) {
         WeaponAPI var5 = (WeaponAPI)var4.next();
         boolean var6 = var5.getSize() == WeaponSize.SMALL;
         if(var6 && var5.getType() != WeaponType.MISSILE) {
            var5.setPD(true);
         }
      }

      Iterator var7 = BLOCKED_HULLMODS.iterator();

      while(var7.hasNext()) {
         String var8 = (String)var7.next();
         if(var1.getVariant().getHullMods().contains(var8)) {
            MagicIncompatibleHullmods.removeHullmodWithWarning(var1.getVariant(), var8, "armaa_SeraphTargetingSoftware");
         }
      }

   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"" + Math.round(50.0F) + "%":(var1 == 1?"incompatible with Safety Overrides.":(var1 == 2?"additional large scale modifications cannot be made to the hull":null));
   }

   static {
      BLOCKED_HULLMODS.add("converted_hangar");
      BLOCKED_HULLMODS.add("cargo_expansion");
      BLOCKED_HULLMODS.add("additional_crew_quarters");
      BLOCKED_HULLMODS.add("fuel_expansion");
      BLOCKED_HULLMODS.add("additional_berthing");
      BLOCKED_HULLMODS.add("auxiliary_fuel_tanks");
      BLOCKED_HULLMODS.add("expanded_cargo_holds");
      BLOCKED_HULLMODS.add("surveying_equipment");
      BLOCKED_HULLMODS.add("recovery_shuttles");
      BLOCKED_HULLMODS.add("operations_center");
      BLOCKED_HULLMODS.add("pointdefenseai");
      BLOCKED_HULLMODS.add("safetyoverrides");
   }
}
