package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.apache.log4j.Logger;

public class armaa_aicoreutilityscript extends BaseHullMod {

   public static final ArrayList DATA_PREFIXES = new ArrayList();
   public static final ArrayList MODS = new ArrayList();
   private static final Logger Log = Logger.getLogger(armaa_aicoreutilityscript.class);
   public static final String ITEM = "alpha_core";
   public static final HashMap itemMap;


   public void advanceInCampaign(FleetMemberAPI var1, float var2) {
      Map var3 = Global.getSector().getPersistentData();
      Iterator var4 = DATA_PREFIXES.iterator();

      while(var4.hasNext()) {
         String var5 = (String)var4.next();
         Iterator var6 = MODS.iterator();

         while(var6.hasNext()) {
            String var7 = (String)var6.next();
            String var8 = var5.substring(0, var5.indexOf("_"));
            String var9 = var7.substring(var7.indexOf("_") + 1, var7.length());
            boolean var10 = var9.toLowerCase().contains(var8);
            if(var10 && var3.containsKey(var5 + var1.getId()) && !var1.getVariant().hasHullMod(var7)) {
               var3.remove(var5 + var1.getId());
               addPlayerCommodityItem((String)itemMap.get(var5), 1);
               var1.getVariant().removePermaMod("armaa_aicoreutilityscript");
            }
         }
      }

   }

   public static void addPlayerCommodityItem(String var0, int var1) {
      CampaignFleetAPI var2 = Global.getSector().getPlayerFleet();
      if(var2 != null) {
         CargoAPI var3 = var2.getCargo();
         System.out.println("Adding the AI core into the cargo...");
         var3.addCommodity(var0, (float)var1);
      }
   }

   static {
      DATA_PREFIXES.add("alpha_core_skymind_check_");
      DATA_PREFIXES.add("beta_core_skymind_check_");
      DATA_PREFIXES.add("gamma_core_skymind_check_");
      MODS.add("armaa_skyMindAlpha");
      MODS.add("armaa_skyMindBeta");
      MODS.add("armaa_skyMindGamma");
      itemMap = new HashMap();
      Iterator var0 = DATA_PREFIXES.iterator();

      while(var0.hasNext()) {
         String var1 = (String)var0.next();
         if(var1.contains("alpha")) {
            itemMap.put(var1, "alpha_core");
         } else if(var1.contains("beta")) {
            itemMap.put(var1, "beta_core");
         } else {
            itemMap.put(var1, "gamma_core");
         }
      }

   }
}
