package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.lazywizard.lazylib.MathUtils;

public class armaa_weaponSwap extends BaseHullMod {

   public Map LEFT_SELECTOR = new HashMap();
   public Map RIGHT_SELECTOR;
   private final Map SWITCH_TO_LEFT;
   private final Map SWITCH_TO_RIGHT;
   private final Map LEFTSWITCH;
   private final Map RIGHTSWITCH;
   private final String leftslotID;
   private final String rightslotID;


   public armaa_weaponSwap() {
      this.LEFT_SELECTOR.put(Integer.valueOf(0), "armaa_koutoBazooka");
      this.LEFT_SELECTOR.put(Integer.valueOf(1), "armaa_alesteLeftArm");
      this.LEFT_SELECTOR.put(Integer.valueOf(2), "armaa_aleste_rifle_left");
      this.LEFT_SELECTOR.put(Integer.valueOf(3), "armaa_aleste_grenade_left");
      this.RIGHT_SELECTOR = new HashMap();
      this.RIGHT_SELECTOR.put(Integer.valueOf(0), "armaa_aleste_heavyrifle_right");
      this.RIGHT_SELECTOR.put(Integer.valueOf(1), "armaa_aleste_rightArm");
      this.RIGHT_SELECTOR.put(Integer.valueOf(2), "armaa_aleste_flamer_right");
      this.RIGHT_SELECTOR.put(Integer.valueOf(3), "armaa_aleste_blade_RightArm");
      this.RIGHT_SELECTOR.put(Integer.valueOf(4), "armaa_leynos_minigun_right");
      this.SWITCH_TO_LEFT = new HashMap();
      this.SWITCH_TO_LEFT.put("armaa_aleste_grenade_left", Integer.valueOf(2));
      this.SWITCH_TO_LEFT.put("armaa_koutoBazooka", Integer.valueOf(3));
      this.SWITCH_TO_LEFT.put("armaa_aleste_rifle_left", Integer.valueOf(1));
      this.SWITCH_TO_LEFT.put("armaa_alesteLeftArm", Integer.valueOf(0));
      this.SWITCH_TO_RIGHT = new HashMap();
      this.SWITCH_TO_RIGHT.put("armaa_aleste_flamer_right", Integer.valueOf(1));
      this.SWITCH_TO_RIGHT.put("armaa_aleste_heavyrifle_right", Integer.valueOf(4));
      this.SWITCH_TO_RIGHT.put("armaa_aleste_rightArm", Integer.valueOf(0));
      this.SWITCH_TO_RIGHT.put("armaa_aleste_blade_RightArm", Integer.valueOf(2));
      this.SWITCH_TO_RIGHT.put("armaa_leynos_minigun_right", Integer.valueOf(3));
      this.LEFTSWITCH = new HashMap();
      this.LEFTSWITCH.put(Integer.valueOf(0), "armaa_selector_blade");
      this.LEFTSWITCH.put(Integer.valueOf(1), "armaa_selector_stake");
      this.LEFTSWITCH.put(Integer.valueOf(2), "armaa_selector_lrifle_left");
      this.LEFTSWITCH.put(Integer.valueOf(3), "armaa_selector_grenade");
      this.RIGHTSWITCH = new HashMap();
      this.RIGHTSWITCH.put(Integer.valueOf(0), "armaa_selector_heavyrifle");
      this.RIGHTSWITCH.put(Integer.valueOf(1), "armaa_selector_lrifle");
      this.RIGHTSWITCH.put(Integer.valueOf(2), "armaa_selector_flamer");
      this.RIGHTSWITCH.put(Integer.valueOf(3), "armaa_selector_blade_right");
      this.RIGHTSWITCH.put(Integer.valueOf(4), "armaa_selector_minigun");
      this.leftslotID = "C_ARML";
      this.rightslotID = "A_GUN";
   }

   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      boolean var4 = true;
      boolean var5 = true;
      int var6 = 0;

      int var7;
      for(var7 = 0; var7 < this.SWITCH_TO_LEFT.size(); ++var7) {
         if(var2.getVariant().getHullMods().contains(this.LEFTSWITCH.get(Integer.valueOf(var7)))) {
            var4 = false;
            ++var6;
         }
      }

      for(var7 = 0; var7 < this.SWITCH_TO_RIGHT.size(); ++var7) {
         if(var2.getVariant().getHullMods().contains(this.RIGHTSWITCH.get(Integer.valueOf(var7)))) {
            var5 = false;
            ++var6;
         }
      }

      boolean var8;
      String var9;
      if(var4) {
         var8 = false;
         if(var2.getVariant().getWeaponSpec("C_ARML") != null && this.SWITCH_TO_LEFT.get(var2.getVariant().getWeaponSpec("C_ARML").getWeaponId()) != null) {
            var7 = ((Integer)this.SWITCH_TO_LEFT.get(var2.getVariant().getWeaponSpec("C_ARML").getWeaponId())).intValue();
         } else {
            var7 = MathUtils.getRandomNumberInRange(0, this.SWITCH_TO_LEFT.size() - 1);
            var8 = true;
         }

         var2.getVariant().addMod((String)this.LEFTSWITCH.get(Integer.valueOf(var7)));
         var2.getVariant().clearSlot("C_ARML");
         var9 = (String)this.LEFT_SELECTOR.get(Integer.valueOf(var7));
         var2.getVariant().addWeapon("C_ARML", var9);
         if(var8) {
            var2.getVariant().autoGenerateWeaponGroups();
         }
      }

      if(var5) {
         var8 = false;
         if(var2.getVariant().getWeaponSpec("A_GUN") != null) {
            var7 = ((Integer)this.SWITCH_TO_RIGHT.get(var2.getVariant().getWeaponSpec("A_GUN").getWeaponId())).intValue();
         } else {
            var7 = MathUtils.getRandomNumberInRange(0, this.SWITCH_TO_RIGHT.size() - 1);
            var8 = true;
         }

         var2.getVariant().addMod((String)this.RIGHTSWITCH.get(Integer.valueOf(var7)));
         var2.getVariant().clearSlot("A_GUN");
         var9 = (String)this.RIGHT_SELECTOR.get(Integer.valueOf(var7));
         var2.getVariant().addWeapon("A_GUN", var9);
         if(var8) {
            var2.getVariant().autoGenerateWeaponGroups();
         }
      }

   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      if(var1.getOriginalOwner() < 0 && Global.getSector() != null && Global.getSector().getPlayerFleet() != null && Global.getSector().getPlayerFleet().getCargo() != null && Global.getSector().getPlayerFleet().getCargo().getStacksCopy() != null && !Global.getSector().getPlayerFleet().getCargo().getStacksCopy().isEmpty()) {
         Iterator var3 = Global.getSector().getPlayerFleet().getCargo().getStacksCopy().iterator();

         while(var3.hasNext()) {
            CargoStackAPI var4 = (CargoStackAPI)var3.next();
            if(var4.isWeaponStack() && (this.LEFT_SELECTOR.containsValue(var4.getWeaponSpecIfWeapon().getWeaponId()) || this.RIGHT_SELECTOR.containsValue(var4.getWeaponSpecIfWeapon().getWeaponId()))) {
               Global.getSector().getPlayerFleet().getCargo().removeStack(var4);
            }
         }
      }

   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"A":(var1 == 1?"B":(var1 == 2?"C":(var1 == 3?"D":null)));
   }

   public boolean isApplicableToShip(ShipAPI var1) {
      return var1.getHullSpec().getHullId().startsWith("armaa_");
   }
}
