package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class EnhancedExplosion extends BaseHullMod {

   public static final float RADIUS_MULT = 2.5F;
   public static final float DAMAGE_MULT = 1.5F;


   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      var2.getDynamic().getStat("explosion_damage_mult").modifyMult(var3, 1.5F);
      var2.getDynamic().getStat("explosion_radius_mult").modifyMult(var3, 2.5F);
   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return null;
   }
}
