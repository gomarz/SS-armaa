package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class armaa_advancedoptics extends BaseHullMod {

   public static final float BEAM_RANGE_BONUS = 35.0F;
   public static final float BEAM_TURN_PENALTY = 15.0F;


   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      var2.getBeamWeaponRangeBonus().modifyFlat(var3, 35.0F);
      var2.getBeamWeaponTurnRateBonus().modifyMult(var3, 0.85F);
      if(Global.getSector().getCharacterData().knowsHullMod("advancedoptics")) {
         Global.getSector().getCharacterData().addHullMod("armaa_advancedoptics");
      }

   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"35":(var1 == 1?"15%":null);
   }
}
