package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;

public class armaa_AWACSHM extends BaseHullMod {

   private final float RANGE_INCREASE = 100.0F;
   private final float SPEED_INCREASE = 15.0F;
   private final Color HL = Global.getSettings().getColor("hColor");
   private final Color F = Global.getSettings().getColor("textFriendColor");
   private final Color E = Global.getSettings().getColor("textEnemyColor");


   public void addPostDescriptionSection(TooltipMakerAPI var1, HullSize var2, ShipAPI var3, float var4, boolean var5) {
      float var6 = 10.0F;
      float var7 = 2.0F;
      boolean var8 = var3.getVariant().hasHullMod("fourteenth");
      Color[] var10000 = new Color[]{Misc.getHighlightColor(), this.F};
      var10000 = new Color[]{Misc.getHighlightColor(), this.F, this.F};
      var10000 = new Color[]{Misc.getHighlightColor(), this.E};
      var10000 = new Color[]{Misc.getHighlightColor(), Misc.getHighlightColor(), this.E};
      var1.addSectionHeading("Details", Alignment.MID, 10.0F);
      var1.addPara("%s Deploys 3 electronic warfare drones that enhance the aura strength and radius of a passive aura", var6, Misc.getHighlightColor(), new String[]{"-", "3"});
      if(!var8) {
         var1.addPara("%s This aura increases the range of all friendly ships by %s", var7, Misc.getHighlightColor(), new String[]{"-", "100.0 units."});
         var1.addPara("%s While the ship system is active, enemy ships within range deal %s less damage.", var7, Misc.getHighlightColor(), new String[]{"-", "20%"});
      } else {
         var1.addPara("%s This aura increases the move speed of all friendly ships by %s", var7, Misc.getHighlightColor(), new String[]{"-", "15.0%"});
         var1.addPara("%s While the ship system is active, enemy missiles in range are slowed by %s, and have %s.", var7, Misc.getHighlightColor(), new String[]{"-", "50%", "reduced tracking"});
      }

   }
}
