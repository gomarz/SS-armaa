package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CampaignFleetAPI;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.characters.PersonAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.FighterLaunchBayAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.combat.FighterWingAPI.ReturningFighter;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.loading.FighterWingSpecAPI;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.MechaModPlugin;
import data.scripts.ai.armaa_combat_docking_AI_fighter;
import data.scripts.ai.armaa_combat_retreat_AI_fighter;
import data.scripts.util.MagicIncompatibleHullmods;
import data.scripts.util.armaa_utils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.input.Keyboard;
import org.lwjgl.util.vector.Vector2f;

public class armaa_skyMindSuiteGamma extends BaseHullMod {

   public static final String DATA_PREFIX = "gamma_core_skymind_check_";
   public static final String coreType = "GAMMA CORE";
   private Color COLOR = new Color(0, 106, 0, 50);
   private static final float RETREAT_AREA_SIZE = 2000.0F;
   private boolean hasLanded;
   public static final String ITEM = "gamma_core";
   private Vector2f landingLoc = new Vector2f();
   private static final Color JITTER_UNDER_COLOR = new Color(50, 125, 50, 50);
   private static final float MAX_TIME_MULT = 1.1F;
   private static final Map ENGAGEMENT_REDUCTION = new HashMap();
   private static final int BOMBER_COST_MOD = 10000;
   private static final float FIGHTER_REPLACEMENT_TIME_MULT = 0.7F;
   private static final float FIGHTER_RATE = 1.25F;
   private static final float CREW_LOSS_MULT = 0.25F;
   private IntervalUtil tracker = new IntervalUtil(0.5F, 1.0F);
   private IntervalUtil tracker2 = new IntervalUtil(0.05F, 0.05F);
   private final List squadChatter_gamma;
   private static final Set BLOCKED_HULLMODS = new HashSet();
   private final Color HL;
   private final Color TT;
   private final Color F;
   private final Color E;
   private final Color def;


   public armaa_skyMindSuiteGamma() {
      this.squadChatter_gamma = MechaModPlugin.squadChatter_gamma;
      this.HL = Global.getSettings().getColor("hColor");
      this.TT = Global.getSettings().getColor("buttonBgDark");
      this.F = Global.getSettings().getColor("textFriendColor");
      this.E = Global.getSettings().getColor("textEnemyColor");
      this.def = Global.getSettings().getColor("standardTextColor");
   }

   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      boolean var4 = false;
      boolean var5 = false;
   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      Iterator var3 = BLOCKED_HULLMODS.iterator();

      while(var3.hasNext()) {
         String var4 = (String)var3.next();
         if(var1.getVariant().getHullMods().contains(var4)) {
            MagicIncompatibleHullmods.removeHullmodWithWarning(var1.getVariant(), var4, "armaa_skyMindGamma");
         }
      }

   }

   public boolean affectsOPCosts() {
      return false;
   }

   public boolean isApplicableToShip(ShipAPI var1) {
      CampaignFleetAPI var2 = Global.getSector().getPlayerFleet();
      boolean var3 = true;
      if(var2 != null) {
         if(Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity("gamma_core") > 0.0F) {
            var3 = true;
         } else {
            var3 = false;
         }
      }

      return var3 && (!var1.isStationModule() && var1.getVariant().hasHullMod("strikeCraft") && var1.getHullSpec().getFighterBays() == 0 || var1.getMutableStats().getNumFighterBays().getModifiedValue() > 0.0F);
   }

   public String getUnapplicableReason(ShipAPI var1) {
      if(var1 == null) {
         return "Can not be assigned";
      } else {
         CampaignFleetAPI var2 = Global.getSector().getPlayerFleet();
         if(var2 != null) {
            String var3 = "armaa_skyMind_gamma_core_" + var1.getFleetMemberId();
            Map var4 = Global.getSector().getPersistentData();
            if(Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity("gamma_core") <= 0.0F && !var4.containsKey(var3)) {
               return "Installation requires 1 GAMMA Core";
            }
         }

         return "Only installable on strikecraft or carriers larger than frigates";
      }
   }

   public void addPostDescriptionSection(TooltipMakerAPI var1, HullSize var2, ShipAPI var3, float var4, boolean var5) {
      float var6 = 10.0F;
      float var7 = 2.0F;
      Color[] var8 = new Color[]{Misc.getHighlightColor(), this.F};
      Color[] var9 = new Color[]{Misc.getHighlightColor(), this.F, this.F};
      Color[] var10 = new Color[]{Misc.getHighlightColor(), this.E};
      var1.addSectionHeading("Details", Alignment.MID, 10.0F);
      var1.addPara("%s Assigning an AI Core to this vessel %s.", var6, var8, new String[]{"•", "will grant it\'s wing all the skills the core possesses"});
      var1.addPara("%s Only applicable with %s fighters.", var6, var9, new String[]{"•", "automated"});
      var1.addPara("%s If this ship is destroyed in combat, the assigned core will be %s.", var6, var10, new String[]{"•", "permanently lost"});
      if(var3 != null) {
         var1.addSectionHeading("=== AI CORE INFO ===", Alignment.MID, 10.0F);
         FighterWingSpecAPI var11 = var3.getVariant().getWing(0);
         this.getWingSize(var3);
         if(var3 != null && var3.getVariant() != null) {
            if(var11 == null) {
               var1.addPara("No wing assigned.", 10.0F, Misc.getHighlightColor(), new String[0]);
            } else {
               boolean var13 = Keyboard.isKeyDown(Keyboard.getKeyIndex("F1"));
               String var14 = var3.getCaptain().getNameString();
               boolean var15 = false;
               String var16 = "";
               ArrayList var17 = new ArrayList();
               Iterator var18 = MechaModPlugin.squadChatter.iterator();

               while(var18.hasNext()) {
                  String var19 = (String)var18.next();
                  var17.add(var19);
               }

               Random var25 = new Random();
               int var26 = var25.nextInt(this.squadChatter_gamma.size());
               String var20 = (String)this.squadChatter_gamma.get(var26);
               PersonAPI var21 = var3.getCaptain();
               String var22 = "armaa_skyMind_gamma_core_" + var3.getFleetMemberId();
               Map var23 = Global.getSector().getPersistentData();
               if(!var23.containsKey(var22)) {
                  return;
               }

               var21 = (PersonAPI)var23.get(var22);
               var1.addSectionHeading(var21.getId().toUpperCase(), Alignment.MID, 10.0F);
               String var24 = "GAMMA CORE";
               var1.addSectionHeading("Persona: " + var24, this.HL, this.TT, Alignment.MID, 0.0F);
               var1.beginImageWithText(var21.getPortraitSprite(), 88.0F).addPara(var20, 3.0F, this.def, new String[]{var20});
               var1.addImageWithText(8.0F);
               var1.addRelationshipBar(var3.getCaptain(), 5.0F);
            }
         }

      }
   }

   public static void removePlayerCommodity(String var0) {
      CampaignFleetAPI var1 = Global.getSector().getPlayerFleet();
      if(var1 != null) {
         List var2 = var1.getCargo().getStacksCopy();
         Iterator var3 = var2.iterator();

         CargoStackAPI var4;
         do {
            if(!var3.hasNext()) {
               return;
            }

            var4 = (CargoStackAPI)var3.next();
         } while(!var4.isCommodityStack() || !var4.getCommodityId().equals(var0));

         var4.subtract(1.0F);
         if(var4.getSize() <= 0.0F) {
            var1.getCargo().removeStack(var4);
         }

      }
   }

   public void advanceInCampaign(FleetMemberAPI var1, float var2) {
      String var3 = "armaa_skyMind_gamma_core_" + var1.getId();
      Map var4 = Global.getSector().getPersistentData();
      if(!var4.containsKey(var3)) {
         if(Misc.getAICoreOfficerPlugin("gamma_core") == null) {
            return;
         }

         PersonAPI var5 = Misc.getAICoreOfficerPlugin("gamma_core").createPerson("gamma_core", var1.getCaptain().getFaction().getId(), Misc.random);
         var5.setAICoreId("gamma_core");
         var4.put(var3, var5);
      }

      if(!var4.containsKey("gamma_core_skymind_check_" + var1.getId())) {
         this.tracker2.advance(var2);
         if(!var1.getVariant().hasHullMod("armaa_aicoreutilityscript")) {
            removePlayerCommodity("gamma_core");
            var4.put("gamma_core_skymind_check_" + var1.getId(), "_");
            var1.getVariant().addPermaMod("armaa_aicoreutilityscript");
         }

      }
   }

   public void advanceInCombat(ShipAPI var1, float var2) {
      if(!var1.getLaunchBaysCopy().isEmpty()) {
         if(!var1.isStationModule()) {
            if((var1.getHullSpec().getFighterBays() <= 0 || var1.isFrigate() || var1.isFighter()) && !var1.getHullSpec().hasTag("strikecraft_with_bays")) {
               FighterLaunchBayAPI var3 = (FighterLaunchBayAPI)var1.getLaunchBaysCopy().get(0);
               if(var1.isLanding()) {
                  ShipAPI var4 = this.getCarrier(var1);
                  if(var4 != null) {
                     Global.getCombatEngine().getCustomData().put("armaa_wingCommander_landingLocation_default" + var1.getId(), var4);
                  }
               }

               if(var3.getWing() != null) {
                  if(!var3.getWing().getWingMembers().isEmpty()) {
                     for(int var17 = 0; var17 < var3.getWing().getWingMembers().size(); ++var17) {
                        ShipAPI var5 = (ShipAPI)var3.getWing().getWingMembers().get(var17);
                        if(var5 != null && !var5.isHulk() && var5 != null) {
                           Object var6 = Global.getCombatEngine().getCustomData().get("armaa_wingCommander_landingLocation_" + var5.getId() + "_set");
                           boolean var7 = var6 instanceof Boolean?((Boolean)var6).booleanValue():false;
                           if(var5.isLiftingOff() && !var7) {
                              float var8 = Global.getCombatEngine().getMapWidth() / 2.0F;
                              float var9 = Global.getCombatEngine().getMapHeight() / 2.0F;
                              Vector2f var10 = new Vector2f(-var8, -var9);
                              Vector2f var11 = new Vector2f(var8, var9);
                              Vector2f var12 = null;
                              ShipAPI var13 = (ShipAPI)Global.getCombatEngine().getCustomData().get("armaa_wingCommander_landingLocation_default" + var1.getId());
                              if(Global.getCombatEngine().getCustomData().get("armaa_wingCommander_landingLocation_" + var1.getId() + "_" + var17) instanceof ShipAPI) {
                                 var13 = (ShipAPI)Global.getCombatEngine().getCustomData().get("armaa_wingCommander_landingLocation_" + var1.getId() + "_" + var17);
                              }

                              if(var13 != null && (!var13.isAlive() || var13.isHulk())) {
                                 var13 = null;
                              }

                              if(var13 == null) {
                                 var13 = this.getCarrier(var5);
                              }

                              if(Global.getCombatEngine().isEntityInPlay(var13) && var13.isAlive()) {
                                 Iterator var14 = var13.getLaunchBaysCopy().iterator();

                                 while(var14.hasNext()) {
                                    FighterLaunchBayAPI var15 = (FighterLaunchBayAPI)var14.next();
                                    if(var15.getWeaponSlot() != null) {
                                       WeaponSlotAPI var16 = var15.getWeaponSlot();
                                       var12 = new Vector2f(var13.getLocation().x + var16.getLocation().y, var13.getLocation().y + var16.getLocation().x);
                                       if(Math.random() <= 0.5D) {
                                          break;
                                       }
                                    }
                                 }
                              }

                              if(var12 == null) {
                                 if(var13 != null && var13.getLocation() != null && var13.isAlive()) {
                                    var12 = var13.getLocation();
                                 } else if(var5.getOwner() == 0) {
                                    if(var1.getLocation().getY() > var10.getY() - 2000.0F) {
                                       var12 = new Vector2f(var1.getLocation().getX(), var1.getLocation().getY() - 2000.0F);
                                    } else {
                                       var12 = new Vector2f((var10.x + var11.x) / 2.0F, var10.y);
                                    }
                                 } else {
                                    var12 = new Vector2f((var10.x + var11.x) / 2.0F, var11.y);
                                 }
                              }

                              armaa_utils.setLocation(var5, var12);
                              Global.getCombatEngine().getCustomData().put("armaa_wingCommander_landingLocation_" + var5.getId() + "_set", Boolean.valueOf(true));
                           }
                        }
                     }
                  }

                  this.tracker.advance(var2);
                  if(this.tracker.intervalElapsed() && !var3.getWing().getReturning().isEmpty()) {
                     this.doLanding(var3, var1);
                  }
               }

            }
         }
      }
   }

   public int getWingSize(ShipAPI var1) {
      FighterWingSpecAPI var2 = var1.getVariant().getWing(0);
      int var3 = 0;
      boolean var4 = false;
      if(var2 != null) {
         for(int var5 = 0; var5 < var1.getVariant().getWings().size(); ++var5) {
            FighterWingSpecAPI var6 = var1.getVariant().getWing(var5);
            if(var6 != null) {
               var4 = var6.getVariant().getHullSpec().getMinCrew() == 0.0F;
               if(var4) {
                  var3 += var6.getNumFighters();
               }
            }
         }
      }

      Iterator var9 = var1.getVariant().getModuleSlots().iterator();

      while(var9.hasNext()) {
         String var10 = (String)var9.next();
         if(var1.getVariant().getModuleVariant(var10).hasHullMod("armaa_wingCommander")) {
            for(int var7 = 0; var7 < var1.getVariant().getModuleVariant(var10).getWings().size(); ++var7) {
               FighterWingSpecAPI var8 = var1.getVariant().getModuleVariant(var10).getWing(var7);
               if(var8 != null) {
                  var4 = var8.getVariant().getHullSpec().getMinCrew() == 0.0F;
                  if(var4) {
                     var3 += var8.getNumFighters();
                  }
               }
            }
         }
      }

      return var3;
   }

   public int getWingSize(ShipVariantAPI var1) {
      FighterWingSpecAPI var2 = var1.getWing(0);
      int var3 = 0;
      boolean var4 = false;
      if(var2 != null) {
         for(int var5 = 0; var5 < var1.getWings().size(); ++var5) {
            FighterWingSpecAPI var6 = var1.getWing(var5);
            if(var6 != null) {
               var4 = var6.getVariant().getHullSpec().getMinCrew() > 0.0F;
               if(var4) {
                  var3 += var6.getNumFighters();
               }
            }
         }
      }

      return var3;
   }

   public void applyEffectsToFighterSpawnedByShip(ShipAPI var1, ShipAPI var2, String var3) {
      if(var1.getHullSpec().getMinCrew() <= 0.0F) {
         String var4 = "armaa_skyMind_gamma_core_" + var2.getFleetMemberId();
         Map var5 = Global.getSector().getPersistentData();
         if(var5.containsKey(var4)) {
            PersonAPI var6 = (PersonAPI)var5.get(var4);
            var1.setCaptain(var6);
         }

      }
   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return null;
   }

   public ShipAPI getCarrier(ShipAPI var1) {
      ShipAPI var2 = null;
      boolean var3 = var1.getVariant().getHullSize() == HullSize.FRIGATE;
      float var4 = 99999.0F;
      Iterator var5 = CombatUtils.getShipsWithinRange(var1.getLocation(), 10000.0F).iterator();

      while(var5.hasNext()) {
         ShipAPI var6 = (ShipAPI)var5.next();
         if(var6.getOwner() == var1.getOwner() && var6.isAlive() && !var6.isHulk() && (!var6.isFighter() || var6.getHullSpec().hasTag("strikecraft_with_bays")) && var6.getHullSpec().getFighterBays() >= 1) {
            if(!var3 && var1.getWing() != null && var1.getWing().getSourceShip() != null) {
               ShipAPI var7 = var1.getWing().getSourceShip();
               if(var4 > MathUtils.getDistance(var6, var7)) {
                  var4 = MathUtils.getDistance(var6, var7);
                  var2 = var6;
               }
            } else if((!var6.isFrigate() || var6.isStationModule()) && var6.hasLaunchBays()) {
               return var6;
            }
         }
      }

      return var2;
   }

   public void doLanding(FighterLaunchBayAPI var1, ShipAPI var2) {
      for(int var3 = 0; var3 < var1.getWing().getReturning().size(); ++var3) {
         ShipAPI var4 = ((ReturningFighter)var1.getWing().getReturning().get(var3)).fighter;
         if(var4 != null && var4 != null) {
            if(var1.getWing().isReturning(var4)) {
               boolean var5 = false;
               ShipAPI var6 = this.getCarrier(var4);
               if(var6 != null) {
                  armaa_combat_docking_AI_fighter var7 = new armaa_combat_docking_AI_fighter(var4);
                  if(var4.getShipAI() != var7) {
                     ;
                  }

                  var4.setShipAI(var7);
                  var7.init();
               } else {
                  boolean var10 = false;
                  if(var4.getCustomData().get("armaa_wingCommander_fighterRetreat_" + var4.getId()) instanceof Boolean) {
                     var10 = ((Boolean)var4.getCustomData().get("armaa_wingCommander_fighterRetreat_" + var4.getId())).booleanValue();
                  }

                  if(!var10) {
                     armaa_combat_retreat_AI_fighter var8 = new armaa_combat_retreat_AI_fighter(var4);
                     if(var4.getShipAI() != var8) {
                        ;
                     }

                     var4.setShipAI(var8);
                     var4.getCustomData().put("armaa_wingCommander_fighterRetreat_" + var4.getId(), Boolean.valueOf(true));
                  }
               }
            }

            if(var4.isLanding()) {
               Iterator var9 = CombatUtils.getShipsWithinRange(var4.getLocation(), 100.0F).iterator();

               while(var9.hasNext()) {
                  ShipAPI var11 = (ShipAPI)var9.next();
                  if(var11.getOwner() == var4.getOwner() && !var11.isFighter() && (!var11.isFrigate() || var11.isStationModule()) && var11.hasLaunchBays()) {
                     Global.getCombatEngine().getCustomData().put("armaa_wingCommander_landingLocation_" + var2.getId() + "_" + var3, var11);
                     break;
                  }
               }
            }

            if(var4.isFinishedLanding()) {
               var1.land(var4);
               Global.getCombatEngine().removeEntity(var4);
            }
         }
      }

   }

   static {
      BLOCKED_HULLMODS.add("armaa_skyMindAlpha");
      BLOCKED_HULLMODS.add("armaa_skyMindBeta");
      ENGAGEMENT_REDUCTION.put(HullSize.FIGHTER, Float.valueOf(0.5F));
      ENGAGEMENT_REDUCTION.put(HullSize.FRIGATE, Float.valueOf(0.5F));
      ENGAGEMENT_REDUCTION.put(HullSize.DESTROYER, Float.valueOf(0.4F));
      ENGAGEMENT_REDUCTION.put(HullSize.CRUISER, Float.valueOf(0.3F));
      ENGAGEMENT_REDUCTION.put(HullSize.CAPITAL_SHIP, Float.valueOf(0.2F));
   }
}
