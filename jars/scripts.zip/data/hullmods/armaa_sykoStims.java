package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.util.armaa_sykoEveryFrame;
import java.awt.Color;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.magiclib.util.MagicIncompatibleHullmods;

public class armaa_sykoStims extends BaseHullMod {

   private static final float DAMAGE_BONUS = 100.0F;
   private static final float MIN_PROJECTILE_DMG = 40.0F;
   private static final float GRAZE_DAMAGE_BONUS = 10.0F;
   private static final float GRAZE_TIME_BONUS = 3.0F;
   private static final float DAMAGE_MALUS = 1.1F;
   private static final float GRAZE_TIME_BONUS_MIN = 1.1F;
   private static final float MAX_TIME_MULT = 1.0F;
   private static final float MIN_TIME_MULT = 0.1F;
   private static final float up = 0.7F;
   private static final float down = 20.0F;
   private IntervalUtil buffTimer = new IntervalUtil(0.7F, 0.7F);
   private IntervalUtil coolDownTimer = new IntervalUtil(20.0F, 20.0F);
   private static final Set BLOCKED_HULLMODS = new HashSet();


   public void addPostDescriptionSection(TooltipMakerAPI var1, HullSize var2, ShipAPI var3, float var4, boolean var5) {
      if(var3 != null) {
         float var6 = 64.0F;
         float var7 = 10.0F;
         Color var8 = new Color(241, 199, 0);
         String var9 = "graphics/armaa/icons/hullsys/armaa_drugs_icon.png";
         String var10 = "\'Sy-Ko\' Combat Stimulant";
         String var11 = "• Narrowly evading projectiles with %s administers a high-grade synthetic stimulant that includes a psychotropic aggression enhancer.";
         String var12 = "• Time Dilation is increased by %s.";
         String var13 = "• Energy and Ballistic weapon damage is increased by %s.";
         String var14 = "• Evasion bonus degrades over %s seconds, after which system cannot trigger again for %s seconds.";
         String var15 = "• Consumes %s unit of %s per engagement.";
         float var16 = 2.0F;
         Color[] var10000 = new Color[]{Misc.getPositiveHighlightColor(), Misc.getHighlightColor()};
         var1.addSectionHeading("Details", Alignment.MID, 5.0F);
         TooltipMakerAPI var18 = var1.beginImageWithText(var9, var6);
         Color[] var19 = new Color[]{Global.getSettings().getColor("textGrayColor"), Misc.getNegativeHighlightColor()};
         var18.addPara(var10, var16, var8, new String[]{var10});
         boolean var20 = Global.getSector().getPlayerFleet() != null;
         if(var20 && Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity("drugs") > 0.0F) {
            var18.addPara(var15, var16, Misc.getNegativeHighlightColor(), new String[]{"one", "Recreational Drugs"});
            var18.addPara(var11, var16, Misc.getHighlightColor(), new String[]{"shields lowered"});
            var18.addPara(var12, var16, Misc.getPositiveHighlightColor(), new String[]{Math.round(200.0F) + "%"});
            var18.addPara(var13, var16, Misc.getPositiveHighlightColor(), new String[]{Misc.getRoundedValueMaxOneAfterDecimal(10.0F) + "%"});
            var18.addPara(var14, var16, Misc.getNegativeHighlightColor(), new String[]{Misc.getRoundedValueMaxOneAfterDecimal(this.buffTimer.getMaxInterval()) + "", (int)this.coolDownTimer.getMaxInterval() + ""});
            var18.addPara("• Damage received to hull increased by %s", var16, Misc.getNegativeHighlightColor(), new String[]{Math.round(10.000002F) + "%"});
         } else {
            var18.addPara("%s - components of the stimulant require %s.", var16, var19, new String[]{"DISABLED", "Recreational Drugs"});
         }

         var1.addImageWithText(var7);
         Color var22 = new Color(110, 110, 110, 255);
         var1.addPara("%s", 6.0F, var22, new String[]{"\"... pilots on stims benefit from enhanced reflexes, but are subject to long-term side effects including insomnia, mania/hypomania, internal hemorrhaging, and cerebral deterioration ... Nonetheless, both commanders and pilots stand by the use of these stims as essential to their continued survival and effectiveness on the field...\""}).italicize();
         var1.addPara("%s", 1.0F, var22, new String[]{"         — Excerpt from \'Rad-Addled: Spacer Life\'"});
         var1.addSectionHeading("Incompatibilities", Alignment.MID, 10.0F);
         String var23 = "";
         int var24 = BLOCKED_HULLMODS.size();
         int var25 = 0;
         Color[] var26 = new Color[]{Misc.getHighlightColor(), Misc.getNegativeHighlightColor()};
         Iterator var27 = Global.getSettings().getAllHullModSpecs().iterator();

         while(var27.hasNext()) {
            HullModSpecAPI var28 = (HullModSpecAPI)var27.next();
            Iterator var29 = BLOCKED_HULLMODS.iterator();

            while(var29.hasNext()) {
               String var30 = (String)var29.next();
               if(var28.getId().equals(var30)) {
                  var23 = var23 + var28.getDisplayName();
                  if(var25 != var24 - 1) {
                     var23 = var23 + ", ";
                     ++var25;
                  }
               }
            }
         }

         var23 = var23.substring(0, var23.length() - 1);
         var1.addPara("%s Incompatible with %s.", var7, var26, new String[]{"•", "" + var23});
      }
   }

   public boolean isApplicableToShip(ShipAPI var1) {
      return !var1.isStationModule() && var1.getVariant().hasHullMod("strikeCraft");
   }

   public String getUnapplicableReason(ShipAPI var1) {
      return var1 == null?"Can not be assigned":"Only installable on strikecraft.";
   }

   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      var2.getHullDamageTakenMult().modifyMult(var3, 1.1F);
   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      Iterator var3 = BLOCKED_HULLMODS.iterator();

      while(var3.hasNext()) {
         String var4 = (String)var3.next();
         if(var1.getVariant().getHullMods().contains(var4)) {
            MagicIncompatibleHullmods.removeHullmodWithWarning(var1.getVariant(), var4, "armaa_sykoStims");
         }
      }

   }

   public void advanceInCombat(ShipAPI var1, float var2) {
      if(!Global.getCombatEngine().isPaused()) {
         Map var3 = Global.getCombatEngine().getCustomData();
         if(!var3.containsKey("armaa_sykoStims_" + var1.getId())) {
            Global.getCombatEngine().addPlugin(new armaa_sykoEveryFrame(var1, 40.0F, 10.0F, 3.0F, 1.1F, 0.7F, 20.0F));
            var3.put("armaa_sykoStims_" + var1.getId(), "_");
         }

      }
   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"" + Math.round(100.0F) + "%":(var1 == 1?"incompatible with Safety Overrides.":(var1 == 2?"additional large scale modifications cannot be made to the hull":null));
   }

   static {
      BLOCKED_HULLMODS.add("armaa_SilverSwordHM");
   }
}
