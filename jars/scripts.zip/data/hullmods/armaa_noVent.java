package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import java.awt.Color;
import java.util.HashMap;
import java.util.Map;

public class armaa_noVent extends BaseHullMod {

   private ShipwideAIFlags flags;
   private static Map speed = new HashMap();
   private static final float PEAK_MULT = 0.33F;
   private static final float FLUX_DISSIPATION_MULT = 2.0F;
   private static final float RANGE_THRESHOLD = 450.0F;
   private static final float RANGE_MULT = 0.25F;
   private Color color = new Color(255, 100, 255, 255);


   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {}

   public String getDescriptionParam(int var1, HullSize var2) {
      return null;
   }

   public boolean isApplicableToShip(ShipAPI var1) {
      return var1.getVariant().getHullSize() == HullSize.CAPITAL_SHIP?false:!var1.getVariant().hasHullMod("civgrade") || var1.getVariant().hasHullMod("militarized_subsystems");
   }

   public String getUnapplicableReason(ShipAPI var1) {
      return var1.getVariant().getHullSize() == HullSize.CAPITAL_SHIP?"Can not be installed on capital ships":(var1.getVariant().hasHullMod("civgrade") && !var1.getVariant().hasHullMod("militarized_subsystems")?"Can not be installed on civilian ships":null);
   }

   public void advanceInCombat(ShipAPI var1, float var2) {
      if(this.flags != null && this.flags == var1.getAIFlags()) {
         this.flags.setFlag(AIFlags.DO_NOT_VENT, 10.0F);
      } else {
         this.flags = var1.getAIFlags();
      }

   }

   static {
      speed.put(HullSize.FRIGATE, Float.valueOf(50.0F));
      speed.put(HullSize.DESTROYER, Float.valueOf(30.0F));
      speed.put(HullSize.CRUISER, Float.valueOf(20.0F));
      speed.put(HullSize.CAPITAL_SHIP, Float.valueOf(10.0F));
   }
}
