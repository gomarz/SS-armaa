package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.lazywizard.lazylib.MathUtils;

public class armaa_valkazardweaponSwap extends BaseHullMod {

   public Map LEFT_SELECTOR = new HashMap();
   public Map RIGHT_SELECTOR;
   private final Map SWITCH_TO_LEFT;
   private final Map SWITCH_TO_RIGHT;
   private final Map RIGHTSWITCH;
   private final Map LEFTSWITCH;
   public Map CORE_SELECTOR;
   private final Map SWITCH_TO_CORE;
   private final Map CORESWITCH;
   private final String leftslotID;
   private final String rightslotID;
   private final String coreslotID;


   public armaa_valkazardweaponSwap() {
      this.LEFT_SELECTOR.put(Integer.valueOf(0), "armaa_valkazard_harpoon");
      this.LEFT_SELECTOR.put(Integer.valueOf(1), "armaa_valkazard_shotgun_left");
      this.LEFT_SELECTOR.put(Integer.valueOf(2), "armaa_valkazard_pulse_rifle_left");
      this.LEFT_SELECTOR.put(Integer.valueOf(3), "armaa_valkazard_machinegun_left");
      this.LEFT_SELECTOR.put(Integer.valueOf(4), "armaa_valkazard_rcl_left");
      this.LEFT_SELECTOR.put(Integer.valueOf(5), "armaa_valkazard_blade");
      this.RIGHT_SELECTOR = new HashMap();
      this.RIGHT_SELECTOR.put(Integer.valueOf(0), "armaa_valkazard_rcl");
      this.RIGHT_SELECTOR.put(Integer.valueOf(1), "armaa_valkazard_chaingun");
      this.RIGHT_SELECTOR.put(Integer.valueOf(2), "armaa_valkazard_pulse_rifle_right");
      this.RIGHT_SELECTOR.put(Integer.valueOf(3), "armaa_valkazard_machinegun_right");
      this.RIGHT_SELECTOR.put(Integer.valueOf(4), "armaa_valkazard_shotgun_right");
      this.SWITCH_TO_LEFT = new HashMap();
      this.SWITCH_TO_LEFT.put("armaa_valkazard_harpoon", Integer.valueOf(5));
      this.SWITCH_TO_LEFT.put("armaa_valkazard_blade", Integer.valueOf(4));
      this.SWITCH_TO_LEFT.put("armaa_valkazard_rcl_left", Integer.valueOf(3));
      this.SWITCH_TO_LEFT.put("armaa_valkazard_machinegun_left", Integer.valueOf(2));
      this.SWITCH_TO_LEFT.put("armaa_valkazard_pulse_rifle_left", Integer.valueOf(1));
      this.SWITCH_TO_LEFT.put("armaa_valkazard_shotgun_left", Integer.valueOf(0));
      this.SWITCH_TO_RIGHT = new HashMap();
      this.SWITCH_TO_RIGHT.put("armaa_valkazard_rcl", Integer.valueOf(4));
      this.SWITCH_TO_RIGHT.put("armaa_valkazard_shotgun_right", Integer.valueOf(3));
      this.SWITCH_TO_RIGHT.put("armaa_valkazard_machinegun_right", Integer.valueOf(2));
      this.SWITCH_TO_RIGHT.put("armaa_valkazard_pulse_rifle_right", Integer.valueOf(1));
      this.SWITCH_TO_RIGHT.put("armaa_valkazard_chaingun", Integer.valueOf(0));
      this.RIGHTSWITCH = new HashMap();
      this.RIGHTSWITCH.put(Integer.valueOf(0), "armaa_selector_rcl");
      this.RIGHTSWITCH.put(Integer.valueOf(1), "armaa_selector_chaingun");
      this.RIGHTSWITCH.put(Integer.valueOf(2), "armaa_selector_pulse_rifle_right");
      this.RIGHTSWITCH.put(Integer.valueOf(3), "armaa_selector_machinegun_right");
      this.RIGHTSWITCH.put(Integer.valueOf(4), "armaa_selector_shotgun_right");
      this.LEFTSWITCH = new HashMap();
      this.LEFTSWITCH.put(Integer.valueOf(0), "armaa_selector_harpoon");
      this.LEFTSWITCH.put(Integer.valueOf(1), "armaa_selector_shotgun_left");
      this.LEFTSWITCH.put(Integer.valueOf(2), "armaa_selector_pulse_rifle_left");
      this.LEFTSWITCH.put(Integer.valueOf(3), "armaa_selector_machinegun_left");
      this.LEFTSWITCH.put(Integer.valueOf(4), "armaa_selector_rcl_left");
      this.LEFTSWITCH.put(Integer.valueOf(5), "armaa_selector_blade_VAL");
      this.CORE_SELECTOR = new HashMap();
      this.CORE_SELECTOR.put(Integer.valueOf(0), "armaa_valkazard_torso");
      this.CORE_SELECTOR.put(Integer.valueOf(1), "armaa_valkazard_torso_shield");
      this.CORE_SELECTOR.put(Integer.valueOf(2), "armaa_valkazard_torso_boson");
      this.CORE_SELECTOR.put(Integer.valueOf(3), "armaa_valkazard_torso_chaosburst");
      this.CORE_SELECTOR.put(Integer.valueOf(4), "armaa_valkazard_torso_ac");
      this.SWITCH_TO_CORE = new HashMap();
      this.SWITCH_TO_CORE.put("armaa_valkazard_torso", Integer.valueOf(4));
      this.SWITCH_TO_CORE.put("armaa_valkazard_torso_ac", Integer.valueOf(3));
      this.SWITCH_TO_CORE.put("armaa_valkazard_torso_chaosburst", Integer.valueOf(2));
      this.SWITCH_TO_CORE.put("armaa_valkazard_torso_boson", Integer.valueOf(1));
      this.SWITCH_TO_CORE.put("armaa_valkazard_torso_shield", Integer.valueOf(0));
      this.CORESWITCH = new HashMap();
      this.CORESWITCH.put(Integer.valueOf(0), "armaa_selector_blunderbuss");
      this.CORESWITCH.put(Integer.valueOf(1), "armaa_selector_counter_shield");
      this.CORESWITCH.put(Integer.valueOf(2), "armaa_selector_boson");
      this.CORESWITCH.put(Integer.valueOf(3), "armaa_selector_chaos");
      this.CORESWITCH.put(Integer.valueOf(4), "armaa_selector_ac20");
      this.leftslotID = "C_ARML";
      this.rightslotID = "A_GUN";
      this.coreslotID = "B_TORSO";
   }

   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      boolean var4 = true;
      boolean var5 = true;
      boolean var6 = true;
      int var7 = 0;

      int var8;
      for(var8 = 0; var8 < this.SWITCH_TO_LEFT.size(); ++var8) {
         if(var2.getVariant().getHullMods().contains(this.LEFTSWITCH.get(Integer.valueOf(var8)))) {
            var4 = false;
            ++var7;
         }
      }

      for(var8 = 0; var8 < this.SWITCH_TO_RIGHT.size(); ++var8) {
         if(var2.getVariant().getHullMods().contains(this.RIGHTSWITCH.get(Integer.valueOf(var8)))) {
            var5 = false;
            ++var7;
         }
      }

      for(var8 = 0; var8 < this.CORESWITCH.size(); ++var8) {
         if(var2.getVariant().getHullMods().contains(this.CORESWITCH.get(Integer.valueOf(var8))) && var2.getVariant().getWeaponSpec("B_TORSO") != null) {
            var6 = false;
            ++var7;
         }
      }

      boolean var9;
      String var10;
      if(var4) {
         var9 = false;
         if(var2.getVariant().getWeaponSpec("C_ARML") != null && this.SWITCH_TO_LEFT.containsKey(var2.getVariant().getWeaponSpec("C_ARML").getWeaponId())) {
            var8 = ((Integer)this.SWITCH_TO_LEFT.get(var2.getVariant().getWeaponSpec("C_ARML").getWeaponId())).intValue();
         } else {
            var8 = MathUtils.getRandomNumberInRange(0, this.SWITCH_TO_LEFT.size() - 1);
            var9 = true;
         }

         var2.getVariant().addMod((String)this.LEFTSWITCH.get(Integer.valueOf(var8)));
         var2.getVariant().clearSlot("C_ARML");
         var10 = (String)this.LEFT_SELECTOR.get(Integer.valueOf(var8));
         var2.getVariant().addWeapon("C_ARML", var10);
         if(var9) {
            var2.getVariant().autoGenerateWeaponGroups();
         }
      }

      if(var5) {
         var9 = false;
         if(var2.getVariant().getWeaponSpec("A_GUN") != null) {
            var8 = ((Integer)this.SWITCH_TO_RIGHT.get(var2.getVariant().getWeaponSpec("A_GUN").getWeaponId())).intValue();
         } else {
            var8 = MathUtils.getRandomNumberInRange(0, this.SWITCH_TO_RIGHT.size() - 1);
            var9 = true;
         }

         var2.getVariant().addMod((String)this.RIGHTSWITCH.get(Integer.valueOf(var8)));
         var2.getVariant().clearSlot("A_GUN");
         var10 = (String)this.RIGHT_SELECTOR.get(Integer.valueOf(var8));
         var2.getVariant().addWeapon("A_GUN", var10);
         if(var9) {
            var2.getVariant().autoGenerateWeaponGroups();
         }
      }

      if(var6) {
         var9 = false;
         if(var2.getVariant().getWeaponSpec("B_TORSO") != null) {
            var8 = ((Integer)this.SWITCH_TO_CORE.get(var2.getVariant().getWeaponSpec("B_TORSO").getWeaponId())).intValue();
         } else {
            var8 = MathUtils.getRandomNumberInRange(0, this.CORESWITCH.size() - 1);
            var10 = "";
            Iterator var11 = var2.getVariant().getHullMods().iterator();

            while(var11.hasNext()) {
               String var12 = (String)var11.next();
               if(this.CORESWITCH.containsValue(var12)) {
                  var10 = var12;
               }
            }

            var2.getVariant().removeMod(var10);
            var9 = true;
         }

         var2.getVariant().addMod((String)this.CORESWITCH.get(Integer.valueOf(var8)));
         var2.getVariant().clearSlot("B_TORSO");
         var10 = (String)this.CORE_SELECTOR.get(Integer.valueOf(var8));
         var2.getVariant().addWeapon("B_TORSO", var10);
         if(var9) {
            var2.getVariant().autoGenerateWeaponGroups();
         }
      }

   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      if(var1.getOriginalOwner() < 0 && Global.getSector() != null && Global.getSector().getPlayerFleet() != null && Global.getSector().getPlayerFleet().getCargo() != null && Global.getSector().getPlayerFleet().getCargo().getStacksCopy() != null && !Global.getSector().getPlayerFleet().getCargo().getStacksCopy().isEmpty()) {
         Iterator var3 = Global.getSector().getPlayerFleet().getCargo().getStacksCopy().iterator();

         while(var3.hasNext()) {
            CargoStackAPI var4 = (CargoStackAPI)var3.next();
            if(var4.isWeaponStack() && (this.LEFT_SELECTOR.containsValue(var4.getWeaponSpecIfWeapon().getWeaponId()) || this.RIGHT_SELECTOR.containsValue(var4.getWeaponSpecIfWeapon().getWeaponId()) || this.CORE_SELECTOR.containsValue(var4.getWeaponSpecIfWeapon().getWeaponId()))) {
               Global.getSector().getPlayerFleet().getCargo().removeStack(var4);
            }
         }
      }

   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"A":(var1 == 1?"B":(var1 == 2?"C":(var1 == 3?"D":null)));
   }

   public boolean isApplicableToShip(ShipAPI var1) {
      return var1.getHullSpec().getHullId().startsWith("armaa_");
   }
}
