package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CollisionClass;
import com.fs.starfarer.api.combat.CombatEntityAPI;
import com.fs.starfarer.api.combat.DamageType;
import com.fs.starfarer.api.combat.DamagingProjectileAPI;
import com.fs.starfarer.api.combat.MissileAPI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.util.Misc;
import data.scripts.util.armaa_utils;
import java.awt.Color;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicIncompatibleHullmods;

public class armaa_SilverSwordHM extends BaseHullMod {

   private static final float DAMAGE_MULT = 1.25F;
   private static final float DAMAGE_BONUS = 100.0F;
   private static final float MIN_PROJECTILE_DMG = 40.0F;
   private static final float GRAZE_DAMAGE_BONUS = 20.0F;
   private static final float GRAZE_TIME_BONUS = 3.0F;
   private static final float GRAZE_TIME_BONUS_MIN = 1.3F;
   private static final float MAX_TIME_MULT = 1.15F;
   private static final float MIN_TIME_MULT = 0.1F;
   private static final float AUTOAIM_BONUS = 0.33333334F;
   private IntervalUtil buffTimer = new IntervalUtil(2.0F, 2.0F);
   private IntervalUtil coolDownTimer = new IntervalUtil(5.0F, 5.0F);
   private boolean dodgeBonus = false;
   private boolean cooldown = false;
   private float multBonus = 1.0F;
   private static final Set BLOCKED_HULLMODS = new HashSet();


   public void addPostDescriptionSection(TooltipMakerAPI var1, HullSize var2, ShipAPI var3, float var4, boolean var5) {
      float var6 = 64.0F;
      float var7 = 10.0F;
      Color var8 = new Color(241, 199, 0);
      String var9 = "graphics/armaa/icons/hullsys/armaa_pilot_icon.png";
      String var10 = "graphics/armaa/icons/hullsys/armaa_ai_core.png";
      String var11 = "graphics/icons/hullsys/displacer.png";
      String var12 = "graphics/armaa/icons/hullsys/armaa_drugs_icon.png";
      String var13 = "Direct Neural Interface";
      String var14 = "- Time dilation increased by %s.";
      String var15 = "- Relative time slows by %s in the presence of dangerous entities within %s SU.";
      String var16 = "- Damage taken to hull and shields increased by %s.";
      String var17 = "Integrated PDAI";
      String var18 = "- Damage against missiles increased by %s.";
      String var19 = "- Damage against fighters increased by %s.";
      String var20 = "- All weapons %s.";
      String var21 = "- Autofire accuracy increased by %s.";
      String var22 = "\'Sy-Ko\' Combat Stimulant";
      String var23 = "- Narrowly evading projectiles with %s administers a high-grade synthetic stimulant that includes a psychotropic aggression enhancer.";
      String var24 = "- Time Dilation is increased by %s.";
      String var25 = "- Energy and Ballistic weapon damage is increased by %s.";
      String var26 = "- Evasion bonus degrades over %s seconds, after which system cannot trigger again for %s seconds.";
      String var27 = "- Consumes %s unit of %s per engagement.";
      float var28 = 2.0F;
      Color[] var29 = new Color[]{Misc.getPositiveHighlightColor(), Misc.getHighlightColor()};
      var1.addSectionHeading("Details", Alignment.MID, 5.0F);
      TooltipMakerAPI var30 = var1.beginImageWithText(var9, var6);
      var30.addPara(var13, var28, var8, new String[]{var13});
      var30.addPara(var14, var28, Misc.getPositiveHighlightColor(), new String[]{Math.round(14.999998F) + "%"});
      var30.addPara(var15, var28, var29, new String[]{Math.round(14.999998F) + "%", "1000"});
      var30.addPara(var16, var28, Misc.getNegativeHighlightColor(), new String[]{Math.round(25.0F) + "%"});
      var1.addImageWithText(var7);
      TooltipMakerAPI var32 = var1.beginImageWithText(var12, var6);
      Color[] var33 = new Color[]{Global.getSettings().getColor("textGrayColor"), Misc.getNegativeHighlightColor()};
      var32.addPara(var22, var28, var8, new String[]{var22});
      boolean var34 = Global.getSector().getPlayerFleet() != null;
      if(var34 && Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity("drugs") > 0.0F) {
         var32.addPara(var27, var28, Misc.getNegativeHighlightColor(), new String[]{"one", "Recreational Drugs"});
         var32.addPara(var23, var28, Misc.getHighlightColor(), new String[]{"shields lowered"});
         var32.addPara(var24, var28, Misc.getPositiveHighlightColor(), new String[]{Math.round(200.0F) + "%"});
         var32.addPara(var25, var28, Misc.getPositiveHighlightColor(), new String[]{Math.round(20.0F) + "%"});
         var32.addPara(var26, var28, Misc.getNegativeHighlightColor(), new String[]{(int)this.buffTimer.getMaxInterval() + "", (int)this.coolDownTimer.getMaxInterval() + ""});
      } else {
         var32.addPara("%s - components of the stimulant require %s.", var28, var33, new String[]{"DISABLED", "Recreational Drugs"});
      }

      var1.addImageWithText(var7);
      if(var2 == HullSize.FRIGATE) {
         TooltipMakerAPI var35 = var1.beginImageWithText(var10, var6);
         var35.addPara(var17, var28, var8, new String[]{var17});
         var35.addPara(var18, var28, Misc.getPositiveHighlightColor(), new String[]{Math.round(100.0F) + "%"});
         var35.addPara(var19, var28, Misc.getPositiveHighlightColor(), new String[]{Math.round(100.0F) + "%"});
         var35.addPara(var20, var28, Misc.getPositiveHighlightColor(), new String[]{"ignore flares"});
         var35.addPara(var21, var28, Misc.getPositiveHighlightColor(), new String[]{Math.round(33.333336F) + "%"});
         var1.addImageWithText(var7);
      }

      var1.addPara("\"Is this the subject? ...Oh, so they took the usual route here. Must have dashed their dreams. But, they will be reborn in this experiment. That is, if they live. Mmh. Let\'s get started.\" - Recovered voice recorder", Global.getSettings().getColor("textGrayColor"), var7);
      var1.addSectionHeading("Incompatibilities", Alignment.MID, 10.0F);
      String var43 = "";
      int var36 = BLOCKED_HULLMODS.size();
      int var37 = 0;
      Color[] var38 = new Color[]{Misc.getHighlightColor(), Misc.getNegativeHighlightColor()};
      Iterator var39 = Global.getSettings().getAllHullModSpecs().iterator();

      while(var39.hasNext()) {
         HullModSpecAPI var40 = (HullModSpecAPI)var39.next();
         Iterator var41 = BLOCKED_HULLMODS.iterator();

         while(var41.hasNext()) {
            String var42 = (String)var41.next();
            if(var40.getId().equals(var42)) {
               var43 = var43 + var40.getDisplayName();
               if(var37 != var36 - 1) {
                  var43 = var43 + ", ";
                  ++var37;
               }
            }
         }
      }

      var43 = var43.substring(0, var43.length() - 1);
      var1.addPara("%s Incompatible with %s.", var7, var38, new String[]{"-", "" + var43});
   }

   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      var2.getTimeMult().modifyMult(var3, 1.15F);
      var2.getHullDamageTakenMult().modifyMult(var3, 1.25F);
      var2.getShieldDamageTakenMult().modifyMult(var3, 1.25F);
      var2.getDynamic().getMod("pd_best_target_leading").modifyFlat(var3, 1.0F);
      var2.getDamageToMissiles().modifyPercent(var3, 100.0F);
      var2.getDamageToFighters().modifyPercent(var3, 100.0F);
      var2.getAutofireAimAccuracy().modifyFlat(var3, 0.33333334F);
   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      List var3 = var1.getAllWeapons();
      Iterator var4 = var3.iterator();

      while(var4.hasNext()) {
         WeaponAPI var5 = (WeaponAPI)var4.next();
         var5.getSpec().addTag("IGNORES_FLARES");
      }

      Iterator var7 = BLOCKED_HULLMODS.iterator();

      while(var7.hasNext()) {
         String var6 = (String)var7.next();
         if(var1.getVariant().getHullMods().contains(var6)) {
            MagicIncompatibleHullmods.removeHullmodWithWarning(var1.getVariant(), var6, "armaa_SilverSwordHM");
         }
      }

   }

   public void advanceInCombat(ShipAPI var1, float var2) {
      if(!Global.getCombatEngine().isPaused()) {
         boolean var3 = var1 == Global.getCombatEngine().getPlayerShip();
         boolean var4 = false;
         boolean var5 = Global.getCombatEngine().isInCampaign();
         if(!(Global.getCombatEngine().getCustomData().get("armaa_hasCopium_" + var1.getId()) instanceof Boolean)) {
            var4 = var1.getOwner() == 0?!var5 || Global.getSector().getPlayerFleet().getCargo().getCommodityQuantity("drugs") > 0.0F:false;
         }

         if(var1.isAlive() && !var1.isPiece()) {
            float var9;
            if(!this.dodgeBonus && !this.cooldown && var4 && !CombatUtils.getEntitiesWithinRange(var1.getLocation(), 1000.0F).isEmpty() && !var1.isFinishedLanding()) {
               ArrayList var6 = new ArrayList(100);
               var6.addAll(CombatUtils.getMissilesWithinRange(var1.getLocation(), var1.getCollisionRadius()));
               var6.addAll(CombatUtils.getProjectilesWithinRange(var1.getLocation(), var1.getCollisionRadius()));
               Iterator var7 = var6.iterator();

               while(var7.hasNext()) {
                  DamagingProjectileAPI var8 = (DamagingProjectileAPI)var7.next();
                  var9 = 0.0F;
                  if(var8.getOwner() != var1.getOwner() && !var8.isFading() && var8.getCollisionClass() != CollisionClass.NONE) {
                     if(var8 instanceof MissileAPI) {
                        MissileAPI var10 = (MissileAPI)var8;
                        if(var10.isFlare()) {
                           continue;
                        }
                     }

                     if(Global.getCombatEngine().isEntityInPlay(var8) && !var8.didDamage() && var8.getBaseDamageAmount() > 0.0F) {
                        if(var8.getDamageType() == DamageType.FRAGMENTATION) {
                           var9 = var8.getDamageAmount() * 0.5F + var8.getEmpAmount() * 0.5F;
                        } else {
                           var9 = var8.getDamageAmount() + var8.getEmpAmount() * 0.25F;
                        }

                        if(CollisionUtils.isPointWithinCollisionCircle(var8.getLocation(), var1) && (var1.getShield() == null || var1.getShield().isOff()) && !CollisionUtils.getCollides(var8.getLocation(), var8.getVelocity(), var1.getLocation(), 30.0F) && var9 >= 40.0F && !var8.didDamage()) {
                           Global.getCombatEngine().addFloatingText(var1.getLocation(), "Grazed!", 15.0F, Color.white, var8, 0.0F, 0.0F);
                           Global.getSoundPlayer().playSound("ui_neural_transfer_begin", 0.7F, 1.0F, var1.getLocation(), new Vector2f());
                           armaa_utils.blink(var1.getLocation());
                           this.dodgeBonus = true;
                        }
                     }
                  }
               }
            }

            boolean var13 = false;
            float var14 = 99999.0F;
            float var15 = 1.0F;
            float var11;
            String var12;
            float var16;
            if(this.dodgeBonus) {
               this.buffTimer.advance(var2);
               var9 = this.buffTimer.getElapsed();
               var16 = this.buffTimer.getMaxInterval();
               var15 = var9 / var16;
               this.multBonus = 3.0F * (1.0F - var15);
               var11 = (float)Math.round(var9 / var16 * 100.0F);
               var12 = String.valueOf(var11);
               Global.getCombatEngine().maintainStatusForPlayerShip("adrenal", "graphics/ui/icons/icon_search_and_destroy.png", "Grazed", "DMG +" + (int)(20.0F * (1.0F - var15)) + "%", false);
            }

            if(this.buffTimer.intervalElapsed() && this.dodgeBonus) {
               this.dodgeBonus = false;
               this.cooldown = true;
            }

            if(this.cooldown) {
               this.coolDownTimer.advance(var2);
               var15 = 0.0F;
               var9 = this.coolDownTimer.getElapsed();
               var16 = this.coolDownTimer.getMaxInterval();
               var11 = (float)Math.round(var9 / var16 * 100.0F);
               var12 = String.valueOf(var11);
               if(var3) {
                  Global.getCombatEngine().maintainStatusForPlayerShip("adrenal", "graphics/ui/icons/icon_repair_refit.png", "Crash", var12 + "%", true);
               }
            }

            if(this.coolDownTimer.intervalElapsed() && this.cooldown) {
               this.cooldown = false;
               var15 = 0.0F;
            }

            var1.getMutableStats().getTimeMult().modifyMult(var1.getId(), 1.15F + this.multBonus);
            if(!this.cooldown && !this.dodgeBonus) {
               this.multBonus = 0.0F;
               var1.getMutableStats().getEnergyWeaponDamageMult().unmodify(var1.getId() + "_graze");
               var1.getMutableStats().getBallisticWeaponDamageMult().unmodify(var1.getId() + "_graze");
            } else {
               var1.getMutableStats().getEnergyWeaponDamageMult().modifyPercent(var1.getId() + "_graze", 20.0F * (1.0F - var15));
               var1.getMutableStats().getBallisticWeaponDamageMult().modifyPercent(var1.getId() + "_graze", 20.0F * (1.0F - var15));
            }

            if(var3 && var1.isAlive()) {
               Iterator var17 = CombatUtils.getEntitiesWithinRange(var1.getLocation(), 1000.0F).iterator();

               while(var17.hasNext()) {
                  CombatEntityAPI var18 = (CombatEntityAPI)var17.next();
                  if(var18.getOwner() != var1.getOwner() && var18.getOwner() != 100) {
                     var13 = true;
                     if(!var1.isLanding() && !var1.isFinishedLanding()) {
                        Global.getCombatEngine().maintainStatusForPlayerShip("timeflow", "graphics/icons/hullsys/temporal_shell.png", "Heightened Reaction", "Timeflow at " + (int)(100.0F + (1.15F + this.multBonus - 1.0F) * 100.0F) + "%", true);
                        break;
                     }
                  }
               }

               if(var13 && !var1.isLanding() && !var1.isFinishedLanding()) {
                  var9 = 1.0F / (1.15F + this.multBonus);
                  Global.getCombatEngine().getTimeMult().modifyMult(var1.getId(), var9);
               }
            } else {
               Global.getCombatEngine().getTimeMult().unmodify(var1.getId());
            }

         } else {
            Global.getCombatEngine().getTimeMult().unmodify(var1.getId());
         }
      }
   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"" + Math.round(100.0F) + "%":(var1 == 1?"incompatible with Safety Overrides.":(var1 == 2?"additional large scale modifications cannot be made to the hull":null));
   }

   static {
      BLOCKED_HULLMODS.add("pointdefenseai");
      BLOCKED_HULLMODS.add("safetyoverrides");
      BLOCKED_HULLMODS.add("armaa_silverSwordHM");
   }
}
