package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.CombatEngineAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class armaa_legEngineCheck extends BaseHullMod {

   private boolean isWeaponSwapped = false;
   private boolean anchordead = false;
   private boolean runOnce = false;
   protected List toRemove = new ArrayList();


   public void advanceInCombat(ShipAPI var1, float var2) {
      ShipAPI var3 = var1.getParentStation();
      CombatEngineAPI var4 = Global.getCombatEngine();
      if(var3 != null) {
         this.getBP(var3, var4);
         if(Global.getCombatEngine().getCustomData().get("armaa_backpack" + var3.getId()) instanceof String) {
            String var5 = (String)Global.getCombatEngine().getCustomData().get("armaa_backpack" + var3.getId());
            if(var5 == var3.getId()) {
               List var6 = var3.getChildModulesCopy();
               boolean var7 = true;
               Iterator var8 = var6.iterator();

               while(var8.hasNext()) {
                  ShipAPI var9 = (ShipAPI)var8.next();
                  var9.ensureClonedStationSlotSpec();
                  if(var9.getStationSlot() != null && var9.getStationSlot().getId().equals("SKIRT")) {
                     var7 = false;
                  }
               }

               if(var7) {
                  var1.setHitpoints(0.0F);
               }
            }
         }

      }
   }

   public void getBP(ShipAPI var1, CombatEngineAPI var2) {
      List var3 = var1.getChildModulesCopy();
      Iterator var4 = var3.iterator();

      while(var4.hasNext()) {
         ShipAPI var5 = (ShipAPI)var4.next();
         var5.ensureClonedStationSlotSpec();
         if(var5.getStationSlot() != null && var5.getStationSlot().getId().equals("SKIRT")) {
            Global.getCombatEngine().getCustomData().put("armaa_backpack" + var1.getId(), var1.getId());
            break;
         }
      }

   }
}
