package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipHullSpecAPI;
import com.fs.starfarer.api.combat.ShipVariantAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import com.fs.starfarer.api.fleet.FleetMemberAPI;
import com.fs.starfarer.api.impl.hullmods.CompromisedStructure;
import com.fs.starfarer.api.loading.HullModSpecAPI;
import com.fs.starfarer.api.ui.Alignment;
import com.fs.starfarer.api.ui.LabelAPI;
import com.fs.starfarer.api.ui.TooltipMakerAPI;
import com.fs.starfarer.api.util.Misc;
import java.awt.Color;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import org.magiclib.util.MagicIncompatibleHullmods;

public class cataphract2 extends BaseHullMod {

   private static final float PARA_PAD = 10.0F;
   private String ERROR = "IncompatibleHullmodWarning";
   private static final Set BLOCKED_HULLMODS = new HashSet();
   public static final Map GROUND_BONUS = new HashMap();
   private final float EMP_RESIST = 33.0F;
   private final float DISABLE_RESIST = 66.0F;
   private static final float CR_PENALTY = 0.1F;
   private final float MISSILES_DEBUFF = 0.25F;
   public static float SMOD_BONUS;
   private final Color E = Global.getSettings().getColor("textEnemyColor");
   private final Color dark = Global.getSettings().getColor("textGrayColor");
   float pad = 10.0F;
   float padS = 2.0F;
   final Color flavor = new Color(110, 110, 110, 255);


   public static float getCRPenalty(ShipVariantAPI var0) {
      float var1 = 1.0F;
      Collection var2 = var0.getHullMods();
      Iterator var3 = var2.iterator();

      while(var3.hasNext()) {
         String var4 = (String)var3.next();
         HullModSpecAPI var5 = Global.getSettings().getHullModSpec(var4);
         if(var5.hasTag("dmod")) {
            var1 /= CompromisedStructure.DEPLOYMENT_COST_MULT;
         }
      }

      return var1 * 0.1F;
   }

   public static String getNonDHullId(ShipHullSpecAPI var0) {
      return var0 == null?null:(var0.getDParentHullId() != null && !var0.getDParentHullId().isEmpty()?var0.getDParentHullId():var0.getHullId());
   }

   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      var2.getEmpDamageTakenMult().modifyMult(var3, 0.67F);
      var2.getEngineDamageTakenMult().modifyMult(var3, 0.34F);
      var2.getWeaponDamageTakenMult().modifyMult(var3, 0.34F);
      boolean var4 = var2.getVariant().getSModdedBuiltIns().contains("cataphract2") || this.isSMod(var2);
      if(var4 && var2.getFleetMember() != null) {
         float var5 = (float)var2.getFleetMember().getCaptain().getStats().getLevel();
         int var6 = (int)var2.getFleetMember().getDeploymentPointsCost();
         var2.getEnergyRoFMult().modifyMult(var3, 1.0F + SMOD_BONUS * var5 / 2.0F * 0.01F);
         var2.getBallisticRoFMult().modifyMult(var3, 1.0F + SMOD_BONUS * var5 / 2.0F * 0.01F);
         var2.getFluxDissipation().modifyMult(var3, 1.0F + SMOD_BONUS * var5 * 0.01F);
         var2.getAutofireAimAccuracy().modifyMult(var3, SMOD_BONUS * var5 * 0.01F);
         var2.getMaxTurnRate().modifyMult(var3, 1.0F + SMOD_BONUS * var5 * 0.01F);
         var2.getTurnAcceleration().modifyMult(var3, 1.0F + SMOD_BONUS * var5 * 0.01F);
         var2.getDynamic().getMod("deployment_points_mod").modifyFlat(var3, (float)var6 * SMOD_BONUS * var5 * 0.01F);
      }

   }

   public boolean isSModEffectAPenalty() {
      return false;
   }

   public String getSModDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"" + (int)SMOD_BONUS + "%":null;
   }

   public void advanceInCampaign(FleetMemberAPI var1, float var2) {
      float var3 = var1.getCaptain().isDefault()?0.0F:(float)var1.getCaptain().getStats().getLevel() * 1.5F;
      if(var1.getRepairTracker().getBaseCR() >= getCRPenalty(var1.getVariant())) {
         if(GROUND_BONUS.get(var1.getHullSpec().getBaseHullId()) != null) {
            var1.getStats().getDynamic().getMod("ground_support").modifyFlat("id", ((Float)GROUND_BONUS.get(var1.getHullSpec().getBaseHullId())).floatValue() + var3);
         }
      } else {
         var1.getStats().getDynamic().getMod("ground_support").unmodify("id");
      }

   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      Iterator var3 = BLOCKED_HULLMODS.iterator();

      while(var3.hasNext()) {
         String var4 = (String)var3.next();
         if(var1.getVariant().getNonBuiltInHullmods().contains(var4)) {
            MagicIncompatibleHullmods.removeHullmodWithWarning(var1.getVariant(), var4, "cataphract");
         }
      }

   }

   public void addPostDescriptionSection(TooltipMakerAPI var1, HullSize var2, ShipAPI var3, float var4, boolean var5) {
      float var6 = 10.0F;
      float var7 = 2.0F;
      float var8 = var3.getCaptain().isDefault()?0.0F:(float)var3.getCaptain().getStats().getLevel() * 1.5F;
      float var9 = 15.0F;
      Color var10 = new Color(110, 110, 110, 255);
      if(GROUND_BONUS.get(var3.getHullSpec().getHullId()) != null) {
         var9 = ((Float)GROUND_BONUS.get(var3.getHullSpec().getHullId())).floatValue();
      }

      float var11 = 25.0F;
      int var12 = (int)(var9 + var8);
      var1.addSectionHeading("Details", Alignment.MID, 10.0F);
      var1.addPara("%s EMP Resistance increased by %s.", var6, Misc.getHighlightColor(), new String[]{"•", "33%"});
      var1.addPara("%s Weapons and engines are %s less likely to be disabled.", var7, Misc.getHighlightColor(), new String[]{"•", "66%"});
      var1.addPara("%s Increases effective strength of ground ops by %s, (up to number of marines in the fleet)", var7, Misc.getHighlightColor(), new String[]{"•", Integer.toString(var12)});
      var1.addPara("%s Ground deployments consume %s CR.", var7, Misc.getHighlightColor(), new String[]{"•", "" + Math.round(getCRPenalty(var3.getVariant()) * 100.0F) + "%"});
      var1.addPara("%s Large modifications cannot be made, %s.", var7, Misc.getHighlightColor(), new String[]{"•", "precluding the addition of several hullmods"});
      var1.addPara("%s", 6.0F, var10, new String[]{"\"Morning! How\'s it feel to be strapped to a walking metal coffin at six AM? Bet you wish you studied harder at the academy! Hit the throttle. We\'re going to be killing people before breakfast today.\""}).italicize();
      var1.addPara("%s", 1.0F, var10, new String[]{"         — Savarin Johnson, c. 192"});
      var1.addSectionHeading("Incompatibilities", Alignment.MID, 10.0F);
      String var13 = "";
      int var14 = BLOCKED_HULLMODS.size();
      int var15 = 0;
      Color[] var16 = new Color[]{Misc.getHighlightColor(), this.E};
      Iterator var17 = Global.getSettings().getAllHullModSpecs().iterator();

      while(var17.hasNext()) {
         HullModSpecAPI var18 = (HullModSpecAPI)var17.next();
         Iterator var19 = BLOCKED_HULLMODS.iterator();

         while(var19.hasNext()) {
            String var20 = (String)var19.next();
            if(var18.getId().equals(var20)) {
               ++var15;
               var13 = var13 + var18.getDisplayName();
               if(var15 != var14 - 1) {
                  var13 = var13 + ", ";
               }
            }
         }
      }

      var13 = var13.substring(0, var13.length() - 2);
      var1.addPara("%s Incompatible with %s.", var6, var16, new String[]{"•", "" + var13});
      float var21;
      if(getCRPenalty(var3.getVariant()) > 0.1F) {
         var21 = 100.0F * (getCRPenalty(var3.getVariant()) / 0.1F - 1.0F);
         var1.addPara("CR Deployment cost is penalized by %s due to hull defects.", 10.0F, Misc.getNegativeHighlightColor(), new String[]{"" + Math.round(var21) + "%"});
      }

      var21 = var3.getCurrentCR();
      if(var3.getFleetMember() != null) {
         var21 = var3.getFleetMember().getRepairTracker().getBaseCR();
      }

      if(var21 < getCRPenalty(var3.getVariant())) {
         LabelAPI var22 = var1.addPara("Insufficient CR for deployment!", Misc.getNegativeHighlightColor(), 10.0F);
      }

   }

   public void addSModEffectSection(TooltipMakerAPI var1, HullSize var2, ShipAPI var3, float var4, boolean var5, boolean var6) {
      Color var7 = this.flavor;
      boolean var8 = var3.getVariant().getSModdedBuiltIns().contains("cataphract2") || this.isSMod(var3.getMutableStats());
      if(var8) {
         var7 = Misc.getStoryBrightColor();
      }

      float var9 = var3.getCaptain().isDefault()?0.0F:(float)var3.getCaptain().getStats().getLevel();
      float var10 = SMOD_BONUS;
      var1.addPara("%s Increases flux dissipation, turning rate, and autofire accuracy by %s per pilot level. The current increase is %s.", this.pad, var7, Misc.getHighlightColor(), new String[]{"•", "" + (int)var10 + "%", (int)(var10 * var9) + "%"});
      var1.addPara("%s Increases non-missile ROF by %s per pilot level. The current increase is %s.", this.pad, var7, Misc.getHighlightColor(), new String[]{"•", "" + (int)var10 / 2 + "%", (int)(var10 * var9) / 2 + "%"});
      var1.addPara("%s Increases deployment cost by %s.", this.pad, var7, Misc.getHighlightColor(), new String[]{"•", "" + (int)(var10 * var9) + "%", (int)(var10 * var9) + "%"});
   }

   static {
      BLOCKED_HULLMODS.add("converted_hangar");
      BLOCKED_HULLMODS.add("cargo_expansion");
      BLOCKED_HULLMODS.add("additional_crew_quarters");
      BLOCKED_HULLMODS.add("fuel_expansion");
      BLOCKED_HULLMODS.add("additional_berthing");
      BLOCKED_HULLMODS.add("auxiliary_fuel_tanks");
      BLOCKED_HULLMODS.add("expanded_cargo_holds");
      BLOCKED_HULLMODS.add("surveying_equipment");
      BLOCKED_HULLMODS.add("recovery_shuttles");
      BLOCKED_HULLMODS.add("operations_center");
      BLOCKED_HULLMODS.add("expanded_deck_crew");
      BLOCKED_HULLMODS.add("combat_docking_module");
      BLOCKED_HULLMODS.add("roider_fighterClamps");
      GROUND_BONUS.put("armaa_einhander", Float.valueOf(25.0F));
      GROUND_BONUS.put("armaa_aleste_frig", Float.valueOf(25.0F));
      GROUND_BONUS.put("armaa_leynos_frig", Float.valueOf(25.0F));
      GROUND_BONUS.put("armaa_leynos_frig_comet", Float.valueOf(25.0F));
      GROUND_BONUS.put("armaa_valkazard", Float.valueOf(50.0F));
      GROUND_BONUS.put("armaa_valkenx_frig", Float.valueOf(25.0F));
      SMOD_BONUS = 2.0F;
   }
}
