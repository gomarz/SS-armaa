package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ViewportAPI;
import com.fs.starfarer.api.graphics.SpriteAPI;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lwjgl.opengl.Display;
import org.lwjgl.opengl.GL11;
import org.lwjgl.util.vector.Vector2f;
import org.magiclib.util.MagicUI;
import org.magiclib.util.ui.StatusBarData;

public class armaa_KarmaMod_Command extends BaseHullMod {

   protected float karma = 0.0F;
   private static final float BONUS_AMT = 1.15F;
   protected static int karmaThreshold = 2000;
   private static final Color AFTERIMAGE_COLOR = new Color(149, 206, 240, 102);
   private static final float AFTERIMAGE_THRESHOLD = 0.4F;
   private static final List SAFE_MODS = new ArrayList();
   private List targets = new ArrayList();
   private List toRemove = new ArrayList();
   public static final String SPRITE_PATH = "graphics/fx/shields256.png";
   public static final Color COLOR = new Color(100, 47, 255, 185);
   public static final float ROTATION_SPEED = 20.0F;
   private SpriteAPI sprite = null;
   private boolean loaded = false;
   private float rotation = 0.0F;
   private static final float EFFECT_RANGE = 1000.0F;


   public void advanceInCombat(ShipAPI var1, float var2) {
      List var3 = var1.getChildModulesCopy();
      float var4;
      if(Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var1.getId()) instanceof Float) {
         var4 = ((Float)Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var1.getId())).floatValue();
         if(var4 > 0.0F) {
            var4 -= 0.001F;
            Global.getCombatEngine().getCustomData().put("armaa_karmaTotal" + var1.getId(), Float.valueOf(var4));
         }
      }

      if(!(Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?" + var1.getId()) instanceof Boolean)) {
         Global.getCombatEngine().getCustomData().put("armaa_hullmodsDone?" + var1.getId(), Boolean.valueOf(false));
      }

      if(Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?" + var1.getId()) instanceof Boolean && !((Boolean)Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?" + var1.getId())).booleanValue() && var3 != null && !var3.isEmpty()) {
         Iterator var13 = var3.iterator();

         while(var13.hasNext()) {
            ShipAPI var5 = (ShipAPI)var13.next();
            var5.ensureClonedStationSlotSpec();
            Collection var6 = var1.getVariant().getHullMods();
            ArrayList var7 = new ArrayList();
            var7.addAll(var6);
            Collection var8 = var5.getVariant().getHullMods();
            ArrayList var9 = new ArrayList();
            var9.addAll(var8);
            var9.removeAll(SAFE_MODS);
            if(!var6.isEmpty()) {
               int var10;
               for(var10 = 0; var10 < var7.size(); ++var10) {
                  if(!var5.getVariant().hasHullMod((String)var7.get(var10))) {
                     var5.getVariant().addMod((String)var7.get(var10));
                  }
               }

               if(!var9.isEmpty()) {
                  for(var10 = 0; var10 < var9.size(); ++var10) {
                     if(!var1.getVariant().hasHullMod((String)var9.get(var10))) {
                        var5.getVariant().removeMod((String)var9.get(var10));
                     }
                  }
               }
            }
         }

         Global.getCombatEngine().getCustomData().put("armaa_hullmodsDone?" + var1.getId(), Boolean.valueOf(true));
         Global.getCombatEngine().getCustomData().put("armaa_hullmodsDoneCheck" + var1.getId(), Boolean.valueOf(true));
      }

      float var15;
      float var16;
      if(Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var1.getId()) instanceof Float) {
         String var14 = "armaa_karma" + var1.getId();
         var15 = ((Float)Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var1.getId())).floatValue();
         var16 = var15 * 1.15F;
         if(var15 > 0.0F) {
            if(this.sprite == null) {
               if(!this.loaded) {
                  try {
                     Global.getSettings().loadTexture("graphics/fx/shields256.png");
                  } catch (IOException var12) {
                     throw new RuntimeException("Failed to load sprite \'graphics/fx/shields256.png\'!", var12);
                  }

                  this.loaded = true;
               }

               this.sprite = Global.getSettings().getSprite("graphics/fx/shields256.png");
            }

            Vector2f var17 = var1.getLocation();
            ViewportAPI var19 = Global.getCombatEngine().getViewport();
            if(var19.isNearViewport(var17, 1000.0F)) {
               GL11.glPushAttrib(8192);
               GL11.glMatrixMode(5889);
               GL11.glPushMatrix();
               GL11.glViewport(0, 0, Display.getWidth(), Display.getHeight());
               GL11.glOrtho(0.0D, (double)Display.getWidth(), 0.0D, (double)Display.getHeight(), -1.0D, 1.0D);
               GL11.glEnable(3553);
               GL11.glEnable(3042);
               float var22 = 2000.0F / var19.getViewMult();
               this.sprite.setSize(var22, var22);
               this.sprite.setColor(COLOR);
               this.sprite.setAlphaMult(0.3F * var15);
               this.sprite.renderAtCenter(var19.convertWorldXtoScreenX(var17.x), var19.convertWorldYtoScreenY(var17.y));
               this.sprite.setAngle(this.rotation);
               GL11.glPopMatrix();
               GL11.glPopAttrib();
            }

            this.rotation += 20.0F * var2;
            if(this.rotation > 360.0F) {
               this.rotation -= 360.0F;
            }
         }

         Iterator var18;
         ShipAPI var21;
         if(var15 > 0.0F) {
            var18 = CombatUtils.getShipsWithinRange(var1.getLocation(), 1000.0F).iterator();

            while(var18.hasNext()) {
               var21 = (ShipAPI)var18.next();
               if(var21.getOwner() == var1.getOwner() && var21 != var1 && !var3.contains(var21) && !var21.isHulk() && !this.targets.contains(var21)) {
                  this.targets.add(var21);
               }
            }
         }

         if(!this.targets.isEmpty()) {
            var18 = this.targets.iterator();

            while(var18.hasNext()) {
               var21 = (ShipAPI)var18.next();
               boolean var23 = var21 == Global.getCombatEngine().getPlayerShip();
               MutableShipStatsAPI var24 = var21.getMutableStats();
               if(MathUtils.getDistance(var21.getLocation(), var1.getLocation()) <= 1000.0F && var15 > 0.0F && var21 != var1) {
                  float var11 = 1.0F + 0.14999998F * var15;
                  var24.getTimeMult().modifyMult(var14, var11);
                  if(var23) {
                     Global.getCombatEngine().getTimeMult().modifyMult(var14, 1.0F / var11);
                     Global.getCombatEngine().maintainStatusForPlayerShip(var1.getId(), "graphics/icons/hullsys/entropy_amplifier.png", "Time Flow Altered", "+" + (int)((var11 - 1.0F) * 100.0F) + "% TIME DILATION ", false);
                  }

                  var21.setJitter(var1, new Color(100, 142, 255, 100), 1.0F * var15, 5, 5.0F, 25.0F);
               } else {
                  var24.getTimeMult().unmodify(var14);
                  if(var23) {
                     Global.getCombatEngine().getTimeMult().unmodify(var14);
                  }

                  this.toRemove.add(var21);
               }
            }
         }

         if(!this.toRemove.isEmpty()) {
            this.targets.removeAll(this.toRemove);
            this.toRemove.removeAll(this.toRemove);
         }

         if(!this.targets.isEmpty() && var15 > 0.0F) {
            this.targets.removeAll(this.targets);
         }

         StatusBarData var20 = new StatusBarData(var1, var15, Color.red, Color.green, 0.0F, "KARMA", (int)var15);
         var20.drawToScreen(new Vector2f());
         MagicUI.drawSystemBar(var1, Color.red, var15, 0.0F);
      }

      if(Global.getCombatEngine().getCustomData().get("armaa_hasGainedKarma" + var1.getId()) instanceof Boolean && ((Boolean)Global.getCombatEngine().getCustomData().get("armaa_hasGainedKarma" + var1.getId())).booleanValue()) {
         var4 = ((Float)Global.getCombatEngine().getCustomData().get("armaa_gainedKarmaAount" + var1.getId())).floatValue();
         if(Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var1.getId()) instanceof Float) {
            var15 = ((Float)Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var1.getId())).floatValue();
            var16 = var15 + var4;
            Global.getCombatEngine().getCustomData().put("armaa_karmaTotal" + var1.getId(), Float.valueOf(var16));
         }

         Global.getCombatEngine().getCustomData().put("armaa_hasGainedKarma" + var1.getId(), Boolean.valueOf(false));
         Global.getCombatEngine().getCustomData().put("armaa_gainedKarmaAount" + var1.getId(), Float.valueOf(0.0F));
      }

   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      if(Global.getCombatEngine() != null) {
         Global.getCombatEngine().getCustomData().put("armaa_hullmodsDone?" + var1.getId(), Boolean.valueOf(false));
         Global.getCombatEngine().getCustomData().put("armaa_karmaTotal" + var1.getId(), Float.valueOf(0.0F));
      }

   }

   public static float getKarma(String var0) {
      float var1 = 0.0F;
      if(Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var0) instanceof Float) {
         var1 = ((Float)Global.getCombatEngine().getCustomData().get("armaa_karmaTotal" + var0)).floatValue();
      }

      return var1;
   }

   public static float getKarmaThreshold() {
      return (float)karmaThreshold;
   }

   static {
      SAFE_MODS.add("armaa_legmodule");
      SAFE_MODS.add("reduced_explosion");
      SAFE_MODS.add("always_detaches");
      SAFE_MODS.add("novent");
      SAFE_MODS.add("leg_engine");
   }
}
