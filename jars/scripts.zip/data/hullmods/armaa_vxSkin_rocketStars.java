package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class armaa_vxSkin_rocketStars extends BaseHullMod {

   public int getDisplaySortOrder() {
      return 2000;
   }

   public int getDisplayCategoryIndex() {
      return 3;
   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"Gauss":(var1 == 1?"Remove this hullmod to cycle between weapons.":null);
   }
}
