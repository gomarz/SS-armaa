package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.CargoStackAPI;
import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import org.lazywizard.lazylib.MathUtils;

public class armaa_weaponSwap_monitor extends BaseHullMod {

   public Map RIGHT_SELECTOR = new HashMap();
   private final Map SWITCH_TO_RIGHT;
   private final Map RIGHTSWITCH;
   private final String leftslotID;
   private final String rightslotID;


   public armaa_weaponSwap_monitor() {
      this.RIGHT_SELECTOR.put(Integer.valueOf(0), "armaa_monitor_rightArm_gauss");
      this.RIGHT_SELECTOR.put(Integer.valueOf(1), "armaa_monitor_rightArm");
      this.SWITCH_TO_RIGHT = new HashMap();
      this.SWITCH_TO_RIGHT.put("armaa_monitor_rightArm_gauss", Integer.valueOf(1));
      this.SWITCH_TO_RIGHT.put("armaa_monitor_rightArm", Integer.valueOf(0));
      this.RIGHTSWITCH = new HashMap();
      this.RIGHTSWITCH.put(Integer.valueOf(0), "armaa_selector_gauss");
      this.RIGHTSWITCH.put(Integer.valueOf(1), "armaa_selector_hellbore");
      this.leftslotID = "E_LARM";
      this.rightslotID = "E_RARM";
   }

   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      boolean var4 = true;
      int var5 = 0;

      int var6;
      for(var6 = 0; var6 < this.SWITCH_TO_RIGHT.size(); ++var6) {
         if(var2.getVariant().getHullMods().contains(this.RIGHTSWITCH.get(Integer.valueOf(var6)))) {
            var4 = false;
            ++var5;
         }
      }

      if(var4) {
         boolean var7 = false;
         if(var2.getVariant().getWeaponSpec("E_RARM") != null) {
            var6 = ((Integer)this.SWITCH_TO_RIGHT.get(var2.getVariant().getWeaponSpec("E_RARM").getWeaponId())).intValue();
         } else {
            var6 = MathUtils.getRandomNumberInRange(0, this.SWITCH_TO_RIGHT.size() - 1);
            var7 = true;
         }

         var2.getVariant().addMod((String)this.RIGHTSWITCH.get(Integer.valueOf(var6)));
         var2.getVariant().clearSlot("E_RARM");
         String var8 = (String)this.RIGHT_SELECTOR.get(Integer.valueOf(var6));
         var2.getVariant().addWeapon("E_RARM", var8);
         if(var7) {
            var2.getVariant().autoGenerateWeaponGroups();
         }
      }

   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      if(var1.getOriginalOwner() < 0 && Global.getSector() != null && Global.getSector().getPlayerFleet() != null && Global.getSector().getPlayerFleet().getCargo() != null && Global.getSector().getPlayerFleet().getCargo().getStacksCopy() != null && !Global.getSector().getPlayerFleet().getCargo().getStacksCopy().isEmpty()) {
         Iterator var3 = Global.getSector().getPlayerFleet().getCargo().getStacksCopy().iterator();

         while(var3.hasNext()) {
            CargoStackAPI var4 = (CargoStackAPI)var3.next();
            if(var4.isWeaponStack() && this.RIGHT_SELECTOR.containsValue(var4.getWeaponSpecIfWeapon().getWeaponId())) {
               Global.getSector().getPlayerFleet().getCargo().removeStack(var4);
            }
         }
      }

   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"A":(var1 == 1?"B":(var1 == 2?"C":(var1 == 3?"D":null)));
   }

   public boolean isApplicableToShip(ShipAPI var1) {
      return var1.getHullSpec().getHullId().startsWith("armaa_");
   }
}
