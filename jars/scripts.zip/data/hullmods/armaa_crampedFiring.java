package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;

public class armaa_crampedFiring extends BaseHullMod {

   public static final float DAMAGE_BONUS = 30.0F;


   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      var2.getBallisticRoFMult().modifyMult(var3, 0.7F);
   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"" + Math.round(30.0F) + "%":null;
   }
}
