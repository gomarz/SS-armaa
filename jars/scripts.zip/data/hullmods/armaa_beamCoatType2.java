package data.hullmods;

import com.fs.starfarer.api.combat.BaseHullMod;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.combat.ShipAPI;
import com.fs.starfarer.api.combat.ShipAPI.HullSize;
import data.scripts.util.MagicIncompatibleHullmods;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public class armaa_beamCoatType2 extends BaseHullMod {

   public static final float BEAM_DAMAGE_REDUCTION = 0.4F;
   private static final Set BLOCKED_HULLMODS = new HashSet();


   public void applyEffectsBeforeShipCreation(HullSize var1, MutableShipStatsAPI var2, String var3) {
      var2.getBeamDamageTakenMult().modifyMult(var3, 0.4F);
   }

   public void applyEffectsAfterShipCreation(ShipAPI var1, String var2) {
      Iterator var3 = BLOCKED_HULLMODS.iterator();

      while(var3.hasNext()) {
         String var4 = (String)var3.next();
         if(var1.getVariant().getHullMods().contains(var4)) {
            MagicIncompatibleHullmods.removeHullmodWithWarning(var1.getVariant(), var4, "cataphract");
         }
      }

   }

   public String getDescriptionParam(int var1, HullSize var2) {
      return var1 == 0?"" + Math.round(60.000004F) + "%":(var1 == 1?"Heavy Armor":null);
   }

   static {
      BLOCKED_HULLMODS.add("heavyarmor");
   }
}
