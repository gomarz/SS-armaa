package data.scripts.shipsystems;

import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import com.fs.starfarer.api.impl.combat.BaseShipSystemScript;
import com.fs.starfarer.api.plugins.ShipSystemStatsScript;
import com.fs.starfarer.api.Global;
import org.lazywizard.lazylib.combat.CombatUtils;
import org.lazywizard.lazylib.CollisionUtils;
import org.lazywizard.lazylib.combat.DefenseUtils;
import org.lwjgl.util.vector.Vector2f;
import org.lazywizard.lazylib.MathUtils;
import com.fs.starfarer.api.combat.ShipAPI;
import data.scripts.util.armaa_utils;
import java.awt.Color;
import java.util.Random;
import com.fs.starfarer.api.combat.WeaponAPI;
import com.fs.starfarer.api.loading.WeaponSlotAPI;
import com.fs.starfarer.api.combat.WeaponGroupAPI;
import com.fs.starfarer.api.combat.MissileRenderDataAPI;
import com.fs.starfarer.api.combat.FighterWingAPI;
import com.fs.starfarer.api.combat.FighterLaunchBayAPI;
public class armaa_TravelDriveStats extends BaseShipSystemScript {

private boolean carriersNearby = false;
private boolean runOnce = false;
private WeaponSlotAPI w;
private	Vector2f takeoffLoc = null;
private ShipAPI carrier;

	public void apply(MutableShipStatsAPI stats, String id, State state, float effectLevel) 
	{
		ShipAPI ship = (ShipAPI)stats.getEntity();
		boolean standardDeploy = ship.getFacing() == 90f ? true:false;
		if(getNearestCarrier(ship) ==null || ship.isRetreating() || !standardDeploy)
		{
			if (state == ShipSystemStatsScript.State.OUT) {
				stats.getMaxSpeed().unmodify(id); // to slow down ship to its regular top speed while powering drive down
			} else {
				stats.getMaxSpeed().modifyFlat(id, 300f * effectLevel);
				stats.getAcceleration().modifyFlat(id, 300f * effectLevel);
				//stats.getAcceleration().modifyPercent(id, 200f * effectLevel);
			}
		}
		
		//Carriers detected "launch" from them
		else
		{		
			if(!ship.isLanding()&& !runOnce)
			{
				carrier = getNearestCarrier(ship);
				for(WeaponAPI w: ship.getAllWeapons())
				{
					if(w.getSprite() != null)
						w.getSprite().setColor(new Color(0,0,0,0));
					
					if(w.getBarrelSpriteAPI() != null)
						w.getBarrelSpriteAPI().setColor(new Color(0,0,0,0));
					
					if(w.getUnderSpriteAPI() != null)
						w.getUnderSpriteAPI().setColor(new Color(0,0,0,0));
					
					if(w.getMissileRenderData() != null)
					{
						for(MissileRenderDataAPI m: w.getMissileRenderData())
							if(m.getSprite() != null)
								m.getSprite().setColor(new Color(0,0,0,0));
					}
				}
				ship.getSpriteAPI().setColor(new Color(0,0,0,0));
				ship.getVelocity().set(0,0);
				ship.setLaunchingShip(carrier);
				//ship.setControlsLocked(true); 
				//ship.getEngineController().fadeToOtherColor(new Object(), new Color(0f,0f,0f), new Color(0f,0f,0f), float effectLevel, float maxBlend) 
				ship.beginLandingAnimation(carrier);
				runOnce = true;

				for(FighterLaunchBayAPI wep:carrier.getLaunchBaysCopy())
				{
					if(wep.getWeaponSlot() != null)
					{
						w = wep.getWeaponSlot();
						takeoffLoc = new Vector2f(carrier.getLocation().x+w.getLocation().y, carrier.getLocation().y+w.getLocation().x);
						
						if(Math.random() <= .50f)
							break;
					}
				}
			}
				if(w != null)
					takeoffLoc = new Vector2f(carrier.getLocation().x+w.getLocation().y, carrier.getLocation().y+w.getLocation().x);
				else
					takeoffLoc = carrier.getLocation();
			armaa_utils.setLocation(ship,takeoffLoc);			
			if(ship.isFinishedLanding())
			{
				for(WeaponAPI w: ship.getAllWeapons())
				{
					if(w.getSprite() != null)
						w.getSprite().setColor(new Color(255,255,255,255));
					
					if(w.getBarrelSpriteAPI() != null)
						w.getBarrelSpriteAPI().setColor(new Color(255,255,255,255));
										
					if(w.getUnderSpriteAPI() != null)
						w.getUnderSpriteAPI().setColor(new Color(255,255,255,255));
					
					if(w.getMissileRenderData() != null)
					{
						for(MissileRenderDataAPI m: w.getMissileRenderData())
							if(m.getSprite() != null)
								m.getSprite().setColor(new Color(255,255,255,255));
					}
				}		

				//armaa_utils.setLocation(ship,takeoffLoc);
				ship.getSpriteAPI().setColor(new Color(255,255,255,255));
				Global.getSoundPlayer().playSound("fighter_takeoff", 1f, 1f, ship.getLocation(),new Vector2f());
				ship.setAnimatedLaunch();
				//ship.setControlsLocked(false); 
				
				carrier.getFluxTracker().showOverloadFloatyIfNeeded("Good luck out there!", Color.white, 2f, true);
				Global.getSoundPlayer().playSound("ui_noise_static", 1f+MathUtils.getRandomNumberInRange(-0.3f, .3f), 1f, carrier.getLocation(),new Vector2f());
				ship.getVelocity().set(carrier.getVelocity());
				for(WeaponGroupAPI w:ship.getWeaponGroupsCopy())
				{
					if(!w.getActiveWeapon().usesAmmo())
						w.toggleOn();
				}		
				ship.getTravelDrive().deactivate();
			}
		}
	}
	
	public void unapply(MutableShipStatsAPI stats, String id) 
	{
		ShipAPI ship = (ShipAPI)stats.getEntity();
		if(ship.isFinishedLanding() || ship.isLanding())
		{
			//ship.getVelocity().set(0,0);
			//ship.fadeToColor(new Object(), new Color(255,255,255,255), 0.1f, 0.1f, 1f);
			//ship.setAnimatedLaunch();
		}

		stats.getMaxSpeed().unmodify(id);
		stats.getMaxTurnRate().unmodify(id);
		stats.getTurnAcceleration().unmodify(id);
		stats.getAcceleration().unmodify(id);
		stats.getDeceleration().unmodify(id);;
	}
	
	public StatusData getStatusData(int index, State state, float effectLevel) 
	{
		if (index == 0) {
			return new StatusData("increased engine power", false);
		}
		return null;
	}

	private ShipAPI getNearestCarrier(ShipAPI ship)
	{
		ShipAPI potCarrier = null;
		float distance = 99999f;
		for (ShipAPI carrier : CombatUtils.getShipsWithinRange(ship.getLocation(), 10000.0F)) 
		{
			if(carrier.getOwner() != ship.getOwner() || carrier.isFighter() || carrier.isFrigate() || carrier == ship)
				continue;
			if(carrier.getOwner() == ship.getOwner() && carrier.isAlly())
				continue;
			
			if(carrier.isHulk())
				continue;
			if(carrier.getNumFighterBays() > 0 && carrier.getHullSpec().getFighterBays() > 0)
			{
				if(MathUtils.getDistance(ship, carrier) < distance)
				{
					distance = MathUtils.getDistance(ship, carrier);
					potCarrier = carrier; 
					
					if(Math.random() <= .50f)
						return potCarrier;
				}
			}				
		}
		
		return potCarrier;
	}	
}
