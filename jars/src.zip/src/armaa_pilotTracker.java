package data.scripts.util;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.util.IntervalUtil;
import data.scripts.util.MagicRender;
import data.scripts.util.MagicTargeting;
import data.scripts.util.MagicLensFlare;
import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;
import org.lazywizard.lazylib.VectorUtils;
import org.lazywizard.lazylib.combat.AIUtils;
import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.util.Misc;
import com.fs.starfarer.api.util.FaderUtil;
import com.fs.starfarer.api.graphics.SpriteAPI;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Collections;
import org.lazywizard.lazylib.combat.CombatUtils;
import com.fs.starfarer.api.loading.DamagingExplosionSpec;
import com.fs.starfarer.api.input.InputEventAPI;
import java.util.Random;

import com.fs.starfarer.api.characters.*;

import data.scripts.MechaModPlugin;


public class armaa_pilotTracker extends BaseEveryFrameCombatPlugin
{
	private ShipAPI fighter;
	private String name;
	private ShipAPI ship;
	private int pilotNo;
	private IntervalUtil interval = new IntervalUtil(10f, 10f);
	private IntervalUtil openingDialogue = new IntervalUtil(1f, 10f);
	private IntervalUtil combatDialogue = new IntervalUtil(20f, 100f);
	private boolean runOnce = false;
	private boolean hasChattered = false;
	private ArrayList<String> introChatter = new ArrayList<String>();
	private ArrayList<String> combatChatter = new ArrayList<String>();
	private ArrayList<String> squadChatter_s = new ArrayList<String>();
	private ArrayList<String> squadChatter_r = new ArrayList<String>();
    public armaa_pilotTracker(ShipAPI fighter, String name,int pilotNo) 
	{	
        this.fighter = fighter;
		this.name  = name;
		this.pilotNo = pilotNo;
		this.ship = fighter.getWing().getSourceShip();
		
		for(String s : MechaModPlugin.introChatter) 
		{
			introChatter.add(s);
		}
		Collections.shuffle(introChatter, new Random());

		for(String s : MechaModPlugin.combatChatter) 
		{
			combatChatter.add(s);
		}
		Collections.shuffle(introChatter, new Random());

		for(String s : MechaModPlugin.intersquadChatter_statement) 
		{
			squadChatter_s.add(s);
		}
		Collections.shuffle(squadChatter_s, new Random());
		
		for(String s : MechaModPlugin.intersquadChatter_response) 
		{
			squadChatter_r.add(s);
		}
		Collections.shuffle(squadChatter_r, new Random());
		
    }

    @Override
	public void advance(float amount, List<InputEventAPI> events)
	{
		if(Global.getCombatEngine().isPaused())
			return;
		
		if(!introChatter.isEmpty())
		{
			if(Global.getCombatEngine().getCustomData().get("armaa_wingCommander_squadron_hasChattered_"+ship.getCaptain().getId()) instanceof Boolean)
				hasChattered = (Boolean)Global.getCombatEngine().getCustomData().get("armaa_wingCommander_squadron_hasChattered_"+ship.getCaptain().getId());

			//String squadName = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_"+ship.getCaptain().getId());
			if(!Global.getCombatEngine().isPaused())
			{
				interval.advance(amount);
				if(!runOnce && !hasChattered && fighter.getWing().getLeader() == fighter)
				{
					openingDialogue.advance(amount);
					if(openingDialogue.intervalElapsed())
					{
						if(Math.random() <= .50f)
						{
							String squadName = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_"+ship.getCaptain().getId());
							Random rand = new Random();
							int size = rand.nextInt(introChatter.size());
							String chatter = introChatter.get(size);
							Color color = fighter.isAlly() ? Misc.getHighlightColor() : Misc.getBasePlayerColor();
							Color textColor = Global.getSettings().getColor("textGrayColor");

							if(chatter.contains("$"))
							{
								String chatter2 = processSpecialStrings(fighter,ship,chatter);
								Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,squadName,Color.white,":",textColor,chatter2);
							}
							else
								Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,squadName,Color.white,":",textColor,chatter);
						}
						runOnce = true;
						Global.getCombatEngine().getCustomData().put("armaa_wingCommander_squadron_hasChattered_"+ship.getCaptain().getId(),true);
					}
				}
			}
		}
		
		combatDialogue.advance(amount);
		if(combatDialogue.intervalElapsed())
		{
			if(fighter.getShipTarget() != null)
			{
				if(Math.random() <= .40f)
				{
					Random rand = new Random();
					int size = rand.nextInt(combatChatter.size());
					String chatter = combatChatter.get(size);
					Color color = fighter.isAlly() ? Misc.getHighlightColor() : Misc.getBasePlayerColor();
					Color textColor = Global.getSettings().getColor("textGrayColor");
					String squadName = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_"+ship.getCaptain().getId());
					if(chatter.contains("$"))
					{
						String chatter2 = processSpecialStrings(fighter,ship,chatter);
						Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,name+", "+squadName,Color.white,":",textColor,chatter2);
					}
					else
						Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,name+", "+squadName,Color.white,":",textColor,chatter);
				}
			}

			else if(Math.random() <= .05f)
			{
				int count = (Integer)Global.getSector().getPersistentData().get("armaa_wingCommander_squadSize_"+ship.getCaptain().getId());
				for(int j = 0; j < count; j++)
				{
					boolean wasAssigned = false;
					Object obj = Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_"+j+"_"+ship.getCaptain().getId());
					if(obj instanceof PersonAPI && fighter.getWing().getSpec().getVariant().getHullSpec().getMinCrew() > 0)
					{
						Object bool = Global.getCombatEngine().getCustomData().get("armaa_wingCommander_wingman_"+j+"_wasAssigned_"+ship.getCaptain().getId());
						if(bool instanceof Boolean)
						{
							wasAssigned = (Boolean)Global.getCombatEngine().getCustomData().get("armaa_wingCommander_wingman_"+j+"_wasAssigned_"+ship.getCaptain().getId());
						}
						PersonAPI pilot = (PersonAPI)Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_"+j+"_"+ship.getCaptain().getId());
						if(!wasAssigned)
							continue;
						if(pilot != fighter.getCaptain())
						{
							String otherguy = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_wingman_"+j+"_"+"callsign_"+ship.getCaptain().getId());
							String squadName = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_"+ship.getCaptain().getId());
							
							Random rand = new Random();
							int size = rand.nextInt(squadChatter_r.size());
							String chatter = squadChatter_r.get(size);
							Color color = fighter.isAlly() ? Misc.getHighlightColor() : Misc.getBasePlayerColor();
							Color textColor = Global.getSettings().getColor("textGrayColor");
							
							if(chatter.contains("$"))
							{
								if(chatter.contains("$squadmember"))
								{
									String chatter2 = chatter.replace("$squadmember",name);
									chatter = chatter2;
								}
								
								String chatter2 = processSpecialStrings(fighter,ship,chatter);
								Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,otherguy+", "+squadName,Color.white,":",textColor,chatter2);
							}
							else
								Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,otherguy+", "+squadName,Color.white,":",textColor,chatter);
							
							rand = new Random();							
							size = rand.nextInt(squadChatter_s.size());
							chatter = squadChatter_s.get(size);

							if(chatter.contains("$"))
							{
								if(chatter.contains("$squadmember"))
								{
									String chatter2 = chatter.replace("$squadmember",otherguy);
									chatter = chatter2;
								}
								String chatter2 = processSpecialStrings(fighter,ship,chatter);
								Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,name+", "+squadName,Color.white,":",textColor,chatter2);
							}
							else
								Global.getCombatEngine().getCombatUI().addMessage(1,fighter,color,name+", "+squadName,Color.white,":",textColor,chatter);
							break;				
						}			
					}
				}
			}
		}
		Vector2f loc = new Vector2f(fighter.getLocation());
		loc.setY(loc.getY()+35);
		if(!Global.getCombatEngine().hasAttachedFloaty(fighter))
			Global.getCombatEngine().addFloatingTextAlways(loc, name, 10f, Misc.getPositiveHighlightColor(), fighter, 0f, 0f, 5f, amount, amount, 0f); 
		
		if (fighter== null || fighter.getHitpoints() <= 0 || !Global.getCombatEngine().isEntityInPlay(fighter)) 
		{
			Global.getCombatEngine().getCustomData().put("armaa_wingCommander_wingman_"+pilotNo+"_wasAssigned_"+ship.getCaptain().getId(),false);
			Global.getCombatEngine().removePlugin(this);
			return;
		}	
	}
	
	private String processSpecialStrings(ShipAPI fighter, ShipAPI ship,String chatter)
	{
		int side = fighter.getOwner() == 0 ? 1 : 0;
		String chatter2 = chatter;
		if(chatter2.contains("$factionnamearticle"))
		{
			
			String faction = Global.getCombatEngine().getFleetManager(side).getFleetCommander().getFaction().getDisplayNameWithArticle();
			chatter2 = chatter.replace("$factionnamearticle",faction);
			chatter = chatter2;
		}
		
		if(chatter2.contains("$factionname"))
		{
			String faction = Global.getCombatEngine().getFleetManager(side).getFleetCommander().getFaction().getDisplayName();
			chatter2 = chatter.replace("$factionname",faction);
			chatter = chatter2;
		}
		
		if(chatter2.contains("$squadronname"))
		{
			String squadName = (String)Global.getSector().getPersistentData().get("armaa_wingCommander_squadronName_"+ship.getCaptain().getId());
			chatter2 = chatter.replace("$squadronname",squadName);
			chatter = chatter2;
		}
				
		if(chatter2.contains("$squadleader"))
		{
			String squadLeader = ship.getName();
			chatter2 = chatter.replace("$squadleader",squadLeader);
			chatter = chatter2;
		}


		return chatter2;
	}
	

}