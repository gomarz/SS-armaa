package data.scripts.weapons;

import org.lwjgl.util.vector.Vector2f;
import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.impl.campaign.ids.Stats;
import com.fs.starfarer.api.util.IntervalUtil;
import com.fs.starfarer.api.SettingsAPI;
import org.lazywizard.lazylib.VectorUtils;
import com.fs.starfarer.api.util.Misc;

import data.scripts.util.MagicRender;
import data.scripts.util.MagicLensFlare;
import data.scripts.plugins.MagicTrailPlugin;
import java.util.List;
import java.util.ArrayList;

import org.lazywizard.lazylib.combat.CombatUtils;

import java.awt.Color;
import org.lazywizard.lazylib.MathUtils;


public class armaa_valkenBlade implements BeamEffectPlugin {

	private IntervalUtil fireInterval = new IntervalUtil(0.05f, 0.05f);

	private final Vector2f ZERO = new Vector2f();
	private final float BLADE_KNOCKBACK_MAX = 300f;
    // -- stuff for tweaking particle characteristics ------------------------
    // color of spawned particles
    private static final Color PARTICLE_COLOR = new Color(250,236,111,255);
    // size of spawned particles (possibly in pixels?)
    private static final float PARTICLE_SIZE = 4f;
    // brightness of spawned particles (i have no idea what this ranges from)
    private static final float PARTICLE_BRIGHTNESS = 150f;
    // how long the particles last (i'm assuming this is in seconds)
    private static final float PARTICLE_DURATION = .8f;
    private static final int PARTICLE_COUNT = 4;

    // -- particle geometry --------------------------------------------------
    // cone angle in degrees
    private static final float CONE_ANGLE = 150f;
    // constant that effects the lower end of the particle velocity
    private static final float VEL_MIN = 0.1f;
    // constant that effects the upper end of the particle velocity
    private static final float VEL_MAX = 0.3f;

    // one half of the angle. used internally, don't mess with thos
    private static final float A_2 = CONE_ANGLE / 2;
	private float  arc = 20f;
    private float level = 0f;
	private boolean firstStrike = false;
	private boolean firstTrail = false;
	private float id;
	private float id2;
	private boolean runOnce = false;
	private WeaponAPI weapon;
	private List<CombatEntityAPI> targets = new ArrayList<CombatEntityAPI>();
	private List<CombatEntityAPI> hitTargets = new ArrayList<CombatEntityAPI>();
	
	public void advance(float amount, CombatEngineAPI engine, BeamAPI beam) {
		
		if(!runOnce)
		{
			id = MagicTrailPlugin.getUniqueID();
			id2 = MagicTrailPlugin.getUniqueID();
			runOnce = true;
		}
		weapon = beam.getWeapon();
		beam.getDamage().setDamage(0);
		CombatEntityAPI target = beam.getDamageTarget();
		if(!targets.contains(target))
		{
			targets.add(target);
		}

		Vector2f spawnPoint = MathUtils.getRandomPointOnLine(beam.getFrom(), beam.getTo());
	
			if(weapon.isFiring())
			{
				if(Math.random() >= 0.75f && beam.getBrightness() >= 0.8f)
				for (int x = 0; x < 2; x++) 
				{
					engine.addHitParticle(beam.getFrom(),
							MathUtils.getPointOnCircumference(weapon.getShip().getVelocity(), MathUtils.getRandomNumberInRange(100f, 150f), 
							MathUtils.getRandomNumberInRange(weapon.getCurrAngle() -30f,weapon.getCurrAngle()+30f)),
							5f, 1f, MathUtils.getRandomNumberInRange(0.1f, 0.6f), beam.getFringeColor());
				}
				for(CombatEntityAPI enemy:targets)
				{
					if(enemy == beam.getDamageTarget())
					{
						if(hitTargets.contains(beam.getDamageTarget()))
						{
							continue;
						}
						
						else
						{
							boolean softFlux = 	true;
							
							if(weapon.getDamage().isForceHardFlux() || weapon.getShip().getVariant().getHullMods().contains("high_scatter_amp"))
							{
								softFlux = false;
							}

							float dmg = weapon.getDamage().getDamage()*weapon.getSpec().getBurstDuration();
							
							float mag = weapon.getShip().getFluxBasedEnergyWeaponDamageMultiplier() - 1f;
							if(mag > 0)
								dmg = dmg*(1+mag);
							
							engine.applyDamage(enemy, beam.getTo(),dmg,weapon.getDamageType(), dmg, false, softFlux, weapon.getShip()); 
							hitTargets.add(enemy);
							if (enemy instanceof ShipAPI)
							{
								ShipAPI empTarget = (ShipAPI)enemy;
								for(int i = 0; i < 2; i++)
								{
								EmpArcEntityAPI arc =  engine.spawnEmpArc(weapon.getShip(), beam.getTo(), empTarget, empTarget,
									DamageType.ENERGY, 0f, 0f, beam.getLength()/2, null, 10f, beam.getFringeColor(), beam.getCoreColor());
								}
							}
						}
					}
				}

				fireInterval.advance(amount);

				if(fireInterval.intervalElapsed() && beam.getBrightness() == 1f)
				{
					float angle = weapon.getCurrAngle()-90f;
					if(weapon.getSpec().getWeaponId().equals("armaa_aleste_blade_RightArm"))
					{
						//id = 1;
						angle = weapon.getCurrAngle()+90f;
					}			
					if(MagicRender.screenCheck(0.2f, beam.getFrom()))
					{					
						MagicTrailPlugin.AddTrailMemberAdvanced(
									weapon.getShip(), id2, Global.getSettings().getSprite("fx","base_trail_smooth"),
									beam.getTo(), 
									 100f, 
									 50f,
									angle, 
									weapon.getShip().getAngularVelocity(), 
									0f,
									beam.getLength()/3, beam.getLength()/3,
									beam.getCoreColor(), beam.getFringeColor(), .7f,
									.1f, .2f, 0f,
									true,
									300f, -256f, 0f,
									null, null,null,2f);
					}
				}				
			}
			
		if (target instanceof CombatEntityAPI) {
			float dur = beam.getDamage().getDpsDuration();

			if (!firstStrike)
			{
				Vector2f point = beam.getTo();
				float variance = MathUtils.getRandomNumberInRange(-0.3f, .3f);
				Global.getSoundPlayer().playSound("armaa_saber_slash",1f+variance,1f+variance,point,ZERO);
				firstStrike = true;
				CombatUtils.applyForce(weapon.getShip(), weapon.getShip().getFacing()-180f, Math.min(target.getMass(),BLADE_KNOCKBACK_MAX));
			}
			if(fireInterval.intervalElapsed() && beam.getBrightness() >= .9f)
			{
			}

			float shipFacing = weapon.getCurrAngle();
			Vector2f shipVelocity = weapon.getShip().getVelocity();
			Vector2f dir = Vector2f.sub(beam.getTo(), beam.getFrom(), new Vector2f());
			if (dir.lengthSquared() > 0) dir.normalise();
			dir.scale(50f);
			Vector2f point = Vector2f.sub(beam.getTo(), dir, new Vector2f());
			if(MagicRender.screenCheck(0.2f, point))
			{
				if(weapon.isFiring() && weapon.getChargeLevel() > 0f && weapon.getChargeLevel() < 1f || weapon.getChargeLevel() == 1f)
				{
					float radius = 10f + (weapon.getChargeLevel() * weapon.getChargeLevel()* MathUtils.getRandomNumberInRange(25f, 75f));
					Color color = beam.getFringeColor();
					Color core = beam.getCoreColor();

					
					float speed = 500f;
					float facing = beam.getWeapon().getCurrAngle();
				
					for (int i = 0; i <= PARTICLE_COUNT; i++)
					{
						float angle = MathUtils.getRandomNumberInRange(facing - A_2,
								facing + A_2);
						float vel = MathUtils.getRandomNumberInRange(speed * -VEL_MIN,
								speed * -VEL_MAX);
						Vector2f vector = MathUtils.getPointOnCircumference(null,
								vel,
								angle);
						engine.addHitParticle(beam.getTo(),
								vector,
								PARTICLE_SIZE,
								PARTICLE_BRIGHTNESS,
								PARTICLE_DURATION,
								PARTICLE_COLOR);
					}
					if((float) Math.random() <= 0.10f)
					{
						MagicLensFlare.createSharpFlare(
							engine,
							beam.getSource(),
							beam.getTo(),
							4,
							150,
							beam.getWeapon().getCurrAngle(),
							color,
							core
						);
					}
					
					if((float) Math.random() <= 0.15f)
					engine.addSmoothParticle(beam.getTo(), ZERO, radius, 0.1f+ weapon.getChargeLevel()* 0.25f, 0.1f, color);
					engine.addHitParticle(beam.getTo(), ZERO, radius*.70f, 0.1f + weapon.getChargeLevel()* 0.1f, 0.1f, core);					
				}
			}
		}
	}
}
