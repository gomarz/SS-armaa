package data.scripts.world;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.campaign.FactionAPI;
import com.fs.starfarer.api.campaign.SectorAPI;
import com.fs.starfarer.api.campaign.SectorEntityToken;
import com.fs.starfarer.api.campaign.SectorGeneratorPlugin;
import com.fs.starfarer.api.campaign.econ.EconomyAPI;
import com.fs.starfarer.api.campaign.econ.MarketAPI;
import com.fs.starfarer.api.impl.campaign.ids.Factions;
import com.fs.starfarer.api.impl.campaign.shared.SharedData;
import data.scripts.world.systems.armaa_K;
import data.scripts.world.systems.armaa_nekki;
import java.util.ArrayList;

public class ARMAAWorldGen implements SectorGeneratorPlugin {
    //Shorthand function for adding a market, just copy it
    public static MarketAPI addMarketplace(String factionID, SectorEntityToken primaryEntity, ArrayList<SectorEntityToken> connectedEntities, String name,
                                           int size, ArrayList<String> marketConditions, ArrayList<String> submarkets, ArrayList<String> industries, float tarrif,
                                           boolean freePort, boolean withJunkAndChatter) {
        EconomyAPI globalEconomy = Global.getSector().getEconomy();
        String planetID = primaryEntity.getId();
        String marketID = planetID + "_market";

        MarketAPI newMarket = Global.getFactory().createMarket(marketID, name, size);
        newMarket.setFactionId(factionID);
        newMarket.setPrimaryEntity(primaryEntity);
        newMarket.getTariff().modifyFlat("generator", tarrif);

        //Adds submarkets
        if (null != submarkets) {
            for (String market : submarkets) {
                newMarket.addSubmarket(market);
            }
        }

        //Adds market conditions
        for (String condition : marketConditions) {
            newMarket.addCondition(condition);
        }

        //Add market industries
        for (String industry : industries) {
            newMarket.addIndustry(industry);
        }

        //Sets us to a free port, if we should
        newMarket.setFreePort(freePort);

        //Adds our connected entities, if any
        if (null != connectedEntities) {
            for (SectorEntityToken entity : connectedEntities) {
                newMarket.getConnectedEntities().add(entity);
            }
        }

        globalEconomy.addMarket(newMarket, withJunkAndChatter);
        primaryEntity.setMarket(newMarket);
        primaryEntity.setFaction(factionID);

        if (null != connectedEntities) {
            for (SectorEntityToken entity : connectedEntities) {
                entity.setMarket(newMarket);
                entity.setFaction(factionID);
            }
        }

        //Finally, return the newly-generated market
        return newMarket;
    }

    @Override
    public void generate(SectorAPI sector) {
        FactionAPI cmc = sector.getFaction("armaarmatura");
        //Generate your system
        new armaa_K().generate(sector);
        new armaa_nekki().generate(sector);
        //Add faction to bounty system
        //SharedData.getData().getPersonBountyEventData().addParticipatingFaction("cmc");
        //set relationship
        cmc.setRelationship(Factions.LUDDIC_CHURCH, -0.35f);
        cmc.setRelationship(Factions.LUDDIC_PATH, -0.51f);
        cmc.setRelationship(Factions.PERSEAN, 0.2f);
		cmc.setRelationship(Factions.INDEPENDENT, 0.55f);
        cmc.setRelationship(Factions.PIRATES, -0.55f);
		cmc.setRelationship(Factions.TRITACHYON, -0.45f);
		cmc.setRelationship(Factions.REMNANTS, -0.55f);
		
		cmc = sector.getFaction("armaarmatura_pirates");
		for(FactionAPI fac : sector.getAllFactions())
		{
			cmc.setRelationship(fac.getId(),-0.45f);
		}
        cmc.setRelationship(Factions.LUDDIC_CHURCH, -0.55f);
        cmc.setRelationship(Factions.LUDDIC_PATH, -0.35f);
        cmc.setRelationship(Factions.PERSEAN, -0.55f);
		cmc.setRelationship(Factions.INDEPENDENT, -0.45f);
        cmc.setRelationship(Factions.PIRATES, 0.12f);
		cmc.setRelationship(Factions.TRITACHYON, -0.45f);
		cmc.setRelationship(Factions.REMNANTS, -0.55f);
		cmc.setRelationship(Factions.DIKTAT, -1.00f);
		cmc.setRelationship(Factions.DERELICT, -0.55f);
		cmc.setRelationship(Factions.HEGEMONY, -0.55f);
		cmc.setRelationship("tahlan_legioinfernalis", 0f);

    }
}
