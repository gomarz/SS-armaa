package data.hullmods;

import com.fs.starfarer.api.Global;
import com.fs.starfarer.api.combat.*;
import com.fs.starfarer.api.combat.ShipEngineControllerAPI.ShipEngineAPI;
import com.fs.starfarer.api.combat.ShipwideAIFlags.AIFlags;
import data.scripts.util.MagicIncompatibleHullmods;
import data.scripts.util.MagicUI;
import com.fs.starfarer.api.combat.MutableShipStatsAPI;
import org.lazywizard.lazylib.FastTrig;
import org.lwjgl.util.vector.Vector2f;
import data.scripts.util.MagicRender;
import com.fs.starfarer.api.graphics.SpriteAPI;
import java.awt.*;
import java.util.*; 
import java.util.List;
import java.util.Collection;
//import java.util.Set;
import org.apache.log4j.Logger;

public class armaa_KarmaMod2 extends BaseHullMod {

protected float karma = 0;
private static final float BONUS_AMT = 30f;
protected static int karmaThreshold = 2000;
private static final Color AFTERIMAGE_COLOR = new Color(149, 206, 240, 102);
private static final float AFTERIMAGE_THRESHOLD = 0.4f;
private static final List<String> SAFE_MODS = new ArrayList<>();

    static 
	{
        /* don't ever remove these */
        SAFE_MODS.add("armaa_legmodule");
        SAFE_MODS.add("reduced_explosion");
		SAFE_MODS.add("always_detaches");
        SAFE_MODS.add("novent");
        SAFE_MODS.add("leg_engine");
	}


    @Override
    public void advanceInCombat(ShipAPI ship, float amount) {
		
		if(!(Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?"+ship.getId()) instanceof Boolean))
		{
			//boolean value = (boolean)Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?"+ship.getId());
		
			//Global.getCombatEngine().maintainStatusForPlayerShip(ship.getId(), "graphics/icons/hullsys/entropy_amplifier.png","DEBUG",(Boolean.toString(value)), false);
		Global.getCombatEngine().getCustomData().put("armaa_hullmodsDone?"+ship.getId(),false);

		}
		
		if(Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?"+ship.getId()) instanceof Boolean)
		{
			//if((boolean)Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?"+ship.getId()) != true)
			//Global.getCombatEngine().maintainStatusForPlayerShip(ship.getId(), "graphics/icons/hullsys/entropy_amplifier.png","DEBUG","TRUE", false);	
			if((boolean)Global.getCombatEngine().getCustomData().get("armaa_hullmodsDone?"+ship.getId()) != true)
			{
				List<ShipAPI> children = ship.getChildModulesCopy();
				if(children != null && !children.isEmpty()) 
				{
					for (ShipAPI module : children) 
					{
						module.ensureClonedStationSlotSpec();

						Collection<String> hmods = ship.getVariant().getHullMods();
						List<String> hmod = new ArrayList<>();
						hmod.addAll(hmods);
						
						Collection<String> mhmods = module.getVariant().getHullMods();
						List<String> mhmod = new ArrayList<>();
						mhmod.addAll(mhmods);
						mhmod.removeAll(SAFE_MODS);


						if(hmods.isEmpty())
							continue;
						for(int i = 0; i < hmod.size();i++)
						{
							if(!module.getVariant().hasHullMod(hmod.get(i)))
							{
								module.getVariant().addMod(hmod.get(i));
							}
						}
						if(mhmod.isEmpty())
							continue;
						for(int i = 0; i < mhmod.size();i++)
						{
							if(!ship.getVariant().hasHullMod(mhmod.get(i)))
							{
								module.getVariant().removeMod(mhmod.get(i));
							}
						}
					}
					Global.getCombatEngine().getCustomData().put("armaa_hullmodsDone?"+ship.getId(),true);
					Global.getCombatEngine().getCustomData().put("armaa_hullmodsDoneCheck"+ship.getId(),true);
				}
			}
		
		}
		
	}

}
